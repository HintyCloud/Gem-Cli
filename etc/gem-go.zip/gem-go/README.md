# Gem CLI - Go Implementation

> A complete Go implementation of the Gem agentic AI ecosystem.

## About

Gem is an agentic AI ecosystem for development, automation, research, and task execution. This Go implementation provides the same CLI interface as the Python version with native performance and single-binary distribution.

## Build

```bash
cd gem-go
go mod tidy
go build -o gem .
```

## Cross-Compilation

```bash
# Linux
GOOS=linux GOARCH=amd64 go build -o gem-linux-amd64 .
GOOS=linux GOARCH=arm64 go build -o gem-linux-arm64 .

# macOS
GOOS=darwin GOARCH=amd64 go build -o gem-macos-amd64 .
GOOS=darwin GOARCH=arm64 go build -o gem-macos-arm64 .

# Windows
GOOS=windows GOARCH=amd64 go build -o gem-windows-amd64.exe .
GOOS=windows GOARCH=arm64 go build -o gem-windows-arm64.exe .
```

## Usage

```bash
gem status           # Show system status
gem serve            # Start API server
gem chat             # Interactive chat
gem project list     # List projects
gem project create myapp  # Create project
gem jobs             # List background jobs
gem models           # Show configured model
gem providers        # List providers
gem tools            # List tools
gem agents           # List agent profiles
```

## Sobre (Português)

Gem é um ecossistema de IA agêntico para desenvolvimento, automação, pesquisa e execução de tarefas. Esta implementação em Go fornece a mesma interface CLI da versão Python com performance nativa e distribuição em binário único.

## License

GPL-3.0 - HintyCloud
