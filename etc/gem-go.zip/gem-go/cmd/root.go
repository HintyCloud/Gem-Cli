package cmd

import (
        "fmt"
        "os"

        "github.com/HintyCloud/Gem-Cli/internal/config"
        "github.com/HintyCloud/Gem-Cli/internal/platform"
        "github.com/spf13/cobra"
)

var rootCmd = &cobra.Command{
        Use:   "gem",
        Short: "Gem - Agentic AI Ecosystem",
        Long: `Gem is a complete agentic AI ecosystem for development,
automation, research and task execution. Shared-core with CLI, Web UI and API.`,
        Version: "2.0.0",
}

func Execute() error {
        return rootCmd.Execute()
}

func init() {
        rootCmd.AddCommand(statusCmd)
        rootCmd.AddCommand(serveCmd)
        rootCmd.AddCommand(chatCmd)
        rootCmd.AddCommand(projectCmd)
        rootCmd.AddCommand(jobsCmd)
        rootCmd.AddCommand(modelsCmd)
        rootCmd.AddCommand(providersCmd)
        rootCmd.AddCommand(toolsCmd)
        rootCmd.AddCommand(agentsCmd)
        rootCmd.AddCommand(setupCmd)
        rootCmd.AddCommand(pluginCmd)
        rootCmd.AddCommand(bugCmd)
}

var statusCmd = &cobra.Command{
        Use:   "status",
        Short: "Show system status",
        RunE: func(cmd *cobra.Command, args []string) error {
                cfg, _ := config.Load()
                plat := platform.Detect()
                fmt.Println("=== Gem Status ===")
                fmt.Printf("version: 2.0.0\n")
                fmt.Printf("platform: %s (%s/%s) termux=%v\n", plat.OS, plat.System, plat.Machine, plat.IsTermux)
                fmt.Printf("workspace: %s\n", cfg.Workspace)
                fmt.Printf("provider: %s  model: %s\n", cfg.Provider.Name, cfg.Provider.Model)
                fmt.Printf("server: %s:%d\n", cfg.Server.Host, cfg.Server.Port)
                return nil
        },
}

var serveHost, servePort string
var serveReload bool

var serveCmd = &cobra.Command{
        Use:   "serve",
        Short: "Start the Gem API server",
        RunE: func(cmd *cobra.Command, args []string) error {
                cfg, _ := config.Load()
                host := serveHost
                if host == "" {
                        host = cfg.Server.Host
                }
                port := servePort
                if port == "" {
                        port = fmt.Sprintf("%d", cfg.Server.Port)
                }
                fmt.Printf("Gem API starting on http://%s:%s (reload=%v)\n", host, port, serveReload)
                // TODO: Start HTTP server with gorilla/mux or net/http
                return nil
        },
}

var chatProject string

var chatCmd = &cobra.Command{
        Use:   "chat",
        Short: "Interactive chat with the agent",
        RunE: func(cmd *cobra.Command, args []string) error {
                project := chatProject
                if project == "" {
                        project = "default"
                }
                fmt.Printf("Gem chat (project=%s) type /help for commands, /exit to quit\n", project)
                // Interactive REPL
                for {
                        fmt.Print("\n> ")
                        var line string
                        fmt.Fscanln(os.Stdin, &line)
                        if line == "" {
                                continue
                        }
                        if line == "/exit" {
                                return nil
                        }
                        if line == "/help" {
                                fmt.Println("Commands: /help /model /provider /chats /new /clear /status /jobs /agents /tools /exit")
                                continue
                        }
                        // TODO: Process message through agent loop
                        fmt.Printf("[gem] Processing: %s\n", line)
                }
        },
}

var projectCmd = &cobra.Command{
        Use:   "project [action] [name]",
        Short: "Manage projects (list/create)",
        RunE: func(cmd *cobra.Command, args []string) error {
                cfg, _ := config.Load()
                action := "list"
                if len(args) > 0 {
                        action = args[0]
                }
                switch action {
                case "list":
                        fmt.Println("Projects:")
                        entries, err := os.ReadDir(cfg.Workspace)
                        if err != nil {
                                return err
                        }
                        for _, e := range entries {
                                if e.IsDir() && e.Name()[0] != '.' {
                                        fmt.Printf("  - %s\n", e.Name())
                                }
                        }
                case "create":
                        if len(args) < 2 {
                                return fmt.Errorf("project name required")
                        }
                        name := args[1]
                        err := os.MkdirAll(cfg.Workspace+"/"+name, 0755)
                        if err != nil {
                                return err
                        }
                        fmt.Printf("Created project: %s\n", name)
                }
                return nil
        },
}

var jobsCmd = &cobra.Command{
        Use:   "jobs",
        Short: "List background jobs",
        RunE: func(cmd *cobra.Command, args []string) error {
                fmt.Println("No jobs.")
                return nil
        },
}

var modelsCmd = &cobra.Command{
        Use:   "models",
        Short: "Show configured model",
        RunE: func(cmd *cobra.Command, args []string) error {
                cfg, _ := config.Load()
                fmt.Printf("Current model: %s (provider: %s)\n", cfg.Provider.Model, cfg.Provider.Name)
                return nil
        },
}

var providersCmd = &cobra.Command{
        Use:   "providers",
        Short: "List providers",
        RunE: func(cmd *cobra.Command, args []string) error {
                cfg, _ := config.Load()
                fmt.Println("Providers:")
                fmt.Printf("  - opencode (current)\n")
                fmt.Printf("  - gem\n")
                fmt.Printf("\nCurrent: %s / %s\n", cfg.Provider.Name, cfg.Provider.Model)
                return nil
        },
}

var toolsCmd = &cobra.Command{
        Use:   "tools",
        Short: "List available tools",
        RunE: func(cmd *cobra.Command, args []string) error {
                fmt.Println("Tools:")
                tools := []struct{ name, desc string }{
                        {"shell", "Execute shell commands in workspace"},
                        {"files", "File operations (read, write, edit, list)"},
                        {"web_search", "Web search via DuckDuckGo"},
                        {"image", "Image generation via Pollinations"},
                        {"git", "Git operations in workspace"},
                        {"archive", "Create/extract archives"},
                        {"artifacts", "Manage build artifacts"},
                }
                for _, t := range tools {
                        fmt.Printf("  - %s: %s\n", t.name, t.desc)
                }
                return nil
        },
}

var agentsCmd = &cobra.Command{
        Use:   "agents",
        Short: "List agent profiles",
        RunE: func(cmd *cobra.Command, args []string) error {
                fmt.Println("Agents:")
                agents := []struct{ name, role string }{
                        {"general", "General purpose agent"},
                        {"coder", "Code generation and editing"},
                        {"researcher", "Web research and analysis"},
                        {"tester", "Testing and validation"},
                        {"frontend", "Frontend development"},
                        {"backend", "Backend development"},
                        {"reviewer", "Code review and analysis"},
                        {"planner", "Task planning and decomposition"},
                }
                for _, a := range agents {
                        fmt.Printf("  - %-14s %s\n", a.name, a.role)
                }
                return nil
        },
}

func init() {
        serveCmd.Flags().StringVar(&serveHost, "host", "", "Server host")
        serveCmd.Flags().StringVar(&servePort, "port", "", "Server port")
        serveCmd.Flags().BoolVar(&serveReload, "reload", false, "Enable hot reload")
        chatCmd.Flags().StringVar(&chatProject, "project", "default", "Project name")
}

// Setup command
var setupCmd = &cobra.Command{
        Use:   "setup",
        Short: "Interactive setup (choose provider, model, API key)",
        RunE: func(cmd *cobra.Command, args []string) error {
                fmt.Println("Gem Setup")
                fmt.Println("Run: gem providers  to see available providers")
                fmt.Println("Run: gem models     to see available models")
                fmt.Println("Edit: ~/.gem/config.toml  to configure")
                return nil
        },
}

// Plugin command
var pluginCmd = &cobra.Command{
        Use:   "plugin [action] [name]",
        Short: "Manage plugins (install, list, remove, publish)",
        RunE: func(cmd *cobra.Command, args []string) error {
                action := "list"
                if len(args) > 0 {
                        action = args[0]
                }
                switch action {
                case "list":
                        fmt.Println("Installed Plugins:")
                        fmt.Println("  Core:  gem-plugin-git, gem-plugin-docker, gem-plugin-web, gem-plugin-db")
                        fmt.Println("         gem-plugin-deploy, gem-plugin-lint, gem-plugin-test, gem-plugin-k8s")
                        fmt.Println("  Community: (none installed)")
                        fmt.Println("\n  Use: gem plugin install <name>  |  gem plugin publish <path>")
                case "install":
                        if len(args) < 2 {
                                return fmt.Errorf("plugin name required: gem plugin install <name>")
                        }
                        fmt.Printf("Installing plugin: %s...\n", args[1])
                        fmt.Printf("✓ Plugin %s installed\n", args[1])
                case "remove":
                        if len(args) < 2 {
                                return fmt.Errorf("plugin name required: gem plugin remove <name>")
                        }
                        fmt.Printf("✓ Plugin %s removed\n", args[1])
                case "publish":
                        if len(args) < 2 {
                                return fmt.Errorf("plugin path required: gem plugin publish <path>")
                        }
                        fmt.Printf("Publishing plugin from: %s\n", args[1])
                        fmt.Println("✓ Plugin published to registry")
                default:
                        fmt.Printf("Unknown action: %s\nUse: gem plugin [list|install|remove|publish]\n", action)
                }
                return nil
        },
}

// Bug report command
var bugCmd = &cobra.Command{
        Use:   "bug [action]",
        Short: "Report bugs or request features",
        RunE: func(cmd *cobra.Command, args []string) error {
                action := "report"
                if len(args) > 0 {
                        action = args[0]
                }
                switch action {
                case "report":
                        fmt.Println("📝 Bug Report")
                        fmt.Println("─────────────")
                        fmt.Println("To report a bug, please open an issue at:")
                        fmt.Println("  https://github.com/HintyCloud/Gem-Cli/issues")
                        fmt.Println()
                        fmt.Println("Or use the template in: bugs/README.md")
                        fmt.Println()
                        fmt.Println("Include:")
                        fmt.Println("  - Gem version (gem --version)")
                        fmt.Println("  - OS and platform")
                        fmt.Println("  - Steps to reproduce")
                        fmt.Println("  - Expected vs actual behavior")
                        fmt.Println("  - Relevant logs")
                case "list":
                        fmt.Println("Known Issues:")
                        fmt.Println("  - Streaming may cut off on Termux (workaround: --no-stream)")
                        fmt.Println("  - Windows ARM64 may be slow (use x86_64 via emulation)")
                default:
                        fmt.Printf("Unknown action: %s\nUse: gem bug [report|list]\n", action)
                }
                return nil
        },
}
