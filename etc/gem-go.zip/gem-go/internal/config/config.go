package config

import (
        "os"
        "path/filepath"

        "github.com/BurntSushi/toml"
)

type ProviderConfig struct {
        Name        string  `toml:"name"`
        Model       string  `toml:"model"`
        BaseURL     string  `toml:"base_url"`
        APIKey      string  `toml:"api_key"`
        Temperature float64 `toml:"temperature"`
        MaxTokens   int     `toml:"max_tokens"`
}

type AgentConfig struct {
        MaxIterations    int `toml:"max_iterations"`
        CommandTimeout   int `toml:"command_timeout"`
        AutoContinue     bool `toml:"auto_continue"`
        ContextTokenBudget int `toml:"context_token_budget"`
}

type ServerConfig struct {
        Host string `toml:"host"`
        Port int    `toml:"port"`
}

type SwarmConfig struct {
        MaxAgents    int `toml:"max_agents"`
        AgentTimeout int `toml:"agent_timeout"`
}

type JobsConfig struct {
        MaxConcurrent     int `toml:"max_concurrent"`
        CheckpointInterval int `toml:"checkpoint_interval"`
}

type Config struct {
        Workspace string         `toml:"workspace"`
        DataDir   string         `toml:"data_dir"`
        Provider  ProviderConfig `toml:"provider"`
        Agent     AgentConfig    `toml:"agent"`
        Server    ServerConfig   `toml:"server"`
        Swarm     SwarmConfig    `toml:"swarm"`
        Jobs      JobsConfig     `toml:"jobs"`
}

func defaults() Config {
        return Config{
                Workspace: "./projects",
                DataDir:   "./data",
                Provider: ProviderConfig{
                        Name:        "openrouter",
                        Model:       "nvidia/nemotron-3-super-120b-a12b:free",
                        BaseURL:     "https://openrouter.ai/api/v1",
                        APIKey:      "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",
                        Temperature: 0.3,
                        MaxTokens:   4096,
                },
                Agent: AgentConfig{
                        MaxIterations:      50,
                        CommandTimeout:     120,
                        AutoContinue:       true,
                        ContextTokenBudget: 24000,
                },
                Server: ServerConfig{Host: "127.0.0.1", Port: 8000},
                Swarm:  SwarmConfig{MaxAgents: 4, AgentTimeout: 300},
                Jobs:   JobsConfig{MaxConcurrent: 2, CheckpointInterval: 5},
        }
}

func Load() (Config, error) {
        cfg := defaults()
        configPath := "config/config.toml"
        if _, err := os.Stat(configPath); err == nil {
                if _, err := toml.DecodeFile(configPath, &cfg); err != nil {
                        return cfg, err
                }
        }
        // Override API key from env (check multiple env vars in priority order)
        if key := os.Getenv("OPENCODE_API_KEY"); key != "" {
                cfg.Provider.APIKey = key
        }
        if key := os.Getenv("GEM_API_KEY"); key != "" {
                cfg.Provider.APIKey = key
        }
        if key := os.Getenv("OPENROUTER_API_KEY"); key != "" {
                cfg.Provider.APIKey = key
        }
        // Make paths absolute
        if !filepath.IsAbs(cfg.Workspace) {
                cfg.Workspace, _ = filepath.Abs(cfg.Workspace)
        }
        if !filepath.IsAbs(cfg.DataDir) {
                cfg.DataDir, _ = filepath.Abs(cfg.DataDir)
        }
        return cfg, nil
}
