package tools

import (
	"context"
	"fmt"
)

// Tool is the interface for all Gem tools.
type Tool interface {
	Name() string
	Description() string
	Run(ctx context.Context, args map[string]interface{}) (string, error)
}

// Registry manages available tools.
type Registry struct {
	tools map[string]Tool
}

func NewRegistry() *Registry {
	return &Registry{tools: make(map[string]Tool)}
}

func (r *Registry) Register(t Tool) {
	r.tools[t.Name()] = t
}

func (r *Registry) Get(name string) (Tool, bool) {
	t, ok := r.tools[name]
	return t, ok
}

func (r *Registry) All() []Tool {
	result := make([]Tool, 0, len(r.tools))
	for _, t := range r.tools {
		result = append(result, t)
	}
	return result
}

func (r *Registry) Execute(ctx context.Context, name string, args map[string]interface{}) (string, error) {
	t, ok := r.tools[name]
	if !ok {
		return "", fmt.Errorf("tool not found: %s", name)
	}
	return t.Run(ctx, args)
}

// --- Built-in tool stubs ---

type ShellTool struct{ Workspace string }
func (s *ShellTool) Name() string    { return "shell" }
func (s *ShellTool) Description() string { return "Execute shell commands in workspace" }
func (s *ShellTool) Run(ctx context.Context, args map[string]interface{}) (string, error) {
	cmd, _ := args["command"].(string)
	return fmt.Sprintf("shell: %s (workspace: %s)", cmd, s.Workspace), nil
}

type FilesTool struct{ Workspace string }
func (f *FilesTool) Name() string    { return "files" }
func (f *FilesTool) Description() string { return "File operations (read, write, edit, list)" }
func (f *FilesTool) Run(ctx context.Context, args map[string]interface{}) (string, error) {
	action, _ := args["action"].(string)
	path, _ := args["path"].(string)
	return fmt.Sprintf("files %s: %s", action, path), nil
}

type WebTool struct{}
func (w *WebTool) Name() string    { return "web_search" }
func (w *WebTool) Description() string { return "Web search via DuckDuckGo" }
func (w *WebTool) Run(ctx context.Context, args map[string]interface{}) (string, error) {
	query, _ := args["query"].(string)
	return fmt.Sprintf("web_search: %s", query), nil
}

type ImageTool struct{}
func (i *ImageTool) Name() string    { return "image" }
func (i *ImageTool) Description() string { return "Image generation via Pollinations" }
func (i *ImageTool) Run(ctx context.Context, args map[string]interface{}) (string, error) {
	prompt, _ := args["prompt"].(string)
	return fmt.Sprintf("image generated: %s", prompt), nil
}

type GitTool struct{ Workspace string }
func (g *GitTool) Name() string    { return "git" }
func (g *GitTool) Description() string { return "Git operations in workspace" }
func (g *GitTool) Run(ctx context.Context, args map[string]interface{}) (string, error) {
	gitArgs, _ := args["args"].(string)
	return fmt.Sprintf("git %s", gitArgs), nil
}

type ArchiveTool struct{ Workspace string }
func (a *ArchiveTool) Name() string    { return "archive" }
func (a *ArchiveTool) Description() string { return "Create/extract archives" }
func (a *ArchiveTool) Run(ctx context.Context, args map[string]interface{}) (string, error) {
	return "archive operation", nil
}

type ArtifactsTool struct{}
func (a *ArtifactsTool) Name() string    { return "artifacts" }
func (a *ArtifactsTool) Description() string { return "Manage build artifacts" }
func (a *ArtifactsTool) Run(ctx context.Context, args map[string]interface{}) (string, error) {
	return "artifacts operation", nil
}
