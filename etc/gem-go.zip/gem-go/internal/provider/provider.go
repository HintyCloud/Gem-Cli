package provider

import (
        "bytes"
        "context"
        "encoding/json"
        "fmt"
        "io"
        "net/http"
        "time"
)

// Message represents a chat message.
type Message struct {
        Role    string `json:"role"`
        Content string `json:"content"`
}

// GenerateResult is the output from a provider.
type GenerateResult struct {
        Content      string `json:"content"`
        FinishReason string `json:"finish_reason"`
}

// Provider is the interface for LLM providers.
type Provider interface {
        Generate(ctx context.Context, messages []Message, system string) (*GenerateResult, error)
        IsConfigured() bool
        Name() string
}

// OpenCodeProvider implements Provider for the OpenCode API.
type OpenCodeProvider struct {
        Model   string
        APIKey  string
        BaseURL string
        Client  *http.Client
}

func NewOpenCodeProvider(model, apiKey, baseURL string) *OpenCodeProvider {
        if baseURL == "" {
                baseURL = "https://openrouter.ai/api/v1"
        }
        return &OpenCodeProvider{
                Model:   model,
                APIKey:  apiKey,
                BaseURL: baseURL,
                Client:  &http.Client{Timeout: 120 * time.Second},
        }
}

func (p *OpenCodeProvider) Name() string    { return "opencode" }
func (p *OpenCodeProvider) IsConfigured() bool { return p.APIKey != "" }

func (p *OpenCodeProvider) Generate(ctx context.Context, messages []Message, system string) (*GenerateResult, error) {
        if !p.IsConfigured() {
                return nil, fmt.Errorf("provider not configured: set OPENCODE_API_KEY")
        }

        // Build OpenAI-compatible request
        allMsgs := []Message{}
        if system != "" {
                allMsgs = append(allMsgs, Message{Role: "system", Content: system})
        }
        allMsgs = append(allMsgs, messages...)

        body := map[string]interface{}{
                "model":    p.Model,
                "messages": allMsgs,
        }
        jsonBody, _ := json.Marshal(body)

        url := p.BaseURL + "/chat/completions"
        req, err := http.NewRequestWithContext(ctx, "POST", url, bytes.NewReader(jsonBody))
        if err != nil {
                return nil, err
        }
        req.Header.Set("Content-Type", "application/json")
        req.Header.Set("Authorization", "Bearer "+p.APIKey)
        req.Header.Set("HTTP-Referer", "https://gem.sh")
        req.Header.Set("X-Title", "Gem-CLI")

        resp, err := p.Client.Do(req)
        if err != nil {
                return nil, err
        }
        defer resp.Body.Close()

        data, _ := io.ReadAll(resp.Body)
        var result map[string]interface{}
        json.Unmarshal(data, &result)

        choices, _ := result["choices"].([]interface{})
        if len(choices) > 0 {
                choice := choices[0].(map[string]interface{})
                msg := choice["message"].(map[string]interface{})
                content, _ := msg["content"].(string)
                return &GenerateResult{Content: content, FinishReason: "stop"}, nil
        }

        return &GenerateResult{Content: "", FinishReason: "error"}, nil
}
