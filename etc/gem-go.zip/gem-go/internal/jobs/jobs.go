package jobs

import (
	"context"
	"fmt"
	"sync"
	"time"
)

// Status represents a job's lifecycle state.
type Status string

const (
	Queued     Status = "queued"
	Running    Status = "running"
	Completed  Status = "completed"
	Failed     Status = "failed"
	Cancelled  Status = "cancelled"
	Paused     Status = "paused"
)

// Job represents a background job.
type Job struct {
	ID        string    `json:"id"`
	Task      string    `json:"task"`
	Project   string    `json:"project"`
	Status    Status    `json:"status"`
	CreatedAt time.Time `json:"created_at"`
	StartedAt *time.Time `json:"started_at,omitempty"`
	EndedAt   *time.Time `json:"ended_at,omitempty"`
	Result    string    `json:"result,omitempty"`
	Error     string    `json:"error,omitempty"`
}

// Manager manages background jobs.
type Manager struct {
	jobs    map[string]*Job
	queue   chan string
	mu      sync.Mutex
	maxConc int
}

func NewManager(maxConcurrent int) *Manager {
	if maxConcurrent == 0 {
		maxConcurrent = 2
	}
	return &Manager{
		jobs:    make(map[string]*Job),
		queue:   make(chan string, 100),
		maxConc: maxConcurrent,
	}
}

func (m *Manager) Create(task, project string) *Job {
	m.mu.Lock()
	defer m.mu.Unlock()
	job := &Job{
		ID:        fmt.Sprintf("job-%d", time.Now().UnixNano()),
		Task:      task,
		Project:   project,
		Status:    Queued,
		CreatedAt: time.Now(),
	}
	m.jobs[job.ID] = job
	return job
}

func (m *Manager) List() []*Job {
	m.mu.Lock()
	defer m.mu.Unlock()
	result := make([]*Job, 0, len(m.jobs))
	for _, j := range m.jobs {
		result = append(result, j)
	}
	return result
}

func (m *Manager) Get(id string) (*Job, bool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	j, ok := m.jobs[id]
	return j, ok
}

func (m *Manager) Cancel(id string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	j, ok := m.jobs[id]
	if !ok {
		return fmt.Errorf("job not found: %s", id)
	}
	j.Status = Cancelled
	return nil
}

// Run executes a job (simplified).
func (m *Manager) Run(ctx context.Context, job *Job, execute func() (string, error)) {
	now := time.Now()
	job.Status = Running
	job.StartedAt = &now

	result, err := execute()
	now = time.Now()
	job.EndedAt = &now
	if err != nil {
		job.Status = Failed
		job.Error = err.Error()
	} else {
		job.Status = Completed
		job.Result = result
	}
}
