package agent

import (
        "context"

        "github.com/HintyCloud/Gem-Cli/internal/provider"
        "github.com/HintyCloud/Gem-Cli/internal/tools"
)

// Loop implements the think/act/observe agent cycle.
type Loop struct {
        Provider      provider.Provider
        ToolRegistry  *tools.Registry
        MaxIterations int
}

func NewLoop(p provider.Provider, reg *tools.Registry, maxIter int) *Loop {
        if maxIter == 0 {
                maxIter = 50
        }
        return &Loop{Provider: p, ToolRegistry: reg, MaxIterations: maxIter}
}

// Run executes the agent loop for a given user message.
func (l *Loop) Run(ctx context.Context, message string) (<-chan Event, error) {
        ch := make(chan Event, 100)
        go func() {
                defer close(ch)
                ch <- Event{Type: "user", Content: message}

                if !l.Provider.IsConfigured() {
                        ch <- Event{Type: "error", Content: "No provider configured. Set OPENCODE_API_KEY."}
                        return
                }

                msgs := []provider.Message{{Role: "user", Content: message}}
                systemPrompt := "You are Gem, an agentic AI assistant. Use tools to accomplish tasks. Never describe actions in prose - execute them."

                for i := 0; i < l.MaxIterations; i++ {
                        result, err := l.Provider.Generate(ctx, msgs, systemPrompt)
                        if err != nil {
                                ch <- Event{Type: "error", Content: err.Error()}
                                return
                        }
                        if result.Content != "" {
                                ch <- Event{Type: "assistant", Content: result.Content}
                        }
                        if result.FinishReason == "stop" {
                                ch <- Event{Type: "done", Content: result.Content}
                                return
                        }
                        msgs = append(msgs, provider.Message{Role: "assistant", Content: result.Content})
                }
                ch <- Event{Type: "done", Content: "Max iterations reached"}
        }()
        return ch, nil
}

// Event represents an agent loop event.
type Event struct {
        Type    string `json:"type"`
        Content string `json:"content"`
}

// AgentProfile defines a specialized agent.
type AgentProfile struct {
        Name        string
        Role        string
        SystemPrompt string
}

var DefaultProfiles = map[string]AgentProfile{
        "general":     {Name: "general", Role: "General purpose agent", SystemPrompt: "You are a general-purpose coding assistant."},
        "coder":       {Name: "coder", Role: "Code generation and editing", SystemPrompt: "You are a code generation specialist."},
        "researcher":  {Name: "researcher", Role: "Web research", SystemPrompt: "You are a research specialist."},
        "tester":      {Name: "tester", Role: "Testing and validation", SystemPrompt: "You are a testing specialist."},
        "frontend":    {Name: "frontend", Role: "Frontend development", SystemPrompt: "You are a frontend development specialist."},
        "backend":     {Name: "backend", Role: "Backend development", SystemPrompt: "You are a backend development specialist."},
        "reviewer":    {Name: "reviewer", Role: "Code review", SystemPrompt: "You are a code review specialist."},
        "planner":     {Name: "planner", Role: "Task planning", SystemPrompt: "You are a task planning specialist."},
}

func ListProfiles() []AgentProfile {
        profiles := make([]AgentProfile, 0, len(DefaultProfiles))
        for _, p := range DefaultProfiles {
                profiles = append(profiles, p)
        }
        return profiles
}
