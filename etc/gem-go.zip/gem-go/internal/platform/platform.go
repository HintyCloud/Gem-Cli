package platform

import (
	"os"
	"runtime"
	"strings"
)

type PlatformInfo struct {
	OS        string
	System    string
	Machine   string
	IsTermux  bool
	IsAndroid bool
	Shell     string
}

func Detect() PlatformInfo {
	info := PlatformInfo{
		OS:      runtime.GOOS,
		System:  runtime.GOOS,
		Machine: runtime.GOARCH,
	}
	// Termux detection
	prefix := os.Getenv("PREFIX")
	if strings.Contains(prefix, "com.termux") {
		info.IsTermux = true
		info.IsAndroid = true
		info.OS = "termux"
	}
	// Shell detection
	info.Shell = os.Getenv("SHELL")
	if info.Shell == "" {
		if info.IsTermux {
			info.Shell = "/data/data/com.termux/files/usr/bin/bash"
		} else if runtime.GOOS == "windows" {
			info.Shell = "cmd.exe"
		} else {
			info.Shell = "/bin/bash"
		}
	}
	return info
}
