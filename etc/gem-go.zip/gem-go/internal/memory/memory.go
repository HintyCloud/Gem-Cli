package memory

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
	"time"
)

// ChatMessage represents a single chat message.
type ChatMessage struct {
	Role      string    `json:"role"`
	Content   string    `json:"content"`
	Timestamp time.Time `json:"timestamp"`
}

// History stores chat message history.
type History struct {
	Messages []ChatMessage `json:"messages"`
	mu       sync.Mutex
	filePath string
}

func NewHistory(dir, chatID string) *History {
	if chatID == "" {
		chatID = "default"
	}
	return &History{
		Messages: []ChatMessage{},
		filePath: filepath.Join(dir, chatID+".json"),
	}
}

func (h *History) Add(role, content string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.Messages = append(h.Messages, ChatMessage{
		Role:      role,
		Content:   content,
		Timestamp: time.Now(),
	})
}

func (h *History) Save() error {
	h.mu.Lock()
	defer h.mu.Unlock()
	data, err := json.MarshalIndent(h.Messages, "", "  ")
	if err != nil {
		return err
	}
	os.MkdirAll(filepath.Dir(h.filePath), 0755)
	return os.WriteFile(h.filePath, data, 0644)
}

// MemoryEntry is a curated fact the agent remembers.
type MemoryEntry struct {
	ID        string    `json:"id"`
	Text      string    `json:"text"`
	Tags      []string  `json:"tags"`
	Project   string    `json:"project"`
	Timestamp time.Time `json:"timestamp"`
}

// MemoryStore manages persistent memory.
type MemoryStore struct {
	Entries []MemoryEntry `json:"entries"`
	mu      sync.Mutex
	path    string
}

func NewMemoryStore(dir string) *MemoryStore {
	path := filepath.Join(dir, "memory.json")
	store := &MemoryStore{path: path}
	data, err := os.ReadFile(path)
	if err == nil {
		json.Unmarshal(data, &store.Entries)
	}
	return store
}

func (m *MemoryStore) Remember(text string, tags []string, project string) string {
	m.mu.Lock()
	defer m.mu.Unlock()
	entry := MemoryEntry{
		ID:        time.Now().Format("20060102150405"),
		Text:      text,
		Tags:      tags,
		Project:   project,
		Timestamp: time.Now(),
	}
	m.Entries = append(m.Entries, entry)
	return entry.ID
}

func (m *MemoryStore) Save() error {
	m.mu.Lock()
	defer m.mu.Unlock()
	data, err := json.MarshalIndent(m.Entries, "", "  ")
	if err != nil {
		return err
	}
	os.MkdirAll(filepath.Dir(m.path), 0755)
	return os.WriteFile(m.path, data, 0644)
}
