//! Configuration loading for Gem CLI.
//!
//! Reads TOML configuration from `config/config.toml` and secrets from
//! `config/secrets.toml`, matching the Python Gem CLI config structure.

use std::collections::HashMap;
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};
use tracing::debug;

use crate::platform::PlatformInfo;

// ── Top-level config ──────────────────────────────────────────────────

/// Root configuration structure matching the Python `config.toml`.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct GemConfig {
    pub core: CoreConfig,
    pub model: ModelConfig,
    pub provider: ProviderConfig,
    pub agent: AgentConfig,
    pub memory: MemoryConfig,
    pub tools: ToolsConfig,
    pub server: ServerConfig,
    pub jobs: JobsConfig,
    pub ui: UiConfig,
}

impl Default for GemConfig {
    fn default() -> Self {
        Self {
            core: CoreConfig::default(),
            model: ModelConfig::default(),
            provider: ProviderConfig::default(),
            agent: AgentConfig::default(),
            memory: MemoryConfig::default(),
            tools: ToolsConfig::default(),
            server: ServerConfig::default(),
            jobs: JobsConfig::default(),
            ui: UiConfig::default(),
        }
    }
}

// ── Sub-config structs ────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct CoreConfig {
    pub name: String,
    pub version: String,
    pub debug: bool,
    pub log_level: String,
    pub data_dir: String,
}

impl Default for CoreConfig {
    fn default() -> Self {
        Self {
            name: "gem".to_string(),
            version: env!("CARGO_PKG_VERSION").to_string(),
            debug: false,
            log_level: "info".to_string(),
            data_dir: String::new(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ModelConfig {
    pub default: String,
    pub available: Vec<String>,
    pub max_tokens: u32,
    pub temperature: f32,
    pub top_p: f32,
}

impl Default for ModelConfig {
    fn default() -> Self {
        Self {
            default: "opencode".to_string(),
            available: vec![
                "opencode".into(),
                "gpt-4o".into(),
                "gpt-4o-mini".into(),
                "claude-3.5-sonnet".into(),
                "claude-3-haiku".into(),
                "gemini-2.0-flash".into(),
            ],
            max_tokens: 4096,
            temperature: 0.7,
            top_p: 1.0,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ProviderConfig {
    pub default: String,
    pub base_url: String,
    pub api_version: String,
    pub timeout_secs: u64,
    pub retries: u32,
    pub extra: HashMap<String, serde_json::Value>,
}

impl Default for ProviderConfig {
    fn default() -> Self {
        Self {
            default: "opencode".to_string(),
            base_url: "https://api.opencode.ai/v1".to_string(),
            api_version: "2024-01-01".to_string(),
            timeout_secs: 120,
            retries: 3,
            extra: HashMap::new(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct AgentConfig {
    pub max_iterations: u32,
    pub think_timeout_secs: u64,
    pub act_timeout_secs: u64,
    pub auto_approve: bool,
    pub sandbox: bool,
    pub system_prompt: String,
}

impl Default for AgentConfig {
    fn default() -> Self {
        Self {
            max_iterations: 50,
            think_timeout_secs: 30,
            act_timeout_secs: 60,
            auto_approve: false,
            sandbox: true,
            system_prompt: "You are Gem, an agentic AI assistant.".to_string(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct MemoryConfig {
    pub enabled: bool,
    pub max_history: usize,
    pub persist: bool,
    pub backend: String,
}

impl Default for MemoryConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            max_history: 1000,
            persist: true,
            backend: "sqlite".to_string(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ToolsConfig {
    pub enabled: Vec<String>,
    pub disabled: Vec<String>,
    pub shell_allow: Vec<String>,
    pub shell_deny: Vec<String>,
}

impl Default for ToolsConfig {
    fn default() -> Self {
        Self {
            enabled: vec![
                "shell".into(),
                "files".into(),
                "web_search".into(),
                "image".into(),
                "git".into(),
                "archive".into(),
                "artifacts".into(),
            ],
            disabled: vec![],
            shell_allow: vec![],
            shell_deny: vec!["rm -rf /".into(), "mkfs".into(), "dd".into()],
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ServerConfig {
    pub host: String,
    pub port: u16,
    pub workers: u16,
    pub cors_origins: Vec<String>,
}

impl Default for ServerConfig {
    fn default() -> Self {
        Self {
            host: "0.0.0.0".to_string(),
            port: 8000,
            workers: 4,
            cors_origins: vec!["*".to_string()],
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct JobsConfig {
    pub max_concurrent: usize,
    pub queue_size: usize,
    pub retry_limit: u32,
}

impl Default for JobsConfig {
    fn default() -> Self {
        Self {
            max_concurrent: 4,
            queue_size: 100,
            retry_limit: 3,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct UiConfig {
    pub theme: String,
    pub spinners: bool,
    pub colors: bool,
    pub rich_errors: bool,
}

impl Default for UiConfig {
    fn default() -> Self {
        Self {
            theme: "dark".to_string(),
            spinners: true,
            colors: true,
            rich_errors: true,
        }
    }
}

// ── Secrets ───────────────────────────────────────────────────────────

/// Secrets loaded from `config/secrets.toml`.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(default)]
pub struct SecretsConfig {
    pub api_keys: HashMap<String, String>,
    pub env: HashMap<String, String>,
}

// ── Loader ────────────────────────────────────────────────────────────

/// Configuration loader that reads TOML files and merges with defaults.
pub struct ConfigLoader;

impl ConfigLoader {
    /// Load configuration from the given directory.
    pub fn load(config_dir: &Path) -> Result<(GemConfig, SecretsConfig), ConfigError> {
        let config_path = config_dir.join("config.toml");
        let secrets_path = config_dir.join("secrets.toml");

        let config = if config_path.exists() {
            debug!("Loading config from {}", config_path.display());
            Self::load_toml::<GemConfig>(&config_path)?
        } else {
            debug!("No config.toml found, using defaults");
            GemConfig::default()
        };

        let secrets = if secrets_path.exists() {
            debug!("Loading secrets from {}", secrets_path.display());
            Self::load_toml::<SecretsConfig>(&secrets_path)?
        } else {
            debug!("No secrets.toml found");
            SecretsConfig::default()
        };

        Ok((config, secrets))
    }

    /// Load and resolve configuration using platform info.
    pub fn load_with_platform(
        platform: &PlatformInfo,
    ) -> Result<(GemConfig, SecretsConfig), ConfigError> {
        let config_dir = platform.gem_config_dir();

        // Ensure config directory exists
        if !config_dir.exists() {
            std::fs::create_dir_all(&config_dir)
                .map_err(|e| ConfigError::Io(format!("Failed to create config dir {}: {}", config_dir.display(), e)))?;
        }

        let (mut config, secrets) = Self::load(&config_dir)?;

        // Resolve data_dir from platform if not set
        if config.core.data_dir.is_empty() {
            config.core.data_dir = platform.data_dir.to_string_lossy().to_string();
        }

        Ok((config, secrets))
    }

    /// Parse a TOML file into the given type.
    fn load_toml<T: serde::de::DeserializeOwned>(path: &Path) -> Result<T, ConfigError> {
        let content = std::fs::read_to_string(path)
            .map_err(|e| ConfigError::Io(format!("Failed to read {}: {}", path.display(), e)))?;
        toml::from_str(&content)
            .map_err(|e| ConfigError::Parse(format!("Failed to parse {}: {}", path.display(), e)))
    }

    /// Write a default config file to the given path (for `gem init`).
    pub fn write_defaults(config_dir: &Path) -> Result<(), ConfigError> {
        if !config_dir.exists() {
            std::fs::create_dir_all(config_dir)
                .map_err(|e| ConfigError::Io(format!("Failed to create config dir {}: {}", config_dir.display(), e)))?;
        }

        let config_path = config_dir.join("config.toml");
        if !config_path.exists() {
            let defaults = GemConfig::default();
            let toml_str = toml::to_string_pretty(&defaults)
                .map_err(|e| ConfigError::Parse(e.to_string()))?;
            std::fs::write(&config_path, toml_str)
                .map_err(|e| ConfigError::Io(format!("Failed to write {}: {}", config_path.display(), e)))?;
            debug!("Wrote default config to {}", config_path.display());
        }

        let secrets_path = config_dir.join("secrets.toml");
        if !secrets_path.exists() {
            let template = "# Gem CLI Secrets\n\
                            # Add your API keys here. This file should NEVER be committed.\n\
                            \n\
                            [api_keys]\n\
                            # opencode = \"sk-...\"\n\
                            # openai = \"sk-...\"\n\
                            # anthropic = \"sk-ant-...\"\n\
                            \n\
                            [env]\n\
                            # CUSTOM_VAR = \"value\"\n";
            std::fs::write(&secrets_path, template)
                .map_err(|e| ConfigError::Io(format!("Failed to write {}: {}", secrets_path.display(), e)))?;
            debug!("Wrote secrets template to {}", secrets_path.display());
        }

        Ok(())
    }
}

// ── Errors ────────────────────────────────────────────────────────────

#[derive(Debug, thiserror::Error)]
pub enum ConfigError {
    #[error("IO error: {0}")]
    Io(String),

    #[error("Parse error: {0}")]
    Parse(String),

    #[error("Validation error: {0}")]
    Validation(String),
}

// ── Resolved config (runtime) ─────────────────────────────────────────

/// Fully resolved configuration ready for use at runtime.
#[derive(Debug, Clone)]
pub struct ResolvedConfig {
    pub config: GemConfig,
    pub secrets: SecretsConfig,
    pub config_dir: PathBuf,
    pub data_dir: PathBuf,
}

impl ResolvedConfig {
    /// Resolve configuration for the current platform.
    pub fn resolve() -> Result<Self, ConfigError> {
        let platform = PlatformInfo::detect();
        let (config, secrets) = ConfigLoader::load_with_platform(&platform)?;
        let data_dir = PathBuf::from(&config.core.data_dir);

        // Ensure data dir exists
        if !data_dir.exists() {
            std::fs::create_dir_all(&data_dir)
                .map_err(|e| ConfigError::Io(format!("Failed to create data dir: {}", e)))?;
        }

        Ok(Self {
            config,
            secrets,
            config_dir: platform.gem_config_dir(),
            data_dir,
        })
    }

    /// Get an API key for a given provider name.
    pub fn api_key(&self, provider: &str) -> Option<String> {
        self.secrets.api_keys.get(provider).cloned()
    }

    /// Get the default API key.
    pub fn default_api_key(&self) -> Option<String> {
        self.api_key(&self.config.provider.default)
    }
}
