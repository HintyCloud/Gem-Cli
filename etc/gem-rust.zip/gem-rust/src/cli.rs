//! CLI command definitions using clap derive macros.
//!
//! Matches the Python Gem CLI command structure:
//! `gem status | serve | chat | project | jobs | models | providers | tools | agents`

use clap::{Args, Parser, Subcommand, ValueEnum};
use serde::{Deserialize, Serialize};

/// Gem CLI — Agentic AI ecosystem by HintyCloud.
#[derive(Debug, Parser)]
#[command(
    name = "gem",
    version,
    about = "Gem CLI — Agentic AI ecosystem",
    long_about = "Gem is an agentic AI ecosystem with multi-provider support,\n\
                  tool registry, agent loop, memory system, job queue,\n\
                  and swarm/multi-agent orchestration.\n\
                  \nHintyCloud — https://hinty.cloud"
)]
pub struct Cli {
    /// Enable debug logging.
    #[arg(short, long, global = true)]
    pub debug: bool,

    /// Log level (trace, debug, info, warn, error).
    #[arg(short, long, global = true, default_value = "info")]
    pub log_level: String,

    /// Configuration directory path.
    #[arg(short, long, global = true)]
    pub config_dir: Option<String>,

    /// The subcommand to run.
    #[command(subcommand)]
    pub command: Option<Commands>,
}

/// Top-level CLI subcommands.
#[derive(Debug, Subcommand)]
pub enum Commands {
    /// Show system status and configuration.
    Status(StatusArgs),

    /// Start the FastAPI-compatible server (HTTP + WebSocket).
    Serve(ServeArgs),

    /// Start an interactive chat session.
    Chat(ChatArgs),

    /// Manage projects.
    Project(ProjectArgs),

    /// Manage background jobs.
    Jobs(JobsArgs),

    /// List and manage models.
    Models(ModelsArgs),

    /// List and manage providers.
    Providers(ProvidersArgs),

    /// List and manage tools.
    Tools(ToolsArgs),

    /// List and manage agents.
    Agents(AgentsArgs),

    /// Initialize configuration files.
    Init(InitArgs),
}

// ── Status ────────────────────────────────────────────────────────────

#[derive(Debug, Args)]
pub struct StatusArgs {
    /// Output format (text, json).
    #[arg(short, long, default_value = "text")]
    pub format: OutputFormat,

    /// Show detailed information.
    #[arg(short, long)]
    pub verbose: bool,
}

// ── Serve ─────────────────────────────────────────────────────────────

#[derive(Debug, Args)]
pub struct ServeArgs {
    /// Host to bind to.
    #[arg(short, long, default_value = "0.0.0.0")]
    pub host: String,

    /// Port to listen on.
    #[arg(short, long, default_value_t = 8000)]
    pub port: u16,

    /// Number of worker threads.
    #[arg(short, long, default_value_t = 4)]
    pub workers: u16,

    /// Enable hot reload (development).
    #[arg(long)]
    pub reload: bool,
}

// ── Chat ──────────────────────────────────────────────────────────────

#[derive(Debug, Args)]
pub struct ChatArgs {
    /// Model to use for this session.
    #[arg(short, long)]
    pub model: Option<String>,

    /// Provider to use.
    #[arg(short, long)]
    pub provider: Option<String>,

    /// Resume a previous chat by ID.
    #[arg(short, long)]
    pub resume: Option<String>,

    /// System prompt override.
    #[arg(short, long)]
    pub system: Option<String>,

    /// Non-interactive mode: send a single message and exit.
    #[arg(short, long)]
    pub message: Option<String>,

    /// Disable tool use in this session.
    #[arg(long)]
    pub no_tools: bool,

    /// Enable auto-approve for tool calls.
    #[arg(long)]
    pub auto_approve: bool,
}

// ── Project ───────────────────────────────────────────────────────────

#[derive(Debug, Args)]
pub struct ProjectArgs {
    /// Project subcommand.
    #[command(subcommand)]
    pub action: Option<ProjectAction>,
}

#[derive(Debug, Subcommand)]
pub enum ProjectAction {
    /// Create a new project.
    Create {
        /// Project name.
        name: String,

        /// Project directory (defaults to current).
        #[arg(short, long)]
        dir: Option<String>,
    },

    /// List all projects.
    List,

    /// Show project details.
    Show {
        /// Project name.
        name: String,
    },

    /// Remove a project.
    Remove {
        /// Project name.
        name: String,
    },
}

// ── Jobs ──────────────────────────────────────────────────────────────

#[derive(Debug, Args)]
pub struct JobsArgs {
    /// Jobs subcommand.
    #[command(subcommand)]
    pub action: Option<JobsAction>,
}

#[derive(Debug, Subcommand)]
pub enum JobsAction {
    /// List all jobs.
    List {
        /// Filter by status.
        #[arg(short, long)]
        status: Option<JobStatusFilter>,
    },

    /// Show job details.
    Show {
        /// Job ID.
        id: String,
    },

    /// Cancel a running job.
    Cancel {
        /// Job ID.
        id: String,
    },

    /// Clear completed/failed jobs.
    Clean,
}

/// Job status filter values.
#[derive(Debug, Clone, ValueEnum, Serialize, Deserialize)]
pub enum JobStatusFilter {
    Pending,
    Running,
    Completed,
    Failed,
    Cancelled,
}

// ── Models ────────────────────────────────────────────────────────────

#[derive(Debug, Args)]
pub struct ModelsArgs {
    /// Models subcommand.
    #[command(subcommand)]
    pub action: Option<ModelsAction>,
}

#[derive(Debug, Subcommand)]
pub enum ModelsAction {
    /// List available models.
    List {
        /// Provider to list models for.
        #[arg(short, long)]
        provider: Option<String>,
    },

    /// Set the default model.
    Default {
        /// Model name.
        name: String,
    },

    /// Test a model with a simple prompt.
    Test {
        /// Model name.
        name: String,

        /// Provider to use.
        #[arg(short, long)]
        provider: Option<String>,
    },
}

// ── Providers ─────────────────────────────────────────────────────────

#[derive(Debug, Args)]
pub struct ProvidersArgs {
    /// Providers subcommand.
    #[command(subcommand)]
    pub action: Option<ProvidersAction>,
}

#[derive(Debug, Subcommand)]
pub enum ProvidersAction {
    /// List configured providers.
    List,

    /// Show provider details.
    Show {
        /// Provider name.
        name: String,
    },

    /// Test provider connectivity.
    Test {
        /// Provider name.
        name: String,
    },
}

// ── Tools ─────────────────────────────────────────────────────────────

#[derive(Debug, Args)]
pub struct ToolsArgs {
    /// Tools subcommand.
    #[command(subcommand)]
    pub action: Option<ToolsAction>,
}

#[derive(Debug, Subcommand)]
pub enum ToolsAction {
    /// List registered tools.
    List {
        /// Show only enabled tools.
        #[arg(short, long)]
        enabled: bool,
    },

    /// Show tool details.
    Show {
        /// Tool name.
        name: String,
    },

    /// Enable a tool.
    Enable {
        /// Tool name.
        name: String,
    },

    /// Disable a tool.
    Disable {
        /// Tool name.
        name: String,
    },
}

// ── Agents ────────────────────────────────────────────────────────────

#[derive(Debug, Args)]
pub struct AgentsArgs {
    /// Agents subcommand.
    #[command(subcommand)]
    pub action: Option<AgentsAction>,
}

#[derive(Debug, Subcommand)]
pub enum AgentsAction {
    /// List available agents.
    List,

    /// Show agent details.
    Show {
        /// Agent name.
        name: String,
    },

    /// Run a specific agent.
    Run {
        /// Agent name.
        name: String,

        /// Input message or prompt.
        #[arg(short, long)]
        input: Option<String>,
    },

    /// Spawn a swarm of agents.
    Swarm {
        /// Swarm configuration file.
        #[arg(short, long)]
        config: Option<String>,

        /// Agent names to include (comma-separated).
        #[arg(short, long)]
        agents: Option<String>,
    },
}

// ── Init ──────────────────────────────────────────────────────────────

#[derive(Debug, Args)]
pub struct InitArgs {
    /// Force overwrite existing config.
    #[arg(short, long)]
    pub force: bool,
}

// ── Shared types ──────────────────────────────────────────────────────

/// Output format for commands.
#[derive(Debug, Clone, ValueEnum)]
pub enum OutputFormat {
    Text,
    Json,
}

// ── Chat slash commands ───────────────────────────────────────────────

/// Slash commands available inside chat mode.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SlashCommand {
    Help,
    Model,
    Provider,
    Chats,
    New,
    Clear,
    Status,
    Jobs,
    Agents,
    Tools,
    Exit,
}

impl SlashCommand {
    /// Parse a slash command from a string.
    pub fn parse(input: &str) -> Option<Self> {
        let cmd = input.trim().trim_start_matches('/');
        match cmd {
            "help" => Some(Self::Help),
            "model" => Some(Self::Model),
            "provider" => Some(Self::Provider),
            "chats" => Some(Self::Chats),
            "new" => Some(Self::New),
            "clear" => Some(Self::Clear),
            "status" => Some(Self::Status),
            "jobs" => Some(Self::Jobs),
            "agents" => Some(Self::Agents),
            "tools" => Some(Self::Tools),
            "exit" | "quit" => Some(Self::Exit),
            _ => None,
        }
    }

    /// Return all available slash commands with descriptions.
    pub fn help_text() -> &'static str {
        r#"Gem Chat — Slash Commands:
  /help      — Show this help message
  /model     — Show or switch the current model
  /provider  — Show or switch the current provider
  /chats     — List previous chat sessions
  /new       — Start a new chat session
  /clear     — Clear the current chat history
  /status    — Show agent status and configuration
  /jobs      — Show running background jobs
  /agents    — List available agents
  /tools     — List available tools
  /exit      — Exit chat mode"#
    }

    /// Returns all command names.
    pub fn all_names() -> &'static [&'static str] {
        &[
            "help", "model", "provider", "chats", "new", "clear", "status", "jobs", "agents",
            "tools", "exit",
        ]
    }
}
