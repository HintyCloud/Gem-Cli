//! Memory and history store for Gem CLI.
//!
//! Provides conversation history tracking and a persistent memory system
//! that the agent can use to recall facts across sessions.

use std::collections::HashMap;
use std::path::PathBuf;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use uuid::Uuid;

use crate::provider::{ChatMessage, Role};

// ── Chat session ──────────────────────────────────────────────────────

/// A chat session with its message history.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ChatSession {
    pub id: String,
    pub title: String,
    pub model: String,
    pub provider: String,
    pub messages: Vec<ChatMessage>,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
    pub metadata: HashMap<String, serde_json::Value>,
}

impl ChatSession {
    /// Create a new empty chat session.
    pub fn new(model: impl Into<String>, provider: impl Into<String>) -> Self {
        let now = Utc::now();
        Self {
            id: Uuid::new_v4().to_string(),
            title: String::new(),
            model: model.into(),
            provider: provider.into(),
            messages: Vec::new(),
            created_at: now,
            updated_at: now,
            metadata: HashMap::new(),
        }
    }

    /// Create with a system prompt.
    pub fn with_system_prompt(
        model: impl Into<String>,
        provider: impl Into<String>,
        prompt: impl Into<String>,
    ) -> Self {
        let mut session = Self::new(model, provider);
        session.messages.push(ChatMessage::system(prompt));
        session
    }

    /// Add a message and update the timestamp.
    pub fn push(&mut self, message: ChatMessage) {
        self.messages.push(message);
        self.updated_at = Utc::now();

        // Auto-generate title from first user message
        if self.title.is_empty() {
            if let Some(msg) = self.messages.iter().find(|m| m.role == Role::User) {
                self.title = msg.content.chars().take(80).collect();
            }
        }
    }

    /// Get the last N messages.
    pub fn last_n(&self, n: usize) -> &[ChatMessage] {
        let start = self.messages.len().saturating_sub(n);
        &self.messages[start..]
    }

    /// Clear all messages except the system prompt.
    pub fn clear(&mut self) {
        self.messages.retain(|m| m.role == Role::System);
        self.updated_at = Utc::now();
    }

    /// Total message count.
    pub fn len(&self) -> usize {
        self.messages.len()
    }

    /// Whether the session has no messages (besides optional system prompt).
    pub fn is_empty(&self) -> bool {
        self.messages.iter().all(|m| m.role == Role::System)
    }

    /// Count of user messages.
    pub fn user_message_count(&self) -> usize {
        self.messages.iter().filter(|m| m.role == Role::User).count()
    }

    /// Token estimate (rough: 4 chars ≈ 1 token).
    pub fn estimated_tokens(&self) -> u32 {
        self.messages
            .iter()
            .map(|m| m.content.len() as u32 / 4)
            .sum()
    }
}

// ── History store ─────────────────────────────────────────────────────

/// Store that manages chat sessions with optional persistence.
pub struct HistoryStore {
    pub sessions: HashMap<String, ChatSession>,
    current_id: Option<String>,
    max_history: usize,
    persist: bool,
    data_dir: PathBuf,
}

impl HistoryStore {
    /// Create a new history store.
    pub fn new(max_history: usize, persist: bool, data_dir: PathBuf) -> Self {
        Self {
            sessions: HashMap::new(),
            current_id: None,
            max_history,
            persist,
            data_dir,
        }
    }

    /// Start a new chat session and make it current.
    pub fn new_session(
        &mut self,
        model: impl Into<String>,
        provider: impl Into<String>,
    ) -> &ChatSession {
        let session = ChatSession::new(model, provider);
        let id = session.id.clone();
        self.sessions.insert(id.clone(), session);
        self.current_id = Some(id);
        self.sessions.get(self.current_id.as_ref().unwrap()).unwrap()
    }

    /// Get the current session mutably.
    pub fn current_mut(&mut self) -> Option<&mut ChatSession> {
        self.current_id
            .as_ref()
            .and_then(|id| self.sessions.get_mut(id))
    }

    /// Get the current session.
    pub fn current(&self) -> Option<&ChatSession> {
        self.current_id
            .as_ref()
            .and_then(|id| self.sessions.get(id))
    }

    /// Resume a session by ID.
    pub fn resume(&mut self, id: &str) -> bool {
        if self.sessions.contains_key(id) {
            self.current_id = Some(id.to_string());
            true
        } else {
            false
        }
    }

    /// List all session IDs and titles.
    pub fn list_sessions(&self) -> Vec<(String, String, DateTime<Utc>)> {
        let mut sessions: Vec<_> = self
            .sessions
            .values()
            .map(|s| (s.id.clone(), s.title.clone(), s.updated_at))
            .collect();
        sessions.sort_by(|a, b| b.2.cmp(&a.2));
        sessions
    }

    /// Delete a session.
    pub fn delete_session(&mut self, id: &str) -> bool {
        if self.current_id.as_ref() == Some(&id.to_string()) {
            self.current_id = None;
        }
        self.sessions.remove(id).is_some()
    }

    /// Save all sessions to disk.
    pub async fn save(&self) -> Result<(), MemoryError> {
        if !self.persist {
            return Ok(());
        }

        let dir = self.data_dir.join("chats");
        tokio::fs::create_dir_all(&dir)
            .await
            .map_err(|e| MemoryError::Io(e.to_string()))?;

        for session in self.sessions.values() {
            let path = dir.join(format!("{}.json", session.id));
            let json = serde_json::to_string_pretty(session)
                .map_err(|e| MemoryError::Serialize(e.to_string()))?;
            tokio::fs::write(&path, json)
                .await
                .map_err(|e| MemoryError::Io(e.to_string()))?;
        }

        Ok(())
    }

    /// Load sessions from disk.
    pub async fn load(&mut self) -> Result<(), MemoryError> {
        if !self.persist {
            return Ok(());
        }

        let dir = self.data_dir.join("chats");
        if !dir.exists() {
            return Ok(());
        }

        let mut entries = tokio::fs::read_dir(&dir)
            .await
            .map_err(|e| MemoryError::Io(e.to_string()))?;

        while let Some(entry) = entries
            .next_entry()
            .await
            .map_err(|e| MemoryError::Io(e.to_string()))?
        {
            let path = entry.path();
            if path.extension().map(|e| e == "json").unwrap_or(false) {
                let content = tokio::fs::read_to_string(&path)
                    .await
                    .map_err(|e| MemoryError::Io(e.to_string()))?;
                if let Ok(session) = serde_json::from_str::<ChatSession>(&content) {
                    self.sessions.insert(session.id.clone(), session);
                }
            }
        }

        // Set the most recent session as current
        if let Some(latest) = self
            .sessions
            .values()
            .max_by_key(|s| s.updated_at)
        {
            self.current_id = Some(latest.id.clone());
        }

        Ok(())
    }
}

// ── Persistent memory ─────────────────────────────────────────────────

/// A single memory entry.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MemoryEntry {
    pub id: String,
    pub key: String,
    pub value: String,
    pub source: String,
    pub created_at: DateTime<Utc>,
    pub accessed_at: DateTime<Utc>,
    pub access_count: u32,
    pub tags: Vec<String>,
}

/// Persistent memory store for cross-session knowledge.
pub struct MemoryStore {
    entries: HashMap<String, MemoryEntry>,
    persist: bool,
    data_dir: PathBuf,
}

impl MemoryStore {
    /// Create a new memory store.
    pub fn new(persist: bool, data_dir: PathBuf) -> Self {
        Self {
            entries: HashMap::new(),
            persist,
            data_dir,
        }
    }

    /// Store a memory entry.
    pub fn remember(
        &mut self,
        key: impl Into<String>,
        value: impl Into<String>,
        source: impl Into<String>,
    ) -> String {
        let key = key.into();
        let now = Utc::now();
        let id = Uuid::new_v4().to_string();

        let entry = MemoryEntry {
            id: id.clone(),
            key: key.clone(),
            value: value.into(),
            source: source.into(),
            created_at: now,
            accessed_at: now,
            access_count: 0,
            tags: Vec::new(),
        };

        self.entries.insert(key, entry);
        id
    }

    /// Recall a memory entry by key.
    pub fn recall(&mut self, key: &str) -> Option<&str> {
        if let Some(entry) = self.entries.get_mut(key) {
            entry.accessed_at = Utc::now();
            entry.access_count += 1;
            Some(&entry.value)
        } else {
            None
        }
    }

    /// Search memory by content substring.
    pub fn search(&self, query: &str) -> Vec<&MemoryEntry> {
        let query_lower = query.to_lowercase();
        self.entries
            .values()
            .filter(|e| {
                e.value.to_lowercase().contains(&query_lower)
                    || e.key.to_lowercase().contains(&query_lower)
                    || e.tags.iter().any(|t| t.to_lowercase().contains(&query_lower))
            })
            .collect()
    }

    /// Delete a memory entry.
    pub fn forget(&mut self, key: &str) -> bool {
        self.entries.remove(key).is_some()
    }

    /// List all memory keys.
    pub fn keys(&self) -> Vec<&str> {
        self.entries.keys().map(|s| s.as_str()).collect()
    }

    /// Count of stored memories.
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    /// Whether the store is empty.
    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Save memory to disk.
    pub async fn save(&self) -> Result<(), MemoryError> {
        if !self.persist {
            return Ok(());
        }

        let dir = self.data_dir.join("memory");
        tokio::fs::create_dir_all(&dir)
            .await
            .map_err(|e| MemoryError::Io(e.to_string()))?;

        let path = dir.join("store.json");
        let entries: Vec<_> = self.entries.values().collect();
        let json = serde_json::to_string_pretty(&entries)
            .map_err(|e| MemoryError::Serialize(e.to_string()))?;
        tokio::fs::write(&path, json)
            .await
            .map_err(|e| MemoryError::Io(e.to_string()))?;

        Ok(())
    }

    /// Load memory from disk.
    pub async fn load(&mut self) -> Result<(), MemoryError> {
        if !self.persist {
            return Ok(());
        }

        let path = self.data_dir.join("memory").join("store.json");
        if !path.exists() {
            return Ok(());
        }

        let content = tokio::fs::read_to_string(&path)
            .await
            .map_err(|e| MemoryError::Io(e.to_string()))?;

        let entries: Vec<MemoryEntry> = serde_json::from_str(&content)
            .map_err(|e| MemoryError::Serialize(e.to_string()))?;

        for entry in entries {
            self.entries.insert(entry.key.clone(), entry);
        }

        Ok(())
    }
}

// ── Errors ────────────────────────────────────────────────────────────

#[derive(Debug, thiserror::Error)]
pub enum MemoryError {
    #[error("IO error: {0}")]
    Io(String),

    #[error("Serialization error: {0}")]
    Serialize(String),

    #[error("Session not found: {0}")]
    SessionNotFound(String),
}
