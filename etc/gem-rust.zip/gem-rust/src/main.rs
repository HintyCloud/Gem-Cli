//! Gem CLI — Agentic AI ecosystem by HintyCloud.
//!
//! Entry point with CLI argument parsing and command dispatch.

mod agent;
mod cli;
mod config;
mod memory;
mod platform;
mod provider;
mod tools;

use std::sync::Arc;

use clap::Parser;
use colored::*;
use tokio::sync::RwLock;
use tracing::{error, warn, Level};
use tracing_subscriber::EnvFilter;

use cli::{Cli, Commands, OutputFormat, SlashCommand};
use config::{ConfigLoader, GemConfig, ResolvedConfig, SecretsConfig};
use memory::{HistoryStore, MemoryStore};
use platform::PlatformInfo;
use provider::{OpenCodeProvider, ProviderRegistry};
use tools::ToolRegistry;

// ── Main ──────────────────────────────────────────────────────────────

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();

    // Initialize logging
    init_logging(&cli);

    // Load configuration
    let resolved = match ResolvedConfig::resolve() {
        Ok(r) => r,
        Err(e) => {
            // If config doesn't exist yet, use defaults
            warn!("Config resolution failed ({}), using defaults", e);
            let platform = PlatformInfo::detect();
            let config = GemConfig::default();
            let secrets = SecretsConfig::default();
            ResolvedConfig {
                config,
                secrets,
                config_dir: platform.gem_config_dir(),
                data_dir: platform.data_dir,
            }
        }
    };

    // Dispatch command
    match cli.command {
        None => {
            // No subcommand — default to chat
            run_chat(&resolved, None, None, None, false, false).await?;
        }
        Some(cmd) => dispatch(cmd, &resolved).await?,
    }

    Ok(())
}

// ── Command dispatch ──────────────────────────────────────────────────

async fn dispatch(cmd: Commands, resolved: &ResolvedConfig) -> anyhow::Result<()> {
    match cmd {
        Commands::Status(args) => run_status(resolved, &args).await,
        Commands::Serve(args) => run_serve(resolved, &args).await,
        Commands::Chat(args) => {
            run_chat(
                resolved,
                args.model.as_deref(),
                args.provider.as_deref(),
                args.system.as_deref(),
                args.auto_approve,
                args.no_tools,
            )
            .await
        }
        Commands::Project(args) => run_project(resolved, &args).await,
        Commands::Jobs(args) => run_jobs(resolved, &args).await,
        Commands::Models(args) => run_models(resolved, &args).await,
        Commands::Providers(args) => run_providers(resolved, &args).await,
        Commands::Tools(args) => run_tools(resolved, &args).await,
        Commands::Agents(args) => run_agents(resolved, &args).await,
        Commands::Init(args) => run_init(resolved, &args).await,
    }
}

// ── Command implementations ───────────────────────────────────────────

async fn run_status(resolved: &ResolvedConfig, args: &cli::StatusArgs) -> anyhow::Result<()> {
    let platform = PlatformInfo::detect();

    match args.format {
        OutputFormat::Json => {
            let status = serde_json::json!({
                "version": env!("CARGO_PKG_VERSION"),
                "platform": {
                    "os": platform.os,
                    "arch": platform.arch,
                    "shell": platform.shell,
                    "is_termux": platform.is_termux,
                },
                "config_dir": resolved.config_dir.to_string_lossy(),
                "data_dir": resolved.data_dir.to_string_lossy(),
                "model": resolved.config.model.default,
                "provider": resolved.config.provider.default,
                "memory_enabled": resolved.config.memory.enabled,
                "tools_enabled": resolved.config.tools.enabled,
            });
            println!("{}", serde_json::to_string_pretty(&status)?);
        }
        OutputFormat::Text => {
            println!(
                "\n  {} {} v{}",
                "gem".bright_cyan().bold(),
                "CLI".bright_white(),
                env!("CARGO_PKG_VERSION")
            );
            println!("  {}", "─".repeat(40).dimmed());
            println!("  {} {}", "Platform:".dimmed(), platform.summary());
            println!(
                "  {} {}",
                "Config:".dimmed(),
                resolved.config_dir.display()
            );
            println!(
                "  {} {}",
                "Data:".dimmed(),
                resolved.data_dir.display()
            );
            println!(
                "  {} {}",
                "Model:".dimmed(),
                resolved.config.model.default
            );
            println!(
                "  {} {}",
                "Provider:".dimmed(),
                resolved.config.provider.default
            );
            println!(
                "  {} {}",
                "Base URL:".dimmed(),
                resolved.config.provider.base_url
            );
            println!(
                "  {} {}",
                "Memory:".dimmed(),
                if resolved.config.memory.enabled {
                    "enabled".green()
                } else {
                    "disabled".red()
                }
            );
            println!(
                "  {} [{}]",
                "Tools:".dimmed(),
                resolved.config.tools.enabled.join(", ")
            );

            if args.verbose {
                println!("\n  {}", "─".repeat(40).dimmed());
                println!(
                    "  {} {}",
                    "Max iterations:".dimmed(),
                    resolved.config.agent.max_iterations
                );
                println!(
                    "  {} {}",
                    "Max tokens:".dimmed(),
                    resolved.config.model.max_tokens
                );
                println!(
                    "  {} {}",
                    "Temperature:".dimmed(),
                    resolved.config.model.temperature
                );
                println!(
                    "  {} {}",
                    "Server:".dimmed(),
                    format!("{}:{}", resolved.config.server.host, resolved.config.server.port)
                );
                println!(
                    "  {} {}",
                    "API key set:".dimmed(),
                    if resolved.default_api_key().is_some() {
                        "yes".green()
                    } else {
                        "no".red()
                    }
                );
            }
            println!();
        }
    }

    Ok(())
}

async fn run_serve(_resolved: &ResolvedConfig, args: &cli::ServeArgs) -> anyhow::Result<()> {
    let host = &args.host;
    let port = args.port;

    println!(
        "\n  {} Starting server on {}:{}",
        "gem".bright_cyan().bold(),
        host,
        port
    );
    println!("  {}", "─".repeat(40).dimmed());

    // TODO: Implement FastAPI-compatible HTTP + WebSocket server
    // For now, indicate the server would start
    println!("  {} HTTP API:   http://{}:{}", "→".green(), host, port);
    println!("  {} WebSocket:  ws://{}:{}/ws", "→".green(), host, port);
    println!(
        "  {} Docs:       http://{}:{}/docs",
        "→".green(),
        host,
        port
    );
    println!("\n  {} Server not yet implemented in Rust.\n", "⚠".yellow());

    Ok(())
}

async fn run_chat(
    resolved: &ResolvedConfig,
    model: Option<&str>,
    provider: Option<&str>,
    system_prompt: Option<&str>,
    auto_approve: bool,
    no_tools: bool,
) -> anyhow::Result<()> {
    let model_name = model
        .map(|s| s.to_string())
        .unwrap_or_else(|| resolved.config.model.default.clone());
    let provider_name = provider
        .map(|s| s.to_string())
        .unwrap_or_else(|| resolved.config.provider.default.clone());

    println!(
        "\n  {} Chat — model: {}, provider: {}",
        "gem".bright_cyan().bold(),
        model_name.bright_white(),
        provider_name.bright_white()
    );
    println!("  {}", "─".repeat(40).dimmed());
    println!(
        "  Type {} for slash commands, {} to exit.\n",
        "/help".bright_yellow(),
        "/exit".bright_yellow()
    );

    // Set up provider registry
    let mut provider_registry = ProviderRegistry::new();
    if let Some(api_key) = resolved.default_api_key() {
        let provider_impl = OpenCodeProvider::new(&resolved.config, api_key);
        provider_registry.register(resolved.config.provider.default.clone(), Box::new(provider_impl));
    }

    // Set up tool registry
    let tool_registry = ToolRegistry::with_builtins();

    // Set up memory and history
    let history = Arc::new(RwLock::new(HistoryStore::new(
        resolved.config.memory.max_history,
        resolved.config.memory.persist,
        resolved.data_dir.clone(),
    )));

    let memory = Arc::new(RwLock::new(MemoryStore::new(
        resolved.config.memory.persist,
        resolved.data_dir.clone(),
    )));

    // Load existing data
    {
        let mut h = history.write().await;
        let _ = h.load().await;
    }
    {
        let mut m = memory.write().await;
        let _ = m.load().await;
    }

    // Create agent
    let agent_config = agent::AgentConfig::from_gem_config(
        &resolved.config,
        Some(&model_name),
        Some(&provider_name),
        system_prompt,
        auto_approve,
        no_tools,
    );

    let provider_arc = Arc::new(provider_registry);
    let tool_arc = Arc::new(tool_registry);

    let mut ag = agent::Agent::new(
        agent_config,
        history.clone(),
        memory.clone(),
        provider_arc.clone(),
        tool_arc.clone(),
    );

    // Start a new session in history
    {
        let mut h = history.write().await;
        h.new_session(&model_name, &provider_name);
    }

    // Interactive REPL
    use rustyline::error::ReadlineError;
    use rustyline::DefaultEditor;

    let mut rl = DefaultEditor::new()?;
    let prompt = format!("{} ", "❯".bright_cyan());

    loop {
        let line = rl.readline(&prompt);
        match line {
            Ok(input) => {
                let trimmed = input.trim();
                if trimmed.is_empty() {
                    continue;
                }

                rl.add_history_entry(trimmed)?;

                // Check for slash commands
                if trimmed.starts_with('/') {
                    if let Some(cmd) = SlashCommand::parse(trimmed) {
                        match cmd {
                            SlashCommand::Exit => break,
                            SlashCommand::Help => {
                                println!("\n{}\n", SlashCommand::help_text());
                            }
                            SlashCommand::Model => {
                                println!(
                                    "  Current model: {}",
                                    ag.status().model.bright_white()
                                );
                            }
                            SlashCommand::Provider => {
                                println!(
                                    "  Current provider: {}",
                                    ag.status().provider.bright_white()
                                );
                            }
                            SlashCommand::Status => {
                                let s = ag.status();
                                println!(
                                    "  Phase: {} | Iter: {}/{} | Tokens: {} | Tools: {}",
                                    s.phase,
                                    s.iteration,
                                    s.max_iterations,
                                    s.tokens_used,
                                    s.tools_called
                                );
                            }
                            SlashCommand::New => {
                                println!("  Starting new chat session...");
                                // Reset agent session
                                let new_config = agent::AgentConfig::from_gem_config(
                                    &resolved.config,
                                    Some(&model_name),
                                    Some(&provider_name),
                                    system_prompt,
                                    auto_approve,
                                    no_tools,
                                );
                                ag = agent::Agent::new(
                                    new_config,
                                    history.clone(),
                                    memory.clone(),
                                    provider_arc.clone(),
                                    tool_arc.clone(),
                                );
                            }
                            SlashCommand::Clear => {
                                println!("  Chat history cleared.");
                            }
                            SlashCommand::Chats => {
                                let h = history.read().await;
                                let sessions = h.list_sessions();
                                if sessions.is_empty() {
                                    println!("  No previous sessions.");
                                } else {
                                    for (id, title, ts) in sessions {
                                        println!("  {} {} ({})", id.dimmed(), title, ts);
                                    }
                                }
                            }
                            SlashCommand::Jobs => {
                                println!("  No running jobs.");
                            }
                            SlashCommand::Agents => {
                                println!("  Available agents: default");
                            }
                            SlashCommand::Tools => {
                                let names = tool_arc.enabled_names();
                                println!("  Enabled tools: [{}]", names.join(", "));
                            }
                        }
                        continue;
                    } else {
                        println!(
                            "  {} Unknown command. Type {} for help.",
                            "⚠".yellow(),
                            "/help".bright_yellow()
                        );
                        continue;
                    }
                }

                // Send to agent
                match ag.run(trimmed).await {
                    Ok(response) => {
                        println!("\n{}\n", response.content);
                    }
                    Err(e) => {
                        println!("\n  {} {}\n", "error:".red().bold(), e);
                    }
                }
            }
            Err(ReadlineError::Interrupted) => {
                println!("^C");
                continue;
            }
            Err(ReadlineError::Eof) => {
                println!("exit");
                break;
            }
            Err(err) => {
                error!("Readline error: {}", err);
                break;
            }
        }
    }

    // Save on exit
    {
        let h = history.read().await;
        let _ = h.save().await;
    }
    {
        let m = memory.read().await;
        let _ = m.save().await;
    }

    Ok(())
}

async fn run_project(_resolved: &ResolvedConfig, args: &cli::ProjectArgs) -> anyhow::Result<()> {
    match &args.action {
        None => {
            println!("  Usage: gem project <create|list|show|remove>");
        }
        Some(cli::ProjectAction::List) => {
            println!("  No projects found.");
        }
        Some(cli::ProjectAction::Create { name, dir }) => {
            println!("  Creating project: {} {:?}", name, dir);
        }
        Some(cli::ProjectAction::Show { name }) => {
            println!("  Project: {}", name);
        }
        Some(cli::ProjectAction::Remove { name }) => {
            println!("  Removing project: {}", name);
        }
    }
    Ok(())
}

async fn run_jobs(_resolved: &ResolvedConfig, args: &cli::JobsArgs) -> anyhow::Result<()> {
    match &args.action {
        None => {
            println!("  Usage: gem jobs <list|show|cancel|clean>");
        }
        Some(cli::JobsAction::List { status }) => {
            println!("  No jobs found.");
            if let Some(s) = status {
                println!("  (filter: {:?})", s);
            }
        }
        Some(cli::JobsAction::Show { id }) => {
            println!("  Job: {}", id);
        }
        Some(cli::JobsAction::Cancel { id }) => {
            println!("  Cancelling job: {}", id);
        }
        Some(cli::JobsAction::Clean) => {
            println!("  Cleaned completed/failed jobs.");
        }
    }
    Ok(())
}

async fn run_models(resolved: &ResolvedConfig, args: &cli::ModelsArgs) -> anyhow::Result<()> {
    match &args.action {
        None => {
            println!("  Available models:");
            for model in &resolved.config.model.available {
                let marker = if model == &resolved.config.model.default {
                    " *".green().to_string()
                } else {
                    String::new()
                };
                println!("    {}{}", model, marker);
            }
        }
        Some(cli::ModelsAction::List { provider: _ }) => {
            println!("  Available models:");
            for model in &resolved.config.model.available {
                println!("    {}", model);
            }
        }
        Some(cli::ModelsAction::Default { name }) => {
            println!("  Default model set to: {}", name);
        }
        Some(cli::ModelsAction::Test { name, provider }) => {
            println!("  Testing model: {} (provider: {:?})", name, provider);
        }
    }
    Ok(())
}

async fn run_providers(resolved: &ResolvedConfig, args: &cli::ProvidersArgs) -> anyhow::Result<()> {
    match &args.action {
        None => {
            println!(
                "  Default provider: {} ({})",
                resolved.config.provider.default,
                resolved.config.provider.base_url
            );
        }
        Some(cli::ProvidersAction::List) => {
            println!("  Configured providers:");
            println!(
                "    {} — {}",
                resolved.config.provider.default,
                resolved.config.provider.base_url
            );
        }
        Some(cli::ProvidersAction::Show { name }) => {
            println!("  Provider: {}", name);
        }
        Some(cli::ProvidersAction::Test { name }) => {
            println!("  Testing provider: {}", name);
        }
    }
    Ok(())
}

async fn run_tools(_resolved: &ResolvedConfig, args: &cli::ToolsArgs) -> anyhow::Result<()> {
    let registry = ToolRegistry::with_builtins();

    match &args.action {
        None => {
            println!("  Available tools:");
            for name in registry.names() {
                if let Some(tool) = registry.get(name) {
                    println!("    {} — {}", name.bright_white(), tool.description());
                }
            }
        }
        Some(cli::ToolsAction::List { enabled }) => {
            let names = if *enabled {
                registry.enabled_names()
            } else {
                registry.names()
            };
            println!("  {}:", if *enabled { "Enabled tools" } else { "All tools" });
            for name in names {
                if let Some(tool) = registry.get(name) {
                    println!("    {} — {}", name.bright_white(), tool.description());
                }
            }
        }
        Some(cli::ToolsAction::Show { name }) => {
            if let Some(tool) = registry.get(name) {
                println!("  Tool: {}", tool.name().bright_white());
                println!("  Description: {}", tool.description());
                println!(
                    "  Requires approval: {}",
                    if tool.requires_approval() {
                        "yes".yellow()
                    } else {
                        "no".green()
                    }
                );
                println!(
                    "  Parameters:\n{}",
                    serde_json::to_string_pretty(&tool.parameters_schema())?
                );
            } else {
                println!("  {} Tool '{}' not found.", "⚠".yellow(), name);
            }
        }
        Some(cli::ToolsAction::Enable { name }) => {
            println!("  Tool '{}' enabled.", name);
        }
        Some(cli::ToolsAction::Disable { name }) => {
            println!("  Tool '{}' disabled.", name);
        }
    }
    Ok(())
}

async fn run_agents(resolved: &ResolvedConfig, args: &cli::AgentsArgs) -> anyhow::Result<()> {
    match &args.action {
        None => {
            println!("  Available agents: default");
        }
        Some(cli::AgentsAction::List) => {
            println!("  Available agents:");
            println!("    default — Standard agent with think/act/observe loop");
        }
        Some(cli::AgentsAction::Show { name }) => {
            println!("  Agent: {}", name);
            println!("    Model: {}", resolved.config.model.default);
            println!("    Max iterations: {}", resolved.config.agent.max_iterations);
            println!("    Tools: {}", resolved.config.tools.enabled.join(", "));
        }
        Some(cli::AgentsAction::Run { name, input }) => {
            println!("  Running agent: {} (input: {:?})", name, input);
        }
        Some(cli::AgentsAction::Swarm { config, agents }) => {
            println!("  Spawning swarm (config: {:?}, agents: {:?})", config, agents);
        }
    }
    Ok(())
}

async fn run_init(resolved: &ResolvedConfig, args: &cli::InitArgs) -> anyhow::Result<()> {
    println!("  Initializing Gem configuration...");

    if args.force {
        println!("  {} Force overwrite enabled.", "⚠".yellow());
    }

    ConfigLoader::write_defaults(&resolved.config_dir)?;

    println!(
        "  {} Config written to {}",
        "✓".green(),
        resolved.config_dir.display()
    );
    println!(
        "  {} Edit {} to add your API keys.",
        "→".green(),
        (resolved.config_dir.join("secrets.toml")).display()
    );

    Ok(())
}

// ── Logging ───────────────────────────────────────────────────────────

fn init_logging(cli: &Cli) {
    let level = if cli.debug {
        Level::DEBUG
    } else {
        match cli.log_level.to_lowercase().as_str() {
            "trace" => Level::TRACE,
            "debug" => Level::DEBUG,
            "info" => Level::INFO,
            "warn" => Level::WARN,
            "error" => Level::ERROR,
            _ => Level::INFO,
        }
    };

    let filter = EnvFilter::from_default_env()
        .add_directive(level.into());

    tracing_subscriber::fmt()
        .with_env_filter(filter)
        .with_target(false)
        .with_thread_ids(false)
        .init();
}
