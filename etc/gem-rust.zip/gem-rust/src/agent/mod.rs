//! Agent loop with think/act/observe cycle.
//!
//! The agent loop is the core of Gem's agentic behavior:
//! 1. **Think** — The LLM reasons about the current state and decides
//!    what to do (respond to the user or call a tool).
//! 2. **Act** — If a tool call is requested, execute it.
//! 3. **Observe** — Feed the tool result back to the LLM and repeat.
//!
//! Also includes job queue and swarm/multi-agent orchestration scaffolding.

use std::collections::HashMap;
use std::sync::Arc;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use tokio::sync::RwLock;
use tracing::{debug, info, instrument, warn};
use uuid::Uuid;

use crate::config::GemConfig;
use crate::memory::{ChatSession, HistoryStore, MemoryStore};
use crate::provider::{
    ChatMessage, CompletionRequest, CompletionResponse, ProviderRegistry,
};
use crate::tools::ToolRegistry;

// ── Agent state ───────────────────────────────────────────────────────

/// Phase of the agent loop.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum AgentPhase {
    Idle,
    Think,
    Act,
    Observe,
    Done,
    Error,
}

impl std::fmt::Display for AgentPhase {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            AgentPhase::Idle => write!(f, "idle"),
            AgentPhase::Think => write!(f, "think"),
            AgentPhase::Act => write!(f, "act"),
            AgentPhase::Observe => write!(f, "observe"),
            AgentPhase::Done => write!(f, "done"),
            AgentPhase::Error => write!(f, "error"),
        }
    }
}

/// Status of the agent.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentStatus {
    pub phase: AgentPhase,
    pub iteration: u32,
    pub max_iterations: u32,
    pub model: String,
    pub provider: String,
    pub session_id: String,
    pub tokens_used: u32,
    pub tools_called: u32,
    pub started_at: DateTime<Utc>,
}

// ── Agent config ──────────────────────────────────────────────────────

/// Configuration for a single agent instance.
#[derive(Debug, Clone)]
pub struct AgentConfig {
    pub model: String,
    pub provider: String,
    pub system_prompt: String,
    pub max_iterations: u32,
    pub auto_approve: bool,
    pub no_tools: bool,
}

impl AgentConfig {
    /// Build from global config with optional overrides.
    pub fn from_gem_config(
        config: &GemConfig,
        model: Option<&str>,
        provider: Option<&str>,
        system_prompt: Option<&str>,
        auto_approve: bool,
        no_tools: bool,
    ) -> Self {
        Self {
            model: model
                .map(|s| s.to_string())
                .unwrap_or_else(|| config.model.default.clone()),
            provider: provider
                .map(|s| s.to_string())
                .unwrap_or_else(|| config.provider.default.clone()),
            system_prompt: system_prompt
                .map(|s| s.to_string())
                .unwrap_or_else(|| config.agent.system_prompt.clone()),
            max_iterations: config.agent.max_iterations,
            auto_approve: auto_approve || config.agent.auto_approve,
            no_tools,
        }
    }
}

// ── Agent ─────────────────────────────────────────────────────────────

/// The main agent that drives the think/act/observe loop.
pub struct Agent {
    config: AgentConfig,
    session: ChatSession,
    status: AgentStatus,
    history: Arc<RwLock<HistoryStore>>,
    memory: Arc<RwLock<MemoryStore>>,
    providers: Arc<ProviderRegistry>,
    tools: Arc<ToolRegistry>,
}

impl Agent {
    /// Create a new agent.
    pub fn new(
        config: AgentConfig,
        history: Arc<RwLock<HistoryStore>>,
        memory: Arc<RwLock<MemoryStore>>,
        providers: Arc<ProviderRegistry>,
        tools: Arc<ToolRegistry>,
    ) -> Self {
        let session = ChatSession::with_system_prompt(
            &config.model,
            &config.provider,
            &config.system_prompt,
        );

        let status = AgentStatus {
            phase: AgentPhase::Idle,
            iteration: 0,
            max_iterations: config.max_iterations,
            model: config.model.clone(),
            provider: config.provider.clone(),
            session_id: session.id.clone(),
            tokens_used: 0,
            tools_called: 0,
            started_at: Utc::now(),
        };

        Self {
            config,
            session,
            status,
            history,
            memory,
            providers,
            tools,
        }
    }

    /// Get the current agent status.
    pub fn status(&self) -> &AgentStatus {
        &self.status
    }

    /// Get the current session.
    pub fn session(&self) -> &ChatSession {
        &self.session
    }

    /// Run a single user message through the agent loop.
    #[instrument(skip(self), fields(model = %self.config.model))]
    pub async fn run(&mut self, user_message: &str) -> Result<AgentResponse, AgentError> {
        // Add user message
        self.session.push(ChatMessage::user(user_message));
        self.status.phase = AgentPhase::Think;
        self.status.iteration = 0;

        let mut final_response = String::new();

        // Main agent loop
        loop {
            if self.status.iteration >= self.status.max_iterations {
                warn!("Max iterations reached ({})", self.status.max_iterations);
                break;
            }

            self.status.iteration += 1;
            self.status.phase = AgentPhase::Think;

            // ── THINK: call the LLM ──────────────────────────────
            let completion = self.think().await?;

            // Update token count
            if let Some(usage) = &completion.usage {
                self.status.tokens_used += usage.total_tokens;
            }

            // Extract the assistant's message
            let choice = completion
                .choices
                .first()
                .ok_or_else(|| AgentError::NoResponse)?;

            self.session.push(choice.message.clone());

            // Check if the LLM wants to call tools
            let tool_calls = choice.message.tool_calls.as_deref();

            match tool_calls {
                Some(calls) if !calls.is_empty() && !self.config.no_tools => {
                    // ── ACT: execute tool calls ───────────────────
                    self.status.phase = AgentPhase::Act;

                    for tool_call in calls {
                        info!("Tool call: {} ({})", tool_call.function.name, tool_call.id);

                        let result = self.act(&tool_call.function.name, &tool_call.function.arguments).await;

                        // ── OBSERVE: feed result back ────────────
                        self.status.phase = AgentPhase::Observe;
                        let observation = match result {
                            Ok(tool_result) => {
                                if tool_result.success {
                                    tool_result.output
                                } else {
                                    format!("[error] {}", tool_result.output)
                                }
                            }
                            Err(e) => format!("[tool error] {}", e),
                        };

                        self.session.push(ChatMessage::tool_result(
                            &tool_call.id,
                            &observation,
                        ));

                        self.status.tools_called += 1;
                    }
                }
                _ => {
                    // No tool calls — we're done
                    final_response = choice.message.content.clone();
                    break;
                }
            }
        }

        self.status.phase = AgentPhase::Done;

        // Persist the session
        {
            let mut history = self.history.write().await;
            history
                .sessions
                .insert(self.session.id.clone(), self.session.clone());
            let _ = history.save().await;
        }

        Ok(AgentResponse {
            content: final_response,
            iterations: self.status.iteration,
            tokens_used: self.status.tokens_used,
            tools_called: self.status.tools_called,
        })
    }

    /// THINK phase: send messages to the LLM.
    async fn think(&self) -> Result<CompletionResponse, AgentError> {
        let provider = self
            .providers
            .get(&self.config.provider)
            .ok_or_else(|| AgentError::ProviderNotFound(self.config.provider.clone()))?;

        let mut request = CompletionRequest {
            model: self.config.model.clone(),
            messages: self.session.messages.clone(),
            max_tokens: Some(crate::config::GemConfig::default().model.max_tokens),
            temperature: Some(crate::config::GemConfig::default().model.temperature),
            top_p: Some(crate::config::GemConfig::default().model.top_p),
            tools: None,
            stream: Some(false),
            stop: None,
        };

        // Add tool definitions if tools are enabled
        if !self.config.no_tools {
            request.tools = Some(self.tools.tool_definitions());
        }

        provider.complete(request).await.map_err(AgentError::Provider)
    }

    /// ACT phase: execute a tool.
    async fn act(&self, tool_name: &str, arguments: &str) -> Result<crate::tools::ToolResult, crate::tools::ToolError> {
        let tool = self
            .tools
            .get(tool_name)
            .ok_or_else(|| crate::tools::ToolError::Execution(format!("Unknown tool: {}", tool_name)))?;

        if self.tools.is_disabled(tool_name) {
            return Err(crate::tools::ToolError::Disabled(tool_name.to_string()));
        }

        // Parse arguments as JSON
        let params: serde_json::Value = if arguments.is_empty() {
            serde_json::json!({})
        } else {
            serde_json::from_str(arguments).unwrap_or_else(|_| {
                serde_json::json!({ "input": arguments })
            })
        };

        // Check if approval is needed
        if tool.requires_approval() && !self.config.auto_approve {
            // In a full implementation, this would prompt the user.
            // For now, we proceed (auto-approve can be toggled).
            debug!("Auto-approving tool call: {}", tool_name);
        }

        tool.execute(params).await
    }

    /// Inject a memory recall into the session context.
    pub async fn recall_memory(&self, query: &str) -> Vec<String> {
        let memory = self.memory.read().await;
        memory
            .search(query)
            .iter()
            .map(|e| format!("[{}] {} = {}", e.source, e.key, e.value))
            .collect()
    }
}

// ── Agent response ────────────────────────────────────────────────────

/// Final response from the agent loop.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentResponse {
    pub content: String,
    pub iterations: u32,
    pub tokens_used: u32,
    pub tools_called: u32,
}

// ── Job system ────────────────────────────────────────────────────────

/// Status of a background job.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum JobStatus {
    Pending,
    Running,
    Completed,
    Failed,
    Cancelled,
}

impl std::fmt::Display for JobStatus {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            JobStatus::Pending => write!(f, "pending"),
            JobStatus::Running => write!(f, "running"),
            JobStatus::Completed => write!(f, "completed"),
            JobStatus::Failed => write!(f, "failed"),
            JobStatus::Cancelled => write!(f, "cancelled"),
        }
    }
}

/// A background job.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Job {
    pub id: String,
    pub name: String,
    pub status: JobStatus,
    pub result: Option<String>,
    pub error: Option<String>,
    pub created_at: DateTime<Utc>,
    pub started_at: Option<DateTime<Utc>>,
    pub finished_at: Option<DateTime<Utc>>,
}

impl Job {
    pub fn new(name: impl Into<String>) -> Self {
        Self {
            id: Uuid::new_v4().to_string(),
            name: name.into(),
            status: JobStatus::Pending,
            result: None,
            error: None,
            created_at: Utc::now(),
            started_at: None,
            finished_at: None,
        }
    }
}

/// Job queue for background execution.
pub struct JobQueue {
    jobs: HashMap<String, Job>,
    max_concurrent: usize,
}

impl JobQueue {
    pub fn new(max_concurrent: usize) -> Self {
        Self {
            jobs: HashMap::new(),
            max_concurrent,
        }
    }

    /// Add a job to the queue.
    pub fn enqueue(&mut self, name: impl Into<String>) -> String {
        let job = Job::new(name);
        let id = job.id.clone();
        self.jobs.insert(id.clone(), job);
        id
    }

    /// Get a job by ID.
    pub fn get(&self, id: &str) -> Option<&Job> {
        self.jobs.get(id)
    }

    /// Update a job's status.
    pub fn update_status(&mut self, id: &str, status: JobStatus) {
        if let Some(job) = self.jobs.get_mut(id) {
            job.status = status;
            match status {
                JobStatus::Running => job.started_at = Some(Utc::now()),
                JobStatus::Completed | JobStatus::Failed | JobStatus::Cancelled => {
                    job.finished_at = Some(Utc::now())
                }
                _ => {}
            }
        }
    }

    /// List all jobs.
    pub fn list(&self) -> Vec<&Job> {
        self.jobs.values().collect()
    }

    /// List jobs by status.
    pub fn list_by_status(&self, status: JobStatus) -> Vec<&Job> {
        self.jobs.values().filter(|j| j.status == status).collect()
    }

    /// Cancel a job.
    pub fn cancel(&mut self, id: &str) -> bool {
        if let Some(job) = self.jobs.get_mut(id) {
            if matches!(job.status, JobStatus::Pending | JobStatus::Running) {
                job.status = JobStatus::Cancelled;
                job.finished_at = Some(Utc::now());
                return true;
            }
        }
        false
    }

    /// Clean up completed/failed/cancelled jobs.
    pub fn clean(&mut self) {
        self.jobs.retain(|_, job| {
            matches!(job.status, JobStatus::Pending | JobStatus::Running)
        });
    }

    /// Count of running jobs.
    pub fn running_count(&self) -> usize {
        self.jobs.values().filter(|j| j.status == JobStatus::Running).count()
    }
}

// ── Swarm / multi-agent ───────────────────────────────────────────────

/// Agent descriptor for swarm orchestration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentDescriptor {
    pub name: String,
    pub model: String,
    pub role: String,
    pub system_prompt: String,
}

/// Swarm configuration for multi-agent orchestration.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SwarmConfig {
    pub name: String,
    pub agents: Vec<AgentDescriptor>,
    pub strategy: SwarmStrategy,
    pub max_rounds: u32,
}

/// Orchestration strategy for the swarm.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum SwarmStrategy {
    /// Run agents sequentially, each getting the previous output.
    Sequential,
    /// Run agents in parallel and merge results.
    Parallel,
    /// Supervisor agent delegates to workers.
    Supervisor,
    /// Round-robin between agents.
    RoundRobin,
}

// ── Errors ────────────────────────────────────────────────────────────

#[derive(Debug, thiserror::Error)]
pub enum AgentError {
    #[error("Provider not found: {0}")]
    ProviderNotFound(String),

    #[error("Provider error: {0}")]
    Provider(#[from] crate::provider::ProviderError),

    #[error("Tool error: {0}")]
    Tool(#[from] crate::tools::ToolError),

    #[error("No response from LLM")]
    NoResponse,

    #[error("Max iterations exceeded")]
    MaxIterations,

    #[error("Cancelled")]
    Cancelled,
}
