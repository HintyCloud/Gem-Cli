//! Tool trait, registry, and built-in tool implementations.
//!
//! The Gem CLI tool system provides a registry of named tools that the
//! agent can invoke during the act phase of the think/act/observe loop.
//!
//! Built-in tools: shell, files, web_search, image, git, archive, artifacts.

use std::collections::HashMap;

use async_trait::async_trait;
use serde::{Deserialize, Serialize};
use serde_json::Value;

// ── Tool trait ────────────────────────────────────────────────────────

/// The core tool trait. Every tool must implement `execute`.
#[async_trait]
pub trait Tool: Send + Sync {
    /// Unique name of the tool (e.g. "shell", "files").
    fn name(&self) -> &str;

    /// Human-readable description.
    fn description(&self) -> &str;

    /// JSON Schema describing the parameters this tool accepts.
    fn parameters_schema(&self) -> Value;

    /// Whether the tool is currently enabled.
    fn enabled(&self) -> bool {
        true
    }

    /// Whether the tool requires user approval before execution.
    fn requires_approval(&self) -> bool {
        true
    }

    /// Execute the tool with the given parameters.
    async fn execute(&self, params: Value) -> Result<ToolResult, ToolError>;
}

// ── Tool result ───────────────────────────────────────────────────────

/// Result of a tool execution.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToolResult {
    pub output: String,
    pub success: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub artifacts: Option<Vec<Artifact>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub metadata: Option<HashMap<String, Value>>,
}

impl ToolResult {
    /// Create a successful result with text output.
    pub fn ok(output: impl Into<String>) -> Self {
        Self {
            output: output.into(),
            success: true,
            artifacts: None,
            metadata: None,
        }
    }

    /// Create a failed result with an error message.
    pub fn err(output: impl Into<String>) -> Self {
        Self {
            output: output.into(),
            success: false,
            artifacts: None,
            metadata: None,
        }
    }

    /// Add an artifact to the result.
    pub fn with_artifact(mut self, artifact: Artifact) -> Self {
        self.artifacts.get_or_insert_with(Vec::new).push(artifact);
        self
    }
}

/// An artifact produced by a tool (file, image, etc.).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Artifact {
    pub kind: ArtifactKind,
    pub name: String,
    pub path: Option<String>,
    pub content: Option<String>,
}

/// Kind of artifact.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ArtifactKind {
    File,
    Image,
    Url,
    Data,
}

// ── Tool error ────────────────────────────────────────────────────────

#[derive(Debug, thiserror::Error)]
pub enum ToolError {
    #[error("Execution error: {0}")]
    Execution(String),

    #[error("Invalid parameters: {0}")]
    InvalidParams(String),

    #[error("Permission denied: {0}")]
    PermissionDenied(String),

    #[error("Timeout after {0}s")]
    Timeout(u64),

    #[error("Tool is disabled: {0}")]
    Disabled(String),
}

// ── Tool registry ─────────────────────────────────────────────────────

/// Registry that holds all available tools.
pub struct ToolRegistry {
    tools: HashMap<String, Box<dyn Tool>>,
    disabled: Vec<String>,
}

impl ToolRegistry {
    /// Create an empty registry.
    pub fn new() -> Self {
        Self {
            tools: HashMap::new(),
            disabled: Vec::new(),
        }
    }

    /// Create a registry with all built-in tools registered.
    pub fn with_builtins() -> Self {
        let mut registry = Self::new();
        registry.register_builtin::<ShellTool>();
        registry.register_builtin::<FilesTool>();
        registry.register_builtin::<WebSearchTool>();
        registry.register_builtin::<ImageTool>();
        registry.register_builtin::<GitTool>();
        registry.register_builtin::<ArchiveTool>();
        registry.register_builtin::<ArtifactsTool>();
        registry
    }

    /// Register a built-in tool by type.
    fn register_builtin<T: Tool + Default + 'static>(&mut self) {
        let tool = T::default();
        self.tools.insert(tool.name().to_string(), Box::new(tool));
    }

    /// Register a custom tool.
    pub fn register(&mut self, tool: Box<dyn Tool>) {
        self.tools.insert(tool.name().to_string(), tool);
    }

    /// Get a tool by name.
    pub fn get(&self, name: &str) -> Option<&dyn Tool> {
        self.tools.get(name).map(|t| t.as_ref())
    }

    /// List all registered tool names.
    pub fn names(&self) -> Vec<&str> {
        self.tools.keys().map(|s| s.as_str()).collect()
    }

    /// List all enabled tool names.
    pub fn enabled_names(&self) -> Vec<&str> {
        self.tools
            .keys()
            .filter(|name| !self.disabled.contains(name))
            .map(|s| s.as_str())
            .collect()
    }

    /// Disable a tool by name.
    pub fn disable(&mut self, name: &str) {
        if !self.disabled.contains(&name.to_string()) {
            self.disabled.push(name.to_string());
        }
    }

    /// Enable a tool by name.
    pub fn enable(&mut self, name: &str) {
        self.disabled.retain(|n| n != name);
    }

    /// Check if a tool is disabled.
    pub fn is_disabled(&self, name: &str) -> bool {
        self.disabled.contains(&name.to_string())
    }

    /// Generate tool definitions in OpenAI function-calling format.
    pub fn tool_definitions(&self) -> Vec<crate::provider::ToolDefinition> {
        self.tools
            .iter()
            .filter(|(name, _)| !self.disabled.contains(name))
            .map(|(_, tool)| {
                crate::provider::ToolDefinition::new(
                    tool.name(),
                    tool.description(),
                    tool.parameters_schema(),
                )
            })
            .collect()
    }
}

impl Default for ToolRegistry {
    fn default() -> Self {
        Self::with_builtins()
    }
}

// ── Built-in tools ────────────────────────────────────────────────────
// Each built-in tool is a unit struct that implements the Tool trait.
// They serve as stubs that can be fully implemented later.

/// Shell tool — execute shell commands.
pub struct ShellTool;

impl Default for ShellTool {
    fn default() -> Self {
        Self
    }
}

#[async_trait]
impl Tool for ShellTool {
    fn name(&self) -> &str {
        "shell"
    }
    fn description(&self) -> &str {
        "Execute shell commands on the host system"
    }
    fn parameters_schema(&self) -> Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute"
                },
                "cwd": {
                    "type": "string",
                    "description": "Working directory (optional)"
                }
            },
            "required": ["command"]
        })
    }
    fn requires_approval(&self) -> bool {
        true
    }
    async fn execute(&self, params: Value) -> Result<ToolResult, ToolError> {
        let command = params
            .get("command")
            .and_then(|v| v.as_str())
            .ok_or_else(|| ToolError::InvalidParams("Missing 'command' parameter".into()))?;

        // Security: block dangerous commands
        let dangerous = ["rm -rf /", "mkfs", "dd if=", ":(){ :|:& };:"];
        if dangerous.iter().any(|d| command.contains(d)) {
            return Err(ToolError::PermissionDenied(
                format!("Blocked dangerous command: {}", command),
            ));
        }

        #[cfg(unix)]
        let shell = "/bin/sh";
        #[cfg(windows)]
        let shell = "cmd.exe";
        #[cfg(unix)]
        let flag = "-c";
        #[cfg(windows)]
        let flag = "/C";

        let output = tokio::process::Command::new(shell)
            .arg(flag)
            .arg(command)
            .output()
            .await
            .map_err(|e| ToolError::Execution(e.to_string()))?;

        let stdout = String::from_utf8_lossy(&output.stdout).to_string();
        let stderr = String::from_utf8_lossy(&output.stderr).to_string();

        if output.status.success() {
            Ok(ToolResult::ok(if stderr.is_empty() {
                stdout
            } else {
                format!("{}\n[stderr] {}", stdout, stderr)
            }))
        } else {
            Ok(ToolResult::err(format!(
                "Exit code {}: {}",
                output.status.code().unwrap_or(-1),
                stderr
            )))
        }
    }
}

/// Files tool — read, write, list files.
pub struct FilesTool;

impl Default for FilesTool {
    fn default() -> Self {
        Self
    }
}

#[async_trait]
impl Tool for FilesTool {
    fn name(&self) -> &str {
        "files"
    }
    fn description(&self) -> &str {
        "Read, write, list, and manage files on the host system"
    }
    fn parameters_schema(&self) -> Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["read", "write", "list", "delete", "exists"],
                    "description": "The file operation to perform"
                },
                "path": {
                    "type": "string",
                    "description": "File or directory path"
                },
                "content": {
                    "type": "string",
                    "description": "Content to write (for write action)"
                }
            },
            "required": ["action", "path"]
        })
    }
    async fn execute(&self, params: Value) -> Result<ToolResult, ToolError> {
        let action = params
            .get("action")
            .and_then(|v| v.as_str())
            .ok_or_else(|| ToolError::InvalidParams("Missing 'action' parameter".into()))?;
        let path = params
            .get("path")
            .and_then(|v| v.as_str())
            .ok_or_else(|| ToolError::InvalidParams("Missing 'path' parameter".into()))?;

        match action {
            "read" => {
                let content = tokio::fs::read_to_string(path)
                    .await
                    .map_err(|e| ToolError::Execution(e.to_string()))?;
                Ok(ToolResult::ok(content))
            }
            "write" => {
                let content = params
                    .get("content")
                    .and_then(|v| v.as_str())
                    .ok_or_else(|| ToolError::InvalidParams("Missing 'content' for write".into()))?;
                tokio::fs::write(path, content)
                    .await
                    .map_err(|e| ToolError::Execution(e.to_string()))?;
                Ok(ToolResult::ok(format!("Written {} bytes to {}", content.len(), path)))
            }
            "list" => {
                let mut entries = tokio::fs::read_dir(path)
                    .await
                    .map_err(|e| ToolError::Execution(e.to_string()))?;
                let mut names = Vec::new();
                while let Some(entry) = entries.next_entry().await.map_err(|e| ToolError::Execution(e.to_string()))? {
                    names.push(entry.file_name().to_string_lossy().to_string());
                }
                Ok(ToolResult::ok(names.join("\n")))
            }
            "delete" => {
                tokio::fs::remove_file(path)
                    .await
                    .map_err(|e| ToolError::Execution(e.to_string()))?;
                Ok(ToolResult::ok(format!("Deleted {}", path)))
            }
            "exists" => {
                let exists = tokio::fs::metadata(path).await.is_ok();
                Ok(ToolResult::ok(exists.to_string()))
            }
            _ => Err(ToolError::InvalidParams(format!("Unknown action: {}", action))),
        }
    }
}

/// Web search tool stub.
pub struct WebSearchTool;

impl Default for WebSearchTool {
    fn default() -> Self {
        Self
    }
}

#[async_trait]
impl Tool for WebSearchTool {
    fn name(&self) -> &str {
        "web_search"
    }
    fn description(&self) -> &str {
        "Search the web for information"
    }
    fn parameters_schema(&self) -> Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "query": { "type": "string", "description": "Search query" },
                "max_results": { "type": "integer", "description": "Max results (default 10)" }
            },
            "required": ["query"]
        })
    }
    async fn execute(&self, params: Value) -> Result<ToolResult, ToolError> {
        let query = params
            .get("query")
            .and_then(|v| v.as_str())
            .ok_or_else(|| ToolError::InvalidParams("Missing 'query' parameter".into()))?;
        // Stub — would integrate with a search API
        Ok(ToolResult::ok(format!("[web_search stub] Query: {}", query)))
    }
}

/// Image tool stub.
pub struct ImageTool;

impl Default for ImageTool {
    fn default() -> Self {
        Self
    }
}

#[async_trait]
impl Tool for ImageTool {
    fn name(&self) -> &str {
        "image"
    }
    fn description(&self) -> &str {
        "Generate, edit, or analyze images"
    }
    fn parameters_schema(&self) -> Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "action": { "type": "string", "enum": ["generate", "edit", "analyze"] },
                "prompt": { "type": "string" }
            },
            "required": ["action"]
        })
    }
    async fn execute(&self, params: Value) -> Result<ToolResult, ToolError> {
        let action = params
            .get("action")
            .and_then(|v| v.as_str())
            .unwrap_or("generate");
        Ok(ToolResult::ok(format!("[image stub] action={}", action)))
    }
}

/// Git tool stub.
pub struct GitTool;

impl Default for GitTool {
    fn default() -> Self {
        Self
    }
}

#[async_trait]
impl Tool for GitTool {
    fn name(&self) -> &str {
        "git"
    }
    fn description(&self) -> &str {
        "Execute git operations"
    }
    fn parameters_schema(&self) -> Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "command": { "type": "string", "description": "Git command (status, log, diff, etc.)" },
                "args": { "type": "array", "items": { "type": "string" } }
            },
            "required": ["command"]
        })
    }
    fn requires_approval(&self) -> bool {
        true
    }
    async fn execute(&self, params: Value) -> Result<ToolResult, ToolError> {
        let command = params
            .get("command")
            .and_then(|v| v.as_str())
            .ok_or_else(|| ToolError::InvalidParams("Missing 'command'".into()))?;

        let mut cmd = tokio::process::Command::new("git");
        cmd.arg(command);

        if let Some(args) = params.get("args").and_then(|v| v.as_array()) {
            for arg in args {
                if let Some(s) = arg.as_str() {
                    cmd.arg(s);
                }
            }
        }

        let output = cmd.output().await.map_err(|e| ToolError::Execution(e.to_string()))?;
        let stdout = String::from_utf8_lossy(&output.stdout).to_string();

        if output.status.success() {
            Ok(ToolResult::ok(stdout))
        } else {
            let stderr = String::from_utf8_lossy(&output.stderr).to_string();
            Ok(ToolResult::err(stderr))
        }
    }
}

/// Archive tool stub.
pub struct ArchiveTool;

impl Default for ArchiveTool {
    fn default() -> Self {
        Self
    }
}

#[async_trait]
impl Tool for ArchiveTool {
    fn name(&self) -> &str {
        "archive"
    }
    fn description(&self) -> &str {
        "Create or extract archives (zip, tar, etc.)"
    }
    fn parameters_schema(&self) -> Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "action": { "type": "string", "enum": ["create", "extract", "list"] },
                "path": { "type": "string" }
            },
            "required": ["action", "path"]
        })
    }
    async fn execute(&self, params: Value) -> Result<ToolResult, ToolError> {
        let action = params
            .get("action")
            .and_then(|v| v.as_str())
            .unwrap_or("list");
        Ok(ToolResult::ok(format!("[archive stub] action={}", action)))
    }
}

/// Artifacts tool stub.
pub struct ArtifactsTool;

impl Default for ArtifactsTool {
    fn default() -> Self {
        Self
    }
}

#[async_trait]
impl Tool for ArtifactsTool {
    fn name(&self) -> &str {
        "artifacts"
    }
    fn description(&self) -> &str {
        "Manage project artifacts (code, documents, etc.)"
    }
    fn parameters_schema(&self) -> Value {
        serde_json::json!({
            "type": "object",
            "properties": {
                "action": { "type": "string", "enum": ["create", "read", "update", "delete", "list"] },
                "name": { "type": "string" },
                "content": { "type": "string" }
            },
            "required": ["action"]
        })
    }
    async fn execute(&self, params: Value) -> Result<ToolResult, ToolError> {
        let action = params
            .get("action")
            .and_then(|v| v.as_str())
            .unwrap_or("list");
        Ok(ToolResult::ok(format!("[artifacts stub] action={}", action)))
    }
}
