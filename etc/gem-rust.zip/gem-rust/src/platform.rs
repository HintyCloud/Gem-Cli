//! Platform detection for Gem CLI.
//!
//! Identifies the current OS and environment (Linux, Windows, macOS, Termux)
//! and provides platform-specific paths and capabilities.

use std::fmt;
use std::path::PathBuf;

/// Supported platforms.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Platform {
    Linux,
    Windows,
    MacOs,
    Termux,
    Unknown,
}

impl fmt::Display for Platform {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Platform::Linux => write!(f, "Linux"),
            Platform::Windows => write!(f, "Windows"),
            Platform::MacOs => write!(f, "macOS"),
            Platform::Termux => write!(f, "Termux"),
            Platform::Unknown => write!(f, "Unknown"),
        }
    }
}

/// Detected platform information.
#[derive(Debug, Clone)]
pub struct PlatformInfo {
    pub platform: Platform,
    pub os: String,
    pub arch: String,
    pub is_termux: bool,
    pub shell: String,
    pub home_dir: PathBuf,
    pub config_dir: PathBuf,
    pub data_dir: PathBuf,
}

impl PlatformInfo {
    /// Detect the current platform and gather information.
    pub fn detect() -> Self {
        let platform = Self::detect_platform();
        let os = std::env::consts::OS.to_string();
        let arch = std::env::consts::ARCH.to_string();
        let is_termux = Self::is_termux();

        let home_dir = dirs::home_dir().unwrap_or_else(|| PathBuf::from("."));
        let config_dir = Self::config_dir(&home_dir, platform);
        let data_dir = Self::data_dir(&home_dir, platform);
        let shell = Self::detect_shell(platform, is_termux);

        Self {
            platform,
            os,
            arch,
            is_termux,
            shell,
            home_dir,
            config_dir,
            data_dir,
        }
    }

    fn detect_platform() -> Platform {
        if cfg!(target_os = "linux") {
            if Self::is_termux() {
                Platform::Termux
            } else {
                Platform::Linux
            }
        } else if cfg!(target_os = "windows") {
            Platform::Windows
        } else if cfg!(target_os = "macos") {
            Platform::MacOs
        } else {
            Platform::Unknown
        }
    }

    fn is_termux() -> bool {
        std::env::var("TERMUX_VERSION").is_ok()
            || std::env::var("PREFIX")
                .map(|p| p.contains("com.termux"))
                .unwrap_or(false)
    }

    fn detect_shell(platform: Platform, is_termux: bool) -> String {
        if is_termux {
            return "bash".to_string();
        }

        // Try SHELL env var first (Unix)
        if let Ok(shell) = std::env::var("SHELL") {
            return shell;
        }

        // Try ComSpec on Windows
        if let Ok(comspec) = std::env::var("COMSPEC") {
            return comspec;
        }

        match platform {
            Platform::Windows => "cmd.exe".to_string(),
            Platform::MacOs => "/bin/zsh".to_string(),
            _ => "/bin/bash".to_string(),
        }
    }

    fn config_dir(home: &PathBuf, platform: Platform) -> PathBuf {
        match platform {
            Platform::Windows => {
                // %APPDATA%\gem
                dirs::config_dir().unwrap_or_else(|| home.join("AppData").join("Roaming"))
            }
            Platform::Termux => home.join(".termux").join("gem"),
            _ => dirs::config_dir()
                .unwrap_or_else(|| home.join(".config"))
                .join("gem"),
        }
    }

    fn data_dir(home: &PathBuf, platform: Platform) -> PathBuf {
        match platform {
            Platform::Windows => {
                dirs::data_dir().unwrap_or_else(|| home.join("AppData").join("Local"))
            }
            Platform::Termux => home.join(".termux").join("gem").join("data"),
            _ => dirs::data_local_dir()
                .unwrap_or_else(|| home.join(".local").join("share"))
                .join("gem"),
        }
    }

    /// Returns the Gem config directory (config/ subfolder inside config_dir).
    pub fn gem_config_dir(&self) -> PathBuf {
        self.config_dir.join("config")
    }

    /// Returns true if the platform supports Unix signals.
    pub fn supports_unix_signals(&self) -> bool {
        matches!(self.platform, Platform::Linux | Platform::MacOs | Platform::Termux)
    }

    /// Returns true if the platform supports `pty` (pseudo-terminals).
    pub fn supports_pty(&self) -> bool {
        !matches!(self.platform, Platform::Windows)
    }

    /// Returns a summary string for display.
    pub fn summary(&self) -> String {
        format!(
            "Platform: {} | OS: {} | Arch: {} | Shell: {} | Termux: {}",
            self.platform, self.os, self.arch, self.shell, self.is_termux
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_detect() {
        let info = PlatformInfo::detect();
        assert!(!info.os.is_empty());
        assert!(!info.arch.is_empty());
        assert!(!info.shell.is_empty());
    }

    #[test]
    fn test_platform_display() {
        assert_eq!(Platform::Linux.to_string(), "Linux");
        assert_eq!(Platform::Windows.to_string(), "Windows");
        assert_eq!(Platform::MacOs.to_string(), "macOS");
        assert_eq!(Platform::Termux.to_string(), "Termux");
    }
}
