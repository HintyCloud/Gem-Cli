# Gem CLI (Rust) — Agentic AI Ecosystem

**Version 1.0.0** | **License: GPL-3.0** | **HintyCloud**

A high-performance Rust implementation of the Gem CLI agentic AI ecosystem, featuring multi-provider LLM support, a tool registry, an agent loop with think/act/observe cycle, persistent memory, background job execution, and swarm/multi-agent orchestration.

---

## Features

- **CLI Commands**: `status`, `serve`, `chat`, `project`, `jobs`, `models`, `providers`, `tools`, `agents`, `init`
- **Interactive Chat**: REPL with slash commands (`/help`, `/model`, `/provider`, `/chats`, `/new`, `/clear`, `/status`, `/jobs`, `/agents`, `/tools`, `/exit`)
- **Configuration**: TOML-based config (`config/config.toml` + `config/secrets.toml`)
- **Providers**: OpenCode API with OpenAI-compatible chat completions endpoint
- **Tool Registry**: 7 built-in tools — `shell`, `files`, `web_search`, `image`, `git`, `archive`, `artifacts`
- **Agent Loop**: Think → Act → Observe cycle with configurable max iterations
- **Memory System**: Session history + persistent cross-session memory
- **Job Queue**: Background job execution with status tracking
- **Swarm**: Multi-agent orchestration (sequential, parallel, supervisor, round-robin)
- **Platform Detection**: Linux, Windows, macOS, Termux
- **Server**: FastAPI-compatible HTTP + WebSocket (scaffolded)

---

## Build

### Prerequisites

- [Rust](https://rustup.rs/) 1.75+ (edition 2021)
- [Cargo](https://doc.rust-lang.org/cargo/) (included with Rust)

### Compile

```bash
# Debug build
cargo build

# Release build (optimized, stripped)
cargo build --release
```

The binary will be at `target/debug/gem` or `target/release/gem`.

### Install

```bash
cargo install --path .
```

---

## Usage

### Initialize Configuration

```bash
gem init
```

This creates `~/.config/gem/config/config.toml` and `~/.config/gem/config/secrets.toml`.

### Check Status

```bash
gem status
gem status --verbose
gem status --format json
```

### Interactive Chat

```bash
gem chat
gem chat --model gpt-4o --provider opencode
gem chat --auto-approve
gem chat --no-tools
```

### One-shot Message

```bash
gem chat --message "Explain Rust ownership in one paragraph"
```

### Manage Models

```bash
gem models
gem models list
gem models default gpt-4o
```

### Manage Tools

```bash
gem tools
gem tools list --enabled
gem tools show shell
gem tools enable web_search
gem tools disable archive
```

### Serve API

```bash
gem serve
gem serve --host 127.0.0.1 --port 8080 --workers 8
```

### Slash Commands (in Chat)

| Command     | Description                     |
|-------------|---------------------------------|
| `/help`     | Show available slash commands    |
| `/model`    | Show or switch current model     |
| `/provider` | Show or switch current provider  |
| `/chats`    | List previous chat sessions      |
| `/new`      | Start a new chat session         |
| `/clear`    | Clear current chat history       |
| `/status`   | Show agent status                |
| `/jobs`     | Show running background jobs     |
| `/agents`   | List available agents            |
| `/tools`    | List available tools             |
| `/exit`     | Exit chat mode                   |

---

## Configuration

### `config.toml`

```toml
[core]
name = "gem"
debug = false
log_level = "info"

[model]
default = "opencode"
max_tokens = 4096
temperature = 0.7

[provider]
default = "opencode"
base_url = "https://api.opencode.ai/v1"
timeout_secs = 120

[agent]
max_iterations = 50
auto_approve = false
sandbox = true

[memory]
enabled = true
max_history = 1000
persist = true

[tools]
enabled = ["shell", "files", "web_search", "image", "git", "archive", "artifacts"]
```

### `secrets.toml`

```toml
[api_keys]
opencode = "sk-..."
# openai = "sk-..."
# anthropic = "sk-ant-..."
```

**⚠ Never commit `secrets.toml` to version control.**

---

## Architecture

```
src/
├── main.rs       — Entry point, CLI dispatch, command handlers
├── cli.rs        — Clap derive CLI definitions + slash commands
├── config.rs     — TOML config loading, resolution, defaults
├── provider.rs   — Provider trait + OpenCode (OpenAI-compatible) impl
├── platform.rs   — OS/platform detection + paths
├── agent/
│   └── mod.rs    — Agent loop, job queue, swarm orchestration
├── memory/
│   └── mod.rs    — Chat session history + persistent memory store
└── tools/
    └── mod.rs    — Tool trait, registry, 7 built-in tool impls
```

---

## Dependencies

| Crate                | Purpose                           |
|----------------------|-----------------------------------|
| `clap`               | CLI argument parsing (derive)     |
| `tokio`              | Async runtime                     |
| `reqwest`            | HTTP client (rustls TLS)          |
| `serde` / `toml`     | Serialization / config parsing    |
| `tracing`            | Structured logging                |
| `uuid`               | Unique IDs for sessions/jobs      |
| `chrono`             | Timestamps                        |
| `async-trait`        | Async trait support               |
| `rustyline`          | Readline for interactive chat     |
| `colored`            | Terminal colors                   |

---

## License

GPL-3.0 — See [LICENSE](./LICENSE) for details.

---

## Links

- **HintyCloud**: https://hinty.cloud
- **Repository**: https://github.com/HintyCloud/gem-rust

---

# Gem CLI (Rust) — Ecossistema de IA Agentiva

**Versão 1.0.0** | **Licença: GPL-3.0** | **HintyCloud**

Uma implementação em Rust de alta performance do ecossistema de IA agentiva Gem CLI, com suporte a múltiplos provedores de LLM, registro de ferramentas, loop de agente com ciclo pensar/agir/observar, memória persistente, execução de jobs em segundo plano e orquestração de enxame/multi-agente.

---

## Funcionalidades

- **Comandos CLI**: `status`, `serve`, `chat`, `project`, `jobs`, `models`, `providers`, `tools`, `agents`, `init`
- **Chat Interativo**: REPL com comandos slash (`/help`, `/model`, `/provider`, `/chats`, `/new`, `/clear`, `/status`, `/jobs`, `/agents`, `/tools`, `/exit`)
- **Configuração**: Configuração baseada em TOML (`config/config.toml` + `config/secrets.toml`)
- **Provedores**: API OpenCode com endpoint de chat completions compatível com OpenAI
- **Registro de Ferramentas**: 7 ferramentas integradas — `shell`, `files`, `web_search`, `image`, `git`, `archive`, `artifacts`
- **Loop do Agente**: Ciclo Pensar → Agir → Observar com iterações máximas configuráveis
- **Sistema de Memória**: Histórico de sessão + memória persistente entre sessões
- **Fila de Jobs**: Execução de jobs em segundo plano com rastreamento de status
- **Enxame**: Orquestração multi-agente (sequencial, paralelo, supervisor, round-robin)
- **Detecção de Plataforma**: Linux, Windows, macOS, Termux
- **Servidor**: HTTP + WebSocket compatível com FastAPI (esboçado)

---

## Compilação

### Pré-requisitos

- [Rust](https://rustup.rs/) 1.75+ (edição 2021)
- [Cargo](https://doc.rust-lang.org/cargo/) (incluído com Rust)

### Compilar

```bash
# Build de debug
cargo build

# Build de release (otimizado, sem símbolos de debug)
cargo build --release
```

O binário ficará em `target/debug/gem` ou `target/release/gem`.

### Instalar

```bash
cargo install --path .
```

---

## Uso

### Inicializar Configuração

```bash
gem init
```

Cria `~/.config/gem/config/config.toml` e `~/.config/gem/config/secrets.toml`.

### Verificar Status

```bash
gem status
gem status --verbose
gem status --format json
```

### Chat Interativo

```bash
gem chat
gem chat --model gpt-4o --provider opencode
gem chat --auto-approve
gem chat --no-tools
```

### Mensagem Única

```bash
gem chat --message "Explique ownership em Rust em um parágrafo"
```

### Gerenciar Modelos

```bash
gem models
gem models list
gem models default gpt-4o
```

### Gerenciar Ferramentas

```bash
gem tools
gem tools list --enabled
gem tools show shell
gem tools enable web_search
gem tools disable archive
```

### Servir API

```bash
gem serve
gem serve --host 127.0.0.1 --port 8080 --workers 8
```

---

## Configuração

### `config.toml`

```toml
[core]
name = "gem"
debug = false
log_level = "info"

[model]
default = "opencode"
max_tokens = 4096
temperature = 0.7

[provider]
default = "opencode"
base_url = "https://api.opencode.ai/v1"
timeout_secs = 120

[agent]
max_iterations = 50
auto_approve = false
sandbox = true

[memory]
enabled = true
max_history = 1000
persist = true

[tools]
enabled = ["shell", "files", "web_search", "image", "git", "archive", "artifacts"]
```

### `secrets.toml`

```toml
[api_keys]
opencode = "sk-..."
# openai = "sk-..."
# anthropic = "sk-ant-..."
```

**⚠ Nunca commite `secrets.toml` no controle de versão.**

---

## Arquitetura

```
src/
├── main.rs       — Ponto de entrada, despacho CLI, handlers de comando
├── cli.rs        — Definições CLI com Clap derive + comandos slash
├── config.rs     — Carregamento de config TOML, resolução, padrões
├── provider.rs   — Trait de provider + impl OpenCode (compatível OpenAI)
├── platform.rs   — Detecção de OS/plataforma + caminhos
├── agent/
│   └── mod.rs    — Loop do agente, fila de jobs, orquestração de enxame
├── memory/
│   └── mod.rs    — Histórico de sessão de chat + armazenamento de memória persistente
└── tools/
    └── mod.rs    — Trait de ferramenta, registro, 7 implementações integradas
```

---

## Licença

GPL-3.0 — Veja [LICENSE](./LICENSE) para detalhes.

---

## Links

- **HintyCloud**: https://hinty.cloud
- **Repositório**: https://github.com/HintyCloud/gem-rust
