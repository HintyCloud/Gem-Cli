# 💎 Gem CLI

**A Bash-based AI agent with tool use, memory, and provider system.**

```
gem v1.0.0 | HintyCloud | GPL-3.0
```

---

## 📖 English Documentation

### Overview

Gem CLI is a command-line AI agent written in Bash 4+ that provides:

- **Interactive chat** with an AI via OpenCode API (or compatible endpoints)
- **Tool use** — the agent can execute shell commands, manage files, search the web, run git, handle archives, and manage code artifacts
- **Long-term memory** — persistent key-value storage across sessions
- **Conversation history** — full session tracking with export capabilities
- **Provider system** — pluggable API backends (OpenCode, OpenAI, Anthropic, local)
- **Background jobs** — submit tasks and check status asynchronously
- **Platform detection** — OS, arch, distro, terminal capabilities

### Requirements

| Dependency | Required | Purpose |
|-----------|----------|---------|
| Bash 4+ | ✅ | Associative arrays, advanced features |
| curl | ✅ | API HTTP requests |
| jq | ✅ | JSON parsing and construction |
| git | Optional | Git tool support |
| fzf | Optional | Fuzzy selection in prompts |
| bat | Optional | Syntax-highlighted output |
| rg (ripgrep) | Optional | Fast file search |

### Installation

```bash
# Clone and install
git clone https://github.com/HintyCloud/gem-bash.git
cd gem-bash
chmod +x install.sh
./install.sh

# Install to custom prefix
./install.sh --prefix /usr/local

# Verbose installation
./install.sh --verbose

# Uninstall
./install.sh --uninstall
```

### Quick Start

```bash
# Set your API key
export GEM_API_KEY="your-api-key-here"
# Or: gem config set GEM_API_KEY your-key-here

# Start interactive chat
gem
gem chat

# Send a single message
gem chat -m "Explain Bash associative arrays"

# Check status
gem status

# List available models
gem models

# List providers
gem providers
```

### Commands

| Command | Shortcut | Description |
|---------|----------|-------------|
| `status` | `s` | Show system status and configuration |
| `serve` | — | Start API server |
| `chat` | `c` | Interactive chat REPL |
| `project` | — | Manage projects |
| `jobs` | — | Manage background jobs |
| `models` | `m` | List and manage models |
| `providers` | `p` | List and manage providers |
| `tools` | `t` | List and execute tools |
| `agents` | `a` | List and run agents |
| `config` | — | Manage configuration |
| `memory` | — | Manage long-term memory |

### Interactive Chat

The chat REPL supports these slash commands:

| Command | Description |
|---------|-------------|
| `/help` | Show available commands |
| `/status` | Show agent status |
| `/model [name]` | Get or set the current model |
| `/provider [name]` | Get or set the current provider |
| `/system [prompt]` | Get or set the system prompt |
| `/clear` | Clear conversation history |
| `/history` | Show conversation history |
| `/export [file]` | Export conversation as Markdown |
| `/memory [key] [value]` | Recall or save memory |
| `/forget [key]` | Delete a memory entry |
| `/tools [on\|off]` | List tools or toggle tool use |
| `/multiline` | Toggle multiline input mode |
| `/session [name]` | Switch or list sessions |
| `/verbose [on\|off]` | Toggle verbose mode |
| `/save` | Save current configuration |
| `/reset` | Reset conversation and agent |
| `/quit` | Exit chat |

### Tools

Gem provides 7 built-in tools that the AI agent can invoke:

| Tool | Description |
|------|-------------|
| `shell` | Execute shell commands with output capture |
| `files` | Read, write, list, search, delete files and directories |
| `web_search` | Search the web using DuckDuckGo |
| `image` | Generate or analyze images (stub — configure API endpoint) |
| `git` | Perform git operations (status, log, diff, add, commit, push, pull) |
| `archive` | Create and extract archives (tar.gz, tar.bz2, tar.xz, zip) |
| `artifacts` | Save, load, list, delete, and run code snippets |

### Providers

| Provider | Default URL |
|----------|------------|
| `opencode` | `https://api.opencode.dev/v1` |
| `openai` | `https://api.openai.com/v1` |
| `anthropic` | `https://api.anthropic.com/v1` |
| `local` | `http://localhost:8080/v1` |

```bash
# Switch provider
gem providers set openai

# Test connectivity
gem providers test

# Set custom URL
gem config set GEM_OPENAI_URL https://my-proxy.example.com/v1
```

### Configuration

Configuration is loaded from multiple sources in priority order:

1. **Environment variables** (highest priority)
2. **Shell config** — `~/.config/gem/config.sh` (sourced)
3. **KV config** — `~/.config/gem/config.env` (KEY=VALUE format)

Key variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `GEM_API_URL` | `https://api.opencode.dev/v1` | API endpoint |
| `GEM_API_KEY` | _(empty)_ | API authentication key |
| `GEM_MODEL` | `opencode/default` | Default model |
| `GEM_PROVIDER` | `opencode` | Default provider |
| `GEM_TEMPERATURE` | `0.7` | Model temperature |
| `GEM_MAX_TOKENS` | `4096` | Maximum response tokens |
| `GEM_TIMEOUT` | `30` | HTTP timeout (seconds) |
| `GEM_HISTORY_SIZE` | `1000` | Max messages per session |
| `GEM_SYSTEM_PROMPT` | `You are Gem, a helpful AI assistant.` | System prompt |
| `GEM_ENABLE_TOOLS` | `1` | Enable tool use |
| `GEM_ENABLE_MEMORY` | `1` | Enable memory |
| `GEM_ENABLE_STREAMING` | `1` | Enable streaming responses |
| `GEM_VERBOSE` | `0` | Verbose output |

### Memory

```bash
# Save a memory
gem memory save default project_name "My Cool Project"

# Recall it
gem memory recall default project_name

# List all memories
gem memory list

# Delete
gem memory delete default project_name
```

### Jobs

```bash
# Submit a background job
gem jobs submit "Analyze the codebase and suggest improvements"

# List jobs
gem jobs list

# Check status
gem jobs status job-1234567890

# Cancel
gem jobs cancel job-1234567890

# Clean finished jobs
gem jobs clean
```

### Architecture

```
gem (main executable)
├── lib/
│   ├── platform.sh   — OS, arch, distro, shell, terminal detection
│   ├── config.sh     — Configuration loading (env, files, get/set)
│   ├── memory.sh     — Long-term memory and conversation history
│   ├── provider.sh   — API provider system (curl-based HTTP)
│   ├── tools.sh      — Tool registry, schemas, and execution
│   ├── agent.sh      — Agent loop with tool-use iteration
│   └── chat.sh       — Interactive REPL with slash commands
├── install.sh        — Installer/uninstaller
└── README.md
```

### License

GPL-3.0 — Copyright (C) 2025 HintyCloud

---

## 📖 Documentação em Português

### Visão Geral

Gem CLI é um agente de IA em linha de comando escrito em Bash 4+ que oferece:

- **Chat interativo** com IA via API OpenCode (ou endpoints compatíveis)
- **Uso de ferramentas** — o agente pode executar comandos shell, gerir arquivos, pesquisar na web, usar git, lidar com arquivos compactados e gerir artefactos de código
- **Memória de longo prazo** — armazenamento persistente de chave-valor entre sessões
- **Histórico de conversas** — rastreamento completo de sessões com capacidades de exportação
- **Sistema de provedores** — backends de API conectáveis (OpenCode, OpenAI, Anthropic, local)
- **Tarefas em segundo plano** — submeta tarefas e verifique o estado de forma assíncrona
- **Deteção de plataforma** — SO, arquitetura, distribuição, capacidades do terminal

### Requisitos

| Dependência | Obrigatório | Propósito |
|-------------|-------------|-----------|
| Bash 4+ | ✅ | Arrays associativos, funcionalidades avançadas |
| curl | ✅ | Pedidos HTTP para a API |
| jq | ✅ | Análise e construção de JSON |
| git | Opcional | Suporte à ferramenta git |
| fzf | Opcional | Seleção fuzzy em prompts |
| bat | Opcional | Saída com destaque de sintaxe |
| rg (ripgrep) | Opcional | Pesquisa rápida de arquivos |

### Instalação

```bash
# Clonar e instalar
git clone https://github.com/HintyCloud/gem-bash.git
cd gem-bash
chmod +x install.sh
./install.sh

# Instalar com prefixo personalizado
./install.sh --prefix /usr/local

# Instalação verbosa
./install.sh --verbose

# Desinstalar
./install.sh --uninstall
```

### Início Rápido

```bash
# Defina a sua chave de API
export GEM_API_KEY="sua-chave-api-aqui"
# Ou: gem config set GEM_API_KEY sua-chave-api-aqui

# Iniciar chat interativo
gem
gem chat

# Enviar uma mensagem única
gem chat -m "Explique arrays associativos em Bash"

# Verificar estado
gem status

# Listar modelos disponíveis
gem models

# Listar provedores
gem providers
```

### Comandos

| Comando | Atalho | Descrição |
|---------|--------|-----------|
| `status` | `s` | Mostra estado do sistema e configuração |
| `serve` | — | Inicia servidor de API |
| `chat` | `c` | REPL de chat interativo |
| `project` | — | Gere projetos |
| `jobs` | — | Gere tarefas em segundo plano |
| `models` | `m` | Lista e gere modelos |
| `providers` | `p` | Lista e gere provedores |
| `tools` | `t` | Lista e executa ferramentas |
| `agents` | `a` | Lista e executa agentes |
| `config` | — | Gere configuração |
| `memory` | — | Gere memória de longo prazo |

### Chat Interativo

O REPL de chat suporta estes comandos de barra:

| Comando | Descrição |
|---------|-----------|
| `/help` | Mostra comandos disponíveis |
| `/status` | Mostra estado do agente |
| `/model [nome]` | Obtém ou define o modelo atual |
| `/provider [nome]` | Obtém ou define o provedor atual |
| `/system [prompt]` | Obtém ou define o prompt de sistema |
| `/clear` | Limpa histórico de conversas |
| `/history` | Mostra histórico de conversas |
| `/export [arquivo]` | Exporta conversa como Markdown |
| `/memory [chave] [valor]` | Recupera ou guarda memória |
| `/forget [chave]` | Apaga uma entrada de memória |
| `/tools [on\|off]` | Lista ferramentas ou ativa/desativa uso |
| `/multiline` | Alterna modo de entrada multilinha |
| `/session [nome]` | Troca ou lista sessões |
| `/verbose [on\|off]` | Alterna modo verboso |
| `/save` | Guarda configuração atual |
| `/reset` | Reinicia conversa e agente |
| `/quit` | Sai do chat |

### Ferramentas

O Gem fornece 7 ferramentas integradas que o agente de IA pode invocar:

| Ferramenta | Descrição |
|-----------|-----------|
| `shell` | Executa comandos shell com captura de saída |
| `files` | Lê, escreve, lista, pesquisa, apaga arquivos e diretórios |
| `web_search` | Pesquisa na web usando DuckDuckGo |
| `image` | Gera ou analisa imagens (stub — configure o endpoint da API) |
| `git` | Realiza operações git (status, log, diff, add, commit, push, pull) |
| `archive` | Cria e extrai arquivos compactados (tar.gz, tar.bz2, tar.xz, zip) |
| `artifacts` | Guarda, carrega, lista, apaga e executa snippets de código |

### Provedores

| Provedor | URL Padrão |
|----------|-----------|
| `opencode` | `https://api.opencode.dev/v1` |
| `openai` | `https://api.openai.com/v1` |
| `anthropic` | `https://api.anthropic.com/v1` |
| `local` | `http://localhost:8080/v1` |

```bash
# Trocar provedor
gem providers set openai

# Testar conectividade
gem providers test

# Definir URL personalizada
gem config set GEM_OPENAI_URL https://meu-proxy.exemplo.com/v1
```

### Configuração

A configuração é carregada de múltiplas fontes por ordem de prioridade:

1. **Variáveis de ambiente** (prioridade mais alta)
2. **Config shell** — `~/.config/gem/config.sh` (sourced)
3. **Config KV** — `~/.config/gem/config.env` (formato CHAVE=VALOR)

Variáveis principais:

| Variável | Padrão | Descrição |
|----------|--------|-----------|
| `GEM_API_URL` | `https://api.opencode.dev/v1` | Endpoint da API |
| `GEM_API_KEY` | _(vazio)_ | Chave de autenticação da API |
| `GEM_MODEL` | `opencode/default` | Modelo padrão |
| `GEM_PROVIDER` | `opencode` | Provedor padrão |
| `GEM_TEMPERATURE` | `0.7` | Temperatura do modelo |
| `GEM_MAX_TOKENS` | `4096` | Máximo de tokens na resposta |
| `GEM_TIMEOUT` | `30` | Timeout HTTP (segundos) |
| `GEM_HISTORY_SIZE` | `1000` | Máximo de mensagens por sessão |
| `GEM_SYSTEM_PROMPT` | `You are Gem, a helpful AI assistant.` | Prompt de sistema |
| `GEM_ENABLE_TOOLS` | `1` | Ativar uso de ferramentas |
| `GEM_ENABLE_MEMORY` | `1` | Ativar memória |
| `GEM_ENABLE_STREAMING` | `1` | Ativar respostas em streaming |
| `GEM_VERBOSE` | `0` | Saída verbosa |

### Memória

```bash
# Guardar uma memória
gem memory save default nome_projeto "Meu Projeto Legal"

# Recuperar
gem memory recall default nome_projeto

# Listar todas as memórias
gem memory list

# Apagar
gem memory delete default nome_projeto
```

### Tarefas

```bash
# Submeter uma tarefa em segundo plano
gem jobs submit "Analise o codebase e sugira melhorias"

# Listar tarefas
gem jobs list

# Verificar estado
gem jobs status job-1234567890

# Cancelar
gem jobs cancel job-1234567890

# Limpar tarefas concluídas
gem jobs clean
```

### Arquitetura

```
gem (executável principal)
├── lib/
│   ├── platform.sh   — Deteção de SO, arquitetura, distribuição, shell, terminal
│   ├── config.sh     — Carregamento de configuração (env, ficheiros, get/set)
│   ├── memory.sh     — Memória de longo prazo e histórico de conversas
│   ├── provider.sh   — Sistema de provedores de API (HTTP via curl)
│   ├── tools.sh      — Registo, schemas e execução de ferramentas
│   ├── agent.sh      — Loop do agente com iteração de uso de ferramentas
│   └── chat.sh       — REPL interativo com comandos de barra
├── install.sh        — Instalador/desinstalador
└── README.md
```

### Licença

GPL-3.0 — Copyright (C) 2025 HintyCloud

---

## 🤝 Contributing

Contributions are welcome! Please ensure:

1. Bash 4+ compatibility
2. POSIX compliance where possible (Bash-specific features clearly marked)
3. ShellCheck passes on all scripts
4. Functions follow the `gem_` prefix naming convention

## 🔗 Links

- **Project**: [https://github.com/HintyCloud/gem-bash](https://github.com/HintyCloud/gem-bash)
- **HintyCloud**: [https://hintycloud.com](https://hintycloud.com)
- **OpenCode API**: [https://opencode.dev](https://opencode.dev)
