#!/usr/bin/env bash
# install.sh - Installer for Gem CLI
# Copyright (C) 2025 HintyCloud - GPL-3.0
#
# Usage:
#   ./install.sh              # Install to default location
#   ./install.sh --prefix /usr/local  # Install to custom prefix
#   ./install.sh --uninstall          # Remove gem

set -euo pipefail

GEM_VERSION="1.0.0"
GEM_PROJECT="HintyCloud"

# Colors
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
BOLD='\033[1m'
RESET='\033[0m'

print_step()   { printf "${GREEN}✓${RESET} %s\n" "$*"; }
print_info()   { printf "${BLUE}→${RESET} %s\n" "$*"; }
print_warn()   { printf "${YELLOW}!${RESET} %s\n" "$*"; }
print_error()  { printf "${RED}✗${RESET} %s\n" "$*" >&2; }
print_header() { printf "\n${BOLD}%s${RESET}\n" "$*"; }

# --- Configuration ---

INSTALL_PREFIX="${HOME}/.local"
INSTALL_BINDIR=""
INSTALL_LIBDIR=""
INSTALL_DOCDIR=""
UNINSTALL=0
FORCE=0
VERBOSE=0

# --- Parse Arguments ---

while [[ $# -gt 0 ]]; do
    case "${1}" in
        --prefix)
            INSTALL_PREFIX="${2}"
            shift 2
            ;;
        --bindir)
            INSTALL_BINDIR="${2}"
            shift 2
            ;;
        --uninstall)
            UNINSTALL=1
            shift
            ;;
        --force|-f)
            FORCE=1
            shift
            ;;
        --verbose|-v)
            VERBOSE=1
            shift
            ;;
        --help|-h)
            printf "Usage: install.sh [options]\n\n"
            printf "Options:\n"
            printf "  --prefix DIR     Install prefix (default: ~/.local)\n"
            printf "  --bindir DIR     Binary directory (default: PREFIX/bin)\n"
            printf "  --uninstall      Remove gem installation\n"
            printf "  --force, -f      Force overwrite\n"
            printf "  --verbose, -v    Verbose output\n"
            printf "  --help, -h       Show this help\n"
            exit 0
            ;;
        *)
            print_error "Unknown option: ${1}"
            exit 1
            ;;
    esac
done

# Set derived paths
INSTALL_BINDIR="${INSTALL_BINDIR:-${INSTALL_PREFIX}/bin}"
INSTALL_LIBDIR="${INSTALL_PREFIX}/lib/gem"
INSTALL_DOCDIR="${INSTALL_PREFIX}/share/doc/gem"

# Source directory (where this script lives)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="${SCRIPT_DIR}"

# --- Uninstall ---

if [[ "${UNINSTALL}" -eq 1 ]]; then
    print_header "Uninstalling Gem CLI"

    # Remove binary
    if [[ -f "${INSTALL_BINDIR}/gem" ]]; then
        rm -f "${INSTALL_BINDIR}/gem"
        print_step "Removed ${INSTALL_BINDIR}/gem"
    else
        print_warn "Binary not found at ${INSTALL_BINDIR}/gem"
    fi

    # Remove library directory
    if [[ -d "${INSTALL_LIBDIR}" ]]; then
        rm -rf "${INSTALL_LIBDIR}"
        print_step "Removed ${INSTALL_LIBDIR}"
    else
        print_warn "Library directory not found at ${INSTALL_LIBDIR}"
    fi

    # Remove doc directory
    if [[ -d "${INSTALL_DOCDIR}" ]]; then
        rm -rf "${INSTALL_DOCDIR}"
        print_step "Removed ${INSTALL_DOCDIR}"
    fi

    # Remove shell completions
    local_comp="${HOME}/.local/share/bash-completion/completions/gem"
    if [[ -f "${local_comp}" ]]; then
        rm -f "${local_comp}"
        print_step "Removed bash completions"
    fi

    print_header "Uninstall complete"
    exit 0
fi

# --- Pre-flight Checks ---

print_header "Gem CLI v${GEM_VERSION} Installer"

# Check Bash version
if [[ "${BASH_VERSINFO[0]:-0}" -lt 4 ]]; then
    print_error "Bash 4+ is required (found: ${BASH_VERSION})"
    print_info "Install Bash 4+:"
    print_info "  macOS:  brew install bash"
    print_info "  Ubuntu: sudo apt install bash"
    exit 1
fi
print_step "Bash ${BASH_VERSION}"

# Check required dependencies
MISSING_DEPS=()
for dep in curl jq; do
    if ! command -v "${dep}" &>/dev/null; then
        MISSING_DEPS+=("${dep}")
    fi
done

if [[ ${#MISSING_DEPS[@]} -gt 0 ]]; then
    print_warn "Missing dependencies: ${MISSING_DEPS[*]}"
    print_info "You can install them after setup with: gem install-deps"

    if [[ "${FORCE}" -ne 1 ]]; then
        printf "\nContinue anyway? [y/N] "
        read -r answer
        if [[ "${answer}" != "y" ]] && [[ "${answer}" != "Y" ]]; then
            print_info "Aborted."
            exit 0
        fi
    fi
fi

# --- Installation ---

print_header "Installing"

# Create directories
print_info "Creating directories..."
mkdir -p "${INSTALL_BINDIR}"
mkdir -p "${INSTALL_LIBDIR}/lib"
mkdir -p "${INSTALL_DOCDIR}"

# Install main script
print_info "Installing gem executable..."
if [[ -f "${INSTALL_BINDIR}/gem" ]] && [[ "${FORCE}" -ne 1 ]]; then
    print_warn "gem already exists at ${INSTALL_BINDIR}/gem"
    printf "Overwrite? [y/N] "
    read -r answer
    if [[ "${answer}" != "y" ]] && [[ "${answer}" != "Y" ]]; then
        print_info "Skipping binary installation"
    else
        cp "${SOURCE_DIR}/gem" "${INSTALL_BINDIR}/gem"
        chmod +x "${INSTALL_BINDIR}/gem"
        print_step "Installed ${INSTALL_BINDIR}/gem"
    fi
else
    cp "${SOURCE_DIR}/gem" "${INSTALL_BINDIR}/gem"
    chmod +x "${INSTALL_BINDIR}/gem"
    print_step "Installed ${INSTALL_BINDIR}/gem"
fi

# Install library files
print_info "Installing libraries..."
for lib in platform.sh config.sh memory.sh provider.sh tools.sh agent.sh chat.sh; do
    if [[ -f "${SOURCE_DIR}/lib/${lib}" ]]; then
        cp "${SOURCE_DIR}/lib/${lib}" "${INSTALL_LIBDIR}/lib/${lib}"
        if [[ "${VERBOSE}" -eq 1 ]]; then
            print_step "Installed lib/${lib}"
        fi
    else
        print_warn "Missing: lib/${lib}"
    fi
done
print_step "Libraries installed to ${INSTALL_LIBDIR}/lib/"

# Update GEM_BINDIR and GEM_LIBDIR in the installed script
print_info "Configuring paths..."
sed -i.bak "s|^GEM_BINDIR=.*|GEM_BINDIR=\"${INSTALL_BINDIR}\"|" "${INSTALL_BINDIR}/gem" 2>/dev/null || true
sed -i.bak "s|^GEM_LIBDIR=.*|GEM_LIBDIR=\"${INSTALL_LIBDIR}/lib\"|" "${INSTALL_BINDIR}/gem" 2>/dev/null || true
rm -f "${INSTALL_BINDIR}/gem.bak"
print_step "Paths configured"

# Install documentation
print_info "Installing documentation..."
if [[ -f "${SOURCE_DIR}/README.md" ]]; then
    cp "${SOURCE_DIR}/README.md" "${INSTALL_DOCDIR}/README.md"
    print_step "Documentation installed"
fi

# Install shell completions
print_info "Installing shell completions..."
COMPLETION_DIR="${HOME}/.local/share/bash-completion/completions"
mkdir -p "${COMPLETION_DIR}" 2>/dev/null || true
cat > "${COMPLETION_DIR}/gem" << 'COMPLEOF'
# Bash completion for gem CLI
_gem_completions() {
    local cur prev commands
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    commands="status serve chat project jobs models providers tools agents config memory help version"

    if [[ ${COMP_CWORD} -eq 1 ]]; then
        COMPREPLY=($(compgen -W "${commands} s c m p t a" -- "${cur}"))
        return 0
    fi

    case "${prev}" in
        chat)       COMPREPLY=($(compgen -W "-s --session -m --message -r --resume" -- "${cur}")) ;;
        models)     COMPREPLY=($(compgen -W "opencode openai anthropic local" -- "${cur}")) ;;
        providers)  COMPREPLY=($(compgen -W "list test set" -- "${cur}")) ;;
        tools)      COMPREPLY=($(compgen -W "list exec schema shell files web_search image git archive artifacts" -- "${cur}")) ;;
        project)    COMPREPLY=($(compgen -W "list create delete info" -- "${cur}")) ;;
        jobs)       COMPREPLY=($(compgen -W "list submit status cancel clean" -- "${cur}")) ;;
        config)     COMPREPLY=($(compgen -W "list get set unset init path" -- "${cur}")) ;;
        memory)     COMPREPLY=($(compgen -W "list save recall delete" -- "${cur}")) ;;
        agents)     COMPREPLY=($(compgen -W "list status run" -- "${cur}")) ;;
    esac

    return 0
}
complete -F _gem_completions gem
COMPLEOF
print_step "Bash completions installed"

# --- PATH Setup ---

print_info "Checking PATH..."
if [[ ":${PATH}:" != *":${INSTALL_BINDIR}:"* ]]; then
    print_warn "${INSTALL_BINDIR} is not in your PATH"

    # Detect shell config file
    SHELL_RC=""
    if [[ -f "${HOME}/.bashrc" ]]; then
        SHELL_RC="${HOME}/.bashrc"
    elif [[ -f "${HOME}/.bash_profile" ]]; then
        SHELL_RC="${HOME}/.bash_profile"
    fi

    if [[ -n "${SHELL_RC}" ]]; then
        printf "Add to PATH in %s? [Y/n] " "${SHELL_RC}"
        read -r answer
        if [[ "${answer}" != "n" ]] && [[ "${answer}" != "N" ]]; then
            printf '\n# Gem CLI\nexport PATH="%s:$PATH"\n' "${INSTALL_BINDIR}" >> "${SHELL_RC}"
            print_step "Added ${INSTALL_BINDIR} to PATH in ${SHELL_RC}"
            print_info "Run 'source ${SHELL_RC}' or start a new shell"
        else
            print_info "Add this to your shell config manually:"
            printf '  export PATH="%s:$PATH"\n' "${INSTALL_BINDIR}"
        fi
    fi
else
    print_step "${INSTALL_BINDIR} is in PATH"
fi

# --- Post-install ---

print_header "Installation Complete!"
printf "\n"
printf "  ${BOLD}Gem CLI v${GEM_VERSION}${RESET}\n"
printf "  Installed to: ${INSTALL_BINDIR}/gem\n"
printf "  Libraries:    ${INSTALL_LIBDIR}/lib/\n"
printf "  Config:       ${XDG_CONFIG_HOME:-$HOME/.config}/gem/\n"
printf "  Data:         ${XDG_DATA_HOME:-$HOME/.local/share}/gem/\n"
printf "\n"

# Quick start
printf "  ${BOLD}Quick Start:${RESET}\n"
printf "    gem status          # Check installation\n"
printf "    gem chat            # Start interactive chat\n"
printf "    gem help            # Show all commands\n"
printf "\n"

# API key reminder
printf "  ${BOLD}Setup API Key:${RESET}\n"
printf "    gem config set GEM_API_KEY your-key-here\n"
printf "    export GEM_API_KEY=your-key-here\n"
printf "\n"

if [[ ${#MISSING_DEPS[@]} -gt 0 ]]; then
    printf "  ${YELLOW}Don't forget to install missing deps:${RESET} ${MISSING_DEPS[*]}\n"
    printf "    gem install-deps\n\n"
fi

print_step "Done! Enjoy Gem CLI 🎉"
