# Gem CLI Agent — Java Implementation

> AI-powered command-line agent for the **HintyCloud** ecosystem

[![License: GPL-3.0](https://img.shields.io/badge/License-GPL%203.0-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Java 17+](https://img.shields.io/badge/Java-17%2B-orange.svg)](https://openjdk.org/)
[![Version 1.0.0](https://img.shields.io/badge/Version-1.0.0-green.svg)]()

## Overview

Gem is an AI-powered CLI agent that connects to LLM providers (OpenCode API, OpenAI-compatible endpoints) and executes tasks through an interactive think/act/observe loop. It supports tool execution, streaming responses, persistent memory, and job queuing.

## Features

- **9 CLI Commands**: `status`, `serve`, `chat`, `project`, `jobs`, `models`, `providers`, `tools`, `agents`
- **Interactive Chat**: REPL with JLine readline, tab completion, and slash commands
- **Agent Loop**: Think → Act → Observe cycle with configurable max turns
- **Provider System**: OpenCode API, OpenAI-compatible, Anthropic endpoints
- **7 Built-in Tools**: `shell`, `files`, `web`, `image`, `git`, `archive`, `artifacts`
- **Memory System**: In-memory + persistent JSON-based conversation history
- **Job Queue**: Async task execution with thread pool
- **Platform Detection**: OS, architecture, and shell auto-detection
- **Configuration**: Properties and TOML config files with environment variable overrides
- **Streaming**: Server-Sent Events (SSE) streaming support

## Requirements

- **Java 17+** (OpenJDK or Oracle JDK)
- **Maven 3.8+** (for building)

## Build

```bash
# Clone and build
cd gem-java
mvn clean package

# Run
java -jar target/gem-1.0.0.jar

# Or install locally
mvn install
```

## Usage

### Status

```bash
gem status
```

Shows platform info, provider configuration, and model settings.

### Interactive Chat

```bash
gem chat
gem chat --model gpt-4 --provider openai
gem chat --system "You are a helpful coding assistant"
gem chat --auto-approve
```

#### Slash Commands (inside chat)

| Command | Description |
|---------|-------------|
| `/help` | Show available slash commands |
| `/status` | Show agent status (turns, history, session) |
| `/model [name]` | Switch model |
| `/provider [name]` | Switch provider |
| `/tools` | List available tools |
| `/clear` | Clear conversation history |
| `/save` | Save conversation to disk |
| `/load [id]` | Load a saved conversation |
| `/sessions` | List saved sessions |
| `/quit` | Exit chat |

### Project Setup

```bash
gem project init          # Creates gem.toml
gem project init --format properties  # Creates gem.properties
```

### Models

```bash
gem models                # List all models from all providers
gem models --provider openai  # Filter by provider
```

### Providers

```bash
gem providers             # List configured providers and API keys
```

### Tools

```bash
gem tools                 # List all registered tools and availability
```

### Jobs

```bash
gem jobs                  # List running/background jobs
```

### Agent Server

```bash
gem serve                 # Start agent as a server
gem serve --port 9090     # Custom port
```

## Configuration

Gem loads configuration from multiple sources (later overrides earlier):

1. `/etc/gem/gem.properties` — System-wide
2. `~/.config/gem/gem.properties` — User properties
3. `~/.config/gem/gem.toml` — User TOML
4. `./gem.properties` — Project properties
5. `./gem.toml` — Project TOML
6. `GEM_*` environment variables

### TOML Example (`gem.toml`)

```toml
provider = "opencode"
model = "default"
max_turns = 20
streaming = true
context_window = 128000
max_tokens = 4096
temperature = 0.7

[providers.opencode]
url = "https://api.opencode.ai"
api_key = "sk-..."

[providers.openai]
url = "https://api.openai.com/v1"
api_key = "sk-..."
```

### Properties Example (`gem.properties`)

```properties
gem.provider=opencode
gem.model=default
gem.max_turns=20
gem.streaming=true
gem.provider.opencode.url=https://api.opencode.ai
gem.provider.opencode.api_key=sk-...
```

### Environment Variables

| Variable | Description |
|----------|-------------|
| `GEM_PROVIDER` | Default provider name |
| `GEM_MODEL` | Default model |
| `GEM_API_BASE_URL` | API base URL |
| `GEM_API_KEY` | API key |
| `GEM_DATA_DIR` | Data directory |
| `GEM_MAX_TURNS` | Max agent turns |

## Architecture

```
com.hintycloud.gem
├── Main.java              — Entry point (picocli)
├── cli/                   — CLI commands
│   ├── GemCommand.java    — Root command
│   ├── StatusCommand.java
│   ├── ServeCommand.java
│   ├── ChatCommand.java   — Interactive REPL
│   ├── ProjectCommand.java
│   ├── JobsCommand.java
│   ├── ModelsCommand.java
│   ├── ProvidersCommand.java
│   ├── ToolsCommand.java
│   ├── AgentsCommand.java
│   ├── SlashCommandParser.java
│   └── SlashCommandCompleter.java
├── config/                — Configuration
│   ├── GemConfig.java     — Multi-source config loading
│   └── ProviderConfig.java
├── provider/              — AI provider interface
│   ├── Provider.java      — Provider interface
│   ├── OpenCodeProvider.java — OpenCode/OpenAI API
│   ├── ProviderRegistry.java
│   ├── ChatMessage.java
│   ├── ModelInfo.java
│   └── ProviderResponse.java
├── tools/                 — Tool system
│   ├── Tool.java          — Tool interface
│   ├── ToolResult.java
│   ├── ToolRegistry.java
│   └── impl/
│       ├── ShellTool.java
│       ├── FilesTool.java
│       ├── WebTool.java
│       ├── ImageTool.java
│       ├── GitTool.java
│       ├── ArchiveTool.java
│       └── ArtifactsTool.java
├── agent/                 — Agent loop
│   ├── AgentLoop.java     — Think/Act/Observe cycle
│   ├── AgentListener.java — Callback interface
│   ├── AgentConfig.java
│   └── JobQueue.java
├── memory/                — Memory store
│   ├── MemoryStore.java   — History + persistence
│   └── ConversationEntry.java
└── platform/              — Platform detection
    └── Platform.java      — OS/Arch/Shell detection
```

## Dependencies

| Library | Version | Purpose |
|---------|---------|---------|
| [Picocli](https://picocli.info) | 4.7.6 | CLI framework + code generation |
| [OkHttp](https://square.github.io/okhttp/) | 4.12.0 | HTTP client + SSE |
| [Jackson](https://github.com/FasterXML/jackson) | 2.17.1 | JSON serialization |
| [JLine](https://github.com/jline/jline3) | 3.26.1 | Interactive readline |
| [SLF4J](https://www.slf4j.org/) + Logback | 2.0.13 | Logging |
| [toml4j](https://github.com/mwanjij/toml4j) | 0.7.2 | TOML parsing |

## License

Copyright © 2024 HintyCloud. Licensed under the **GNU General Public License v3.0**.

---

# Gem CLI Agent — Implementação Java

> Agente de linha de comando com IA para o ecossistema **HintyCloud**

## Visão Geral

O Gem é um agente CLI com IA que se conecta a provedores de LLM (API OpenCode, endpoints compatíveis com OpenAI) e executa tarefas através de um loop interativo pensar/agir/observar. Suporta execução de ferramentas, respostas em streaming, memória persistente e fila de tarefas.

## Funcionalidades

- **9 Comandos CLI**: `status`, `serve`, `chat`, `project`, `jobs`, `models`, `providers`, `tools`, `agents`
- **Chat Interativo**: REPL com JLine, autocompletar com Tab e comandos slash
- **Loop do Agente**: Ciclo Pensar → Agir → Observar com turnos máximos configuráveis
- **Sistema de Provedores**: API OpenCode, compatível com OpenAI, endpoints Anthropic
- **7 Ferramentas Integradas**: `shell`, `files`, `web`, `image`, `git`, `archive`, `artifacts`
- **Sistema de Memória**: Histórico em memória + persistência JSON
- **Fila de Tarefas**: Execução assíncrona com pool de threads
- **Detecção de Plataforma**: Auto-detecção de SO, arquitetura e shell
- **Configuração**: Arquivos properties e TOML com sobrescrita por variáveis de ambiente
- **Streaming**: Suporte a Server-Sent Events (SSE)

## Requisitos

- **Java 17+** (OpenJDK ou Oracle JDK)
- **Maven 3.8+** (para compilação)

## Compilação

```bash
cd gem-java
mvn clean package
java -jar target/gem-1.0.0.jar
```

## Uso

### Status

```bash
gem status
```

Mostra informações da plataforma, configuração do provedor e configurações do modelo.

### Chat Interativo

```bash
gem chat
gem chat --model gpt-4 --provider openai
gem chat --system "Você é um assistente de programação útil"
```

#### Comandos Slash (dentro do chat)

| Comando | Descrição |
|---------|-----------|
| `/help` | Mostra comandos disponíveis |
| `/status` | Mostra status do agente |
| `/model [nome]` | Troca o modelo |
| `/provider [nome]` | Troca o provedor |
| `/tools` | Lista ferramentas disponíveis |
| `/clear` | Limpa o histórico da conversa |
| `/save` | Salva a conversa no disco |
| `/load [id]` | Carrega uma conversa salva |
| `/sessions` | Lista sessões salvas |
| `/quit` | Sai do chat |

### Inicialização de Projeto

```bash
gem project init
gem project init --format properties
```

## Configuração

O Gem carrega configuração de múltiplas fontes (posterior sobrescreve anterior):

1. `/etc/gem/gem.properties` — Sistema
2. `~/.config/gem/gem.properties` — Usuário (properties)
3. `~/.config/gem/gem.toml` — Usuário (TOML)
4. `./gem.properties` — Projeto (properties)
5. `./gem.toml` — Projeto (TOML)
6. Variáveis de ambiente `GEM_*`

### Exemplo TOML (`gem.toml`)

```toml
provider = "opencode"
model = "default"
max_turns = 20
streaming = true

[providers.opencode]
url = "https://api.opencode.ai"
api_key = "sk-..."
```

### Variáveis de Ambiente

| Variável | Descrição |
|----------|-----------|
| `GEM_PROVIDER` | Nome do provedor padrão |
| `GEM_MODEL` | Modelo padrão |
| `GEM_API_BASE_URL` | URL base da API |
| `GEM_API_KEY` | Chave da API |
| `GEM_DATA_DIR` | Diretório de dados |
| `GEM_MAX_TURNS` | Turnos máximos do agente |

## Licença

Copyright © 2024 HintyCloud. Licenciado sob a **GNU General Public License v3.0**.
