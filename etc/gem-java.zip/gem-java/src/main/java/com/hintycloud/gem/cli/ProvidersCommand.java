package com.hintycloud.gem.cli;

import com.hintycloud.gem.config.GemConfig;
import com.hintycloud.gem.config.ProviderConfig;
import com.hintycloud.gem.provider.Provider;
import com.hintycloud.gem.provider.ProviderRegistry;
import picocli.CommandLine.Command;
import picocli.CommandLine.ParentCommand;

import java.util.concurrent.Callable;

/**
 * `gem providers` — List and manage AI providers.
 */
@Command(name = "providers", description = "List and manage AI providers", mixinStandardHelpOptions = true)
public class ProvidersCommand implements Callable<Integer> {

    @ParentCommand
    private GemCommand parent;

    @Override
    public Integer call() {
        GemConfig config = GemConfig.load();
        ProviderRegistry registry = new ProviderRegistry(config);

        System.out.println();
        System.out.println("  AI Providers");
        System.out.println("  ─────────────────────────────────────");
        System.out.printf("  %-12s %-40s %s%n", "NAME", "BASE URL", "KEY");
        System.out.println("  ─────────────────────────────────────");

        for (ProviderConfig pc : config.getProviders().values()) {
            String keyStatus = pc.hasApiKey() ? "••••••••" : "(not set)";
            System.out.printf("  %-12s %-40s %s%n", pc.name(), pc.safeUrl(), keyStatus);
        }

        System.out.println();
        System.out.println("  Default: " + config.getDefaultProvider());
        System.out.println();

        return 0;
    }
}
