package com.hintycloud.gem.cli;

import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.Callable;

/**
 * `gem project init` — Initialize a new Gem project with a config file.
 */
@Command(name = "init", description = "Initialize a new Gem project", mixinStandardHelpOptions = true)
public class ProjectInitCommand implements Callable<Integer> {

    @Option(names = {"--format"}, description = "Config format: toml or properties", defaultValue = "toml")
    private String format;

    @Override
    public Integer call() {
        try {
            if ("toml".equalsIgnoreCase(format)) {
                Path path = Path.of("gem.toml");
                if (Files.exists(path)) {
                    System.err.println("gem.toml already exists.");
                    return 1;
                }
                String content = """
                    # Gem CLI Agent Configuration
                    # See: https://hintycloud.com/gem/docs/config
                    
                    provider = "opencode"
                    model = "default"
                    max_turns = 20
                    streaming = true
                    context_window = 128000
                    max_tokens = 4096
                    temperature = 0.7
                    
                    [providers.opencode]
                    url = "https://api.opencode.ai"
                    
                    [providers.openai]
                    url = "https://api.openai.com/v1"
                    
                    [providers.anthropic]
                    url = "https://api.anthropic.com/v1"
                    """;
                Files.writeString(path, content);
                System.out.println("Created gem.toml");
            } else {
                Path path = Path.of("gem.properties");
                if (Files.exists(path)) {
                    System.err.println("gem.properties already exists.");
                    return 1;
                }
                String content = """
                    # Gem CLI Agent Configuration
                    gem.provider=opencode
                    gem.model=default
                    gem.max_turns=20
                    gem.streaming=true
                    gem.context_window=128000
                    gem.max_tokens=4096
                    gem.temperature=0.7
                    
                    # Provider URLs
                    gem.provider.opencode.url=https://api.opencode.ai
                    gem.provider.openai.url=https://api.openai.com/v1
                    gem.provider.anthropic.url=https://api.anthropic.com/v1
                    """;
                Files.writeString(path, content);
                System.out.println("Created gem.properties");
            }

            // Create .gem directory for session data
            Files.createDirectories(Path.of(".gem"));

            System.out.println("Project initialized successfully.");
            return 0;

        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            return 1;
        }
    }
}
