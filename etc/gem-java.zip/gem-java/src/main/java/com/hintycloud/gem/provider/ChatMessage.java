package com.hintycloud.gem.provider;

/**
 * A chat message in the conversation history.
 */
public record ChatMessage(Role role, String content) {

    public enum Role {
        SYSTEM("system"),
        USER("user"),
        ASSISTANT("assistant"),
        TOOL("tool");

        private final String value;

        Role(String value) {
            this.value = value;
        }

        public String value() {
            return value;
        }

        public static Role fromValue(String value) {
            return switch (value.toLowerCase()) {
                case "system" -> SYSTEM;
                case "user" -> USER;
                case "assistant" -> ASSISTANT;
                case "tool" -> TOOL;
                default -> throw new IllegalArgumentException("Unknown role: " + value);
            };
        }
    }

    /**
     * Create a system message.
     */
    public static ChatMessage system(String content) {
        return new ChatMessage(Role.SYSTEM, content);
    }

    /**
     * Create a user message.
     */
    public static ChatMessage user(String content) {
        return new ChatMessage(Role.USER, content);
    }

    /**
     * Create an assistant message.
     */
    public static ChatMessage assistant(String content) {
        return new ChatMessage(Role.ASSISTANT, content);
    }

    /**
     * Create a tool result message.
     */
    public static ChatMessage tool(String content) {
        return new ChatMessage(Role.TOOL, content);
    }
}
