package com.hintycloud.gem.provider;

import com.fasterxml.jackson.databind.JsonNode;
import com.hintycloud.gem.config.GemConfig;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Interface for AI model providers. Implementations connect to different
 * LLM APIs (OpenCode, OpenAI-compatible, Anthropic, etc.).
 */
public interface Provider {

    /**
     * The unique name of this provider.
     */
    String name();

    /**
     * Check if this provider is available (configured and reachable).
     */
    boolean isAvailable();

    /**
     * List available models from this provider.
     */
    List<ModelInfo> listModels() throws IOException;

    /**
     * Send a chat completion request.
     *
     * @param messages  conversation messages
     * @param model    model identifier (provider-specific or alias)
     * @param config   provider-specific parameters
     * @return the provider response
     */
    ProviderResponse complete(List<ChatMessage> messages, String model, Map<String, Object> config) throws IOException;

    /**
     * Send a streaming chat completion request.
     *
     * @param messages  conversation messages
     * @param model    model identifier
     * @param config   provider-specific parameters
     * @param handler  callback for streaming chunks
     */
    void completeStream(List<ChatMessage> messages, String model,
                        Map<String, Object> config, StreamHandler handler) throws IOException;

    /**
     * Callback interface for streaming responses.
     */
    interface StreamHandler {
        void onChunk(String delta, boolean isToolCall);
        void onComplete(ProviderResponse response);
        void onError(Throwable error);
    }
}
