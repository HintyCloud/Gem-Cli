package com.hintycloud.gem.agent;

import com.hintycloud.gem.provider.ProviderResponse;
import com.hintycloud.gem.tools.ToolResult;

import java.util.List;

/**
 * Listener interface for observing the agent loop's think/act/observe cycle.
 */
public interface AgentListener {

    /**
     * Called when the agent starts a think phase.
     */
    default void onThink(int turn, String prompt) {}

    /**
     * Called when the agent enters the act phase (tool calls received).
     */
    default void onAct(List<ProviderResponse.ToolCall> toolCalls) {}

    /**
     * Called when a tool is about to be invoked.
     */
    default void onToolCall(String toolName, String arguments) {}

    /**
     * Called when a tool execution completes.
     */
    default void onToolResult(String toolName, ToolResult result) {}

    /**
     * Called when the agent produces a final observation (text response).
     */
    default void onObserve(String content) {}

    /**
     * Called on each streaming chunk.
     */
    default void onStreamChunk(String delta, boolean isToolCall) {}

    /**
     * Called when an error occurs.
     */
    default void onError(String message) {}
}
