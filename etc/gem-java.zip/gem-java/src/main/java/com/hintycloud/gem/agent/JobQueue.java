package com.hintycloud.gem.agent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Job queue for managing asynchronous agent tasks.
 *
 * <p>Jobs are submitted to the queue and executed by a thread pool.
 * Each job has a unique ID, status, and optional result.
 */
public class JobQueue {

    private static final Logger LOG = LoggerFactory.getLogger(JobQueue.class);

    public enum Status {
        PENDING, RUNNING, COMPLETED, FAILED, CANCELLED
    }

    /**
     * A job in the queue.
     */
    public record Job(
        long id,
        String name,
        String description,
        Status status,
        Instant submittedAt,
        Instant startedAt,
        Instant completedAt,
        String result,
        String error
    ) {}

    private final Map<Long, Job> jobs = new ConcurrentHashMap<>();
    private final AtomicLong idCounter = new AtomicLong(1);
    private final ExecutorService executor;
    private final int maxConcurrent;

    public JobQueue() {
        this(4);
    }

    public JobQueue(int maxConcurrent) {
        this.maxConcurrent = maxConcurrent;
        this.executor = Executors.newFixedThreadPool(maxConcurrent,
            r -> {
                Thread t = new Thread(r, "gem-job-worker");
                t.setDaemon(true);
                return t;
            });
    }

    /**
     * Submit a job for execution.
     *
     * @param name        job name
     * @param description job description
     * @param task        the callable to execute
     * @return the job ID
     */
    public long submit(String name, String description, Callable<String> task) {
        long id = idCounter.getAndIncrement();
        Job job = new Job(id, name, description, Status.PENDING,
            Instant.now(), null, null, null, null);
        jobs.put(id, job);

        CompletableFuture.runAsync(() -> {
            Job running = updateStatus(id, Status.RUNNING);
            try {
                String result = task.call();
                jobs.put(id, new Job(id, name, description, Status.COMPLETED,
                    running.submittedAt(), Instant.now(), Instant.now(), result, null));
                LOG.debug("Job {} completed: {}", id, name);
            } catch (Exception e) {
                jobs.put(id, new Job(id, name, description, Status.FAILED,
                    running.submittedAt(), Instant.now(), Instant.now(), null, e.getMessage()));
                LOG.warn("Job {} failed: {} - {}", id, name, e.getMessage());
            }
        }, executor);

        return id;
    }

    private Job updateStatus(long id, Status status) {
        Job existing = jobs.get(id);
        if (existing == null) return null;
        Job updated = new Job(id, existing.name(), existing.description(), status,
            existing.submittedAt(), Instant.now(), null, null, null);
        jobs.put(id, updated);
        return updated;
    }

    /**
     * Cancel a pending job.
     */
    public boolean cancel(long id) {
        Job job = jobs.get(id);
        if (job != null && (job.status() == Status.PENDING || job.status() == Status.RUNNING)) {
            jobs.put(id, new Job(id, job.name(), job.description(), Status.CANCELLED,
                job.submittedAt(), job.startedAt(), Instant.now(), null, "Cancelled"));
            return true;
        }
        return false;
    }

    /**
     * Get a job by ID.
     */
    public Job get(long id) {
        return jobs.get(id);
    }

    /**
     * List all jobs.
     */
    public List<Job> listAll() {
        return new ArrayList<>(jobs.values());
    }

    /**
     * List jobs by status.
     */
    public List<Job> listByStatus(Status status) {
        return jobs.values().stream()
            .filter(j -> j.status() == status)
            .toList();
    }

    /**
     * Get the number of active (pending + running) jobs.
     */
    public int activeCount() {
        return (int) jobs.values().stream()
            .filter(j -> j.status() == Status.PENDING || j.status() == Status.RUNNING)
            .count();
    }

    /**
     * Shutdown the job queue.
     */
    public void shutdown() {
        executor.shutdown();
    }
}
