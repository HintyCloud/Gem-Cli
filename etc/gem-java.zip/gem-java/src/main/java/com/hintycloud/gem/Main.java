package com.hintycloud.gem;

import com.hintycloud.gem.cli.GemCommand;
import picocli.CommandLine;

/**
 * Gem CLI Agent — AI-powered command-line agent for the HintyCloud ecosystem.
 *
 * <p>Usage: gem [command] [options]</p>
 *
 * @author HintyCloud
 * @version 1.0.0
 */
public class Main {

    public static final String VERSION = "1.0.0";
    public static final String NAME = "gem";

    public static void main(String[] args) {
        GemCommand gemCommand = new GemCommand();
        CommandLine cmd = new CommandLine(gemCommand);

        cmd.setExecutionExceptionHandler((ex, commandLine, parseResult) -> {
            commandLine.getErr().println(ex.getMessage());
            return commandLine.getCommandSpec().exitCodeOnExecutionException();
        });

        int exitCode = cmd.execute(args);
        System.exit(exitCode);
    }
}
