package com.hintycloud.gem.cli;

import com.hintycloud.gem.config.GemConfig;
import com.hintycloud.gem.provider.ModelInfo;
import com.hintycloud.gem.provider.Provider;
import com.hintycloud.gem.provider.ProviderRegistry;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;
import picocli.CommandLine.ParentCommand;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.Callable;

/**
 * `gem models` — List available AI models.
 */
@Command(name = "models", description = "List available AI models", mixinStandardHelpOptions = true)
public class ModelsCommand implements Callable<Integer> {

    @ParentCommand
    private GemCommand parent;

    @Option(names = {"-p", "--provider"}, description = "Filter by provider")
    private String providerFilter;

    @Override
    public Integer call() {
        GemConfig config = GemConfig.load();
        ProviderRegistry registry = new ProviderRegistry(config);

        System.out.println();
        System.out.println("  Available Models");
        System.out.println("  ─────────────────────────────────────");

        for (Provider provider : registry.all()) {
            if (providerFilter != null && !provider.name().equals(providerFilter)) continue;

            System.out.println("  [" + provider.name() + "]");
            try {
                List<ModelInfo> models = provider.listModels();
                if (models.isEmpty()) {
                    System.out.println("    (no models found or provider unreachable)");
                } else {
                    for (ModelInfo m : models) {
                        System.out.printf("    %-40s ctx=%d%n", m.id(), m.contextWindow());
                    }
                }
            } catch (IOException e) {
                System.out.println("    (error: " + e.getMessage() + ")");
            }
            System.out.println();
        }

        return 0;
    }
}
