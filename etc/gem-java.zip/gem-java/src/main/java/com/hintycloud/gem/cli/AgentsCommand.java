package com.hintycloud.gem.cli;

import com.hintycloud.gem.agent.AgentConfig;
import picocli.CommandLine.Command;
import picocli.CommandLine.ParentCommand;

import java.util.concurrent.Callable;

/**
 * `gem agents` — List and manage agent configurations.
 */
@Command(name = "agents", description = "List and manage agent configurations", mixinStandardHelpOptions = true)
public class AgentsCommand implements Callable<Integer> {

    @ParentCommand
    private GemCommand parent;

    @Override
    public Integer call() {
        AgentConfig defaults = AgentConfig.defaults();

        System.out.println();
        System.out.println("  Agent Configurations");
        System.out.println("  ─────────────────────────────────────");
        System.out.println("  Name:        " + defaults.name());
        System.out.println("  Model:       " + defaults.model());
        System.out.println("  Max Turns:   " + defaults.maxTurns());
        System.out.println("  Auto Approve:" + defaults.autoApprove());
        System.out.println();
        System.out.println("  (Custom agent configurations can be");
        System.out.println("   defined in gem.toml [agents] sections)");
        System.out.println();

        return 0;
    }
}
