package com.hintycloud.gem.cli;

import com.hintycloud.gem.Main;
import com.hintycloud.gem.config.GemConfig;
import com.hintycloud.gem.platform.Platform;
import picocli.CommandLine.Command;
import picocli.CommandLine.ParentCommand;

import java.util.concurrent.Callable;

/**
 * `gem status` — Show system and agent status information.
 */
@Command(name = "status", description = "Show system and agent status", mixinStandardHelpOptions = true)
public class StatusCommand implements Callable<Integer> {

    @ParentCommand
    private GemCommand parent;

    @Override
    public Integer call() {
        GemConfig config = GemConfig.load();
        Platform platform = Platform.detect();

        System.out.println();
        System.out.println("  ╔══════════════════════════════════════════╗");
        System.out.println("  ║           Gem CLI Agent v" + Main.VERSION + "          ║");
        System.out.println("  ╚══════════════════════════════════════════╝");
        System.out.println();
        System.out.println("  Platform:    " + platform.summary());
        System.out.println("  Provider:    " + config.getDefaultProvider());
        System.out.println("  Model:       " + config.getDefaultModel());
        System.out.println("  API Base:    " + config.getApiBaseUrl());
        System.out.println("  API Key:     " + (config.getApiKey().isEmpty() ? "(not set)" : "••••••••"));
        System.out.println("  Data Dir:    " + config.getDataDir());
        System.out.println("  Max Turns:   " + config.getMaxTurns());
        System.out.println("  Streaming:   " + config.isStreaming());
        System.out.println("  Context:     " + config.getContextWindow() + " tokens");
        System.out.println("  Max Tokens:  " + config.getMaxTokens());
        System.out.println("  Temperature: " + config.getTemperature());
        System.out.println();

        return 0;
    }
}
