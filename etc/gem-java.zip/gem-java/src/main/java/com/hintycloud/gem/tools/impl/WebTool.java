package com.hintycloud.gem.tools.impl;

import com.hintycloud.gem.tools.Tool;
import com.hintycloud.gem.tools.ToolResult;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Web tool — fetch URLs and search the web.
 */
public class WebTool implements Tool {

    @Override
    public String name() {
        return "web";
    }

    @Override
    public String description() {
        return "Fetch web pages and search the internet for information";
    }

    @Override
    public Map<String, Object> schema() {
        Map<String, Object> schema = new LinkedHashMap<>();
        schema.put("type", "object");
        Map<String, Object> action = Map.of("type", "string", "description", "Action: fetch, search");
        Map<String, Object> url = Map.of("type", "string", "description", "URL to fetch (for fetch action)");
        Map<String, Object> query = Map.of("type", "string", "description", "Search query (for search action)");
        schema.put("properties", Map.of("action", action, "url", url, "query", query));
        schema.put("required", java.util.List.of("action"));
        return schema;
    }

    @Override
    public ToolResult execute(Map<String, Object> args) {
        String action = (String) args.get("action");
        if (action == null) return ToolResult.fail("Missing required parameter: action");

        return switch (action.toLowerCase()) {
            case "fetch" -> {
                String url = (String) args.get("url");
                if (url == null) yield ToolResult.fail("Missing parameter: url");
                yield fetchUrl(url);
            }
            case "search" -> {
                String query = (String) args.get("query");
                if (query == null) yield ToolResult.fail("Missing parameter: query");
                yield searchWeb(query);
            }
            default -> ToolResult.fail("Unknown action: " + action);
        };
    }

    private ToolResult fetchUrl(String url) {
        try {
            okhttp3.OkHttpClient client = new okhttp3.OkHttpClient.Builder()
                .followRedirects(true)
                .followSslRedirects(true)
                .build();
            okhttp3.Request request = new okhttp3.Request.Builder()
                .url(url)
                .header("User-Agent", "gem/1.0.0")
                .get()
                .build();
            try (okhttp3.Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    return ToolResult.fail("HTTP " + response.code() + " for " + url);
                }
                String body = response.body() != null ? response.body().string() : "";
                // Truncate very large responses
                if (body.length() > 50000) {
                    body = body.substring(0, 50000) + "\n... [truncated]";
                }
                return ToolResult.ok(body);
            }
        } catch (Exception e) {
            return ToolResult.fail(e);
        }
    }

    private ToolResult searchWeb(String query) {
        // Placeholder — would integrate with a search API
        return ToolResult.ok("Search results for: " + query + "\n[Web search integration not configured]");
    }
}
