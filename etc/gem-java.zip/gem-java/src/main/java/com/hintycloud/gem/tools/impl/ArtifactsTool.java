package com.hintycloud.gem.tools.impl;

import com.hintycloud.gem.tools.Tool;
import com.hintycloud.gem.tools.ToolResult;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Artifacts tool — manage persistent artifacts (code, documents, diagrams).
 */
public class ArtifactsTool implements Tool {

    @Override
    public String name() {
        return "artifacts";
    }

    @Override
    public String description() {
        return "Manage persistent artifacts: code blocks, documents, diagrams, and generated outputs";
    }

    @Override
    public Map<String, Object> schema() {
        Map<String, Object> schema = new LinkedHashMap<>();
        schema.put("type", "object");
        Map<String, Object> action = Map.of("type", "string", "description", "Action: save, load, list, delete");
        Map<String, Object> name = Map.of("type", "string", "description", "Artifact name/identifier");
        Map<String, Object> content = Map.of("type", "string", "description", "Artifact content (for save)");
        Map<String, Object> type = Map.of("type", "string", "description", "Artifact type: code, document, diagram, other");
        schema.put("properties", Map.of("action", action, "name", name, "content", content, "type", type));
        schema.put("required", java.util.List.of("action", "name"));
        return schema;
    }

    @Override
    public ToolResult execute(Map<String, Object> args) {
        String action = (String) args.get("action");
        String name = (String) args.get("name");
        if (action == null || name == null) {
            return ToolResult.fail("Missing required parameters: action, name");
        }

        Path artifactsDir = Path.of(System.getProperty("user.home"), ".local", "share", "gem", "artifacts");

        try {
            Files.createDirectories(artifactsDir);

            return switch (action.toLowerCase()) {
                case "save" -> {
                    String content = (String) args.getOrDefault("content", "");
                    String type = (String) args.getOrDefault("type", "other");
                    Path dir = artifactsDir.resolve(type);
                    Files.createDirectories(dir);
                    Files.writeString(dir.resolve(name), content);
                    yield ToolResult.ok("Saved artifact: " + type + "/" + name);
                }
                case "load" -> {
                    // Search across type subdirectories
                    Path found = null;
                    try (var stream = Files.list(artifactsDir)) {
                        for (Path typeDir : stream.toList()) {
                            if (Files.isDirectory(typeDir)) {
                                Path candidate = typeDir.resolve(name);
                                if (Files.exists(candidate)) {
                                    found = candidate;
                                    break;
                                }
                            }
                        }
                    }
                    if (found != null) {
                        yield ToolResult.ok(Files.readString(found));
                    } else {
                        yield ToolResult.fail("Artifact not found: " + name);
                    }
                }
                case "list" -> {
                    StringBuilder sb = new StringBuilder();
                    if (Files.isDirectory(artifactsDir)) {
                        try (var typeStream = Files.list(artifactsDir)) {
                            for (Path typeDir : typeStream.toList()) {
                                if (Files.isDirectory(typeDir)) {
                                    try (var fileStream = Files.list(typeDir)) {
                                        for (Path file : fileStream.toList()) {
                                            sb.append(typeDir.getFileName()).append("/")
                                              .append(file.getFileName()).append("\n");
                                        }
                                    }
                                }
                            }
                        }
                    }
                    yield ToolResult.ok(sb.length() > 0 ? sb.toString().trim() : "No artifacts found");
                }
                case "delete" -> {
                    boolean deleted = false;
                    try (var stream = Files.list(artifactsDir)) {
                        for (Path typeDir : stream.toList()) {
                            if (Files.isDirectory(typeDir)) {
                                Path candidate = typeDir.resolve(name);
                                if (Files.exists(candidate)) {
                                    Files.delete(candidate);
                                    deleted = true;
                                    break;
                                }
                            }
                        }
                    }
                    yield deleted ? ToolResult.ok("Deleted artifact: " + name) : ToolResult.fail("Artifact not found: " + name);
                }
                default -> ToolResult.fail("Unknown action: " + action);
            };
        } catch (Exception e) {
            return ToolResult.fail(e);
        }
    }
}
