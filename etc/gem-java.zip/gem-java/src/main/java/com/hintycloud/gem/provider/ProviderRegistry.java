package com.hintycloud.gem.provider;

import com.hintycloud.gem.config.GemConfig;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registry for managing provider instances.
 */
public class ProviderRegistry {

    private final Map<String, Provider> providers = new ConcurrentHashMap<>();
    private final GemConfig config;

    public ProviderRegistry(GemConfig config) {
        this.config = config;
        // Register built-in providers
        register(new OpenCodeProvider(config, "opencode"));
        register(new OpenCodeProvider(config, "openai"));
        register(new OpenCodeProvider(config, "anthropic"));
    }

    /**
     * Register a provider.
     */
    public void register(Provider provider) {
        providers.put(provider.name(), provider);
    }

    /**
     * Get a provider by name.
     */
    public Provider get(String name) {
        return providers.get(name);
    }

    /**
     * Get the default provider from config.
     */
    public Provider getDefault() {
        return get(config.getDefaultProvider());
    }

    /**
     * List all registered provider names.
     */
    public java.util.Set<String> names() {
        return providers.keySet();
    }

    /**
     * List all providers.
     */
    public java.util.Collection<Provider> all() {
        return providers.values();
    }

    /**
     * Check if a provider is registered.
     */
    public boolean has(String name) {
        return providers.containsKey(name);
    }
}
