package com.hintycloud.gem.config;

/**
 * Configuration for a specific AI provider.
 */
public record ProviderConfig(
    String name,
    String baseUrl,
    String apiKey
) {
    /**
     * Check if this provider has an API key configured.
     */
    public boolean hasApiKey() {
        return apiKey != null && !apiKey.isEmpty();
    }

    /**
     * Return the display-safe URL (mask any key in query params).
     */
    public String safeUrl() {
        return baseUrl;
    }
}
