package com.hintycloud.gem.cli;

import picocli.CommandLine.Command;
import picocli.CommandLine.ParentCommand;

import java.util.concurrent.Callable;

/**
 * `gem project` — Manage project-level configuration.
 */
@Command(name = "project", description = "Manage project configuration", mixinStandardHelpOptions = true,
    subcommands = { ProjectInitCommand.class })
public class ProjectCommand implements Callable<Integer> {

    @ParentCommand
    private GemCommand parent;

    @Override
    public Integer call() {
        System.out.println("Project management commands:");
        System.out.println("  init    Initialize a new Gem project");
        return 0;
    }
}
