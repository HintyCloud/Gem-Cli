package com.hintycloud.gem.provider;

/**
 * Information about a model available from a provider.
 */
public record ModelInfo(
    String id,
    String name,
    String provider,
    long contextWindow,
    boolean supportsStreaming,
    boolean supportsToolCalls,
    boolean supportsVision
) {
    /**
     * Create a basic model info with default capabilities.
     */
    public static ModelInfo of(String id, String provider) {
        return new ModelInfo(id, id, provider, 128000, true, true, false);
    }

    /**
     * Create a model info with custom context window.
     */
    public static ModelInfo of(String id, String provider, long contextWindow) {
        return new ModelInfo(id, id, provider, contextWindow, true, true, false);
    }

    @Override
    public String toString() {
        return String.format("%s (%s, ctx=%d)", id, provider, contextWindow);
    }
}
