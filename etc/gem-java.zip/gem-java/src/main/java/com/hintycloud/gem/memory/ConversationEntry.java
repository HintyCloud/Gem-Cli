package com.hintycloud.gem.memory;

import com.hintycloud.gem.provider.ChatMessage;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.Instant;
import java.util.Map;

/**
 * A single entry in the conversation history.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record ConversationEntry(
    String sessionId,
    Instant timestamp,
    ChatMessage message,
    Map<String, String> metadata
) {
    /**
     * Create an entry without metadata.
     */
    public static ConversationEntry of(String sessionId, ChatMessage message) {
        return new ConversationEntry(sessionId, Instant.now(), message, Map.of());
    }

    /**
     * Get the role of the message.
     */
    public ChatMessage.Role role() {
        return message.role();
    }

    /**
     * Get the content of the message.
     */
    public String content() {
        return message.content();
    }
}
