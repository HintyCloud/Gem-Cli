package com.hintycloud.gem.tools.impl;

import com.hintycloud.gem.tools.Tool;
import com.hintycloud.gem.tools.ToolResult;

import java.io.IOException;
import java.nio.file.*;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Files tool — read, write, list, and search files on the local filesystem.
 */
public class FilesTool implements Tool {

    @Override
    public String name() {
        return "files";
    }

    @Override
    public String description() {
        return "Read, write, list, and search files on the local filesystem";
    }

    @Override
    public Map<String, Object> schema() {
        Map<String, Object> schema = new LinkedHashMap<>();
        schema.put("type", "object");
        Map<String, Object> action = Map.of("type", "string", "description", "Action: read, write, list, delete, exists");
        Map<String, Object> path = Map.of("type", "string", "description", "File or directory path");
        Map<String, Object> content = Map.of("type", "string", "description", "Content to write (for write action)");
        Map<String, Object> pattern = Map.of("type", "string", "description", "Glob pattern for list action");
        schema.put("properties", Map.of("action", action, "path", path, "content", content, "pattern", pattern));
        schema.put("required", java.util.List.of("action", "path"));
        return schema;
    }

    @Override
    public ToolResult execute(Map<String, Object> args) {
        String action = (String) args.get("action");
        String path = (String) args.get("path");

        if (action == null || path == null) {
            return ToolResult.fail("Missing required parameters: action, path");
        }

        try {
            return switch (action.toLowerCase()) {
                case "read" -> readFile(path);
                case "write" -> writeFile(path, (String) args.getOrDefault("content", ""));
                case "list" -> listDirectory(path, (String) args.getOrDefault("pattern", "*"));
                case "delete" -> deleteFile(path);
                case "exists" -> ToolResult.ok(String.valueOf(Files.exists(Path.of(path))));
                default -> ToolResult.fail("Unknown action: " + action);
            };
        } catch (Exception e) {
            return ToolResult.fail(e);
        }
    }

    private ToolResult readFile(String path) throws IOException {
        Path p = Path.of(path);
        if (!Files.exists(p)) return ToolResult.fail("File not found: " + path);
        if (Files.isDirectory(p)) return ToolResult.fail("Path is a directory: " + path);
        if (Files.size(p) > 1_000_000) return ToolResult.fail("File too large (>1MB): " + path);
        return ToolResult.ok(Files.readString(p));
    }

    private ToolResult writeFile(String path, String content) throws IOException {
        Path p = Path.of(path);
        Files.createDirectories(p.getParent());
        Files.writeString(p, content);
        return ToolResult.ok("Written " + content.length() + " chars to " + path);
    }

    private ToolResult listDirectory(String path, String pattern) throws IOException {
        Path p = Path.of(path);
        if (!Files.isDirectory(p)) return ToolResult.fail("Not a directory: " + path);

        StringBuilder sb = new StringBuilder();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(p, pattern)) {
            for (Path entry : stream) {
                String type = Files.isDirectory(entry) ? "DIR " : "FILE";
                sb.append(type).append(" ").append(entry.getFileName()).append("\n");
            }
        }
        return ToolResult.ok(sb.toString().trim());
    }

    private ToolResult deleteFile(String path) throws IOException {
        Path p = Path.of(path);
        if (!Files.exists(p)) return ToolResult.fail("File not found: " + path);
        Files.delete(p);
        return ToolResult.ok("Deleted: " + path);
    }
}
