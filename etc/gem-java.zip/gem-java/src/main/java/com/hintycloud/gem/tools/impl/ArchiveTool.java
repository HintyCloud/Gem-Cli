package com.hintycloud.gem.tools.impl;

import com.hintycloud.gem.tools.Tool;
import com.hintycloud.gem.tools.ToolResult;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Archive tool — create and extract archive files (zip, tar, tar.gz).
 */
public class ArchiveTool implements Tool {

    @Override
    public String name() {
        return "archive";
    }

    @Override
    public String description() {
        return "Create and extract archive files (zip, tar, tar.gz, tar.bz2)";
    }

    @Override
    public Map<String, Object> schema() {
        Map<String, Object> schema = new LinkedHashMap<>();
        schema.put("type", "object");
        Map<String, Object> action = Map.of("type", "string", "description", "Action: create, extract, list");
        Map<String, Object> archive = Map.of("type", "string", "description", "Archive file path");
        Map<String, Object> target = Map.of("type", "string", "description", "Target path (source dir for create, extract dir for extract)");
        schema.put("properties", Map.of("action", action, "archive", archive, "target", target));
        schema.put("required", java.util.List.of("action", "archive"));
        return schema;
    }

    @Override
    public ToolResult execute(Map<String, Object> args) {
        String action = (String) args.get("action");
        String archive = (String) args.get("archive");
        if (action == null || archive == null) {
            return ToolResult.fail("Missing required parameters: action, archive");
        }

        try {
            return switch (action.toLowerCase()) {
                case "create" -> createArchive(archive, (String) args.getOrDefault("target", "."));
                case "extract" -> extractArchive(archive, (String) args.getOrDefault("target", "."));
                case "list" -> listArchive(archive);
                default -> ToolResult.fail("Unknown action: " + action);
            };
        } catch (Exception e) {
            return ToolResult.fail(e);
        }
    }

    private ToolResult createArchive(String archivePath, String sourceDir) throws IOException {
        Path source = Path.of(sourceDir);
        if (!Files.isDirectory(source)) return ToolResult.fail("Not a directory: " + sourceDir);

        if (archivePath.endsWith(".zip")) {
            // Use jar command which can create zip files
            ProcessBuilder pb = new ProcessBuilder("jar", "cf", archivePath, "-C", sourceDir, ".");
            pb.redirectErrorStream(true);
            try {
                Process p = pb.start();
                p.waitFor();
                return ToolResult.ok("Created zip archive: " + archivePath);
            } catch (Exception e) {
                return ToolResult.fail("Failed to create zip: " + e.getMessage());
            }
        } else {
            // Use tar for tar/tar.gz/tar.bz2
            String flag = archivePath.endsWith(".tar.gz") || archivePath.endsWith(".tgz") ? "czf" : "cf";
            ProcessBuilder pb = new ProcessBuilder("tar", flag, archivePath, "-C", sourceDir, ".");
            pb.redirectErrorStream(true);
            try {
                Process p = pb.start();
                p.waitFor();
                return ToolResult.ok("Created archive: " + archivePath);
            } catch (Exception e) {
                return ToolResult.fail("Failed to create tar: " + e.getMessage());
            }
        }
    }

    private ToolResult extractArchive(String archivePath, String targetDir) throws IOException {
        Files.createDirectories(Path.of(targetDir));

        if (archivePath.endsWith(".zip")) {
            ProcessBuilder pb = new ProcessBuilder("unzip", "-o", archivePath, "-d", targetDir);
            pb.redirectErrorStream(true);
            try {
                Process p = pb.start();
                p.waitFor();
                return ToolResult.ok("Extracted zip to: " + targetDir);
            } catch (Exception e) {
                return ToolResult.fail("Failed to extract zip: " + e.getMessage());
            }
        } else {
            ProcessBuilder pb = new ProcessBuilder("tar", "xf", archivePath, "-C", targetDir);
            pb.redirectErrorStream(true);
            try {
                Process p = pb.start();
                p.waitFor();
                return ToolResult.ok("Extracted archive to: " + targetDir);
            } catch (Exception e) {
                return ToolResult.fail("Failed to extract tar: " + e.getMessage());
            }
        }
    }

    private ToolResult listArchive(String archivePath) {
        try {
            ProcessBuilder pb;
            if (archivePath.endsWith(".zip")) {
                pb = new ProcessBuilder("unzip", "-l", archivePath);
            } else {
                pb = new ProcessBuilder("tar", "tf", archivePath);
            }
            pb.redirectErrorStream(true);
            Process p = pb.start();
            StringBuilder out = new StringBuilder();
            try (var reader = new java.io.BufferedReader(new java.io.InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) out.append(line).append("\n");
            }
            p.waitFor();
            return ToolResult.ok(out.toString());
        } catch (Exception e) {
            return ToolResult.fail(e);
        }
    }
}
