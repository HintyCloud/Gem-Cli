package com.hintycloud.gem.config;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.moandjiezana.toml.Toml;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Gem configuration loaded from properties or TOML files.
 *
 * <p>Resolution order (later overrides earlier):
 * <ol>
 *   <li>/etc/gem/gem.properties (system)</li>
 *   <li>~/.config/gem/gem.properties (user)</li>
 *   <li>~/.config/gem/gem.toml (user)</li>
 *   <li>./gem.properties (project)</li>
 *   <li>./gem.toml (project)</li>
 *   <li>Environment variables (GEM_ prefix)</li>
 * </ol>
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class GemConfig {

    private String defaultProvider = "opencode";
    private String defaultModel = "default";
    private String apiBaseUrl = "https://api.opencode.ai";
    private String apiKey = "";
    private int maxTurns = 20;
    private boolean verbose = false;
    private String dataDir = "";
    private String promptTemplate = "default";
    private boolean streaming = true;
    private int contextWindow = 128000;
    private int maxTokens = 4096;
    private double temperature = 0.7;
    private Map<String, ProviderConfig> providers = new LinkedHashMap<>();
    private Map<String, String> tools = new LinkedHashMap<>();

    public GemConfig() {
        // Default provider configs
        providers.put("opencode", new ProviderConfig("opencode", "https://api.opencode.ai", ""));
        providers.put("openai", new ProviderConfig("openai", "https://api.openai.com/v1", ""));
        providers.put("anthropic", new ProviderConfig("anthropic", "https://api.anthropic.com/v1", ""));
    }

    /**
     * Load configuration from the standard search paths.
     */
    public static GemConfig load() {
        GemConfig config = new GemConfig();
        List<Path> searchPaths = getSearchPaths();

        for (Path path : searchPaths) {
            if (!Files.exists(path)) continue;
            if (path.toString().endsWith(".toml")) {
                config.mergeToml(path);
            } else {
                config.mergeProperties(path);
            }
        }

        // Environment overrides
        config.applyEnvironment();

        // Default data dir
        if (config.dataDir.isEmpty()) {
            config.dataDir = System.getProperty("user.home") + "/.local/share/gem";
        }

        return config;
    }

    private static List<Path> getSearchPaths() {
        List<Path> paths = new ArrayList<>();
        String home = System.getProperty("user.home");

        // System
        paths.add(Path.of("/etc/gem/gem.properties"));
        // User
        paths.add(Path.of(home, ".config", "gem", "gem.properties"));
        paths.add(Path.of(home, ".config", "gem", "gem.toml"));
        // Project
        paths.add(Path.of("gem.properties"));
        paths.add(Path.of("gem.toml"));

        return paths;
    }

    private void mergeProperties(Path path) {
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(path.toFile())) {
            props.load(fis);
            applyProperties(props);
        } catch (IOException e) {
            // Silently skip unreadable config files
        }
    }

    private void mergeToml(Path path) {
        try {
            Toml toml = new Toml().read(path.toFile());
            applyToml(toml);
        } catch (Exception e) {
            // Silently skip unreadable config files
        }
    }

    private void applyProperties(Properties props) {
        String val;
        if ((val = props.getProperty("gem.provider")) != null) this.defaultProvider = val;
        if ((val = props.getProperty("gem.model")) != null) this.defaultModel = val;
        if ((val = props.getProperty("gem.api_base_url")) != null) this.apiBaseUrl = val;
        if ((val = props.getProperty("gem.api_key")) != null) this.apiKey = val;
        if ((val = props.getProperty("gem.max_turns")) != null) this.maxTurns = Integer.parseInt(val);
        if ((val = props.getProperty("gem.verbose")) != null) this.verbose = Boolean.parseBoolean(val);
        if ((val = props.getProperty("gem.data_dir")) != null) this.dataDir = val;
        if ((val = props.getProperty("gem.streaming")) != null) this.streaming = Boolean.parseBoolean(val);
        if ((val = props.getProperty("gem.context_window")) != null) this.contextWindow = Integer.parseInt(val);
        if ((val = props.getProperty("gem.max_tokens")) != null) this.maxTokens = Integer.parseInt(val);
        if ((val = props.getProperty("gem.temperature")) != null) this.temperature = Double.parseDouble(val);

        // Provider-specific properties
        for (String name : List.of("opencode", "openai", "anthropic")) {
            String url = props.getProperty("gem.provider." + name + ".url");
            String key = props.getProperty("gem.provider." + name + ".api_key");
            if (url != null || key != null) {
                ProviderConfig existing = providers.getOrDefault(name, new ProviderConfig(name, "", ""));
                providers.put(name, new ProviderConfig(
                    name,
                    url != null ? url : existing.baseUrl(),
                    key != null ? key : existing.apiKey()
                ));
            }
        }
    }

    private void applyToml(Toml toml) {
        if (toml.contains("provider")) this.defaultProvider = toml.getString("provider");
        if (toml.contains("model")) this.defaultModel = toml.getString("model");
        if (toml.contains("api_base_url")) this.apiBaseUrl = toml.getString("api_base_url");
        if (toml.contains("api_key")) this.apiKey = toml.getString("api_key");
        if (toml.contains("max_turns")) this.maxTurns = toml.getLong("max_turns").intValue();
        if (toml.contains("verbose")) this.verbose = toml.getBoolean("verbose");
        if (toml.contains("data_dir")) this.dataDir = toml.getString("data_dir");
        if (toml.contains("streaming")) this.streaming = toml.getBoolean("streaming");
        if (toml.contains("context_window")) this.contextWindow = toml.getLong("context_window").intValue();
        if (toml.contains("max_tokens")) this.maxTokens = toml.getLong("max_tokens").intValue();
        if (toml.contains("temperature")) this.temperature = toml.getDouble("temperature");

        // Provider sections
        if (toml.containsTable("providers")) {
            Toml providersTable = toml.getTable("providers");
            for (String name : providersTable.toMap().keySet()) {
                Toml prov = providersTable.getTable(name);
                providers.put(name, new ProviderConfig(
                    name,
                    prov.contains("url") ? prov.getString("url") : "",
                    prov.contains("api_key") ? prov.getString("api_key") : ""
                ));
            }
        }
    }

    private void applyEnvironment() {
        String val;
        if ((val = System.getenv("GEM_PROVIDER")) != null) this.defaultProvider = val;
        if ((val = System.getenv("GEM_MODEL")) != null) this.defaultModel = val;
        if ((val = System.getenv("GEM_API_BASE_URL")) != null) this.apiBaseUrl = val;
        if ((val = System.getenv("GEM_API_KEY")) != null) this.apiKey = val;
        if ((val = System.getenv("GEM_DATA_DIR")) != null) this.dataDir = val;
        if ((val = System.getenv("GEM_MAX_TURNS")) != null) this.maxTurns = Integer.parseInt(val);
    }

    // Getters and setters

    public String getDefaultProvider() { return defaultProvider; }
    public void setDefaultProvider(String defaultProvider) { this.defaultProvider = defaultProvider; }

    public String getDefaultModel() { return defaultModel; }
    public void setDefaultModel(String defaultModel) { this.defaultModel = defaultModel; }

    public String getApiBaseUrl() { return apiBaseUrl; }
    public void setApiBaseUrl(String apiBaseUrl) { this.apiBaseUrl = apiBaseUrl; }

    public String getApiKey() { return apiKey; }
    public void setApiKey(String apiKey) { this.apiKey = apiKey; }

    public int getMaxTurns() { return maxTurns; }
    public void setMaxTurns(int maxTurns) { this.maxTurns = maxTurns; }

    public boolean isVerbose() { return verbose; }
    public void setVerbose(boolean verbose) { this.verbose = verbose; }

    public String getDataDir() { return dataDir; }
    public void setDataDir(String dataDir) { this.dataDir = dataDir; }

    public String getPromptTemplate() { return promptTemplate; }
    public void setPromptTemplate(String promptTemplate) { this.promptTemplate = promptTemplate; }

    public boolean isStreaming() { return streaming; }
    public void setStreaming(boolean streaming) { this.streaming = streaming; }

    public int getContextWindow() { return contextWindow; }
    public void setContextWindow(int contextWindow) { this.contextWindow = contextWindow; }

    public int getMaxTokens() { return maxTokens; }
    public void setMaxTokens(int maxTokens) { this.maxTokens = maxTokens; }

    public double getTemperature() { return temperature; }
    public void setTemperature(double temperature) { this.temperature = temperature; }

    public Map<String, ProviderConfig> getProviders() { return providers; }
    public void setProviders(Map<String, ProviderConfig> providers) { this.providers = providers; }

    public Map<String, String> getTools() { return tools; }
    public void setTools(Map<String, String> tools) { this.tools = tools; }
}
