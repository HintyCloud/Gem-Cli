package com.hintycloud.gem.cli;

import com.hintycloud.gem.Main;
import com.hintycloud.gem.config.GemConfig;
import com.hintycloud.gem.provider.*;
import com.hintycloud.gem.tools.ToolRegistry;
import com.hintycloud.gem.memory.MemoryStore;
import com.hintycloud.gem.agent.*;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;
import picocli.CommandLine.ParentCommand;

import java.io.IOException;
import java.util.concurrent.Callable;

/**
 * `gem serve` — Start the Gem agent as a persistent server/daemon.
 */
@Command(name = "serve", description = "Start the Gem agent server", mixinStandardHelpOptions = true)
public class ServeCommand implements Callable<Integer> {

    @ParentCommand
    private GemCommand parent;

    @Option(names = {"-p", "--port"}, description = "Server port (default: 8080)", defaultValue = "8080")
    private int port;

    @Option(names = {"--host"}, description = "Bind host (default: localhost)", defaultValue = "localhost")
    private String host;

    @Override
    public Integer call() {
        GemConfig config = GemConfig.load();
        System.out.println("Starting Gem agent server on " + host + ":" + port);
        System.out.println("Provider: " + config.getDefaultProvider());
        System.out.println("Model: " + config.getDefaultModel());
        System.out.println();

        // TODO: Implement HTTP server (e.g., using Javalin or Spark)
        // For now, just run the chat loop interactively
        System.out.println("Server mode is not yet fully implemented.");
        System.out.println("Use 'gem chat' for interactive mode.");
        return 0;
    }
}
