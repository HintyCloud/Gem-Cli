package com.hintycloud.gem.tools;

/**
 * Result of a tool execution.
 */
public record ToolResult(
    boolean success,
    String output,
    String error
) {

    /**
     * Create a successful result.
     */
    public static ToolResult ok(String output) {
        return new ToolResult(true, output, "");
    }

    /**
     * Create a failed result.
     */
    public static ToolResult fail(String error) {
        return new ToolResult(false, "", error);
    }

    /**
     * Create a failed result from an exception.
     */
    public static ToolResult fail(Throwable e) {
        return new ToolResult(false, "", e.getMessage() != null ? e.getMessage() : e.getClass().getName());
    }

    @Override
    public String toString() {
        return success ? output : "ERROR: " + error;
    }
}
