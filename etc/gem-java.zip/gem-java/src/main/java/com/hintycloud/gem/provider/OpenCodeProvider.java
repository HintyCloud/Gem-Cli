package com.hintycloud.gem.provider;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.hintycloud.gem.config.GemConfig;
import com.hintycloud.gem.config.ProviderConfig;
import okhttp3.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * OpenCode API provider — connects to the OpenCode API (OpenAI-compatible).
 */
public class OpenCodeProvider implements Provider {

    private static final MediaType JSON_TYPE = MediaType.get("application/json; charset=utf-8");
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private final String name;
    private final String baseUrl;
    private final String apiKey;
    private final OkHttpClient httpClient;
    private final GemConfig config;

    public OpenCodeProvider(GemConfig config) {
        this(config, "opencode");
    }

    public OpenCodeProvider(GemConfig config, String name) {
        this.name = name;
        ProviderConfig pc = config.getProviders().getOrDefault(name, new ProviderConfig(name, "", ""));
        this.baseUrl = pc.baseUrl().isEmpty() ? config.getApiBaseUrl() : pc.baseUrl();
        this.apiKey = pc.apiKey().isEmpty() ? config.getApiKey() : pc.apiKey();
        this.config = config;
        this.httpClient = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build();
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public boolean isAvailable() {
        try {
            Request request = new Request.Builder()
                .url(baseUrl + "/models")
                .header("Authorization", "Bearer " + apiKey)
                .header("User-Agent", "gem/1.0.0")
                .get()
                .build();
            try (Response response = httpClient.newCall(request).execute()) {
                return response.isSuccessful();
            }
        } catch (IOException e) {
            return false;
        }
    }

    @Override
    public List<ModelInfo> listModels() throws IOException {
        Request request = new Request.Builder()
            .url(baseUrl + "/models")
            .header("Authorization", "Bearer " + apiKey)
            .header("User-Agent", "gem/1.0.0")
            .get()
            .build();

        try (Response response = httpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Failed to list models: " + response.code());
            }
            String body = response.body().string();
            JsonNode root = MAPPER.readTree(body);
            List<ModelInfo> models = new ArrayList<>();
            JsonNode data = root.has("data") ? root.get("data") : root;
            if (data.isArray()) {
                for (JsonNode node : data) {
                    String id = node.has("id") ? node.get("id").asText() : "unknown";
                    long ctx = node.has("context_window") ? node.get("context_window").asLong() : 128000;
                    models.add(ModelInfo.of(id, name, ctx));
                }
            }
            return models;
        }
    }

    @Override
    public ProviderResponse complete(List<ChatMessage> messages, String model, Map<String, Object> params) throws IOException {
        ObjectNode requestBody = buildRequestBody(messages, model, params, false);
        RequestBody httpBody = RequestBody.create(MAPPER.writeValueAsString(requestBody), JSON_TYPE);

        Request request = new Request.Builder()
            .url(baseUrl + "/chat/completions")
            .header("Authorization", "Bearer " + apiKey)
            .header("User-Agent", "gem/1.0.0")
            .header("Content-Type", "application/json")
            .post(httpBody)
            .build();

        try (Response response = httpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                String errBody = response.body() != null ? response.body().string() : "no body";
                throw new IOException("Provider error " + response.code() + ": " + errBody);
            }
            return parseResponse(response.body().string());
        }
    }

    @Override
    public void completeStream(List<ChatMessage> messages, String model,
                               Map<String, Object> params, StreamHandler handler) throws IOException {
        ObjectNode requestBody = buildRequestBody(messages, model, params, true);
        RequestBody httpBody = RequestBody.create(MAPPER.writeValueAsString(requestBody), JSON_TYPE);

        Request request = new Request.Builder()
            .url(baseUrl + "/chat/completions")
            .header("Authorization", "Bearer " + apiKey)
            .header("User-Agent", "gem/1.0.0")
            .header("Content-Type", "application/json")
            .header("Accept", "text/event-stream")
            .post(httpBody)
            .build();

        StringBuilder fullContent = new StringBuilder();
        List<ProviderResponse.ToolCall> toolCalls = new ArrayList<>();

        try (Response response = httpClient.newCall(request).execute()) {
            if (!response.isSuccessful()) {
                handler.onError(new IOException("Provider error: " + response.code()));
                return;
            }

            BufferedReader reader = new BufferedReader(
                new InputStreamReader(response.body().byteStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("data: ")) {
                    String data = line.substring(6).trim();
                    if (data.equals("[DONE]")) break;
                    try {
                        JsonNode chunk = MAPPER.readTree(data);
                        JsonNode delta = chunk.at("/choices/0/delta");
                        if (delta.has("content")) {
                            String content = delta.get("content").asText();
                            fullContent.append(content);
                            handler.onChunk(content, false);
                        }
                        if (delta.has("tool_calls")) {
                            for (JsonNode tc : delta.get("tool_calls")) {
                                String tcId = tc.has("id") ? tc.get("id").asText() : "";
                                String tcName = tc.at("/function/name").asText("");
                                String tcArgs = tc.at("/function/arguments").asText("");
                                handler.onChunk(tcName + "(" + tcArgs + ")", true);
                                toolCalls.add(new ProviderResponse.ToolCall(tcId, tcName, tcArgs));
                            }
                        }
                    } catch (Exception e) {
                        // Skip malformed chunks
                    }
                }
            }
        }

        handler.onComplete(new ProviderResponse(
            "", model, fullContent.toString(), toolCalls,
            ProviderResponse.Usage.empty(), true
        ));
    }

    private ObjectNode buildRequestBody(List<ChatMessage> messages, String model,
                                         Map<String, Object> params, boolean stream) {
        ObjectNode root = MAPPER.createObjectNode();
        root.put("model", model);
        root.put("stream", stream);
        root.put("max_tokens", config.getMaxTokens());
        root.put("temperature", config.getTemperature());

        ArrayNode messagesArray = MAPPER.createArrayNode();
        for (ChatMessage msg : messages) {
            ObjectNode msgNode = MAPPER.createObjectNode();
            msgNode.put("role", msg.role().value());
            msgNode.put("content", msg.content());
            messagesArray.add(msgNode);
        }
        root.set("messages", messagesArray);

        // Merge extra params
        if (params != null) {
            params.forEach((k, v) -> {
                if (v instanceof Number n) root.put(k, n.doubleValue());
                else if (v instanceof Boolean b) root.put(k, b);
                else if (v instanceof String s) root.put(k, s);
            });
        }

        return root;
    }

    private ProviderResponse parseResponse(String body) throws IOException {
        JsonNode root = MAPPER.readTree(body);
        String id = root.has("id") ? root.get("id").asText() : "";
        String model = root.has("model") ? root.get("model").asText() : "";

        String content = root.at("/choices/0/message/content").asText("");

        List<ProviderResponse.ToolCall> toolCalls = new ArrayList<>();
        JsonNode tcNode = root.at("/choices/0/message/tool_calls");
        if (tcNode.isArray()) {
            for (JsonNode tc : tcNode) {
                toolCalls.add(new ProviderResponse.ToolCall(
                    tc.has("id") ? tc.get("id").asText() : "",
                    tc.at("/function/name").asText(""),
                    tc.at("/function/arguments").asText("")
                ));
            }
        }

        ProviderResponse.Usage usage = ProviderResponse.Usage.empty();
        if (root.has("usage")) {
            JsonNode u = root.get("usage");
            usage = new ProviderResponse.Usage(
                u.has("prompt_tokens") ? u.get("prompt_tokens").asLong() : 0,
                u.has("completion_tokens") ? u.get("completion_tokens").asLong() : 0,
                u.has("total_tokens") ? u.get("total_tokens").asLong() : 0
            );
        }

        boolean finished = "stop".equals(root.at("/choices/0/finish_reason").asText(""));

        return new ProviderResponse(id, model, content, toolCalls, usage, finished);
    }
}
