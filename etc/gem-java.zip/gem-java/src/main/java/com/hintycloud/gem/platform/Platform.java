package com.hintycloud.gem.platform;

import java.util.Locale;

/**
 * Detects the current platform (OS, arch, shell) for environment-aware behavior.
 */
public record Platform(OS os, Arch arch, Shell shell, String osVersion) {

    public enum OS {
        LINUX, MACOS, WINDOWS, FREEBSD, UNKNOWN;

        public String displayName() {
            return switch (this) {
                case LINUX -> "Linux";
                case MACOS -> "macOS";
                case WINDOWS -> "Windows";
                case FREEBSD -> "FreeBSD";
                case UNKNOWN -> "Unknown";
            };
        }
    }

    public enum Arch {
        X86_64, AARCH64, ARM32, X86, UNKNOWN;

        public String displayName() {
            return switch (this) {
                case X86_64 -> "x86_64 (amd64)";
                case AARCH64 -> "aarch64 (arm64)";
                case ARM32 -> "arm32";
                case X86 -> "x86 (i686)";
                case UNKNOWN -> "unknown";
            };
        }
    }

    public enum Shell {
        BASH, ZSH, FISH, POWERSHELL, CMD, SH, UNKNOWN;

        public String displayName() {
            return switch (this) {
                case BASH -> "bash";
                case ZSH -> "zsh";
                case FISH -> "fish";
                case POWERSHELL -> "powershell";
                case CMD -> "cmd";
                case SH -> "sh";
                case UNKNOWN -> "unknown";
            };
        }
    }

    /**
     * Detect the current platform.
     */
    public static Platform detect() {
        OS os = detectOS();
        Arch arch = detectArch();
        Shell shell = detectShell();
        String osVersion = System.getProperty("os.version", "unknown");
        return new Platform(os, arch, shell, osVersion);
    }

    private static OS detectOS() {
        String name = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (name.contains("linux")) return OS.LINUX;
        if (name.contains("mac") || name.contains("darwin")) return OS.MACOS;
        if (name.contains("win")) return OS.WINDOWS;
        if (name.contains("freebsd")) return OS.FREEBSD;
        return OS.UNKNOWN;
    }

    private static Arch detectArch() {
        String arch = System.getProperty("os.arch", "").toLowerCase(Locale.ROOT);
        if (arch.matches("amd64|x86_64")) return Arch.X86_64;
        if (arch.matches("aarch64|arm64")) return Arch.AARCH64;
        if (arch.matches("arm|arm32")) return Arch.ARM32;
        if (arch.matches("x86|i386|i686")) return Arch.X86;
        return Arch.UNKNOWN;
    }

    private static Shell detectShell() {
        String shellEnv = System.getenv("SHELL");
        if (shellEnv == null) {
            String psModule = System.getenv("PSModulePath");
            if (psModule != null) return Shell.POWERSHELL;
            String comspec = System.getenv("COMSPEC");
            if (comspec != null && comspec.toLowerCase(Locale.ROOT).contains("cmd")) return Shell.CMD;
            return Shell.UNKNOWN;
        }
        if (shellEnv.contains("zsh")) return Shell.ZSH;
        if (shellEnv.contains("bash")) return Shell.BASH;
        if (shellEnv.contains("fish")) return Shell.FISH;
        if (shellEnv.contains("sh")) return Shell.SH;
        return Shell.UNKNOWN;
    }

    /**
     * Returns a human-readable summary of the platform.
     */
    public String summary() {
        return String.format("%s/%s (%s) shell=%s", os.displayName(), arch.displayName(), osVersion, shell.displayName());
    }

    /**
     * Check if the platform is Unix-like (Linux, macOS, FreeBSD).
     */
    public boolean isUnixLike() {
        return os == OS.LINUX || os == OS.MACOS || os == OS.FREEBSD;
    }
}
