package com.hintycloud.gem.agent;

import com.hintycloud.gem.config.GemConfig;
import com.hintycloud.gem.memory.MemoryStore;
import com.hintycloud.gem.provider.*;
import com.hintycloud.gem.tools.ToolRegistry;
import com.hintycloud.gem.tools.ToolResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Agent loop — the core think/act/observe cycle that drives the AI agent.
 *
 * <p>The agent operates in a loop:
 * <ol>
 *   <li><b>Think</b>: Send conversation to the LLM, receive response (possibly with tool calls)</li>
 *   <li><b>Act</b>: If tool calls are present, execute them via the tool registry</li>
 *   <li><b>Observe</b>: Add tool results back to the conversation and continue</li>
 * </ol>
 *
 * <p>The loop terminates when the LLM produces a final text response without tool calls,
 * or when the maximum number of turns is reached.
 */
public class AgentLoop {

    private static final Logger LOG = LoggerFactory.getLogger(AgentLoop.class);

    private final GemConfig config;
    private final Provider provider;
    private final ToolRegistry toolRegistry;
    private final MemoryStore memory;
    private final AtomicInteger turnCount = new AtomicInteger(0);

    public AgentLoop(GemConfig config, Provider provider, ToolRegistry toolRegistry, MemoryStore memory) {
        this.config = config;
        this.provider = provider;
        this.toolRegistry = toolRegistry;
        this.memory = memory;
    }

    /**
     * Run the agent loop for a given user prompt.
     *
     * @param prompt     the user's input
     * @param listener   callback for observing agent activity
     * @return the final response text
     */
    public String run(String prompt, AgentListener listener) {
        memory.add(ChatMessage.user(prompt));

        String model = config.getDefaultModel();
        int maxTurns = config.getMaxTurns();

        while (turnCount.get() < maxTurns) {
            int turn = turnCount.incrementAndGet();
            LOG.debug("Agent turn {} of {}", turn, maxTurns);

            // THINK — query the LLM
            listener.onThink(turn, prompt);
            ProviderResponse response;
            try {
                List<ChatMessage> messages = memory.getMessages();
                response = provider.complete(messages, model, Map.of());
            } catch (IOException e) {
                listener.onError("Provider error: " + e.getMessage());
                return "Error: " + e.getMessage();
            }

            // Add assistant response to memory
            if (!response.content().isEmpty()) {
                memory.add(ChatMessage.assistant(response.content()));
            }

            // ACT — execute tool calls if present
            if (response.hasToolCalls()) {
                listener.onAct(response.toolCalls());
                for (ProviderResponse.ToolCall tc : response.toolCalls()) {
                    listener.onToolCall(tc.name(), tc.arguments());

                    ToolResult result;
                    try {
                        @SuppressWarnings("unchecked")
                        Map<String, Object> args = new com.fasterxml.jackson.databind.ObjectMapper()
                            .readValue(tc.arguments(), Map.class);
                        result = toolRegistry.execute(tc.name(), args);
                    } catch (Exception e) {
                        result = ToolResult.fail("Failed to parse tool arguments: " + e.getMessage());
                    }

                    listener.onToolResult(tc.name(), result);
                    memory.add(ChatMessage.tool(result.toString()));
                }
                // Loop back to THINK
                continue;
            }

            // OBSERVE — final response, no more tool calls
            listener.onObserve(response.content());
            return response.content();
        }

        String msg = "Agent reached maximum turns (" + maxTurns + ")";
        listener.onError(msg);
        return msg;
    }

    /**
     * Run the agent loop with streaming support.
     */
    public String runStream(String prompt, AgentListener listener) {
        memory.add(ChatMessage.user(prompt));

        String model = config.getDefaultModel();
        int maxTurns = config.getMaxTurns();
        StringBuilder finalContent = new StringBuilder();

        while (turnCount.get() < maxTurns) {
            int turn = turnCount.incrementAndGet();
            listener.onThink(turn, prompt);

            ProviderResponse response;
            try {
                List<ChatMessage> messages = memory.getMessages();
                final ProviderResponse[] responseHolder = new ProviderResponse[1];

                provider.completeStream(messages, model, Map.of(), new Provider.StreamHandler() {
                    @Override
                    public void onChunk(String delta, boolean isToolCall) {
                        listener.onStreamChunk(delta, isToolCall);
                        if (!isToolCall) {
                            finalContent.append(delta);
                        }
                    }

                    @Override
                    public void onComplete(ProviderResponse r) {
                        responseHolder[0] = r;
                    }

                    @Override
                    public void onError(Throwable error) {
                        listener.onError("Stream error: " + error.getMessage());
                    }
                });

                response = responseHolder[0];
                if (response == null) {
                    return finalContent.toString();
                }
            } catch (IOException e) {
                listener.onError("Provider error: " + e.getMessage());
                return "Error: " + e.getMessage();
            }

            if (!response.content().isEmpty()) {
                memory.add(ChatMessage.assistant(response.content()));
            }

            if (response.hasToolCalls()) {
                listener.onAct(response.toolCalls());
                for (ProviderResponse.ToolCall tc : response.toolCalls()) {
                    listener.onToolCall(tc.name(), tc.arguments());
                    ToolResult result;
                    try {
                        @SuppressWarnings("unchecked")
                        Map<String, Object> args = new com.fasterxml.jackson.databind.ObjectMapper()
                            .readValue(tc.arguments(), Map.class);
                        result = toolRegistry.execute(tc.name(), args);
                    } catch (Exception e) {
                        result = ToolResult.fail("Failed to parse tool arguments: " + e.getMessage());
                    }
                    listener.onToolResult(tc.name(), result);
                    memory.add(ChatMessage.tool(result.toString()));
                }
                finalContent.setLength(0);
                continue;
            }

            listener.onObserve(response.content());
            return response.content();
        }

        return "Agent reached maximum turns";
    }

    /**
     * Get the current turn count.
     */
    public int getTurnCount() {
        return turnCount.get();
    }

    /**
     * Reset the agent for a new conversation.
     */
    public void reset() {
        turnCount.set(0);
        memory.newSession();
    }
}
