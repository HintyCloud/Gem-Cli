package com.hintycloud.gem.cli;

import com.hintycloud.gem.agent.JobQueue;
import picocli.CommandLine.Command;
import picocli.CommandLine.ParentCommand;

import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.Callable;

/**
 * `gem jobs` — List and manage agent jobs.
 */
@Command(name = "jobs", description = "List and manage agent jobs", mixinStandardHelpOptions = true)
public class JobsCommand implements Callable<Integer> {

    @ParentCommand
    private GemCommand parent;

    @Override
    public Integer call() {
        // Show a placeholder job listing
        // In a full implementation, this would connect to a running agent server
        System.out.println();
        System.out.println("  Jobs (no active server connection)");
        System.out.println("  ─────────────────────────────────────");
        System.out.println("  Use 'gem serve' to start the agent server,");
        System.out.println("  then 'gem jobs' to list running jobs.");
        System.out.println();

        return 0;
    }
}
