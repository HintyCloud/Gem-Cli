package com.hintycloud.gem.tools;

import java.util.Map;

/**
 * Interface for tools that the agent can execute.
 */
public interface Tool {

    /**
     * Unique name of the tool (e.g. "shell", "files").
     */
    String name();

    /**
     * Human-readable description of what this tool does.
     */
    String description();

    /**
     * JSON schema describing the tool's input parameters.
     */
    Map<String, Object> schema();

    /**
     * Execute the tool with the given parameters.
     *
     * @param args the input arguments matching the schema
     * @return the tool execution result
     */
    ToolResult execute(Map<String, Object> args);

    /**
     * Check if this tool is available on the current platform.
     */
    default boolean isAvailable() {
        return true;
    }

    /**
     * Whether this tool requires user confirmation before execution.
     */
    default boolean requiresConfirmation() {
        return false;
    }
}
