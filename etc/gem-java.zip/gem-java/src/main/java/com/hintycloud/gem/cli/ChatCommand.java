package com.hintycloud.gem.cli;

import com.hintycloud.gem.Main;
import com.hintycloud.gem.agent.*;
import com.hintycloud.gem.config.GemConfig;
import com.hintycloud.gem.memory.MemoryStore;
import com.hintycloud.gem.provider.*;
import com.hintycloud.gem.tools.ToolRegistry;
import org.jline.reader.*;
import org.jline.reader.impl.history.DefaultHistory;
import org.jline.terminal.Terminal;
import org.jline.terminal.TerminalBuilder;
import org.jline.utils.AttributedString;
import org.jline.utils.AttributedStyle;
import org.jline.utils.InfoCmp;
import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;
import picocli.CommandLine.ParentCommand;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.Callable;

/**
 * `gem chat` — Start an interactive chat session with the AI agent.
 *
 * <p>Supports slash commands:
 * <ul>
 *   <li>/help — Show available slash commands</li>
 *   <li>/status — Show agent status</li>
 *   <li>/model [name] — Switch model</li>
 *   <li>/provider [name] — Switch provider</li>
 *   <li>/tools — List available tools</li>
 *   <li>/clear — Clear conversation history</li>
 *   <li>/save — Save conversation to disk</li>
 *   <li>/load [id] — Load a saved conversation</li>
 *   <li>/sessions — List saved sessions</li>
 *   <li>/quit or /exit — Exit the chat</li>
 * </ul>
 */
@Command(name = "chat", description = "Start an interactive chat session", mixinStandardHelpOptions = true)
public class ChatCommand implements Callable<Integer> {

    @ParentCommand
    private GemCommand parent;

    @Option(names = {"-m", "--model"}, description = "Model to use")
    private String model;

    @Option(names = {"-p", "--provider"}, description = "Provider to use")
    private String provider;

    @Option(names = {"--system"}, description = "System prompt")
    private String systemPrompt;

    @Option(names = {"--auto-approve"}, description = "Auto-approve tool executions")
    private boolean autoApprove;

    @Override
    public Integer call() {
        GemConfig config = GemConfig.load();
        if (model != null) config.setDefaultModel(model);
        if (provider != null) config.setDefaultProvider(provider);

        ProviderRegistry providerRegistry = new ProviderRegistry(config);
        ToolRegistry toolRegistry = new ToolRegistry();
        MemoryStore memory = new MemoryStore(config.getDataDir(), config.getContextWindow());

        Provider activeProvider = providerRegistry.getDefault();
        if (activeProvider == null) {
            System.err.println("No provider available: " + config.getDefaultProvider());
            return 1;
        }

        // Add system prompt if provided
        if (systemPrompt != null && !systemPrompt.isEmpty()) {
            memory.add(com.hintycloud.gem.provider.ChatMessage.system(systemPrompt));
        }

        AgentLoop agent = new AgentLoop(config, activeProvider, toolRegistry, memory);

        try {
            Terminal terminal = TerminalBuilder.builder()
                .system(true)
                .build();
            LineReader reader = LineReaderBuilder.builder()
                .terminal(terminal)
                .history(new DefaultHistory())
                .parser(new SlashCommandParser())
                .completer(new SlashCommandCompleter())
                .build();

            printWelcome(config);

            while (true) {
                String line;
                try {
                    line = reader.readLine("gem> ");
                } catch (UserInterruptException e) {
                    break;
                } catch (EndOfFileException e) {
                    break;
                }

                if (line == null || line.isBlank()) continue;
                line = line.trim();

                // Handle slash commands
                if (line.startsWith("/")) {
                    if (handleSlashCommand(line, reader, config, providerRegistry, toolRegistry, memory, agent)) {
                        break; // /quit or /exit
                    }
                    continue;
                }

                // Run the agent loop
                AgentListener listener = createListener(terminal);
                String response;
                if (config.isStreaming()) {
                    response = agent.runStream(line, listener);
                } else {
                    response = agent.run(line, listener);
                }

                if (!config.isStreaming()) {
                    System.out.println();
                    System.out.println(formatResponse(response));
                    System.out.println();
                }
            }

        } catch (IOException e) {
            System.err.println("Terminal error: " + e.getMessage());
            return 1;
        }

        return 0;
    }

    private void printWelcome(GemConfig config) {
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════════╗");
        System.out.println("  ║      Gem Chat — Interactive Agent        ║");
        System.out.println("  ╚══════════════════════════════════════════╝");
        System.out.println();
        System.out.println("  Provider: " + config.getDefaultProvider());
        System.out.println("  Model:    " + config.getDefaultModel());
        System.out.println("  Type /help for slash commands, /quit to exit");
        System.out.println();
    }

    private boolean handleSlashCommand(String input, LineReader reader,
                                        GemConfig config, ProviderRegistry providers,
                                        ToolRegistry tools, MemoryStore memory,
                                        AgentLoop agent) {
        String[] parts = input.split("\\s+", 2);
        String cmd = parts[0].toLowerCase();
        String arg = parts.length > 1 ? parts[1].trim() : "";

        switch (cmd) {
            case "/help" -> {
                System.out.println();
                System.out.println("  Slash Commands:");
                System.out.println("    /help              Show this help");
                System.out.println("    /status            Show agent status");
                System.out.println("    /model [name]      Switch model");
                System.out.println("    /provider [name]   Switch provider");
                System.out.println("    /tools             List available tools");
                System.out.println("    /clear             Clear conversation");
                System.out.println("    /save              Save conversation");
                System.out.println("    /load [id]         Load a session");
                System.out.println("    /sessions          List saved sessions");
                System.out.println("    /quit, /exit       Exit chat");
                System.out.println();
            }
            case "/status" -> {
                System.out.println("  Turns: " + agent.getTurnCount());
                System.out.println("  History: " + memory.size() + " messages");
                System.out.println("  Session: " + memory.getSessionId());
                System.out.println("  Provider: " + config.getDefaultProvider());
                System.out.println("  Model: " + config.getDefaultModel());
            }
            case "/model" -> {
                if (arg.isEmpty()) {
                    System.out.println("  Current model: " + config.getDefaultModel());
                } else {
                    config.setDefaultModel(arg);
                    System.out.println("  Switched to model: " + arg);
                }
            }
            case "/provider" -> {
                if (arg.isEmpty()) {
                    System.out.println("  Current provider: " + config.getDefaultProvider());
                } else {
                    if (providers.has(arg)) {
                        config.setDefaultProvider(arg);
                        System.out.println("  Switched to provider: " + arg);
                    } else {
                        System.out.println("  Unknown provider: " + arg);
                        System.out.println("  Available: " + String.join(", ", providers.names()));
                    }
                }
            }
            case "/tools" -> {
                System.out.println("  Available tools:");
                for (var tool : tools.all()) {
                    String avail = tool.isAvailable() ? "✓" : "✗";
                    System.out.println("    " + avail + " " + tool.name() + " — " + tool.description());
                }
            }
            case "/clear" -> {
                memory.clear();
                agent.reset();
                System.out.println("  Conversation cleared.");
            }
            case "/save" -> {
                try {
                    memory.persist();
                    System.out.println("  Saved session: " + memory.getSessionId());
                } catch (IOException e) {
                    System.out.println("  Error saving: " + e.getMessage());
                }
            }
            case "/load" -> {
                if (arg.isEmpty()) {
                    System.out.println("  Usage: /load <session-id>");
                } else {
                    try {
                        memory.load(arg);
                        System.out.println("  Loaded session: " + arg + " (" + memory.size() + " messages)");
                    } catch (IOException e) {
                        System.out.println("  Error loading: " + e.getMessage());
                    }
                }
            }
            case "/sessions" -> {
                try {
                    List<String> sessions = memory.listSessions();
                    if (sessions.isEmpty()) {
                        System.out.println("  No saved sessions.");
                    } else {
                        System.out.println("  Saved sessions:");
                        for (String s : sessions) {
                            System.out.println("    " + s);
                        }
                    }
                } catch (IOException e) {
                    System.out.println("  Error listing sessions: " + e.getMessage());
                }
            }
            case "/quit", "/exit" -> {
                System.out.println("  Goodbye!");
                return true;
            }
            default -> System.out.println("  Unknown command: " + cmd + " (type /help for commands)");
        }
        return false;
    }

    private AgentListener createListener(Terminal terminal) {
        return new AgentListener() {
            @Override
            public void onThink(int turn, String prompt) {
                // Silent in streaming mode
            }

            @Override
            public void onToolCall(String toolName, String arguments) {
                System.out.println("  ⚙ " + toolName + "(" + truncate(arguments, 60) + ")");
            }

            @Override
            public void onToolResult(String toolName, com.hintycloud.gem.tools.ToolResult result) {
                if (result.success()) {
                    System.out.println("  ✓ " + toolName + ": " + truncate(result.output(), 100));
                } else {
                    System.out.println("  ✗ " + toolName + ": " + result.error());
                }
            }

            @Override
            public void onStreamChunk(String delta, boolean isToolCall) {
                if (!isToolCall) {
                    System.out.print(delta);
                    System.out.flush();
                }
            }

            @Override
            public void onObserve(String content) {
                // In non-streaming mode, this is handled in the main loop
            }

            @Override
            public void onError(String message) {
                System.err.println("  ✗ " + message);
            }
        };
    }

    private String formatResponse(String response) {
        return "  " + response.replace("\n", "\n  ");
    }

    private String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }
}
