package com.hintycloud.gem.cli;

import com.hintycloud.gem.tools.Tool;
import com.hintycloud.gem.tools.ToolRegistry;
import picocli.CommandLine.Command;
import picocli.CommandLine.ParentCommand;

import java.util.concurrent.Callable;

/**
 * `gem tools` — List available tools.
 */
@Command(name = "tools", description = "List available tools", mixinStandardHelpOptions = true)
public class ToolsCommand implements Callable<Integer> {

    @ParentCommand
    private GemCommand parent;

    @Override
    public Integer call() {
        ToolRegistry registry = new ToolRegistry();

        System.out.println();
        System.out.println("  Available Tools");
        System.out.println("  ─────────────────────────────────────");
        System.out.printf("  %-3s %-12s %s%n", "✓", "NAME", "DESCRIPTION");
        System.out.println("  ─────────────────────────────────────");

        for (Tool tool : registry.all()) {
            String avail = tool.isAvailable() ? "✓" : "✗";
            System.out.printf("  %s %-12s %s%n", avail, tool.name(), tool.description());
        }

        System.out.println();
        return 0;
    }
}
