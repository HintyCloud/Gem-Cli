package com.hintycloud.gem.cli;

import org.jline.reader.Parser;
import org.jline.reader.ParsedLine;
import org.jline.reader.impl.DefaultParser;

/**
 * Parser that handles slash commands in the chat REPL.
 */
public class SlashCommandParser implements Parser {

    private final DefaultParser delegate = new DefaultParser();

    @Override
    public ParsedLine parse(String line, int cursor, Parser.ParseContext context) {
        return delegate.parse(line, cursor, context);
    }

    @Override
    public ParsedLine parse(String line, int cursor) {
        return delegate.parse(line, cursor);
    }
}
