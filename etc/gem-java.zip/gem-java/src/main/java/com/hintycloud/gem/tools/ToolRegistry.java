package com.hintycloud.gem.tools;

import com.hintycloud.gem.tools.impl.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registry for managing tool instances.
 */
public class ToolRegistry {

    private final Map<String, Tool> tools = new ConcurrentHashMap<>();

    public ToolRegistry() {
        // Register built-in tools
        register(new ShellTool());
        register(new FilesTool());
        register(new WebTool());
        register(new ImageTool());
        register(new GitTool());
        register(new ArchiveTool());
        register(new ArtifactsTool());
    }

    /**
     * Register a tool.
     */
    public void register(Tool tool) {
        tools.put(tool.name(), tool);
    }

    /**
     * Get a tool by name.
     */
    public Tool get(String name) {
        return tools.get(name);
    }

    /**
     * List all registered tool names.
     */
    public Set<String> names() {
        return tools.keySet();
    }

    /**
     * List all tools.
     */
    public Collection<Tool> all() {
        return tools.values();
    }

    /**
     * Check if a tool is registered.
     */
    public boolean has(String name) {
        return tools.containsKey(name);
    }

    /**
     * Execute a tool by name with the given arguments.
     */
    public ToolResult execute(String toolName, Map<String, Object> args) {
        Tool tool = tools.get(toolName);
        if (tool == null) {
            return ToolResult.fail("Unknown tool: " + toolName);
        }
        if (!tool.isAvailable()) {
            return ToolResult.fail("Tool not available: " + toolName);
        }
        try {
            return tool.execute(args);
        } catch (Exception e) {
            return ToolResult.fail(e);
        }
    }

    /**
     * Get tool definitions in OpenAI function-calling format.
     */
    public List<Map<String, Object>> toOpenAITools() {
        List<Map<String, Object>> result = new ArrayList<>();
        for (Tool tool : tools.values()) {
            if (!tool.isAvailable()) continue;
            Map<String, Object> def = new LinkedHashMap<>();
            def.put("type", "function");
            Map<String, Object> function = new LinkedHashMap<>();
            function.put("name", tool.name());
            function.put("description", tool.description());
            function.put("parameters", tool.schema());
            def.put("function", function);
            result.add(def);
        }
        return result;
    }
}
