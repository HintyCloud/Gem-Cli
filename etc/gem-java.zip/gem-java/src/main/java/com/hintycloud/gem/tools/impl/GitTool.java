package com.hintycloud.gem.tools.impl;

import com.hintycloud.gem.tools.Tool;
import com.hintycloud.gem.tools.ToolResult;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Git tool — interact with Git repositories.
 */
public class GitTool implements Tool {

    @Override
    public String name() {
        return "git";
    }

    @Override
    public String description() {
        return "Interact with Git repositories: status, log, diff, add, commit, branch, etc.";
    }

    @Override
    public Map<String, Object> schema() {
        Map<String, Object> schema = new LinkedHashMap<>();
        schema.put("type", "object");
        Map<String, Object> action = Map.of("type", "string", "description", "Git subcommand: status, log, diff, add, commit, branch, checkout, pull, push");
        Map<String, Object> args = Map.of("type", "string", "description", "Additional arguments for the git command");
        Map<String, Object> cwd = Map.of("type", "string", "description", "Working directory (repository root)");
        schema.put("properties", Map.of("action", action, "args", args, "cwd", cwd));
        schema.put("required", java.util.List.of("action"));
        return schema;
    }

    @Override
    public ToolResult execute(Map<String, Object> args) {
        String action = (String) args.get("action");
        if (action == null) return ToolResult.fail("Missing required parameter: action");

        String extraArgs = (String) args.getOrDefault("args", "");
        String workDir = (String) args.getOrDefault("cwd", System.getProperty("user.dir"));

        String command = "git " + action + (extraArgs.isEmpty() ? "" : " " + extraArgs);

        try {
            ProcessBuilder pb = new ProcessBuilder("sh", "-c", command);
            pb.directory(new java.io.File(workDir));
            pb.redirectErrorStream(true);

            Process process = pb.start();
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
            }

            boolean finished = process.waitFor(30, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                return ToolResult.fail("Git command timed out");
            }

            int exitCode = process.exitValue();
            String result = output.toString().trim();
            if (exitCode != 0 && result.isEmpty()) {
                return ToolResult.fail("git " + action + " failed with exit code " + exitCode);
            }
            return ToolResult.ok(result);

        } catch (Exception e) {
            return ToolResult.fail(e);
        }
    }

    @Override
    public boolean isAvailable() {
        try {
            Process process = new ProcessBuilder("git", "--version")
                .redirectErrorStream(true)
                .start();
            return process.waitFor(5, TimeUnit.SECONDS) && process.exitValue() == 0;
        } catch (Exception e) {
            return false;
        }
    }
}
