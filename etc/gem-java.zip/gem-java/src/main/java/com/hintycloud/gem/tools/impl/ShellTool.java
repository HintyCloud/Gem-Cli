package com.hintycloud.gem.tools.impl;

import com.hintycloud.gem.tools.Tool;
import com.hintycloud.gem.tools.ToolResult;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Shell tool — execute shell commands on the host system.
 */
public class ShellTool implements Tool {

    @Override
    public String name() {
        return "shell";
    }

    @Override
    public String description() {
        return "Execute shell commands on the host system and return their output";
    }

    @Override
    public Map<String, Object> schema() {
        Map<String, Object> schema = new LinkedHashMap<>();
        schema.put("type", "object");
        Map<String, Object> command = Map.of(
            "type", "string",
            "description", "The shell command to execute"
        );
        Map<String, Object> timeout = Map.of(
            "type", "integer",
            "description", "Timeout in seconds (default: 30)"
        );
        Map<String, Object> cwd = Map.of(
            "type", "string",
            "description", "Working directory for command execution"
        );
        schema.put("properties", Map.of("command", command, "timeout", timeout, "cwd", cwd));
        schema.put("required", java.util.List.of("command"));
        return schema;
    }

    @Override
    public ToolResult execute(Map<String, Object> args) {
        String command = (String) args.get("command");
        if (command == null || command.isEmpty()) {
            return ToolResult.fail("Missing required parameter: command");
        }

        int timeoutSec = args.containsKey("timeout") ? ((Number) args.get("timeout")).intValue() : 30;
        String workDir = (String) args.getOrDefault("cwd", System.getProperty("user.dir"));

        try {
            ProcessBuilder pb = new ProcessBuilder();
            String os = System.getProperty("os.name").toLowerCase();
            if (os.contains("win")) {
                pb.command("cmd", "/c", command);
            } else {
                pb.command("sh", "-c", command);
            }
            pb.directory(new java.io.File(workDir));
            pb.redirectErrorStream(true);

            Process process = pb.start();
            StringBuilder output = new StringBuilder();

            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }
            }

            boolean finished = process.waitFor(timeoutSec, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                return ToolResult.fail("Command timed out after " + timeoutSec + "s");
            }

            int exitCode = process.exitValue();
            String result = output.toString().trim();
            if (exitCode != 0 && result.isEmpty()) {
                return ToolResult.fail("Command exited with code " + exitCode);
            }
            return ToolResult.ok(result + (exitCode != 0 ? "\n[exit code: " + exitCode + "]" : ""));

        } catch (Exception e) {
            return ToolResult.fail(e);
        }
    }

    @Override
    public boolean requiresConfirmation() {
        return true;
    }
}
