package com.hintycloud.gem.agent;

/**
 * Agent configuration and metadata.
 */
public record AgentConfig(
    String name,
    String model,
    String systemPrompt,
    int maxTurns,
    boolean autoApprove
) {
    /**
     * Create a default agent config.
     */
    public static AgentConfig defaults() {
        return new AgentConfig("gem", "default", "", 20, false);
    }

    /**
     * Create an agent config with a custom system prompt.
     */
    public static AgentConfig withPrompt(String systemPrompt) {
        return new AgentConfig("gem", "default", systemPrompt, 20, false);
    }

    /**
     * Builder-style: set the model.
     */
    public AgentConfig withModel(String model) {
        return new AgentConfig(name, model, systemPrompt, maxTurns, autoApprove);
    }

    /**
     * Builder-style: set max turns.
     */
    public AgentConfig withMaxTurns(int maxTurns) {
        return new AgentConfig(name, model, systemPrompt, maxTurns, autoApprove);
    }

    /**
     * Builder-style: set auto-approve.
     */
    public AgentConfig withAutoApprove(boolean autoApprove) {
        return new AgentConfig(name, model, systemPrompt, maxTurns, autoApprove);
    }
}
