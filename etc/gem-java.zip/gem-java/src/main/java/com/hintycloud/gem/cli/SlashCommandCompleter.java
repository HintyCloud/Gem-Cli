package com.hintycloud.gem.cli;

import org.jline.reader.Completer;
import org.jline.reader.LineReader;
import org.jline.reader.ParsedLine;
import org.jline.reader.Candidate;
import org.jline.utils.AttributedString;

import java.util.List;

/**
 * Completer for slash commands in the chat REPL.
 */
public class SlashCommandCompleter implements Completer {

    private static final List<String> SLASH_COMMANDS = List.of(
        "/help", "/status", "/model", "/provider", "/tools",
        "/clear", "/save", "/load", "/sessions", "/quit", "/exit"
    );

    @Override
    public void complete(LineReader reader, ParsedLine line, List<Candidate> candidates) {
        if (line.word().startsWith("/")) {
            for (String cmd : SLASH_COMMANDS) {
                candidates.add(new Candidate(
                    cmd,
                    cmd,
                    null,
                    null,
                    null,
                    null,
                    true
                ));
            }
        }
    }
}
