package com.hintycloud.gem.provider;

import java.util.List;

/**
 * Response from a provider completion request.
 */
public record ProviderResponse(
    String id,
    String model,
    String content,
    List<ToolCall> toolCalls,
    Usage usage,
    boolean finished
) {

    /**
     * A tool call requested by the model.
     */
    public record ToolCall(
        String id,
        String name,
        String arguments
    ) {}

    /**
     * Token usage statistics.
     */
    public record Usage(
        long promptTokens,
        long completionTokens,
        long totalTokens
    ) {
        public static Usage empty() {
            return new Usage(0, 0, 0);
        }
    }

    /**
     * Create a simple text response.
     */
    public static ProviderResponse text(String content, String model) {
        return new ProviderResponse("", model, content, List.of(), Usage.empty(), true);
    }

    /**
     * Create a response with tool calls.
     */
    public static ProviderResponse withToolCalls(String model, List<ToolCall> toolCalls) {
        return new ProviderResponse("", model, "", toolCalls, Usage.empty(), false);
    }

    /**
     * Check if the response contains tool calls.
     */
    public boolean hasToolCalls() {
        return toolCalls != null && !toolCalls.isEmpty();
    }
}
