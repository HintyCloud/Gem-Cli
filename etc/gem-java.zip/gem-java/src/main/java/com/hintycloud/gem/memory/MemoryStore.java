package com.hintycloud.gem.memory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.hintycloud.gem.provider.ChatMessage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedDeque;

/**
 * Memory store — manages conversation history with both in-memory
 * and persistent (file-based) storage.
 */
public class MemoryStore {

    private static final ObjectMapper MAPPER = new ObjectMapper()
        .registerModule(new JavaTimeModule())
        .enable(SerializationFeature.INDENT_OUTPUT);

    private final Deque<ConversationEntry> history = new ConcurrentLinkedDeque<>();
    private final Path persistDir;
    private final int maxHistoryEntries;
    private String sessionId;

    public MemoryStore(String dataDir, int maxHistoryEntries) {
        this.persistDir = Path.of(dataDir, "memory");
        this.maxHistoryEntries = maxHistoryEntries;
        this.sessionId = generateSessionId();
    }

    /**
     * Add a message to the current conversation history.
     */
    public void add(ChatMessage message) {
        add(message, Map.of());
    }

    /**
     * Add a message with metadata to the current conversation history.
     */
    public void add(ChatMessage message, Map<String, String> metadata) {
        ConversationEntry entry = new ConversationEntry(
            sessionId,
            Instant.now(),
            message,
            metadata
        );
        history.addLast(entry);

        // Trim if exceeding max
        while (history.size() > maxHistoryEntries) {
            history.removeFirst();
        }
    }

    /**
     * Get all messages in the current conversation.
     */
    public List<ChatMessage> getMessages() {
        return history.stream()
            .map(ConversationEntry::message)
            .toList();
    }

    /**
     * Get the last N messages.
     */
    public List<ChatMessage> getLast(int n) {
        List<ChatMessage> all = getMessages();
        if (all.size() <= n) return all;
        return all.subList(all.size() - n, all.size());
    }

    /**
     * Get all conversation entries (including metadata).
     */
    public List<ConversationEntry> getEntries() {
        return List.copyOf(history);
    }

    /**
     * Clear the current conversation history.
     */
    public void clear() {
        history.clear();
    }

    /**
     * Save the current conversation to persistent storage.
     */
    public void persist() throws IOException {
        Files.createDirectories(persistDir);
        Path file = persistDir.resolve(sessionId + ".json");
        MAPPER.writeValue(file.toFile(), List.copyOf(history));
    }

    /**
     * Load a conversation from persistent storage.
     */
    public void load(String sessionId) throws IOException {
        Path file = persistDir.resolve(sessionId + ".json");
        if (!Files.exists(file)) {
            throw new IOException("Session not found: " + sessionId);
        }
        history.clear();
        this.sessionId = sessionId;
        List<ConversationEntry> entries = MAPPER.readValue(file.toFile(),
            MAPPER.getTypeFactory().constructCollectionType(List.class, ConversationEntry.class));
        history.addAll(entries);
    }

    /**
     * List all persisted session IDs.
     */
    public List<String> listSessions() throws IOException {
        if (!Files.isDirectory(persistDir)) return List.of();
        try (var stream = Files.list(persistDir)) {
            return stream
                .filter(p -> p.toString().endsWith(".json"))
                .map(p -> p.getFileName().toString().replace(".json", ""))
                .sorted()
                .toList();
        }
    }

    /**
     * Start a new conversation session.
     */
    public void newSession() {
        this.sessionId = generateSessionId();
        history.clear();
    }

    /**
     * Get the current session ID.
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * Number of messages in the current history.
     */
    public int size() {
        return history.size();
    }

    private static String generateSessionId() {
        return Instant.now().toString().replace(":", "-").replace(".", "-");
    }
}
