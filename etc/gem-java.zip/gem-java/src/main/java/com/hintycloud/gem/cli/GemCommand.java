package com.hintycloud.gem.cli;

import com.hintycloud.gem.Main;
import com.hintycloud.gem.cli.*;
import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

import java.util.concurrent.Callable;

/**
 * Root command for the Gem CLI.
 */
@Command(
    name = Main.NAME,
    version = Main.VERSION,
    mixinStandardHelpOptions = true,
    description = "Gem CLI Agent — AI-powered command-line agent for the HintyCloud ecosystem",
    subcommands = {
        StatusCommand.class,
        ServeCommand.class,
        ChatCommand.class,
        ProjectCommand.class,
        JobsCommand.class,
        ModelsCommand.class,
        ProvidersCommand.class,
        ToolsCommand.class,
        AgentsCommand.class,
    }
)
public class GemCommand implements Callable<Integer> {

    @Option(names = {"--config"}, description = "Path to config file")
    private String configFile;

    @Option(names = {"-v", "--verbose"}, description = "Enable verbose output")
    private boolean verbose;

    @Option(names = {"--provider"}, description = "Override the default provider")
    private String provider;

    @Option(names = {"--model"}, description = "Override the default model")
    private String model;

    @Override
    public Integer call() {
        // No subcommand specified — show help
        CommandLine.usage(this, System.out);
        return 0;
    }

    public String getConfigFile() { return configFile; }
    public boolean isVerbose() { return verbose; }
    public String getProvider() { return provider; }
    public String getModel() { return model; }
}
