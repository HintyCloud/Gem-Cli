/*
 * agent.h - Agent loop (think/act/observe) for Gem CLI
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 */
#ifndef GEM_AGENT_H
#define GEM_AGENT_H

#include "config.h"
#include "provider.h"
#include "tools.h"
#include "memory.h"

/* Agent state during a run */
typedef enum {
    GEM_AGENT_IDLE,
    GEM_AGENT_THINKING,
    GEM_AGENT_ACTING,
    GEM_AGENT_OBSERVING,
    GEM_AGENT_DONE,
    GEM_AGENT_ERROR
} gem_agent_state_t;

/* Agent run context */
typedef struct {
    char                  name[GEM_MAX_NAME_LEN];
    gem_agent_state_t     state;
    int                   turn;
    int                   max_turns;
    gem_message_t        *messages;     /* conversation history for this run */
    int                   msg_count;
    gem_provider_t       *provider;
    gem_tool_registry_t  *tools;
    gem_memory_t         *memory;
    gem_config_t         *config;
    char                  model[GEM_MAX_NAME_LEN];
    char                  system_prompt[1024];

    /* Callbacks (optional) */
    void (*on_think)(const char *thought, void *ctx);
    void (*on_act)(const char *tool_name, const char *args, void *ctx);
    void (*on_observe)(const char *result, void *ctx);
    void (*on_error)(const char *error, void *ctx);
    void  *callback_ctx;
} gem_agent_t;

/* Initialize an agent */
int gem_agent_init(gem_agent_t *agent, const char *name,
                   gem_provider_t *provider,
                   gem_tool_registry_t *tools,
                   gem_memory_t *memory,
                   gem_config_t *config);

/* Run the agent loop with an initial user message */
int gem_agent_run(gem_agent_t *agent, const char *user_message);

/* Run a single step (think/act/observe) — returns 0 if more steps, 1 if done */
int gem_agent_step(gem_agent_t *agent);

/* Get the last assistant response */
const char *gem_agent_last_response(const gem_agent_t *agent);

/* Stop the agent */
void gem_agent_stop(gem_agent_t *agent);

/* Free agent resources */
void gem_agent_free(gem_agent_t *agent);

/* State to string */
const char *gem_agent_state_str(gem_agent_state_t state);

#endif /* GEM_AGENT_H */
