/*
 * main.c - Entry point for Gem CLI
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <curl/curl.h>

#include "config.h"
#include "provider.h"
#include "tools.h"
#include "agent.h"
#include "memory.h"
#include "chat.h"
#include "platform.h"

/* ---- version banner ---- */

static void print_banner(void) {
    printf("  Gem CLI v" GEM_VERSION " — HintyCloud\n");
    printf("  An AI agent powered by the think/act/observe loop.\n\n");
}

/* ---- usage ---- */

static void print_usage(const char *prog) {
    print_banner();
    printf("  Usage: %s [options] <command> [args...]\n\n", prog);
    printf("  Commands:\n");
    printf("    status       Show system status and configuration\n");
    printf("    serve        Start the Gem API server\n");
    printf("    chat         Start interactive chat REPL\n");
    printf("    project      Manage projects\n");
    printf("    jobs         List and manage background jobs\n");
    printf("    models       List available models\n");
    printf("    providers    List and manage providers\n");
    printf("    tools        List and manage tools\n");
    printf("    agents       List and manage agents\n");
    printf("\n");
    printf("  Options:\n");
    printf("    -c, --config <path>   Configuration file path\n");
    printf("    -m, --model <name>    Override default model\n");
    printf("    -p, --provider <name> Override default provider\n");
    printf("    -v, --verbose         Enable verbose output\n");
    printf("    -d, --debug           Enable debug output\n");
    printf("    -V, --version         Print version and exit\n");
    printf("    -h, --help            Print this help and exit\n");
    printf("\n");
    printf("  License: GPL-3.0 — https://www.gnu.org/licenses/gpl-3.0.html\n");
}

/* ---- command: status ---- */

static int cmd_status(gem_config_t *cfg, gem_platform_info_t *platform,
                      gem_tool_registry_t *tools, gem_memory_t *mem) {
    print_banner();
    printf("  Platform:\n");
    printf("    OS:       %s %s\n", platform->os_name, platform->os_version);
    printf("    Arch:     %s\n", gem_platform_arch_str(platform->arch));
    printf("    Hostname: %s\n", platform->hostname);
    printf("    User:     %s\n", platform->username);
    printf("    Shell:    %s\n", platform->shell);
    printf("    CPUs:     %d\n", platform->ncpu);
    printf("    Memory:   %lu MB\n", platform->mem_total_mb);
    printf("\n");
    printf("  Directories:\n");
    printf("    Config: %s\n", gem_platform_config_dir());
    printf("    Data:   %s\n", gem_platform_data_dir());
    printf("    Cache:  %s\n", gem_platform_cache_dir());
    printf("\n");
    printf("  Configuration:\n");
    gem_config_print(cfg);
    printf("\n");
    printf("  Tools (%d):\n", tools->count);
    gem_tool_list(tools);
    printf("\n");
    gem_memory_stats(mem);
    return 0;
}

/* ---- command: chat ---- */

static int cmd_chat(gem_config_t *cfg, gem_provider_t *provider,
                    gem_tool_registry_t *tools, gem_memory_t *mem,
                    const char *model_override) {
    gem_agent_t agent;
    gem_agent_init(&agent, "default", provider, tools, mem, cfg);
    if (model_override) {
        strncpy(agent.model, model_override, GEM_MAX_NAME_LEN - 1);
    }

    gem_chat_t chat;
    gem_chat_init(&chat, &agent, cfg->chat_prompt_format, cfg->chat_history_size);
    return gem_chat_start(&chat);
}

/* ---- command: models ---- */

static int cmd_models(gem_config_t *cfg) {
    printf("  Available Models (from configured providers):\n\n");
    for (int i = 0; i < cfg->provider_count; i++) {
        gem_provider_config_t *p = &cfg->providers[i];
        printf("  [%s] %s\n", p->name, p->model);
        printf("    API: %s\n", p->api_url);
        printf("    Enabled: %s\n", p->enabled ? "yes" : "no");
    }
    printf("\n  Default: %s (via %s)\n", cfg->default_model, cfg->default_provider);
    return 0;
}

/* ---- command: providers ---- */

static int cmd_providers(gem_config_t *cfg) {
    printf("  Providers (%d):\n\n", cfg->provider_count);
    for (int i = 0; i < cfg->provider_count; i++) {
        gem_provider_config_t *p = &cfg->providers[i];
        printf("  %-12s %-8s %s\n", p->name, p->enabled ? "[ON]" : "[OFF]", p->api_url);
        printf("    Model: %s | Timeout: %dms | Retries: %d\n",
               p->model, p->timeout_ms, p->max_retries);
    }
    printf("\n  Default: %s\n", cfg->default_provider);
    return 0;
}

/* ---- command: tools ---- */

static int cmd_tools(gem_tool_registry_t *tools) {
    printf("  Registered Tools (%d):\n\n", tools->count);
    gem_tool_list(tools);
    printf("\n");
    return 0;
}

/* ---- command: agents ---- */

static int cmd_agents(gem_config_t *cfg) {
    printf("  Configured Agents (%d):\n\n", cfg->agent_count);
    printf("  %-12s %-16s %-10s %s\n", "NAME", "MODEL", "MAX_TURNS", "STATUS");
    printf("  %-12s %-16s %-10s %s\n", "----", "-----", "---------", "------");
    for (int i = 0; i < cfg->agent_count; i++) {
        gem_agent_config_t *a = &cfg->agents[i];
        printf("  %-12s %-16s %-10d %s\n",
               a->name, a->model, a->max_turns,
               a->enabled ? "enabled" : "disabled");
    }
    return 0;
}

/* ---- command: serve ---- */

static int cmd_serve(gem_config_t *cfg) {
    printf("  Gem API Server (v" GEM_VERSION ")\n");
    printf("  Note: serve command requires the full Gem server build.\n");
    printf("  Use 'gem serve' from the Go/Node build for HTTP API.\n\n");
    printf("  Config: default_model=%s default_provider=%s\n",
           cfg->default_model, cfg->default_provider);
    return 0;
}

/* ---- command: project ---- */

static int cmd_project(int argc, char **argv) {
    if (argc > 0 && strcmp(argv[0], "list") == 0) {
        printf("  Projects: (none configured)\n");
    } else if (argc > 0 && strcmp(argv[0], "create") == 0) {
        printf("  Project created: %s\n", argc > 1 ? argv[1] : "default");
    } else {
        printf("  Project subcommands: list, create, delete, info\n");
    }
    return 0;
}

/* ---- command: jobs ---- */

static int cmd_jobs(int argc, char **argv) {
    if (argc > 0 && strcmp(argv[0], "list") == 0) {
        printf("  No background jobs running.\n");
    } else {
        printf("  Jobs subcommands: list, cancel, info\n");
    }
    return 0;
}

/* ---- main ---- */

int main(int argc, char **argv) {
    /* Long options */
    static struct option long_options[] = {
        {"config",   required_argument, 0, 'c'},
        {"model",    required_argument, 0, 'm'},
        {"provider", required_argument, 0, 'p'},
        {"verbose",  no_argument,       0, 'v'},
        {"debug",    no_argument,       0, 'd'},
        {"version",  no_argument,       0, 'V'},
        {"help",     no_argument,       0, 'h'},
        {0, 0, 0, 0}
    };

    char *config_path = NULL;
    char *model_override = NULL;
    char *provider_override = NULL;
    int verbose = 0, debug = 0;

    int opt;
    while ((opt = getopt_long(argc, argv, "c:m:p:vdVh", long_options, NULL)) != -1) {
        switch (opt) {
            case 'c': config_path = optarg; break;
            case 'm': model_override = optarg; break;
            case 'p': provider_override = optarg; break;
            case 'v': verbose = 1; break;
            case 'd': debug = 1; break;
            case 'V':
                printf("gem " GEM_VERSION "\n");
                return 0;
            case 'h':
                print_usage(argv[0]);
                return 0;
            default:
                print_usage(argv[0]);
                return 1;
        }
    }

    /* Remaining args = command + subargs */
    int cmd_argc = argc - optind;
    char **cmd_argv = argv + optind;

    if (cmd_argc == 0) {
        print_usage(argv[0]);
        return 0;
    }

    const char *command = cmd_argv[0];

    /* ---- Initialize core components ---- */

    /* Platform detection */
    gem_platform_info_t platform;
    gem_platform_detect(&platform);

    /* Configuration */
    gem_config_t cfg;
    if (config_path) {
        gem_config_defaults(&cfg);
        if (gem_config_load_file(&cfg, config_path) != 0) {
            fprintf(stderr, "Warning: could not load config from %s, using defaults.\n", config_path);
        }
    } else {
        gem_config_load(&cfg);
    }
    if (verbose) cfg.verbose = 1;
    if (debug)   cfg.debug = 1;
    if (model_override) strncpy(cfg.default_model, model_override, GEM_MAX_NAME_LEN - 1);

    /* Provider */
    const char *prov_name = provider_override ? provider_override : cfg.default_provider;
    gem_provider_config_t *pc = gem_config_find_provider(&cfg, prov_name);
    if (!pc) pc = &cfg.providers[0]; /* fallback to first */

    gem_provider_t provider;
    if (gem_provider_opencode_create(&provider, pc) != 0) {
        fprintf(stderr, "Error: failed to initialize provider '%s'.\n", prov_name);
        return 1;
    }

    /* Tools */
    gem_tool_registry_t tools;
    gem_tool_registry_init(&tools);

    /* Memory */
    gem_memory_t mem;
    gem_memory_init(&mem, cfg.memory_path, cfg.memory_max_entries, cfg.memory_enabled);

    /* ---- Dispatch commands ---- */

    int rc = 0;

    if (strcmp(command, "status") == 0) {
        rc = cmd_status(&cfg, &platform, &tools, &mem);
    }
    else if (strcmp(command, "chat") == 0) {
        rc = cmd_chat(&cfg, &provider, &tools, &mem, model_override);
    }
    else if (strcmp(command, "models") == 0) {
        rc = cmd_models(&cfg);
    }
    else if (strcmp(command, "providers") == 0) {
        rc = cmd_providers(&cfg);
    }
    else if (strcmp(command, "tools") == 0) {
        rc = cmd_tools(&tools);
    }
    else if (strcmp(command, "agents") == 0) {
        rc = cmd_agents(&cfg);
    }
    else if (strcmp(command, "serve") == 0) {
        rc = cmd_serve(&cfg);
    }
    else if (strcmp(command, "project") == 0) {
        rc = cmd_project(cmd_argc - 1, cmd_argv + 1);
    }
    else if (strcmp(command, "jobs") == 0) {
        rc = cmd_jobs(cmd_argc - 1, cmd_argv + 1);
    }
    else {
        fprintf(stderr, "Unknown command: %s\n", command);
        fprintf(stderr, "Run '%s --help' for usage.\n", argv[0]);
        rc = 1;
    }

    /* ---- Cleanup ---- */
    gem_memory_free(&mem);
    if (provider.curl_handle) curl_easy_cleanup(provider.curl_handle);
    curl_global_cleanup();

    return rc;
}
