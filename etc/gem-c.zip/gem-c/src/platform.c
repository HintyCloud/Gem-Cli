/*
 * platform.c - Platform detection for Gem CLI
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 */
#include "platform.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
  #include <windows.h>
  #define GEM_OS_WINDOWS 1
#else
  #include <unistd.h>
  #include <sys/utsname.h>
  #ifdef __APPLE__
    #include <sys/sysctl.h>
  #endif
  #if defined(__linux__)
    #include <sys/sysinfo.h>
  #endif
#endif

/* ---- static buffers for directory paths ---- */
static char config_dir_buf[512];
static char data_dir_buf[512];
static char cache_dir_buf[512];
static int  dirs_initialized = 0;

static void init_dirs(void) {
    if (dirs_initialized) return;
    const char *home = getenv("HOME");
    if (!home) home = "/tmp";

#ifdef __APPLE__
    snprintf(config_dir_buf, sizeof(config_dir_buf), "%s/Library/Application Support/gem", home);
    snprintf(data_dir_buf,    sizeof(data_dir_buf),    "%s/Library/Application Support/gem", home);
    snprintf(cache_dir_buf,   sizeof(cache_dir_buf),   "%s/Library/Caches/gem", home);
#elif defined(_WIN32)
    const char *appdata = getenv("APPDATA");
    if (appdata) {
        snprintf(config_dir_buf, sizeof(config_dir_buf), "%s/gem", appdata);
        snprintf(data_dir_buf,   sizeof(data_dir_buf),   "%s/gem", appdata);
        snprintf(cache_dir_buf,  sizeof(cache_dir_buf),  "%s/gem/cache", appdata);
    } else {
        snprintf(config_dir_buf, sizeof(config_dir_buf), "%s/.config/gem", home);
        snprintf(data_dir_buf,   sizeof(data_dir_buf),   "%s/.local/share/gem", home);
        snprintf(cache_dir_buf,  sizeof(cache_dir_buf),  "%s/.cache/gem", home);
    }
#else
    /* Linux / BSD — XDG */
    const char *xdg_cfg = getenv("XDG_CONFIG_HOME");
    const char *xdg_data = getenv("XDG_DATA_HOME");
    const char *xdg_cache = getenv("XDG_CACHE_HOME");
    if (xdg_cfg) snprintf(config_dir_buf, sizeof(config_dir_buf), "%s/gem", xdg_cfg);
    else         snprintf(config_dir_buf, sizeof(config_dir_buf), "%s/.config/gem", home);
    if (xdg_data) snprintf(data_dir_buf, sizeof(data_dir_buf), "%s/gem", xdg_data);
    else          snprintf(data_dir_buf, sizeof(data_dir_buf), "%s/.local/share/gem", home);
    if (xdg_cache) snprintf(cache_dir_buf, sizeof(cache_dir_buf), "%s/gem", xdg_cache);
    else           snprintf(cache_dir_buf, sizeof(cache_dir_buf), "%s/.cache/gem", home);
#endif
    dirs_initialized = 1;
}

const char *gem_platform_config_dir(void) { init_dirs(); return config_dir_buf; }
const char *gem_platform_data_dir(void)   { init_dirs(); return data_dir_buf;  }
const char *gem_platform_cache_dir(void)  { init_dirs(); return cache_dir_buf; }

const char *gem_platform_os_str(gem_platform_t os) {
    switch (os) {
        case GEM_PLATFORM_LINUX:   return "linux";
        case GEM_PLATFORM_MACOS:   return "macos";
        case GEM_PLATFORM_WINDOWS: return "windows";
        case GEM_PLATFORM_BSD:     return "bsd";
        default:                   return "unknown";
    }
}

const char *gem_platform_arch_str(gem_arch_t arch) {
    switch (arch) {
        case GEM_ARCH_X86_64: return "x86_64";
        case GEM_ARCH_ARM64:  return "arm64";
        case GEM_ARCH_X86:    return "x86";
        case GEM_ARCH_ARM:    return "arm";
        default:              return "unknown";
    }
}

void gem_platform_detect(gem_platform_info_t *info) {
    memset(info, 0, sizeof(*info));

    /* --- OS --- */
#if defined(__APPLE__)
    info->os = GEM_PLATFORM_MACOS;
    strncpy(info->os_name, "macOS", sizeof(info->os_name) - 1);
#elif defined(__linux__)
    info->os = GEM_PLATFORM_LINUX;
    strncpy(info->os_name, "Linux", sizeof(info->os_name) - 1);
#elif defined(_WIN32)
    info->os = GEM_PLATFORM_WINDOWS;
    strncpy(info->os_name, "Windows", sizeof(info->os_name) - 1);
#elif defined(__FreeBSD__) || defined(__OpenBSD__) || defined(__NetBSD__)
    info->os = GEM_PLATFORM_BSD;
    strncpy(info->os_name, "BSD", sizeof(info->os_name) - 1);
#else
    info->os = GEM_PLATFORM_UNKNOWN;
    strncpy(info->os_name, "Unknown", sizeof(info->os_name) - 1);
#endif

    /* --- Arch --- */
#if defined(__x86_64__) || defined(_M_X64)
    info->arch = GEM_ARCH_X86_64;
#elif defined(__aarch64__) || defined(_M_ARM64)
    info->arch = GEM_ARCH_ARM64;
#elif defined(__i386__) || defined(_M_IX86)
    info->arch = GEM_ARCH_X86;
#elif defined(__arm__) || defined(_M_ARM)
    info->arch = GEM_ARCH_ARM;
#else
    info->arch = GEM_ARCH_UNKNOWN;
#endif

    /* --- Hostname --- */
    gethostname(info->hostname, sizeof(info->hostname) - 1);

    /* --- Username --- */
    const char *user = getenv("USER");
    if (!user) user = getenv("USERNAME");
    if (user) strncpy(info->username, user, sizeof(info->username) - 1);

    /* --- Home dir --- */
    const char *home = getenv("HOME");
#ifdef _WIN32
    if (!home) home = getenv("USERPROFILE");
#endif
    if (home) strncpy(info->home_dir, home, sizeof(info->home_dir) - 1);

    /* --- Shell --- */
    const char *shell = getenv("SHELL");
    if (shell) strncpy(info->shell, shell, sizeof(info->shell) - 1);
    else       strncpy(info->shell, "/bin/sh", sizeof(info->shell) - 1);

    /* --- OS version --- */
#ifndef _WIN32
    struct utsname uts;
    if (uname(&uts) == 0) {
        strncpy(info->os_version, uts.release, sizeof(info->os_version) - 1);
    }
#endif

    /* --- CPU count --- */
#ifdef _WIN32
    SYSTEM_INFO si; GetSystemInfo(&si);
    info->ncpu = si.dwNumberOfProcessors;
#else
    info->ncpu = (int)sysconf(_SC_NPROCESSORS_ONLN);
    if (info->ncpu < 1) info->ncpu = 1;
#endif

    /* --- Total memory --- */
#if defined(__linux__)
    struct sysinfo si;
    if (sysinfo(&si) == 0) {
        info->mem_total_mb = si.totalram * si.mem_unit / (1024 * 1024);
    }
#elif defined(__APPLE__)
    int64_t mem = 0;
    size_t len = sizeof(mem);
    if (sysctlbyname("hw.memsize", &mem, &len, NULL, 0) == 0) {
        info->mem_total_mb = (unsigned long)(mem / (1024 * 1024));
    }
#elif defined(_WIN32)
    MEMORYSTATUSEX ms = { sizeof(ms) };
    if (GlobalMemoryStatusEx(&ms)) {
        info->mem_total_mb = (unsigned long)(ms.ullTotalPhys / (1024 * 1024));
    }
#endif
}
