/*
 * agent.c - Agent loop (think/act/observe) for Gem CLI
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 */
#include "agent.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "../vendor/cJSON.h"

const char *gem_agent_state_str(gem_agent_state_t state) {
    switch (state) {
        case GEM_AGENT_IDLE:     return "idle";
        case GEM_AGENT_THINKING: return "thinking";
        case GEM_AGENT_ACTING:   return "acting";
        case GEM_AGENT_OBSERVING:return "observing";
        case GEM_AGENT_DONE:     return "done";
        case GEM_AGENT_ERROR:    return "error";
        default:                 return "unknown";
    }
}

int gem_agent_init(gem_agent_t *agent, const char *name,
                   gem_provider_t *provider,
                   gem_tool_registry_t *tools,
                   gem_memory_t *memory,
                   gem_config_t *config) {
    memset(agent, 0, sizeof(*agent));
    strncpy(agent->name, name ? name : "default", GEM_MAX_NAME_LEN - 1);
    agent->state = GEM_AGENT_IDLE;
    agent->provider = provider;
    agent->tools = tools;
    agent->memory = memory;
    agent->config = config;

    /* Look up agent config */
    gem_agent_config_t *ac = gem_config_find_agent(config, agent->name);
    if (ac) {
        strncpy(agent->model, ac->model, GEM_MAX_NAME_LEN - 1);
        strncpy(agent->system_prompt, ac->system_prompt, sizeof(agent->system_prompt) - 1);
        agent->max_turns = ac->max_turns;
    } else {
        strncpy(agent->model, config->default_model, GEM_MAX_NAME_LEN - 1);
        strncpy(agent->system_prompt, "You are Gem, an AI assistant.", sizeof(agent->system_prompt) - 1);
        agent->max_turns = 20;
    }

    return 0;
}

int gem_agent_step(gem_agent_t *agent) {
    if (agent->state == GEM_AGENT_DONE || agent->state == GEM_AGENT_ERROR) return 1;

    /* === THINK === */
    agent->state = GEM_AGENT_THINKING;
    if (agent->config->verbose) {
        fprintf(stderr, "[agent] turn %d: thinking...\n", agent->turn + 1);
    }

    /* Build tools JSON schema */
    char *tools_json = gem_tool_schemas_json(agent->tools);

    /* Add system prompt if first turn */
    if (agent->msg_count == 0) {
        gem_message_append(&agent->messages, GEM_ROLE_SYSTEM, agent->system_prompt);
        agent->msg_count++;
    }

    /* Count messages for provider call */
    int total_msgs = 0;
    gem_message_t *m = agent->messages;
    while (m) { total_msgs++; m = m->next; }

    /* Call provider */
    gem_provider_response_t resp = {0};
    int rc = agent->provider->chat(agent->provider, agent->messages, total_msgs, tools_json, &resp);
    free(tools_json);

    if (rc != 0) {
        agent->state = GEM_AGENT_ERROR;
        if (agent->on_error) agent->on_error(resp.content ? resp.content : "Provider error", agent->callback_ctx);
        if (resp.content) {
            fprintf(stderr, "[agent] error: %s\n", resp.content);
        }
        agent->provider->free_response(&resp);
        return 1;
    }

    /* Add assistant response to messages */
    if (resp.content && resp.content[0]) {
        gem_message_append(&agent->messages, GEM_ROLE_ASSISTANT, resp.content);
        agent->msg_count++;

        if (agent->on_think) agent->on_think(resp.content, agent->callback_ctx);

        /* Add to memory */
        if (agent->memory) {
            gem_memory_add(agent->memory, GEM_ROLE_ASSISTANT, resp.content, NULL);
        }
    }

    /* === ACT (if tool calls) === */
    if (resp.tool_calls) {
        agent->state = GEM_AGENT_ACTING;

        cJSON *tc_array = cJSON_Parse(resp.tool_calls);
        if (tc_array) {
            cJSON *tc;
            cJSON_ArrayForEach(tc, tc_array) {
                cJSON *fn = cJSON_GetObjectItem(tc, "function");
                if (!fn) continue;

                const char *tool_name = cJSON_GetObjectItem(fn, "name")->valuestring;
                cJSON *args_obj = cJSON_GetObjectItem(fn, "arguments");
                const char *args_str = args_obj ? args_obj->valuestring : "{}";

                if (agent->config->verbose) {
                    fprintf(stderr, "[agent] tool call: %s(%s)\n", tool_name, args_str);
                }
                if (agent->on_act) agent->on_act(tool_name, args_str, agent->callback_ctx);

                /* === OBSERVE === */
                agent->state = GEM_AGENT_OBSERVING;
                gem_tool_result_t result = {0};
                gem_tool_execute(agent->tools, tool_name, args_str, &result);

                if (agent->on_observe) agent->on_observe(result.output, agent->callback_ctx);

                /* Build tool result message content */
                char obs_content[GEM_TOOL_OUTPUT_SIZE + 64];
                if (result.success) {
                    snprintf(obs_content, sizeof(obs_content), "%s", result.output);
                } else {
                    snprintf(obs_content, sizeof(obs_content), "Error: %s", result.error);
                }

                /* Add tool call and result to conversation */
                gem_message_append(&agent->messages, GEM_ROLE_TOOL, obs_content);
                agent->msg_count++;

                if (agent->memory) {
                    gem_memory_add(agent->memory, GEM_ROLE_TOOL, obs_content, tool_name);
                }
            }
            cJSON_Delete(tc_array);
        }
        free((void *)resp.tool_calls);
    }

    agent->provider->free_response(&resp);
    agent->turn++;

    /* Check termination */
    if (agent->turn >= agent->max_turns) {
        agent->state = GEM_AGENT_DONE;
        return 1;
    }

    /* If no tool calls, we're done (assistant gave final answer) */
    if (!resp.tool_calls) {
        agent->state = GEM_AGENT_DONE;
        return 1;
    }

    /* More steps needed (tool calls were made) */
    agent->state = GEM_AGENT_IDLE;
    return 0;
}

int gem_agent_run(gem_agent_t *agent, const char *user_message) {
    if (!user_message || !user_message[0]) return -1;

    /* Add user message */
    gem_message_append(&agent->messages, GEM_ROLE_USER, user_message);
    agent->msg_count++;

    /* Add to memory */
    if (agent->memory) {
        gem_memory_add(agent->memory, GEM_ROLE_USER, user_message, NULL);
    }

    agent->state = GEM_AGENT_IDLE;
    agent->turn = 0;

    /* Run loop */
    while (1) {
        int done = gem_agent_step(agent);
        if (done) break;
    }

    return (agent->state == GEM_AGENT_DONE) ? 0 : -1;
}

const char *gem_agent_last_response(const gem_agent_t *agent) {
    /* Find last assistant message */
    const gem_message_t *last = NULL;
    const gem_message_t *m = agent->messages;
    while (m) {
        if (m->role == GEM_ROLE_ASSISTANT) last = m;
        m = m->next;
    }
    return last ? last->content : NULL;
}

void gem_agent_stop(gem_agent_t *agent) {
    agent->state = GEM_AGENT_DONE;
}

void gem_agent_free(gem_agent_t *agent) {
    gem_message_free_all(agent->messages);
    agent->messages = NULL;
    agent->msg_count = 0;
    agent->state = GEM_AGENT_IDLE;
    agent->turn = 0;
}
