/*
 * provider.c - Provider interface for Gem CLI (OpenCode API via libcurl)
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 */
#include "provider.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <curl/curl.h>
#include "../vendor/cJSON.h"

/* ---- curl write callback ---- */

typedef struct {
    char  *data;
    size_t size;
} curl_buf_t;

static size_t curl_write_cb(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t total = size * nmemb;
    curl_buf_t *buf = (curl_buf_t *)userp;
    char *ptr = (char *)realloc(buf->data, buf->size + total + 1);
    if (!ptr) return 0;
    buf->data = ptr;
    memcpy(buf->data + buf->size, contents, total);
    buf->size += total;
    buf->data[buf->size] = '\0';
    return total;
}

/* ---- role helpers ---- */

const char *gem_role_to_str(gem_role_t role) {
    switch (role) {
        case GEM_ROLE_SYSTEM:    return "system";
        case GEM_ROLE_USER:      return "user";
        case GEM_ROLE_ASSISTANT: return "assistant";
        case GEM_ROLE_TOOL:      return "tool";
        default:                 return "user";
    }
}

gem_role_t gem_str_to_role(const char *s) {
    if (strcmp(s, "system") == 0)    return GEM_ROLE_SYSTEM;
    if (strcmp(s, "user") == 0)      return GEM_ROLE_USER;
    if (strcmp(s, "assistant") == 0) return GEM_ROLE_ASSISTANT;
    if (strcmp(s, "tool") == 0)      return GEM_ROLE_TOOL;
    return GEM_ROLE_USER;
}

/* ---- message helpers ---- */

gem_message_t *gem_message_append(gem_message_t **list, gem_role_t role, const char *content) {
    gem_message_t *msg = (gem_message_t *)calloc(1, sizeof(gem_message_t));
    if (!msg) return NULL;
    msg->role = role;
    msg->content = strdup(content);
    msg->next = NULL;

    if (!*list) {
        *list = msg;
    } else {
        gem_message_t *tail = *list;
        while (tail->next) tail = tail->next;
        tail->next = msg;
    }
    return msg;
}

void gem_message_free_all(gem_message_t *msg) {
    while (msg) {
        gem_message_t *next = msg->next;
        free(msg->content);
        free(msg->tool_call_id);
        free(msg->tool_name);
        free(msg);
        msg = next;
    }
}

/* ---- build request JSON ---- */

static char *build_request_body(const char *model,
                                const gem_message_t *messages,
                                int msg_count,
                                const char *tools_json) {
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "model", model);
    cJSON_AddNumberToObject(root, "max_tokens", 4096);

    /* messages array */
    cJSON *msgs_arr = cJSON_CreateArray();
    const gem_message_t *m = messages;
    int count = 0;
    while (m && count < msg_count) {
        cJSON *msg_obj = cJSON_CreateObject();
        cJSON_AddStringToObject(msg_obj, "role", gem_role_to_str(m->role));
        cJSON_AddStringToObject(msg_obj, "content", m->content ? m->content : "");
        cJSON_AddItemToArray(msgs_arr, msg_obj);
        m = m->next;
        count++;
    }
    cJSON_AddItemToObject(root, "messages", msgs_arr);

    /* tools if provided */
    if (tools_json) {
        cJSON *tools = cJSON_Parse(tools_json);
        if (tools) {
            cJSON_AddItemToObject(root, "tools", tools);
            cJSON_AddStringToObject(root, "tool_choice", "auto");
        }
    }

    char *body = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    return body;
}

/* ---- parse response JSON ---- */

static int parse_response(const char *json, gem_provider_response_t *resp) {
    resp->raw_response = strdup(json);

    cJSON *root = cJSON_Parse(json);
    if (!root) {
        resp->content = strdup("Error: failed to parse provider response");
        resp->status_code = 0;
        return -1;
    }

    /* Check for error */
    cJSON *error = cJSON_GetObjectItem(root, "error");
    if (error) {
        cJSON *msg = cJSON_GetObjectItem(error, "message");
        resp->content = strdup(msg ? msg->valuestring : "Unknown provider error");
        cJSON_Delete(root);
        return -1;
    }

    /* choices[0].message.content */
    cJSON *choices = cJSON_GetObjectItem(root, "choices");
    if (choices && cJSON_GetArraySize(choices) > 0) {
        cJSON *choice = cJSON_GetArrayItem(choices, 0);
        cJSON *message = cJSON_GetObjectItem(choice, "message");
        if (message) {
            cJSON *content = cJSON_GetObjectItem(message, "content");
            resp->content = content ? strdup(content->valuestring ? content->valuestring : "") : strdup("");

            /* Check for tool_calls */
            cJSON *tool_calls = cJSON_GetObjectItem(message, "tool_calls");
            if (tool_calls && cJSON_GetArraySize(tool_calls) > 0) {
                resp->tool_calls = cJSON_PrintUnformatted(tool_calls);
                resp->finish_reason = 1; /* tool_calls */
            } else {
                resp->tool_calls = NULL;
                resp->finish_reason = 0; /* stop */
            }
        } else {
            resp->content = strdup("");
        }

        cJSON *finish = cJSON_GetObjectItem(choice, "finish_reason");
        if (finish && finish->valuestring) {
            if (strcmp(finish->valuestring, "length") == 0) resp->finish_reason = 2;
        }
    } else {
        resp->content = strdup("");
    }

    cJSON_Delete(root);
    return 0;
}

/* ---- OpenCode provider implementation ---- */

static int opencode_init(gem_provider_t *self, const gem_provider_config_t *cfg) {
    memcpy(&self->config, cfg, sizeof(self->config));
    curl_global_init(CURL_GLOBAL_DEFAULT);
    self->curl_handle = curl_easy_init();
    self->initialized = self->curl_handle ? 1 : 0;
    return self->initialized ? 0 : -1;
}

static int opencode_chat(gem_provider_t *self,
                         const gem_message_t *messages,
                         int msg_count,
                         const char *tools_json,
                         gem_provider_response_t *resp) {
    memset(resp, 0, sizeof(*resp));

    if (!self->initialized) {
        resp->content = strdup("Provider not initialized");
        return -1;
    }

    /* Build request body */
    char *body = build_request_body(self->config.model, messages, msg_count, tools_json);
    if (!body) {
        resp->content = strdup("Failed to build request body");
        return -1;
    }

    /* Build URL: api_url/chat/completions */
    char url[1024];
    snprintf(url, sizeof(url), "%s/chat/completions", self->config.api_url);

    /* Reset curl handle */
    curl_easy_reset(self->curl_handle);

    /* Set headers */
    struct curl_slist *headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/json");

    char auth_header[512];
    const char *key = self->config.api_key[0] ? self->config.api_key : getenv("GEM_API_KEY");
    if (!key) key = getenv("OPENAI_API_KEY");
    if (key) {
        snprintf(auth_header, sizeof(auth_header), "Authorization: Bearer %s", key);
        headers = curl_slist_append(headers, auth_header);
    }

    curl_easy_setopt(self->curl_handle, CURLOPT_URL, url);
    curl_easy_setopt(self->curl_handle, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(self->curl_handle, CURLOPT_POSTFIELDS, body);
    curl_easy_setopt(self->curl_handle, CURLOPT_TIMEOUT_MS, (long)self->config.timeout_ms);

    /* Response buffer */
    curl_buf_t rbuf = { .data = NULL, .size = 0 };
    curl_easy_setopt(self->curl_handle, CURLOPT_WRITEFUNCTION, curl_write_cb);
    curl_easy_setopt(self->curl_handle, CURLOPT_WRITEDATA, &rbuf);

    /* Perform request */
    CURLcode res = curl_easy_perform(self->curl_handle);
    free(body);
    curl_slist_free_all(headers);

    if (res != CURLE_OK) {
        const char *err = curl_easy_strerror(res);
        resp->content = (char *)malloc(strlen(err) + 32);
        sprintf(resp->content, "HTTP request failed: %s", err);
        free(rbuf.data);
        return -1;
    }

    /* Get HTTP status code */
    long http_code = 0;
    curl_easy_getinfo(self->curl_handle, CURLINFO_RESPONSE_CODE, &http_code);
    resp->status_code = (int)http_code;

    if (!rbuf.data) {
        resp->content = strdup("Empty response from provider");
        return -1;
    }

    /* Parse response */
    int rc = parse_response(rbuf.data, resp);
    free(rbuf.data);
    return rc;
}

static void opencode_free_response(gem_provider_response_t *resp) {
    if (resp->content)      { free(resp->content);      resp->content = NULL; }
    if (resp->tool_calls)   { free(resp->tool_calls);   resp->tool_calls = NULL; }
    if (resp->raw_response) { free(resp->raw_response);  resp->raw_response = NULL; }
}

int gem_provider_opencode_create(gem_provider_t *provider, const gem_provider_config_t *cfg) {
    memset(provider, 0, sizeof(*provider));
    strncpy(provider->name, "opencode", GEM_MAX_NAME_LEN - 1);
    provider->init = opencode_init;
    provider->chat = opencode_chat;
    provider->free_response = opencode_free_response;
    return provider->init(provider, cfg);
}
