/*
 * chat.h - Interactive chat REPL for Gem CLI
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 */
#ifndef GEM_CHAT_H
#define GEM_CHAT_H

#include "agent.h"

/* Chat session */
typedef struct {
    gem_agent_t  *agent;
    char          prompt[64];
    int           history_size;
    int           running;
    int           multi_line;
    char          multi_line_buf[8192];
} gem_chat_t;

/* Start interactive chat REPL */
int gem_chat_start(gem_chat_t *chat);

/* Process a single input line (returns 0 to continue, 1 to exit) */
int gem_chat_process_line(gem_chat_t *chat, const char *line);

/* Handle slash commands (/help, /clear, /model, /tools, /quit, etc.) */
int gem_chat_handle_command(gem_chat_t *chat, const char *line);

/* Initialize chat session */
void gem_chat_init(gem_chat_t *chat, gem_agent_t *agent,
                   const char *prompt, int history_size);

/* Print help */
void gem_chat_print_help(void);

#endif /* GEM_CHAT_H */
