/*
 * config.c - Configuration loading for Gem CLI (minimal TOML parser)
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 *
 * Implements a simple line-by-line TOML parser sufficient for Gem config.
 * Does not support nested tables beyond [section] or [section.subsection].
 */
#include "config.h"
#include "platform.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* ---- helpers ---- */

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *end = s + strlen(s) - 1;
    while (end > s && isspace((unsigned char)*end)) *end-- = '\0';
    return s;
}

static char *strip_quotes(char *s) {
    size_t len = strlen(s);
    if (len >= 2 && s[0] == '"' && s[len - 1] == '"') {
        s[len - 1] = '\0';
        return s + 1;
    }
    return s;
}

static void parse_key_value(const char *section, const char *key, const char *value, gem_config_t *cfg) {
    /* General settings */
    if (strcmp(section, "general") == 0 || strcmp(section, "") == 0) {
        if (strcmp(key, "default_model") == 0)
            strncpy(cfg->default_model, strip_quotes((char *)value), GEM_MAX_NAME_LEN - 1);
        else if (strcmp(key, "default_provider") == 0)
            strncpy(cfg->default_provider, strip_quotes((char *)value), GEM_MAX_NAME_LEN - 1);
        else if (strcmp(key, "verbose") == 0)
            cfg->verbose = atoi(value);
        else if (strcmp(key, "debug") == 0)
            cfg->debug = atoi(value);
        else if (strcmp(key, "log_level") == 0)
            strncpy(cfg->log_level, strip_quotes((char *)value), sizeof(cfg->log_level) - 1);
    }
    /* Memory settings */
    else if (strcmp(section, "memory") == 0) {
        if (strcmp(key, "path") == 0)
            strncpy(cfg->memory_path, strip_quotes((char *)value), sizeof(cfg->memory_path) - 1);
        else if (strcmp(key, "max_entries") == 0)
            cfg->memory_max_entries = atoi(value);
        else if (strcmp(key, "enabled") == 0)
            cfg->memory_enabled = atoi(value);
    }
    /* Chat settings */
    else if (strcmp(section, "chat") == 0) {
        if (strcmp(key, "history_size") == 0)
            cfg->chat_history_size = atoi(value);
        else if (strcmp(key, "prompt_format") == 0)
            strncpy(cfg->chat_prompt_format, strip_quotes((char *)value), sizeof(cfg->chat_prompt_format) - 1);
    }
    /* Provider section: [providers.NAME] */
    else if (strncmp(section, "providers.", 10) == 0) {
        const char *pname = section + 10;
        /* find or create provider */
        gem_provider_config_t *p = gem_config_find_provider(cfg, pname);
        if (!p && cfg->provider_count < GEM_MAX_PROVIDERS) {
            p = &cfg->providers[cfg->provider_count++];
            memset(p, 0, sizeof(*p));
            strncpy(p->name, pname, GEM_MAX_NAME_LEN - 1);
            p->enabled = 1;
            p->timeout_ms = 30000;
            p->max_retries = 3;
        }
        if (p) {
            if (strcmp(key, "api_url") == 0)
                strncpy(p->api_url, strip_quotes((char *)value), GEM_MAX_URL_LEN - 1);
            else if (strcmp(key, "api_key") == 0)
                strncpy(p->api_key, strip_quotes((char *)value), GEM_MAX_KEY_LEN - 1);
            else if (strcmp(key, "model") == 0)
                strncpy(p->model, strip_quotes((char *)value), GEM_MAX_NAME_LEN - 1);
            else if (strcmp(key, "enabled") == 0)
                p->enabled = atoi(value);
            else if (strcmp(key, "timeout_ms") == 0)
                p->timeout_ms = atoi(value);
            else if (strcmp(key, "max_retries") == 0)
                p->max_retries = atoi(value);
        }
    }
    /* Agent section: [agents.NAME] */
    else if (strncmp(section, "agents.", 7) == 0) {
        const char *aname = section + 7;
        gem_agent_config_t *a = gem_config_find_agent(cfg, aname);
        if (!a && cfg->agent_count < GEM_MAX_AGENTS) {
            a = &cfg->agents[cfg->agent_count++];
            memset(a, 0, sizeof(*a));
            strncpy(a->name, aname, GEM_MAX_NAME_LEN - 1);
            a->enabled = 1;
            a->max_turns = 20;
        }
        if (a) {
            if (strcmp(key, "model") == 0)
                strncpy(a->model, strip_quotes((char *)value), GEM_MAX_NAME_LEN - 1);
            else if (strcmp(key, "system_prompt") == 0)
                strncpy(a->system_prompt, strip_quotes((char *)value), sizeof(a->system_prompt) - 1);
            else if (strcmp(key, "max_turns") == 0)
                a->max_turns = atoi(value);
            else if (strcmp(key, "enabled") == 0)
                a->enabled = atoi(value);
        }
    }
}

/* ---- public API ---- */

void gem_config_defaults(gem_config_t *cfg) {
    memset(cfg, 0, sizeof(*cfg));
    strncpy(cfg->default_model, "gpt-4", GEM_MAX_NAME_LEN - 1);
    strncpy(cfg->default_provider, "opencode", GEM_MAX_NAME_LEN - 1);
    strncpy(cfg->log_level, "info", sizeof(cfg->log_level) - 1);
    cfg->verbose = 0;
    cfg->debug = 0;
    cfg->memory_enabled = 1;
    cfg->memory_max_entries = 1000;
    cfg->chat_history_size = 100;
    strncpy(cfg->chat_prompt_format, "gem> ", sizeof(cfg->chat_prompt_format) - 1);

    /* Set default memory path */
    const char *data_dir = gem_platform_data_dir();
    snprintf(cfg->memory_path, sizeof(cfg->memory_path), "%s/memory.json", data_dir);

    /* Set default provider: OpenCode API */
    gem_provider_config_t *p = &cfg->providers[0];
    strncpy(p->name, "opencode", GEM_MAX_NAME_LEN - 1);
    strncpy(p->api_url, "https://api.opencode.ai/v1", GEM_MAX_URL_LEN - 1);
    strncpy(p->model, "gpt-4", GEM_MAX_NAME_LEN - 1);
    p->enabled = 1;
    p->timeout_ms = 30000;
    p->max_retries = 3;
    cfg->provider_count = 1;

    /* Set default agent */
    gem_agent_config_t *a = &cfg->agents[0];
    strncpy(a->name, "default", GEM_MAX_NAME_LEN - 1);
    strncpy(a->model, "gpt-4", GEM_MAX_NAME_LEN - 1);
    strncpy(a->system_prompt, "You are Gem, an AI assistant.", sizeof(a->system_prompt) - 1);
    a->max_turns = 20;
    a->enabled = 1;
    cfg->agent_count = 1;
}

int gem_config_load_file(gem_config_t *cfg, const char *path) {
    FILE *fp = fopen(path, "r");
    if (!fp) return -1;

    strncpy(cfg->config_path, path, sizeof(cfg->config_path) - 1);

    char line[1024];
    char section[128] = "";
    int line_no = 0;

    while (fgets(line, sizeof(line), fp)) {
        line_no++;
        char *l = trim(line);
        /* skip empty lines and comments */
        if (*l == '\0' || *l == '#') continue;

        /* section header: [name] */
        if (*l == '[') {
            char *end = strchr(l, ']');
            if (!end) continue;
            *end = '\0';
            strncpy(section, trim(l + 1), sizeof(section) - 1);
            continue;
        }

        /* key = value */
        char *eq = strchr(l, '=');
        if (!eq) continue;
        *eq = '\0';
        char *key = trim(l);
        char *value = trim(eq + 1);

        parse_key_value(section, key, value, cfg);
    }

    fclose(fp);
    return 0;
}

int gem_config_load(gem_config_t *cfg) {
    gem_config_defaults(cfg);

    /* Try multiple locations */
    const char *config_dir = gem_platform_config_dir();
    char path[512];

    /* 1. XDG config dir */
    snprintf(path, sizeof(path), "%s/%s", config_dir, GEM_CONFIG_NAME);
    if (gem_config_load_file(cfg, path) == 0) return 0;

    /* 2. Current directory */
    if (gem_config_load_file(cfg, "./" GEM_CONFIG_NAME) == 0) return 0;

    /* 3. Home directory */
    const char *home = getenv("HOME");
    if (home) {
        snprintf(path, sizeof(path), "%s/.gemrc", home);
        if (gem_config_load_file(cfg, path) == 0) return 0;
    }

    /* No config found; use defaults */
    return 0;
}

gem_provider_config_t *gem_config_find_provider(gem_config_t *cfg, const char *name) {
    for (int i = 0; i < cfg->provider_count; i++) {
        if (strcmp(cfg->providers[i].name, name) == 0) return &cfg->providers[i];
    }
    return NULL;
}

gem_agent_config_t *gem_config_find_agent(gem_config_t *cfg, const char *name) {
    for (int i = 0; i < cfg->agent_count; i++) {
        if (strcmp(cfg->agents[i].name, name) == 0) return &cfg->agents[i];
    }
    return NULL;
}

void gem_config_print(const gem_config_t *cfg) {
    printf("Gem Configuration (v" GEM_VERSION ")\n");
    printf("  Config path:     %s\n", cfg->config_path[0] ? cfg->config_path : "(defaults)");
    printf("  Default model:   %s\n", cfg->default_model);
    printf("  Default provider:%s\n", cfg->default_provider);
    printf("  Verbose:         %d\n", cfg->verbose);
    printf("  Debug:           %d\n", cfg->debug);
    printf("  Log level:       %s\n", cfg->log_level);
    printf("  Memory:          %s (max %d entries)\n",
           cfg->memory_enabled ? "enabled" : "disabled", cfg->memory_max_entries);
    printf("  Memory path:     %s\n", cfg->memory_path);
    printf("  Chat history:    %d\n", cfg->chat_history_size);
    printf("  Providers (%d):\n", cfg->provider_count);
    for (int i = 0; i < cfg->provider_count; i++) {
        const gem_provider_config_t *p = &cfg->providers[i];
        printf("    [%s] url=%s model=%s enabled=%d timeout=%dms retries=%d\n",
               p->name, p->api_url, p->model, p->enabled, p->timeout_ms, p->max_retries);
    }
    printf("  Agents (%d):\n", cfg->agent_count);
    for (int i = 0; i < cfg->agent_count; i++) {
        const gem_agent_config_t *a = &cfg->agents[i];
        printf("    [%s] model=%s max_turns=%d enabled=%d\n",
               a->name, a->model, a->max_turns, a->enabled);
    }
}

int gem_config_save(const gem_config_t *cfg, const char *path) {
    FILE *fp = fopen(path, "w");
    if (!fp) return -1;

    fprintf(fp, "# Gem CLI Configuration - v" GEM_VERSION "\n");
    fprintf(fp, "# HintyCloud - GPL-3.0\n\n");

    fprintf(fp, "[general]\n");
    fprintf(fp, "default_model = \"%s\"\n", cfg->default_model);
    fprintf(fp, "default_provider = \"%s\"\n", cfg->default_provider);
    fprintf(fp, "verbose = %d\n", cfg->verbose);
    fprintf(fp, "debug = %d\n", cfg->debug);
    fprintf(fp, "log_level = \"%s\"\n\n", cfg->log_level);

    fprintf(fp, "[memory]\n");
    fprintf(fp, "enabled = %d\n", cfg->memory_enabled);
    fprintf(fp, "max_entries = %d\n", cfg->memory_max_entries);
    fprintf(fp, "path = \"%s\"\n\n", cfg->memory_path);

    fprintf(fp, "[chat]\n");
    fprintf(fp, "history_size = %d\n", cfg->chat_history_size);
    fprintf(fp, "prompt_format = \"%s\"\n\n", cfg->chat_prompt_format);

    for (int i = 0; i < cfg->provider_count; i++) {
        const gem_provider_config_t *p = &cfg->providers[i];
        fprintf(fp, "[providers.%s]\n", p->name);
        fprintf(fp, "api_url = \"%s\"\n", p->api_url);
        fprintf(fp, "model = \"%s\"\n", p->model);
        fprintf(fp, "enabled = %d\n", p->enabled);
        fprintf(fp, "timeout_ms = %d\n", p->timeout_ms);
        fprintf(fp, "max_retries = %d\n\n", p->max_retries);
    }

    for (int i = 0; i < cfg->agent_count; i++) {
        const gem_agent_config_t *a = &cfg->agents[i];
        fprintf(fp, "[agents.%s]\n", a->name);
        fprintf(fp, "model = \"%s\"\n", a->model);
        fprintf(fp, "system_prompt = \"%s\"\n", a->system_prompt);
        fprintf(fp, "max_turns = %d\n", a->max_turns);
        fprintf(fp, "enabled = %d\n\n", a->enabled);
    }

    fclose(fp);
    return 0;
}
