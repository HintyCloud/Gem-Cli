/*
 * tools.c - Tool registry for Gem CLI
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 */
#include "tools.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../vendor/cJSON.h"

/* ---- category strings ---- */

const char *gem_tool_category_str(gem_tool_category_t cat) {
    switch (cat) {
        case GEM_TOOL_SHELL:     return "shell";
        case GEM_TOOL_FILES:     return "files";
        case GEM_TOOL_WEB:       return "web";
        case GEM_TOOL_IMAGE:     return "image";
        case GEM_TOOL_GIT:       return "git";
        case GEM_TOOL_ARCHIVE:   return "archive";
        case GEM_TOOL_ARTIFACTS: return "artifacts";
        case GEM_TOOL_CUSTOM:    return "custom";
        default:                 return "unknown";
    }
}

/* ================================================================
 *  Built-in tool implementations
 * ================================================================ */

/* --- shell tool: execute a shell command --- */
static int tool_shell_execute(gem_tool_t *self, const char *args, gem_tool_result_t *result) {
    (void)self;
    memset(result, 0, sizeof(*result));

    cJSON *json = cJSON_Parse(args);
    if (!json) {
        snprintf(result->error, sizeof(result->error), "Invalid JSON args");
        result->success = 0;
        return -1;
    }

    cJSON *cmd_obj = cJSON_GetObjectItem(json, "command");
    if (!cmd_obj || !cmd_obj->valuestring) {
        snprintf(result->error, sizeof(result->error), "Missing 'command' parameter");
        cJSON_Delete(json);
        result->success = 0;
        return -1;
    }

    const char *cmd = cmd_obj->valuestring;
    FILE *fp = popen(cmd, "r");
    if (!fp) {
        snprintf(result->error, sizeof(result->error), "Failed to execute: %s", cmd);
        cJSON_Delete(json);
        result->success = 0;
        return -1;
    }

    size_t total = 0;
    while (total < GEM_TOOL_OUTPUT_SIZE - 1) {
        size_t n = fread(result->output + total, 1, GEM_TOOL_OUTPUT_SIZE - total - 1, fp);
        if (n == 0) break;
        total += n;
    }
    result->output[total] = '\0';

    int rc = pclose(fp);
    result->success = (rc == 0) ? 1 : 0;
    if (rc != 0) {
        snprintf(result->error, sizeof(result->error), "Command exited with code %d", rc);
    }

    cJSON_Delete(json);
    return rc == 0 ? 0 : -1;
}

static char *tool_shell_schema(gem_tool_t *self) {
    (void)self;
    return strdup(
        "{\"type\":\"function\",\"function\":{\"name\":\"shell\","
        "\"description\":\"Execute a shell command and return its output\","
        "\"parameters\":{\"type\":\"object\",\"properties\":{"
        "\"command\":{\"type\":\"string\",\"description\":\"The shell command to execute\"}"
        "},\"required\":[\"command\"]}}}"
    );
}

/* --- files tool: read/write/list files --- */
static int tool_files_execute(gem_tool_t *self, const char *args, gem_tool_result_t *result) {
    (void)self;
    memset(result, 0, sizeof(*result));

    cJSON *json = cJSON_Parse(args);
    if (!json) {
        snprintf(result->error, sizeof(result->error), "Invalid JSON args");
        result->success = 0;
        return -1;
    }

    cJSON *action_obj = cJSON_GetObjectItem(json, "action");
    cJSON *path_obj   = cJSON_GetObjectItem(json, "path");

    if (!action_obj || !path_obj) {
        snprintf(result->error, sizeof(result->error), "Missing 'action' or 'path'");
        cJSON_Delete(json);
        result->success = 0;
        return -1;
    }

    const char *action = action_obj->valuestring;
    const char *path   = path_obj->valuestring;

    if (strcmp(action, "read") == 0) {
        FILE *fp = fopen(path, "r");
        if (!fp) {
            snprintf(result->error, sizeof(result->error), "Cannot open file: %s", path);
            cJSON_Delete(json);
            result->success = 0;
            return -1;
        }
        size_t n = fread(result->output, 1, GEM_TOOL_OUTPUT_SIZE - 1, fp);
        result->output[n] = '\0';
        fclose(fp);
        result->success = 1;
    } else if (strcmp(action, "write") == 0) {
        cJSON *content_obj = cJSON_GetObjectItem(json, "content");
        if (!content_obj) {
            snprintf(result->error, sizeof(result->error), "Missing 'content' for write");
            cJSON_Delete(json);
            result->success = 0;
            return -1;
        }
        FILE *fp = fopen(path, "w");
        if (!fp) {
            snprintf(result->error, sizeof(result->error), "Cannot open file for writing: %s", path);
            cJSON_Delete(json);
            result->success = 0;
            return -1;
        }
        fputs(content_obj->valuestring, fp);
        fclose(fp);
        snprintf(result->output, sizeof(result->output), "Wrote to %s", path);
        result->success = 1;
    } else if (strcmp(action, "list") == 0) {
        char cmd[GEM_TOOL_OUTPUT_SIZE];
        snprintf(cmd, sizeof(cmd), "ls -la %s 2>&1", path);
        FILE *fp = popen(cmd, "r");
        if (fp) {
            size_t n = fread(result->output, 1, GEM_TOOL_OUTPUT_SIZE - 1, fp);
            result->output[n] = '\0';
            pclose(fp);
            result->success = 1;
        }
    } else {
        snprintf(result->error, sizeof(result->error), "Unknown action: %s", action);
        result->success = 0;
    }

    cJSON_Delete(json);
    return result->success ? 0 : -1;
}

static char *tool_files_schema(gem_tool_t *self) {
    (void)self;
    return strdup(
        "{\"type\":\"function\",\"function\":{\"name\":\"files\","
        "\"description\":\"Read, write, or list files on the filesystem\","
        "\"parameters\":{\"type\":\"object\",\"properties\":{"
        "\"action\":{\"type\":\"string\",\"enum\":[\"read\",\"write\",\"list\"],\"description\":\"Action to perform\"},"
        "\"path\":{\"type\":\"string\",\"description\":\"File or directory path\"},"
        "\"content\":{\"type\":\"string\",\"description\":\"Content to write (for write action)\"}"
        "},\"required\":[\"action\",\"path\"]}}}"
    );
}

/* --- web tool: fetch URL --- */
static int tool_web_execute(gem_tool_t *self, const char *args, gem_tool_result_t *result) {
    (void)self;
    memset(result, 0, sizeof(*result));

    cJSON *json = cJSON_Parse(args);
    if (!json) {
        snprintf(result->error, sizeof(result->error), "Invalid JSON args");
        return -1;
    }

    cJSON *url_obj = cJSON_GetObjectItem(json, "url");
    if (!url_obj) {
        snprintf(result->error, sizeof(result->error), "Missing 'url'");
        cJSON_Delete(json);
        return -1;
    }

    /* Use curl command for simplicity */
    char cmd[GEM_TOOL_OUTPUT_SIZE];
    snprintf(cmd, sizeof(cmd), "curl -sL --max-time 10 '%s' 2>&1", url_obj->valuestring);
    FILE *fp = popen(cmd, "r");
    if (fp) {
        size_t n = fread(result->output, 1, GEM_TOOL_OUTPUT_SIZE - 1, fp);
        result->output[n] = '\0';
        pclose(fp);
        result->success = 1;
    }
    cJSON_Delete(json);
    return result->success ? 0 : -1;
}

static char *tool_web_schema(gem_tool_t *self) {
    (void)self;
    return strdup(
        "{\"type\":\"function\",\"function\":{\"name\":\"web\","
        "\"description\":\"Fetch content from a URL\","
        "\"parameters\":{\"type\":\"object\",\"properties\":{"
        "\"url\":{\"type\":\"string\",\"description\":\"URL to fetch\"}"
        "},\"required\":[\"url\"]}}}"
    );
}

/* --- git tool --- */
static int tool_git_execute(gem_tool_t *self, const char *args, gem_tool_result_t *result) {
    (void)self;
    memset(result, 0, sizeof(*result));

    cJSON *json = cJSON_Parse(args);
    if (!json) {
        snprintf(result->error, sizeof(result->error), "Invalid JSON args");
        return -1;
    }

    cJSON *cmd_obj = cJSON_GetObjectItem(json, "command");
    if (!cmd_obj) {
        snprintf(result->error, sizeof(result->error), "Missing 'command'");
        cJSON_Delete(json);
        return -1;
    }

    char cmd[GEM_TOOL_OUTPUT_SIZE];
    snprintf(cmd, sizeof(cmd), "git %s 2>&1", cmd_obj->valuestring);
    FILE *fp = popen(cmd, "r");
    if (fp) {
        size_t n = fread(result->output, 1, GEM_TOOL_OUTPUT_SIZE - 1, fp);
        result->output[n] = '\0';
        pclose(fp);
        result->success = 1;
    }
    cJSON_Delete(json);
    return result->success ? 0 : -1;
}

static char *tool_git_schema(gem_tool_t *self) {
    (void)self;
    return strdup(
        "{\"type\":\"function\",\"function\":{\"name\":\"git\","
        "\"description\":\"Execute a git command\","
        "\"parameters\":{\"type\":\"object\",\"properties\":{"
        "\"command\":{\"type\":\"string\",\"description\":\"Git command (without 'git' prefix)\"}"
        "},\"required\":[\"command\"]}}}"
    );
}

/* --- image tool (placeholder) --- */
static int tool_image_execute(gem_tool_t *self, const char *args, gem_tool_result_t *result) {
    (void)self; (void)args;
    memset(result, 0, sizeof(*result));
    snprintf(result->output, sizeof(result->output), "Image tool: not yet fully implemented");
    result->success = 1;
    return 0;
}
static char *tool_image_schema(gem_tool_t *self) {
    (void)self;
    return strdup(
        "{\"type\":\"function\",\"function\":{\"name\":\"image\","
        "\"description\":\"Generate or manipulate images\","
        "\"parameters\":{\"type\":\"object\",\"properties\":{"
        "\"prompt\":{\"type\":\"string\",\"description\":\"Image generation prompt\"}"
        "},\"required\":[\"prompt\"]}}}"
    );
}

/* --- archive tool --- */
static int tool_archive_execute(gem_tool_t *self, const char *args, gem_tool_result_t *result) {
    (void)self; (void)args;
    memset(result, 0, sizeof(*result));
    snprintf(result->output, sizeof(result->output), "Archive tool: not yet fully implemented");
    result->success = 1;
    return 0;
}
static char *tool_archive_schema(gem_tool_t *self) {
    (void)self;
    return strdup(
        "{\"type\":\"function\",\"function\":{\"name\":\"archive\","
        "\"description\":\"Create or extract archives (tar, zip)\","
        "\"parameters\":{\"type\":\"object\",\"properties\":{"
        "\"action\":{\"type\":\"string\",\"enum\":[\"create\",\"extract\"]},"
        "\"path\":{\"type\":\"string\"}"
        "},\"required\":[\"action\",\"path\"]}}}"
    );
}

/* --- artifacts tool --- */
static int tool_artifacts_execute(gem_tool_t *self, const char *args, gem_tool_result_t *result) {
    (void)self; (void)args;
    memset(result, 0, sizeof(*result));
    snprintf(result->output, sizeof(result->output), "Artifacts tool: not yet fully implemented");
    result->success = 1;
    return 0;
}
static char *tool_artifacts_schema(gem_tool_t *self) {
    (void)self;
    return strdup(
        "{\"type\":\"function\",\"function\":{\"name\":\"artifacts\","
        "\"description\":\"Manage project artifacts and outputs\","
        "\"parameters\":{\"type\":\"object\",\"properties\":{"
        "\"action\":{\"type\":\"string\",\"enum\":[\"list\",\"create\",\"delete\"]}"
        "},\"required\":[\"action\"]}}}"
    );
}

/* ================================================================
 *  Registry functions
 * ================================================================ */

static void register_tool(gem_tool_registry_t *reg,
                          const char *name, const char *desc,
                          gem_tool_category_t cat,
                          int (*exec_fn)(gem_tool_t *, const char *, gem_tool_result_t *),
                          char *(*schema_fn)(gem_tool_t *)) {
    if (reg->count >= GEM_MAX_TOOLS) return;
    gem_tool_t *t = &reg->tools[reg->count++];
    memset(t, 0, sizeof(*t));
    strncpy(t->name, name, GEM_MAX_TOOL_NAME - 1);
    strncpy(t->description, desc, GEM_MAX_TOOL_DESC - 1);
    t->category = cat;
    t->enabled = 1;
    t->execute = exec_fn;
    t->to_schema = schema_fn;
}

void gem_tool_registry_init(gem_tool_registry_t *reg) {
    memset(reg, 0, sizeof(*reg));

    register_tool(reg, "shell",     "Execute shell commands",               GEM_TOOL_SHELL,     tool_shell_execute,     tool_shell_schema);
    register_tool(reg, "files",     "Read, write, and list files",          GEM_TOOL_FILES,     tool_files_execute,     tool_files_schema);
    register_tool(reg, "web",       "Fetch content from URLs",             GEM_TOOL_WEB,       tool_web_execute,       tool_web_schema);
    register_tool(reg, "image",     "Generate or manipulate images",        GEM_TOOL_IMAGE,     tool_image_execute,     tool_image_schema);
    register_tool(reg, "git",       "Execute git commands",                GEM_TOOL_GIT,       tool_git_execute,       tool_git_schema);
    register_tool(reg, "archive",   "Create or extract archives",           GEM_TOOL_ARCHIVE,   tool_archive_execute,   tool_archive_schema);
    register_tool(reg, "artifacts", "Manage project artifacts",             GEM_TOOL_ARTIFACTS, tool_artifacts_execute, tool_artifacts_schema);
}

gem_tool_t *gem_tool_find(gem_tool_registry_t *reg, const char *name) {
    for (int i = 0; i < reg->count; i++) {
        if (strcmp(reg->tools[i].name, name) == 0) return &reg->tools[i];
    }
    return NULL;
}

int gem_tool_execute(gem_tool_registry_t *reg, const char *name,
                     const char *args, gem_tool_result_t *result) {
    gem_tool_t *tool = gem_tool_find(reg, name);
    if (!tool) {
        memset(result, 0, sizeof(*result));
        snprintf(result->error, sizeof(result->error), "Tool not found: %s", name);
        result->success = 0;
        return -1;
    }
    if (!tool->enabled) {
        memset(result, 0, sizeof(*result));
        snprintf(result->error, sizeof(result->error), "Tool disabled: %s", name);
        result->success = 0;
        return -1;
    }
    return tool->execute(tool, args, result);
}

char *gem_tool_schemas_json(gem_tool_registry_t *reg) {
    cJSON *arr = cJSON_CreateArray();
    for (int i = 0; i < reg->count; i++) {
        if (!reg->tools[i].enabled) continue;
        char *schema_str = reg->tools[i].to_schema(&reg->tools[i]);
        if (schema_str) {
            cJSON *schema = cJSON_Parse(schema_str);
            if (schema) cJSON_AddItemToArray(arr, schema);
            free(schema_str);
        }
    }
    char *json = cJSON_PrintUnformatted(arr);
    cJSON_Delete(arr);
    return json;
}

void gem_tool_list(const gem_tool_registry_t *reg) {
    printf("  %-12s %-10s %s\n", "NAME", "CATEGORY", "STATUS");
    printf("  %-12s %-10s %s\n", "----", "--------", "------");
    for (int i = 0; i < reg->count; i++) {
        const gem_tool_t *t = &reg->tools[i];
        printf("  %-12s %-10s %s\n",
               t->name,
               gem_tool_category_str(t->category),
               t->enabled ? "enabled" : "disabled");
    }
}

int gem_tool_set_enabled(gem_tool_registry_t *reg, const char *name, int enabled) {
    gem_tool_t *tool = gem_tool_find(reg, name);
    if (!tool) return -1;
    tool->enabled = enabled;
    return 0;
}
