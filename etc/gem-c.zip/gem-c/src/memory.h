/*
 * memory.h - Memory / history store for Gem CLI
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 */
#ifndef GEM_MEMORY_H
#define GEM_MEMORY_H

#include "provider.h"

#define GEM_MEMORY_MAX_ENTRIES  4096
#define GEM_MEMORY_MAX_SUMMARY 512

/* A single memory entry */
typedef struct gem_memory_entry {
    long               id;
    long               timestamp;    /* unix timestamp */
    gem_role_t         role;
    char              *content;
    char              *summary;      /* optional short summary */
    struct gem_memory_entry *next;
} gem_memory_entry_t;

/* Memory store */
typedef struct {
    char                path[512];
    int                 max_entries;
    int                 enabled;
    gem_memory_entry_t *entries;
    int                 count;
    long                next_id;
} gem_memory_t;

/* Initialize memory store */
int gem_memory_init(gem_memory_t *mem, const char *path, int max_entries, int enabled);

/* Add an entry to memory */
gem_memory_entry_t *gem_memory_add(gem_memory_t *mem, gem_role_t role,
                                   const char *content, const char *summary);

/* Get recent N entries as a message list (for context) */
int gem_memory_get_recent(gem_memory_t *mem, int count, gem_message_t **out);

/* Search memory by keyword */
int gem_memory_search(gem_memory_t *mem, const char *keyword, gem_message_t **out);

/* Clear all memory */
void gem_memory_clear(gem_memory_t *mem);

/* Save memory to disk (JSON) */
int gem_memory_save(gem_memory_t *mem);

/* Load memory from disk */
int gem_memory_load(gem_memory_t *mem);

/* Print memory stats */
void gem_memory_stats(const gem_memory_t *mem);

/* Free memory store */
void gem_memory_free(gem_memory_t *mem);

#endif /* GEM_MEMORY_H */
