/*
 * platform.h - Platform detection for Gem CLI
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 */
#ifndef GEM_PLATFORM_H
#define GEM_PLATFORM_H

typedef enum {
    GEM_PLATFORM_LINUX,
    GEM_PLATFORM_MACOS,
    GEM_PLATFORM_WINDOWS,
    GEM_PLATFORM_BSD,
    GEM_PLATFORM_UNKNOWN
} gem_platform_t;

typedef enum {
    GEM_ARCH_X86_64,
    GEM_ARCH_ARM64,
    GEM_ARCH_X86,
    GEM_ARCH_ARM,
    GEM_ARCH_UNKNOWN
} gem_arch_t;

typedef struct {
    gem_platform_t os;
    gem_arch_t     arch;
    char           hostname[256];
    char           username[128];
    char           home_dir[512];
    char           shell[256];
    char           os_name[64];
    char           os_version[64];
    int            ncpu;
    unsigned long  mem_total_mb;
} gem_platform_info_t;

/* Detect and populate platform info */
void gem_platform_detect(gem_platform_info_t *info);

/* Return human-readable OS name */
const char *gem_platform_os_str(gem_platform_t os);

/* Return human-readable arch name */
const char *gem_platform_arch_str(gem_arch_t arch);

/* Get XDG-compatible config directory */
const char *gem_platform_config_dir(void);

/* Get XDG-compatible data directory */
const char *gem_platform_data_dir(void);

/* Get XDG-compatible cache directory */
const char *gem_platform_cache_dir(void);

#endif /* GEM_PLATFORM_H */
