/*
 * tools.h - Tool registry for Gem CLI
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 */
#ifndef GEM_TOOLS_H
#define GEM_TOOLS_H

#define GEM_MAX_TOOL_NAME    32
#define GEM_MAX_TOOL_DESC    256
#define GEM_MAX_TOOLS        32
#define GEM_TOOL_OUTPUT_SIZE 8192

/* Tool categories */
typedef enum {
    GEM_TOOL_SHELL,
    GEM_TOOL_FILES,
    GEM_TOOL_WEB,
    GEM_TOOL_IMAGE,
    GEM_TOOL_GIT,
    GEM_TOOL_ARCHIVE,
    GEM_TOOL_ARTIFACTS,
    GEM_TOOL_CUSTOM
} gem_tool_category_t;

/* Tool execution result */
typedef struct {
    int   success;
    char  output[GEM_TOOL_OUTPUT_SIZE];
    char  error[GEM_TOOL_OUTPUT_SIZE];
} gem_tool_result_t;

/* Tool definition */
typedef struct gem_tool {
    char                name[GEM_MAX_TOOL_NAME];
    char                description[GEM_MAX_TOOL_DESC];
    gem_tool_category_t category;
    int                 enabled;

    /* Execute the tool. args is a JSON string of parameters. */
    int  (*execute)(struct gem_tool *self, const char *args, gem_tool_result_t *result);

    /* Generate OpenAI-format tool JSON schema (caller frees) */
    char *(*to_schema)(struct gem_tool *self);

    void *user_data;  /* optional context */
} gem_tool_t;

/* Tool registry */
typedef struct {
    gem_tool_t tools[GEM_MAX_TOOLS];
    int        count;
} gem_tool_registry_t;

/* Initialize registry and register all built-in tools */
void gem_tool_registry_init(gem_tool_registry_t *reg);

/* Find a tool by name */
gem_tool_t *gem_tool_find(gem_tool_registry_t *reg, const char *name);

/* Execute a tool by name with JSON args */
int gem_tool_execute(gem_tool_registry_t *reg, const char *name,
                     const char *args, gem_tool_result_t *result);

/* Generate JSON schema array for all enabled tools (caller frees) */
char *gem_tool_schemas_json(gem_tool_registry_t *reg);

/* List all registered tools */
void gem_tool_list(const gem_tool_registry_t *reg);

/* Enable/disable a tool */
int gem_tool_set_enabled(gem_tool_registry_t *reg, const char *name, int enabled);

/* Category to string */
const char *gem_tool_category_str(gem_tool_category_t cat);

#endif /* GEM_TOOLS_H */
