/*
 * memory.c - Memory / history store for Gem CLI
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 */
#include "memory.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "../vendor/cJSON.h"

int gem_memory_init(gem_memory_t *mem, const char *path, int max_entries, int enabled) {
    memset(mem, 0, sizeof(*mem));
    if (path) strncpy(mem->path, path, sizeof(mem->path) - 1);
    mem->max_entries = max_entries > 0 ? max_entries : GEM_MEMORY_MAX_ENTRIES;
    mem->enabled = enabled;
    mem->entries = NULL;
    mem->count = 0;
    mem->next_id = 1;

    /* Try loading from disk */
    if (enabled && path) gem_memory_load(mem);
    return 0;
}

gem_memory_entry_t *gem_memory_add(gem_memory_t *mem, gem_role_t role,
                                   const char *content, const char *summary) {
    if (!mem->enabled) return NULL;

    /* Enforce max entries by removing oldest */
    while (mem->count >= mem->max_entries && mem->entries) {
        gem_memory_entry_t *old = mem->entries;
        mem->entries = old->next;
        free(old->content);
        free(old->summary);
        free(old);
        mem->count--;
    }

    gem_memory_entry_t *entry = (gem_memory_entry_t *)calloc(1, sizeof(gem_memory_entry_t));
    if (!entry) return NULL;

    entry->id = mem->next_id++;
    entry->timestamp = (long)time(NULL);
    entry->role = role;
    entry->content = content ? strdup(content) : strdup("");
    entry->summary = summary ? strdup(summary) : NULL;
    entry->next = NULL;

    /* Append to list */
    if (!mem->entries) {
        mem->entries = entry;
    } else {
        gem_memory_entry_t *tail = mem->entries;
        while (tail->next) tail = tail->next;
        tail->next = entry;
    }
    mem->count++;

    return entry;
}

int gem_memory_get_recent(gem_memory_t *mem, int count, gem_message_t **out) {
    *out = NULL;
    if (!mem->entries || count <= 0) return 0;

    /* Find starting point: skip (total - count) entries */
    int skip = mem->count - count;
    if (skip < 0) skip = 0;

    gem_memory_entry_t *e = mem->entries;
    int idx = 0;
    while (e && idx < skip) { e = e->next; idx++; }

    int added = 0;
    while (e) {
        gem_message_append(out, e->role, e->content);
        e = e->next;
        added++;
    }
    return added;
}

int gem_memory_search(gem_memory_t *mem, const char *keyword, gem_message_t **out) {
    *out = NULL;
    int found = 0;
    gem_memory_entry_t *e = mem->entries;
    while (e) {
        if ((e->content && strstr(e->content, keyword)) ||
            (e->summary && strstr(e->summary, keyword))) {
            gem_message_append(out, e->role, e->content);
            found++;
        }
        e = e->next;
    }
    return found;
}

void gem_memory_clear(gem_memory_t *mem) {
    gem_memory_entry_t *e = mem->entries;
    while (e) {
        gem_memory_entry_t *next = e->next;
        free(e->content);
        free(e->summary);
        free(e);
        e = next;
    }
    mem->entries = NULL;
    mem->count = 0;
}

int gem_memory_save(gem_memory_t *mem) {
    if (!mem->path[0]) return -1;

    cJSON *root = cJSON_CreateObject();
    cJSON_AddNumberToObject(root, "version", 1);
    cJSON_AddNumberToObject(root, "count", mem->count);

    cJSON *arr = cJSON_CreateArray();
    gem_memory_entry_t *e = mem->entries;
    while (e) {
        cJSON *obj = cJSON_CreateObject();
        cJSON_AddNumberToObject(obj, "id", e->id);
        cJSON_AddNumberToObject(obj, "timestamp", e->timestamp);
        cJSON_AddStringToObject(obj, "role", gem_role_to_str(e->role));
        cJSON_AddStringToObject(obj, "content", e->content ? e->content : "");
        if (e->summary) cJSON_AddStringToObject(obj, "summary", e->summary);
        cJSON_AddItemToArray(arr, obj);
        e = e->next;
    }
    cJSON_AddItemToObject(root, "entries", arr);

    char *json = cJSON_Print(root);
    cJSON_Delete(root);

    FILE *fp = fopen(mem->path, "w");
    if (!fp) { free(json); return -1; }
    fputs(json, fp);
    fclose(fp);
    free(json);
    return 0;
}

int gem_memory_load(gem_memory_t *mem) {
    if (!mem->path[0]) return -1;

    FILE *fp = fopen(mem->path, "r");
    if (!fp) return -1; /* not an error — file may not exist yet */

    /* Read entire file */
    fseek(fp, 0, SEEK_END);
    long sz = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    char *buf = (char *)malloc(sz + 1);
    if (!buf) { fclose(fp); return -1; }
    size_t nread = fread(buf, 1, sz, fp);
    buf[nread] = '\0';
    fclose(fp);

    cJSON *root = cJSON_Parse(buf);
    free(buf);
    if (!root) return -1;

    cJSON *arr = cJSON_GetObjectItem(root, "entries");
    if (!arr) { cJSON_Delete(root); return -1; }

    gem_memory_clear(mem);

    cJSON *entry_json;
    cJSON_ArrayForEach(entry_json, arr) {
        cJSON *role_obj = cJSON_GetObjectItem(entry_json, "role");
        cJSON *content_obj = cJSON_GetObjectItem(entry_json, "content");
        cJSON *summary_obj = cJSON_GetObjectItem(entry_json, "summary");

        gem_role_t role = role_obj ? gem_str_to_role(role_obj->valuestring) : GEM_ROLE_USER;
        const char *content = content_obj ? content_obj->valuestring : "";
        const char *summary = summary_obj ? summary_obj->valuestring : NULL;

        gem_memory_entry_t *e = gem_memory_add(mem, role, content, summary);
        if (e) {
            cJSON *id_obj = cJSON_GetObjectItem(entry_json, "id");
            cJSON *ts_obj = cJSON_GetObjectItem(entry_json, "timestamp");
            if (id_obj) e->id = (long)id_obj->valuedouble;
            if (ts_obj) e->timestamp = (long)ts_obj->valuedouble;
            if (e->id >= mem->next_id) mem->next_id = e->id + 1;
        }
    }

    cJSON_Delete(root);
    return 0;
}

void gem_memory_stats(const gem_memory_t *mem) {
    printf("  Memory: %s\n", mem->enabled ? "enabled" : "disabled");
    printf("  Entries: %d (max %d)\n", mem->count, mem->max_entries);
    printf("  Path: %s\n", mem->path[0] ? mem->path : "(none)");
    if (mem->entries) {
        printf("  Oldest: id=%ld ts=%ld\n", mem->entries->id, mem->entries->timestamp);
        const gem_memory_entry_t *e = mem->entries;
        while (e->next) e = e->next;
        printf("  Newest: id=%ld ts=%ld\n", e->id, e->timestamp);
    }
}

void gem_memory_free(gem_memory_t *mem) {
    if (mem->enabled) gem_memory_save(mem);
    gem_memory_clear(mem);
}
