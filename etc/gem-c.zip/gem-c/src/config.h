/*
 * config.h - Configuration loading for Gem CLI
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 */
#ifndef GEM_CONFIG_H
#define GEM_CONFIG_H

#define GEM_VERSION      "1.0.0"
#define GEM_CONFIG_NAME  "gem.toml"
#define GEM_MAX_PROVIDERS  16
#define GEM_MAX_TOOLS      32
#define GEM_MAX_AGENTS     16
#define GEM_MAX_KEY_LEN    256
#define GEM_MAX_URL_LEN    512
#define GEM_MAX_NAME_LEN   64

/* Provider configuration */
typedef struct {
    char name[GEM_MAX_NAME_LEN];
    char api_url[GEM_MAX_URL_LEN];
    char api_key[GEM_MAX_KEY_LEN];
    char model[GEM_MAX_NAME_LEN];
    int  enabled;
    int  timeout_ms;
    int  max_retries;
} gem_provider_config_t;

/* Agent configuration */
typedef struct {
    char name[GEM_MAX_NAME_LEN];
    char model[GEM_MAX_NAME_LEN];
    char system_prompt[1024];
    int  max_turns;
    int  enabled;
} gem_agent_config_t;

/* Main configuration */
typedef struct {
    char             config_path[512];
    /* General */
    char             default_model[GEM_MAX_NAME_LEN];
    char             default_provider[GEM_MAX_NAME_LEN];
    int              verbose;
    int              debug;
    char             log_level[16];
    /* Provider */
    gem_provider_config_t providers[GEM_MAX_PROVIDERS];
    int              provider_count;
    /* Agent */
    gem_agent_config_t agents[GEM_MAX_AGENTS];
    int              agent_count;
    /* Memory */
    char             memory_path[512];
    int              memory_max_entries;
    int              memory_enabled;
    /* Chat */
    int              chat_history_size;
    char             chat_prompt_format[64];
} gem_config_t;

/* Load config from default locations */
int gem_config_load(gem_config_t *cfg);

/* Load config from a specific TOML file */
int gem_config_load_file(gem_config_t *cfg, const char *path);

/* Apply defaults to an uninitialized config */
void gem_config_defaults(gem_config_t *cfg);

/* Find a provider by name */
gem_provider_config_t *gem_config_find_provider(gem_config_t *cfg, const char *name);

/* Find an agent by name */
gem_agent_config_t *gem_config_find_agent(gem_config_t *cfg, const char *name);

/* Print config for debugging */
void gem_config_print(const gem_config_t *cfg);

/* Save current config to file */
int gem_config_save(const gem_config_t *cfg, const char *path);

#endif /* GEM_CONFIG_H */
