/*
 * provider.h - Provider interface for Gem CLI (OpenCode API)
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 */
#ifndef GEM_PROVIDER_H
#define GEM_PROVIDER_H

#include "config.h"

/* Message roles */
typedef enum {
    GEM_ROLE_SYSTEM,
    GEM_ROLE_USER,
    GEM_ROLE_ASSISTANT,
    GEM_ROLE_TOOL
} gem_role_t;

/* A single chat message */
typedef struct gem_message {
    gem_role_t  role;
    char       *content;
    char       *tool_call_id;   /* optional */
    char       *tool_name;      /* optional */
    struct gem_message *next;
} gem_message_t;

/* Provider response */
typedef struct {
    char  *content;        /* text content */
    char  *tool_calls;     /* JSON array of tool calls (or NULL) */
    int    finish_reason;  /* 0=stop, 1=tool_calls, 2=length */
    int    status_code;    /* HTTP status */
    char  *raw_response;   /* full raw JSON for debugging */
} gem_provider_response_t;

/* Provider interface (virtual table style) */
typedef struct gem_provider {
    char name[GEM_MAX_NAME_LEN];

    /* Initialize provider with config */
    int  (*init)(struct gem_provider *self, const gem_provider_config_t *cfg);

    /* Send chat completion request */
    int  (*chat)(struct gem_provider *self,
                 const gem_message_t *messages,
                 int msg_count,
                 const char *tools_json,
                 gem_provider_response_t *resp);

    /* Free response */
    void (*free_response)(gem_provider_response_t *resp);

    /* Internal state */
    gem_provider_config_t config;
    void *curl_handle;     /* CURL* if needed */
    int   initialized;
} gem_provider_t;

/* Create the default OpenCode provider */
int gem_provider_opencode_create(gem_provider_t *provider, const gem_provider_config_t *cfg);

/* Helper: role to string */
const char *gem_role_to_str(gem_role_t role);

/* Helper: string to role */
gem_role_t gem_str_to_role(const char *s);

/* Helper: free a message list */
void gem_message_free_all(gem_message_t *msg);

/* Helper: append a message */
gem_message_t *gem_message_append(gem_message_t **list, gem_role_t role, const char *content);

#endif /* GEM_PROVIDER_H */
