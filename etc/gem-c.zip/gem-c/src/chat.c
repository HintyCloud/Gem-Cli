/*
 * chat.c - Interactive chat REPL for Gem CLI
 * Copyright (C) 2025 HintyCloud - GPL-3.0
 *
 * Uses GNU readline for line editing and history if available.
 * Falls back to simple fgets if readline is not present.
 */
#include "chat.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>

/* Try readline, fallback to simple input */
#ifdef HAVE_READLINE
  #include <readline/readline.h>
  #include <readline/history.h>
  #define USE_READLINE 1
#else
  #define USE_READLINE 0
#endif

/* ---- signal handling ---- */

static volatile int g_interrupted = 0;

static void sigint_handler(int sig) {
    (void)sig;
    g_interrupted = 1;
    fprintf(stderr, "\n(interrupt — type /quit to exit)\n");
}

/* ---- chat init ---- */

void gem_chat_init(gem_chat_t *chat, gem_agent_t *agent,
                   const char *prompt, int history_size) {
    memset(chat, 0, sizeof(*chat));
    chat->agent = agent;
    strncpy(chat->prompt, prompt ? prompt : "gem> ", sizeof(chat->prompt) - 1);
    chat->history_size = history_size > 0 ? history_size : 100;
    chat->running = 0;
    chat->multi_line = 0;
}

/* ---- help ---- */

void gem_chat_print_help(void) {
    printf("\n  Gem CLI Chat Commands:\n");
    printf("  ─────────────────────────────────────────\n");
    printf("  /help          Show this help message\n");
    printf("  /quit, /exit   Exit chat session\n");
    printf("  /clear         Clear conversation history\n");
    printf("  /model [name]  Show or change current model\n");
    printf("  /tools         List available tools\n");
    printf("  /tools <n> <0|1>  Enable/disable tool\n");
    printf("  /status        Show agent status\n");
    printf("  /memory        Show memory statistics\n");
    printf("  /multi         Toggle multi-line input mode\n");
    printf("  /save          Save conversation to memory\n");
    printf("  /config        Show current configuration\n");
    printf("\n");
}

/* ---- slash commands ---- */

int gem_chat_handle_command(gem_chat_t *chat, const char *line) {
    const char *cmd = line + 1; /* skip '/' */

    if (strcmp(cmd, "quit") == 0 || strcmp(cmd, "exit") == 0) {
        chat->running = 0;
        return 1;
    }

    if (strcmp(cmd, "help") == 0) {
        gem_chat_print_help();
        return 0;
    }

    if (strcmp(cmd, "clear") == 0) {
        gem_agent_free(chat->agent);
        printf("  Conversation cleared.\n");
        return 0;
    }

    if (strcmp(cmd, "status") == 0) {
        printf("  Agent:    %s\n", chat->agent->name);
        printf("  Model:    %s\n", chat->agent->model);
        printf("  State:    %s\n", gem_agent_state_str(chat->agent->state));
        printf("  Turns:    %d / %d\n", chat->agent->turn, chat->agent->max_turns);
        printf("  Messages: %d\n", chat->agent->msg_count);
        return 0;
    }

    if (strcmp(cmd, "memory") == 0) {
        if (chat->agent->memory) {
            gem_memory_stats(chat->agent->memory);
        } else {
            printf("  Memory not configured.\n");
        }
        return 0;
    }

    if (strcmp(cmd, "config") == 0) {
        gem_config_print(chat->agent->config);
        return 0;
    }

    if (strcmp(cmd, "multi") == 0) {
        chat->multi_line = !chat->multi_line;
        printf("  Multi-line mode: %s\n", chat->multi_line ? "ON (end with ;;)" : "OFF");
        return 0;
    }

    if (strcmp(cmd, "save") == 0) {
        if (chat->agent->memory) {
            gem_memory_save(chat->agent->memory);
            printf("  Memory saved.\n");
        } else {
            printf("  No memory store.\n");
        }
        return 0;
    }

    if (strncmp(cmd, "model", 5) == 0) {
        const char *new_model = cmd + 5;
        while (*new_model && isspace((unsigned char)*new_model)) new_model++;
        if (*new_model) {
            strncpy(chat->agent->model, new_model, GEM_MAX_NAME_LEN - 1);
            printf("  Model changed to: %s\n", chat->agent->model);
        } else {
            printf("  Current model: %s\n", chat->agent->model);
        }
        return 0;
    }

    if (strcmp(cmd, "tools") == 0) {
        gem_tool_list(chat->agent->tools);
        return 0;
    }

    if (strncmp(cmd, "tools ", 6) == 0) {
        /* /tools <name> <0|1> */
        char name[64];
        int enabled = 0;
        if (sscanf(cmd + 6, "%63s %d", name, &enabled) == 2) {
            if (gem_tool_set_enabled(chat->agent->tools, name, enabled) == 0) {
                printf("  Tool '%s' %s\n", name, enabled ? "enabled" : "disabled");
            } else {
                printf("  Tool '%s' not found.\n", name);
            }
        } else {
            gem_tool_list(chat->agent->tools);
        }
        return 0;
    }

    printf("  Unknown command: /%s  (type /help for commands)\n", cmd);
    return 0;
}

/* ---- process a line ---- */

int gem_chat_process_line(gem_chat_t *chat, const char *line) {
    /* Empty line */
    if (!line || !line[0]) return 0;

    /* Slash command */
    if (line[0] == '/') {
        return gem_chat_handle_command(chat, line);
    }

    /* Multi-line mode: accumulate until ";;" */
    if (chat->multi_line) {
        size_t len = strlen(chat->multi_line_buf);
        size_t line_len = strlen(line);

        /* Check for end marker */
        if (line_len >= 2 && strcmp(line + line_len - 2, ";;") == 0) {
            /* Append without the ;; */
            size_t append = line_len - 2;
            if (len + append < sizeof(chat->multi_line_buf) - 1) {
                memcpy(chat->multi_line_buf + len, line, append);
                chat->multi_line_buf[len + append] = '\0';
            }
            /* Send accumulated text */
            if (chat->multi_line_buf[0]) {
                printf("\n");
                int rc = gem_agent_run(chat->agent, chat->multi_line_buf);
                const char *resp = gem_agent_last_response(chat->agent);
                if (resp) {
                    printf("%s\n", resp);
                } else if (rc != 0) {
                    printf("(agent error)\n");
                }
                printf("\n");
            }
            chat->multi_line_buf[0] = '\0';
            return 0;
        }

        /* Accumulate */
        if (len + line_len + 1 < sizeof(chat->multi_line_buf) - 1) {
            memcpy(chat->multi_line_buf + len, line, line_len);
            chat->multi_line_buf[len + line_len] = '\n';
            chat->multi_line_buf[len + line_len + 1] = '\0';
        }
        return 0;
    }

    /* Single-line: send directly to agent */
    printf("\n");
    int rc = gem_agent_run(chat->agent, line);
    const char *resp = gem_agent_last_response(chat->agent);
    if (resp) {
        printf("%s\n", resp);
    } else if (rc != 0) {
        printf("(agent error)\n");
    }
    printf("\n");
    return 0;
}

/* ---- readline input (with fallback) ---- */

#if USE_READLINE

static char *chat_readline(const char *prompt) {
    char *line = readline(prompt);
    if (line && *line) add_history(line);
    return line;
}

#else

static char chat_line_buf[4096];

static char *chat_readline(const char *prompt) {
    printf("%s", prompt);
    fflush(stdout);
    if (!fgets(chat_line_buf, sizeof(chat_line_buf), stdin)) return NULL;
    /* Strip newline */
    size_t len = strlen(chat_line_buf);
    if (len > 0 && chat_line_buf[len - 1] == '\n') chat_line_buf[len - 1] = '\0';
    return strdup(chat_line_buf);
}

#endif

/* ---- main REPL ---- */

/* Safe wrapper that checks for interrupts */
static void chat_process_line_safe(gem_chat_t *chat, const char *line) {
    if (g_interrupted) return;
    gem_chat_process_line(chat, line);
}

int gem_chat_start(gem_chat_t *chat) {
    chat->running = 1;

    /* Set up signal handler */
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = sigint_handler;
    sigaction(SIGINT, &sa, NULL);

    printf("\n  Gem CLI v" GEM_VERSION " - HintyCloud\n");
    printf("  Agent: %s | Model: %s\n", chat->agent->name, chat->agent->model);
    printf("  Type /help for commands, /quit to exit.\n\n");

    while (chat->running) {
        g_interrupted = 0;

        char *line = chat_readline(chat->prompt);
        if (!line) {
            /* EOF */
            printf("\n");
            break;
        }

        chat_process_line_safe(chat, line);
        free(line);
    }

    printf("  Goodbye!\n");
    return 0;
}
