# Gem CLI — C Implementation

> A high-performance AI agent CLI built in pure C.  
> **Version 1.0.0** · **License: GPL-3.0** · **HintyCloud Project**

---

## Overview

Gem CLI is an AI agent that operates on a **think → act → observe** loop. It connects to LLM providers (OpenCode API), executes tools (shell, files, web, git, etc.), and maintains conversation memory — all implemented in portable C11.

### Features

| Feature | Description |
|---------|-------------|
| **Commands** | `status`, `serve`, `chat`, `project`, `jobs`, `models`, `providers`, `tools`, `agents` |
| **Configuration** | TOML config files with XDG directory support |
| **Provider System** | OpenCode API (OpenAI-compatible) via libcurl |
| **Tool Registry** | shell, files, web, image, git, archive, artifacts |
| **Agent Loop** | think/act/observe with max-turns control |
| **Memory System** | JSON-based persistent conversation history |
| **Platform Detection** | OS, arch, hostname, CPU, memory auto-detection |
| **Chat REPL** | Interactive mode with readline support, slash commands |
| **Cross-Compilation** | Linux, macOS, Windows targets |

---

## Building

### Prerequisites

- **C compiler**: GCC ≥ 8 or Clang ≥ 10 (C11 support)
- **libcurl**: HTTP client library (`libcurl4-openssl-dev` on Debian/Ubuntu)
- **readline**: Optional, for enhanced line editing (`libreadline-dev`)
- **pthreads**: POSIX threads (usually available)

### Install Dependencies

```bash
# Debian/Ubuntu
sudo apt install gcc libcurl4-openssl-dev libreadline-dev

# Fedora/RHEL
sudo dnf install gcc libcurl-devel readline-devel

# macOS (Homebrew)
brew install curl readline
```

### Build

```bash
# Default build (release, current platform)
make

# Debug build
make debug

# Verbose build info
make info

# Check dependencies
make deps
```

### Cross-Compilation

```bash
# Linux x86_64
make linux

# Linux ARM64 (requires cross-compiler)
make linux-arm64

# macOS (requires osxcross)
make macos

# Windows (requires MinGW)
make windows
```

### Install

```bash
sudo make install           # installs to /usr/local/bin/gem
sudo make install PREFIX=/opt/gem   # custom prefix
make uninstall
```

---

## Usage

### Commands

```bash
# Show system status
gem status

# Start interactive chat
gem chat

# List models
gem models

# List providers
gem providers

# List tools
gem tools

# List agents
gem agents

# Override model
gem -m gpt-3.5-turbo chat

# Use custom config
gem -c /path/to/gem.toml chat

# Verbose mode
gem -v chat
```

### Chat Commands (inside REPL)

```
/help          Show help
/quit          Exit chat
/clear         Clear conversation
/model [name]  Show or change model
/tools         List tools
/tools <n> 0   Disable a tool
/status        Agent status
/memory        Memory statistics
/multi         Toggle multi-line input (end with ;;)
/save          Save conversation to memory
/config        Show configuration
```

---

## Configuration

Gem reads config from (in order of priority):

1. `~/.config/gem/gem.toml` (XDG)
2. `./gem.toml` (current directory)
3. `~/.gemrc` (home directory)

### Example `gem.toml`

```toml
[general]
default_model = "gpt-4"
default_provider = "opencode"
verbose = false
log_level = "info"

[providers.opencode]
api_url = "https://api.opencode.ai/v1"
api_key = ""             # or set GEM_API_KEY env var
model = "gpt-4"
enabled = true
timeout_ms = 30000
max_retries = 3

[agents.default]
model = "gpt-4"
system_prompt = "You are Gem, an AI assistant."
max_turns = 20
enabled = true

[memory]
enabled = true
max_entries = 1000
path = "~/.local/share/gem/memory.json"

[chat]
history_size = 100
prompt_format = "gem> "
```

### Environment Variables

| Variable | Description |
|----------|-------------|
| `GEM_API_KEY` | API key (overrides config) |
| `OPENAI_API_KEY` | Fallback API key |
| `GEM_CONFIG` | Path to config file |
| `XDG_CONFIG_HOME` | XDG config directory |
| `XDG_DATA_HOME` | XDG data directory |
| `XDG_CACHE_HOME` | XDG cache directory |

---

## Architecture

```
┌──────────────┐
│   main.c     │  Entry point, CLI parsing, command dispatch
├──────────────┤
│   chat.c     │  Interactive REPL (readline/fallback)
├──────────────┤
│   agent.c    │  Think → Act → Observe loop
├──────────────┤
│  provider.c  │  OpenCode API via libcurl + cJSON
├──────────────┤
│   tools.c    │  Tool registry + built-in tools
├──────────────┤
│  memory.c    │  JSON-based conversation store
├──────────────┤
│  config.c    │  TOML parser, defaults, save/load
├──────────────┤
│ platform.c   │  OS/arch/hostname/CPU/mem detection
└──────────────┘
```

### Agent Loop

```
  User Input
      │
      ▼
  ┌─────────┐
  │  THINK   │  Send messages + tools to LLM provider
  └────┬────┘
       │
       ├── text response → DONE (display to user)
       │
       └── tool_calls → ACT
              │
              ▼
         ┌─────────┐
         │   ACT    │  Execute tool (shell, files, web, git...)
         └────┬────┘
              │
              ▼
         ┌──────────┐
         │ OBSERVE  │  Capture tool output, add to messages
         └────┬─────┘
              │
              └── loop back to THINK (until max_turns or no tool_calls)
```

---

## Project Structure

```
gem-c/
├── Makefile              Build system
├── README.md             This file
├── vendor/
│   ├── cJSON.h           Vendored JSON parser
│   └── cJSON.c
└── src/
    ├── main.c            Entry point
    ├── config.h/c        Configuration
    ├── provider.h/c      Provider interface
    ├── tools.h/c         Tool registry
    ├── agent.h/c         Agent loop
    ├── memory.h/c        Memory store
    ├── platform.h/c      Platform detection
    └── chat.h/c          Chat REPL
```

---

## License

Copyright (C) 2025 HintyCloud. Licensed under the **GNU General Public License v3.0**.

See [LICENSE](https://www.gnu.org/licenses/gpl-3.0.html) for details.

---

<br>

---

# Gem CLI — Implementação em C

> Um CLI de agente de IA de alta performance construído em C puro.  
> **Versão 1.0.0** · **Licença: GPL-3.0** · **Projeto HintyCloud**

---

## Visão Geral

O Gem CLI é um agente de IA que opera em um loop **pensar → agir → observar**. Ele se conecta a provedores de LLM (API OpenCode), executa ferramentas (shell, arquivos, web, git, etc.) e mantém histórico de conversação — tudo implementado em C11 portátil.

### Funcionalidades

| Funcionalidade | Descrição |
|----------------|-----------|
| **Comandos** | `status`, `serve`, `chat`, `project`, `jobs`, `models`, `providers`, `tools`, `agents` |
| **Configuração** | Arquivos TOML com suporte a diretórios XDG |
| **Sistema de Provedores** | API OpenCode (compatível com OpenAI) via libcurl |
| **Registro de Ferramentas** | shell, arquivos, web, imagem, git, arquivo, artefatos |
| **Loop do Agente** | pensar/agir/observar com controle de max_turns |
| **Sistema de Memória** | Histórico de conversação persistente em JSON |
| **Detecção de Plataforma** | SO, arquitetura, hostname, CPU, memória |
| **Chat REPL** | Modo interativo com readline, comandos slash |
| **Compilação Cruzada** | Alvos: Linux, macOS, Windows |

---

## Compilação

### Pré-requisitos

- **Compilador C**: GCC ≥ 8 ou Clang ≥ 10 (suporte C11)
- **libcurl**: Biblioteca cliente HTTP (`libcurl4-openssl-dev` no Debian/Ubuntu)
- **readline**: Opcional, para edição de linha aprimorada (`libreadline-dev`)
- **pthreads**: Threads POSIX (geralmente disponível)

### Instalar Dependências

```bash
# Debian/Ubuntu
sudo apt install gcc libcurl4-openssl-dev libreadline-dev

# Fedora/RHEL
sudo dnf install gcc libcurl-devel readline-devel

# macOS (Homebrew)
brew install curl readline
```

### Compilar

```bash
# Build padrão (release, plataforma atual)
make

# Build de debug
make debug

# Informações de build
make info

# Verificar dependências
make deps
```

### Compilação Cruzada

```bash
# Linux x86_64
make linux

# Linux ARM64 (requer cross-compiler)
make linux-arm64

# macOS (requer osxcross)
make macos

# Windows (requer MinGW)
make windows
```

### Instalar

```bash
sudo make install           # instala em /usr/local/bin/gem
sudo make install PREFIX=/opt/gem   # prefixo personalizado
make uninstall
```

---

## Uso

### Comandos

```bash
# Mostrar status do sistema
gem status

# Iniciar chat interativo
gem chat

# Listar modelos
gem models

# Listar provedores
gem providers

# Listar ferramentas
gem tools

# Listar agentes
gem agents

# Sobrescrever modelo
gem -m gpt-3.5-turbo chat

# Usar config personalizada
gem -c /caminho/para/gem.toml chat

# Modo verboso
gem -v chat
```

### Comandos do Chat (dentro do REPL)

```
/help          Mostrar ajuda
/quit          Sair do chat
/clear         Limpar conversação
/model [nome]  Mostrar ou alterar modelo
/tools         Listar ferramentas
/tools <n> 0   Desativar ferramenta
/status        Status do agente
/memory        Estatísticas de memória
/multi         Alternar modo multi-linha (terminar com ;;)
/save          Salvar conversação na memória
/config        Mostrar configuração
```

---

## Configuração

O Gem lê a configuração de (em ordem de prioridade):

1. `~/.config/gem/gem.toml` (XDG)
2. `./gem.toml` (diretório atual)
3. `~/.gemrc` (diretório home)

### Variáveis de Ambiente

| Variável | Descrição |
|----------|-----------|
| `GEM_API_KEY` | Chave de API (sobrescreve config) |
| `OPENAI_API_KEY` | Chave de API alternativa |
| `GEM_CONFIG` | Caminho para arquivo de config |
| `XDG_CONFIG_HOME` | Diretório de config XDG |
| `XDG_DATA_HOME` | Diretório de dados XDG |
| `XDG_CACHE_HOME` | Diretório de cache XDG |

---

## Licença

Copyright (C) 2025 HintyCloud. Licenciado sob a **GNU General Public License v3.0**.

Veja [LICENÇA](https://www.gnu.org/licenses/gpl-3.0.html) para detalhes.
