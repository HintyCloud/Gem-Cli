# Gem CLI — Agentic AI Ecosystem

**Version 1.0.0** | **HintyCloud** | **GPL-3.0 License**

Gem CLI is a powerful agentic AI ecosystem that provides a command-line interface for interacting with AI models, managing tools, running agent loops, and orchestrating multi-agent swarms.

---

## Features

- **CLI Commands**: `status`, `serve`, `chat`, `project`, `jobs`, `models`, `providers`, `tools`, `agents`
- **Interactive Chat**: Chat mode with slash commands (`/help`, `/model`, `/tools`, `/memory`, etc.)
- **Configuration**: TOML and JSON config files with environment variable resolution
- **Provider System**: OpenCode API and OpenAI-compatible providers
- **Tool Registry**: Built-in tools — shell, files, web, image, git, archive, artifacts
- **Agent Loop**: Think/Act/Observe cycle with tool calling
- **Memory System**: Conversation history + persistent long-term memory
- **Job Queue**: Background job execution with concurrency control
- **Swarm**: Multi-agent coordination (central, mesh, hierarchical)
- **Platform Detection**: OS, shell, environment capabilities
- **HTTP API Server**: REST API with Express.js

---

## Installation

```bash
# Clone and build
git clone https://github.com/hintycloud/gem-cli.git
cd gem-cli
npm install
npm run build

# Or run directly with tsx
npm run dev
```

---

## Quick Start

```bash
# Show status
gem status

# Start interactive chat
gem chat

# Chat with a specific provider and model
gem chat --provider openai --model gpt-4o

# List available models
gem models

# List and manage tools
gem tools list
gem tools enable image
gem tools disable artifacts

# Initialize a project
gem project init --name my-project

# Start the API server
gem serve --port 8080

# Manage providers
gem providers list
gem providers test openai

# View jobs
gem jobs list
gem jobs stats

# Agent and swarm info
gem agents list
```

---

## Configuration

Gem CLI looks for configuration in the following order:

1. `gem.toml` or `gem.json` in the current directory
2. `.gem/config.toml` or `.gem/config.json`
3. `$XDG_CONFIG_HOME/gem/config.toml`
4. `~/.config/gem/config.toml`
5. `~/.gemrc.toml` or `~/.gemrc.json`

### Example Configuration (JSON)

```json
{
  "version": "1.0.0",
  "defaultProvider": "opencode",
  "defaultModel": "default",
  "providers": [
    {
      "name": "opencode",
      "type": "opencode",
      "apiKeyEnv": "OPENCODE_API_KEY",
      "baseUrl": "https://api.opencode.ai"
    },
    {
      "name": "openai",
      "type": "openai-compat",
      "apiKeyEnv": "OPENAI_API_KEY",
      "baseUrl": "https://api.openai.com/v1",
      "models": ["gpt-4o", "gpt-4o-mini", "o1", "o1-mini"],
      "defaultModel": "gpt-4o"
    }
  ],
  "memory": {
    "enabled": true,
    "maxHistory": 100
  },
  "server": {
    "host": "0.0.0.0",
    "port": 8080
  },
  "swarm": {
    "enabled": false,
    "maxAgents": 5,
    "coordination": "central"
  }
}
```

---

## Chat Slash Commands

| Command | Description |
|---------|-------------|
| `/help` | Show available commands |
| `/exit`, `/quit` | Exit chat mode |
| `/clear` | Clear conversation history |
| `/model [name]` | Show or change model |
| `/provider [name]` | Show or change provider |
| `/tools [enable\|disable name]` | List or toggle tools |
| `/memory [search]` | Search or list memory |
| `/history` | Show conversation history |
| `/system <prompt>` | Set system prompt |
| `/save` | Save memory to disk |
| `/status` | Show agent status |
| `/reset` | Reset the agent |

---

## Built-in Tools

| Tool | Category | Description |
|------|----------|-------------|
| `shell` | system | Execute shell commands |
| `files` | filesystem | Read, write, list, and manage files |
| `web` | network | HTTP requests and web operations |
| `image` | media | Image generation and manipulation |
| `git` | version-control | Git operations |
| `archive` | filesystem | Create and extract archives |
| `artifacts` | generation | Create and manage code artifacts |

---

## HTTP API

When running `gem serve`, the following endpoints are available:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | Health check |
| `/api/status` | GET | System status |
| `/api/providers` | GET | List providers |
| `/api/providers/:name/models` | GET | List models for provider |
| `/api/chat` | POST | Chat completion (supports streaming) |
| `/api/tools` | GET | List tools |
| `/api/tools/:name/execute` | POST | Execute a tool |
| `/api/jobs` | GET/POST | List or create jobs |
| `/api/memory` | GET/POST | List or store memory |
| `/api/conversations` | GET/POST | Manage conversations |

---

## Architecture

```
src/
├── index.ts          # Entry point
├── cli/              # CLI commands and chat
│   ├── commands/     # Individual command implementations
│   └── chat/         # Slash commands
├── config/           # Configuration loading (TOML/JSON)
├── provider/         # Provider interface + implementations
├── tools/            # Tool interface, registry, and implementations
├── agent/            # Agent loop, swarm, job queue
├── memory/           # History and persistent memory
├── platform/         # Platform detection
└── server/           # HTTP API server
```

---

## Environment Variables

| Variable | Description |
|----------|-------------|
| `GEM_CONFIG_PATH` | Path to config file |
| `OPENCODE_API_KEY` | API key for OpenCode provider |
| `OPENAI_API_KEY` | API key for OpenAI provider |
| `XDG_CONFIG_HOME` | XDG config directory |

---

## License

GPL-3.0 — See [LICENSE](https://www.gnu.org/licenses/gpl-3.0.en.html) for details.

---

# Gem CLI — Ecossistema de IA Agentic

**Versão 1.0.0** | **HintyCloud** | **Licença GPL-3.0**

Gem CLI é um poderoso ecossistema de IA agentic que fornece uma interface de linha de comando para interagir com modelos de IA, gerenciar ferramentas, executar loops de agentes e orquestrar enxames multi-agente.

---

## Funcionalidades

- **Comandos CLI**: `status`, `serve`, `chat`, `project`, `jobs`, `models`, `providers`, `tools`, `agents`
- **Chat Interativo**: Modo de chat com comandos slash (`/help`, `/model`, `/tools`, `/memory`, etc.)
- **Configuração**: Arquivos de configuração TOML e JSON com resolução de variáveis de ambiente
- **Sistema de Provedores**: Provedores OpenCode API e compatíveis com OpenAI
- **Registro de Ferramentas**: Ferramentas integradas — shell, files, web, image, git, archive, artifacts
- **Loop do Agente**: Ciclo Pensar/Agir/Observar com chamada de ferramentas
- **Sistema de Memória**: Histórico de conversas + memória persistente de longo prazo
- **Fila de Jobs**: Execução de jobs em segundo plano com controle de concorrência
- **Enxame (Swarm)**: Coordenação multi-agente (central, mesh, hierárquico)
- **Detecção de Plataforma**: SO, shell, capacidades do ambiente
- **Servidor HTTP API**: API REST com Express.js

---

## Instalação

```bash
git clone https://github.com/hintycloud/gem-cli.git
cd gem-cli
npm install
npm run build
```

---

## Início Rápido

```bash
# Mostrar status
gem status

# Iniciar chat interativo
gem chat

# Chat com provedor e modelo específicos
gem chat --provider openai --model gpt-4o

# Listar modelos disponíveis
gem models

# Listar e gerenciar ferramentas
gem tools list
gem tools enable image

# Inicializar um projeto
gem project init --name meu-projeto

# Iniciar o servidor API
gem serve --port 8080
```

---

## Configuração

O Gem CLI procura configuração na seguinte ordem:

1. `gem.toml` ou `gem.json` no diretório atual
2. `.gem/config.toml` ou `.gem/config.json`
3. `$XDG_CONFIG_HOME/gem/config.toml`
4. `~/.config/gem/config.toml`
5. `~/.gemrc.toml` ou `~/.gemrc.json`

---

## Comandos Slash do Chat

| Comando | Descrição |
|---------|-----------|
| `/help` | Mostrar comandos disponíveis |
| `/exit`, `/quit` | Sair do modo de chat |
| `/clear` | Limpar histórico da conversa |
| `/model [nome]` | Mostrar ou alterar modelo |
| `/provider [nome]` | Mostrar ou alterar provedor |
| `/tools` | Listar ou ativar/desativar ferramentas |
| `/memory` | Pesquisar ou listar memória |
| `/history` | Mostrar histórico da conversa |
| `/system <prompt>` | Definir prompt do sistema |
| `/save` | Salvar memória no disco |
| `/status` | Mostrar status do agente |
| `/reset` | Resetar o agente |

---

## Ferramentas Integradas

| Ferramenta | Categoria | Descrição |
|-----------|-----------|-----------|
| `shell` | sistema | Executar comandos shell |
| `files` | sistema de arquivos | Ler, escrever, listar e gerenciar arquivos |
| `web` | rede | Requisições HTTP e operações web |
| `image` | mídia | Geração e manipulação de imagens |
| `git` | controle de versão | Operações Git |
| `archive` | sistema de arquivos | Criar e extrair arquivos |
| `artifacts` | geração | Criar e gerenciar artefatos de código |

---

## Licença

GPL-3.0 — Veja [LICENÇA](https://www.gnu.org/licenses/gpl-3.0.en.html) para detalhes.
