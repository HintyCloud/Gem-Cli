/**
 * Provider Module
 * Exports provider interface and implementations.
 */

export {
  type IProvider,
  type BaseProvider,
  type ChatMessage,
  type ChatResponse,
  type ChatStreamChunk,
  type ModelInfo,
  type ProviderChatOptions,
  type ProviderToolDefinition,
  type ToolCall,
} from './interface.js';

export { OpenCodeProvider, type OpenCodeProviderConfig } from './opencode.js';
export { OpenAICompatProvider, type OpenAICompatProviderConfig } from './openai-compat.js';

import type { IProvider } from './interface.js';
import type { ProviderConfig } from '../config/schema.js';
import { OpenCodeProvider } from './opencode.js';
import { OpenAICompatProvider } from './openai-compat.js';

/**
 * Create a provider from configuration
 */
export function createProvider(config: ProviderConfig): IProvider {
  const apiKey = config.apiKeyEnv ? process.env[config.apiKeyEnv] : config.apiKey;

  switch (config.type) {
    case 'opencode':
      return new OpenCodeProvider({
        apiKey,
        apiKeyEnv: config.apiKeyEnv,
        baseUrl: config.baseUrl,
        defaultModel: config.defaultModel,
        maxTokens: config.maxTokens,
        temperature: config.temperature,
      });

    case 'openai-compat':
      return new OpenAICompatProvider({
        name: config.name,
        apiKey,
        apiKeyEnv: config.apiKeyEnv,
        baseUrl: config.baseUrl,
        defaultModel: config.defaultModel,
        models: config.models,
        maxTokens: config.maxTokens,
        temperature: config.temperature,
      });

    default:
      throw new Error(`Unknown provider type: ${config.type}`);
  }
}

/**
 * Provider registry - manages all configured providers
 */
export class ProviderRegistry {
  private providers: Map<string, IProvider> = new Map();
  private defaultProvider: string;

  constructor(configs: ProviderConfig[], defaultName: string) {
    this.defaultProvider = defaultName;
    for (const config of configs) {
      try {
        const provider = createProvider(config);
        this.providers.set(config.name, provider);
      } catch (err) {
        console.warn(`Failed to create provider "${config.name}": ${err instanceof Error ? err.message : String(err)}`);
      }
    }
  }

  get(name?: string): IProvider | undefined {
    return this.providers.get(name || this.defaultProvider);
  }

  getDefault(): IProvider | undefined {
    return this.providers.get(this.defaultProvider);
  }

  list(): IProvider[] {
    return Array.from(this.providers.values());
  }

  listNames(): string[] {
    return Array.from(this.providers.keys());
  }

  has(name: string): boolean {
    return this.providers.has(name);
  }
}
