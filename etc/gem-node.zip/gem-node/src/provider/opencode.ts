/**
 * OpenCode API Provider
 * Implements the provider interface for the OpenCode API.
 */

import { BaseProvider, type ChatMessage, type ChatResponse, type ChatStreamChunk, type ModelInfo, type ProviderChatOptions } from './interface.js';

export interface OpenCodeProviderConfig {
  apiKey?: string;
  apiKeyEnv?: string;
  baseUrl?: string;
  defaultModel?: string;
  maxTokens?: number;
  temperature?: number;
}

export class OpenCodeProvider extends BaseProvider {
  readonly name = 'opencode';
  readonly type = 'opencode';

  private maxTokens: number;
  private temperature: number;
  private apiKeyEnv: string;

  constructor(config: OpenCodeProviderConfig = {}) {
    super({
      apiKey: config.apiKey,
      baseUrl: config.baseUrl || 'https://api.opencode.ai',
      defaultModel: config.defaultModel || 'default',
    });
    this.apiKeyEnv = config.apiKeyEnv || 'OPENCODE_API_KEY';
    this.maxTokens = config.maxTokens || 4096;
    this.temperature = config.temperature || 0.7;
    this.apiKey = this.resolveApiKey(this.apiKeyEnv);
  }

  isAvailable(): boolean {
    return !!this.apiKey || !!process.env[this.apiKeyEnv];
  }

  async listModels(): Promise<ModelInfo[]> {
    try {
      const response = await fetch(`${this.baseUrl}/v1/models`, {
        headers: {
          Authorization: `Bearer ${this.resolveApiKey(this.apiKeyEnv)}`,
        },
      });
      if (!response.ok) {
        return this.getDefaultModels();
      }
      const data = await response.json() as { data: Array<{ id: string; name?: string }> };
      return data.data.map((m) => ({
        id: m.id,
        name: m.name || m.id,
        provider: this.name,
        supportsTools: true,
        supportsStreaming: true,
      }));
    } catch {
      return this.getDefaultModels();
    }
  }

  async chat(messages: ChatMessage[], options?: ProviderChatOptions): Promise<ChatResponse> {
    const model = options?.model || this.defaultModel;
    const apiKey = this.resolveApiKey(this.apiKeyEnv);

    const body: Record<string, unknown> = {
      model,
      messages: this.formatMessages(messages),
      max_tokens: options?.maxTokens || this.maxTokens,
      temperature: options?.temperature ?? this.temperature,
    };

    if (options?.systemPrompt) {
      body.messages = [{ role: 'system', content: options.systemPrompt }, ...body.messages as ChatMessage[]];
    }

    if (options?.tools && options.tools.length > 0) {
      body.tools = options.tools.map((t) => ({
        type: 'function',
        function: {
          name: t.name,
          description: t.description,
          parameters: t.parameters,
        },
      }));
    }

    const response = await fetch(`${this.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenCode API error (${response.status}): ${errorText}`);
    }

    const data = await response.json() as Record<string, unknown>;
    const choice = (data.choices as Array<Record<string, unknown>>)[0];
    const message = choice?.message as Record<string, unknown>;

    return {
      content: (message?.content as string) || null,
      toolCalls: this.extractToolCalls(message),
      usage: data.usage
        ? {
            promptTokens: (data.usage as Record<string, number>).prompt_tokens || 0,
            completionTokens: (data.usage as Record<string, number>).completion_tokens || 0,
            totalTokens: (data.usage as Record<string, number>).total_tokens || 0,
          }
        : undefined,
      model: (data.model as string) || model,
      finishReason: (choice?.finish_reason as string) || null,
    };
  }

  async *chatStream(
    messages: ChatMessage[],
    options?: ProviderChatOptions,
  ): AsyncIterable<ChatStreamChunk> {
    const model = options?.model || this.defaultModel;
    const apiKey = this.resolveApiKey(this.apiKeyEnv);

    const body: Record<string, unknown> = {
      model,
      messages: this.formatMessages(messages),
      max_tokens: options?.maxTokens || this.maxTokens,
      temperature: options?.temperature ?? this.temperature,
      stream: true,
    };

    const response = await fetch(`${this.baseUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify(body),
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenCode API stream error (${response.status}): ${errorText}`);
    }

    if (!response.body) {
      throw new Error('No response body for streaming');
    }

    const decoder = new TextDecoder();
    const reader = response.body.getReader();
    let buffer = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || !trimmed.startsWith('data: ')) continue;

          const data = trimmed.slice(6);
          if (data === '[DONE]') {
            yield { done: true };
            return;
          }

          try {
            const parsed = JSON.parse(data) as Record<string, unknown>;
            const choices = parsed.choices as Array<Record<string, unknown>>;
            const delta = choices?.[0]?.delta as Record<string, unknown>;

            if (delta?.content) {
              yield { content: delta.content as string, done: false };
            }
          } catch {
            // Skip malformed chunks
          }
        }
      }
    } finally {
      reader.releaseLock();
    }

    yield { done: true };
  }

  private formatMessages(messages: ChatMessage[]): Record<string, unknown>[] {
    return messages.map((m) => {
      const msg: Record<string, unknown> = { role: m.role, content: m.content };
      if (m.name) msg.name = m.name;
      if (m.toolCallId) msg.tool_call_id = m.toolCallId;
      return msg;
    });
  }

  private extractToolCalls(message: Record<string, unknown> | undefined): ChatResponse['toolCalls'] {
    if (!message?.tool_calls) return undefined;
    const toolCalls = message.tool_calls as Array<Record<string, unknown>>;
    return toolCalls.map((tc) => {
      const func = tc.function as Record<string, unknown>;
      return {
        id: tc.id as string,
        name: func.name as string,
        arguments: typeof func.arguments === 'string' ? func.arguments : JSON.stringify(func.arguments),
      };
    });
  }

  private getDefaultModels(): ModelInfo[] {
    return [
      {
        id: 'default',
        name: 'OpenCode Default',
        provider: this.name,
        supportsTools: true,
        supportsStreaming: true,
      },
    ];
  }
}

export default OpenCodeProvider;
