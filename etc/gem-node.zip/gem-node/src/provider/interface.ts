/**
 * Provider Interface
 * Defines the contract for AI model providers.
 */

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string;
  name?: string;
  toolCallId?: string;
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: string;
}

export interface ChatResponse {
  content: string | null;
  toolCalls?: ToolCall[];
  usage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  model: string;
  finishReason: string | null;
}

export interface ChatStreamChunk {
  content?: string;
  toolCalls?: Partial<ToolCall>[];
  done: boolean;
}

export interface ModelInfo {
  id: string;
  name: string;
  provider: string;
  contextWindow?: number;
  maxTokens?: number;
  supportsTools?: boolean;
  supportsVision?: boolean;
  supportsStreaming?: boolean;
}

export interface ProviderChatOptions {
  model?: string;
  temperature?: number;
  maxTokens?: number;
  topP?: number;
  stream?: boolean;
  tools?: ProviderToolDefinition[];
  systemPrompt?: string;
}

export interface ProviderToolDefinition {
  name: string;
  description: string;
  parameters: Record<string, unknown>;
}

/**
 * Provider interface - all providers must implement this
 */
export interface IProvider {
  readonly name: string;
  readonly type: string;

  /**
   * Check if the provider is configured and available
   */
  isAvailable(): boolean;

  /**
   * List available models
   */
  listModels(): Promise<ModelInfo[]>;

  /**
   * Send a chat completion request
   */
  chat(messages: ChatMessage[], options?: ProviderChatOptions): Promise<ChatResponse>;

  /**
   * Send a streaming chat completion request
   */
  chatStream(
    messages: ChatMessage[],
    options?: ProviderChatOptions,
  ): AsyncIterable<ChatStreamChunk>;

  /**
   * Get the default model for this provider
   */
  getDefaultModel(): string;

  /**
   * Get the API key (masked for display)
   */
  getMaskedApiKey(): string;
}

/**
 * Base provider class with common functionality
 */
export abstract class BaseProvider implements IProvider {
  abstract readonly name: string;
  abstract readonly type: string;

  protected apiKey: string;
  protected baseUrl: string;
  protected defaultModel: string;

  constructor(config: { apiKey?: string; baseUrl: string; defaultModel: string }) {
    this.apiKey = config.apiKey || '';
    this.baseUrl = config.baseUrl;
    this.defaultModel = config.defaultModel;
  }

  abstract isAvailable(): boolean;
  abstract listModels(): Promise<ModelInfo[]>;
  abstract chat(messages: ChatMessage[], options?: ProviderChatOptions): Promise<ChatResponse>;
  abstract chatStream(
    messages: ChatMessage[],
    options?: ProviderChatOptions,
  ): AsyncIterable<ChatStreamChunk>;

  getDefaultModel(): string {
    return this.defaultModel;
  }

  getMaskedApiKey(): string {
    if (!this.apiKey || this.apiKey.length < 8) return '***';
    return `${this.apiKey.slice(0, 4)}...${this.apiKey.slice(-4)}`;
  }

  protected resolveApiKey(envVar?: string): string {
    if (this.apiKey) return this.apiKey;
    if (envVar) return process.env[envVar] || '';
    return '';
  }
}
