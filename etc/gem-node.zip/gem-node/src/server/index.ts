/**
 * HTTP API Server
 * Express-based server that exposes the Gem CLI functionality via REST API.
 */

import express from 'express';
import type { GemConfig } from '../config/schema.js';
import type { ProviderRegistry } from '../provider/index.js';
import type { ToolRegistry } from '../tools/registry.js';
import type { JobQueue } from '../agent/job-queue.js';
import type { MemorySystem } from '../memory/index.js';
import { registerRoutes, type RouteContext } from './routes.js';

export interface ServerConfig {
  host: string;
  port: number;
  cors?: boolean;
  apiKey?: string;
}

export class GemServer {
  private app: express.Express;
  private server: ReturnType<express.Express['listen']> | null = null;
  private config: ServerConfig;
  private routeContext: RouteContext;

  constructor(
    config: ServerConfig,
    ctx: {
      config: GemConfig;
      providers: ProviderRegistry;
      tools: ToolRegistry;
      jobs: JobQueue;
      memory: MemorySystem;
    },
  ) {
    this.config = config;
    this.app = express();
    this.routeContext = ctx;

    this.setupMiddleware();
    registerRoutes(this.app, this.routeContext);
  }

  /**
   * Setup Express middleware
   */
  private setupMiddleware(): void {
    // JSON body parser
    this.app.use(express.json({ limit: '10mb' }));

    // CORS
    if (this.config.cors) {
      this.app.use((_req, res, next) => {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
        if (_req.method === 'OPTIONS') {
          res.sendStatus(204);
          return;
        }
        next();
      });
    }

    // API key authentication
    if (this.config.apiKey) {
      this.app.use('/api', (req, res, next) => {
        const authHeader = req.headers.authorization;
        const queryKey = req.query.apiKey as string | undefined;

        if (
          authHeader === `Bearer ${this.config.apiKey}` ||
          queryKey === this.config.apiKey
        ) {
          next();
        } else {
          res.status(401).json({ error: 'Unauthorized' });
        }
      });
    }

    // Request logging
    this.app.use('/api', (req, res, next) => {
      const start = Date.now();
      res.on('finish', () => {
        const duration = Date.now() - start;
        console.log(`${req.method} ${req.path} ${res.statusCode} ${duration}ms`);
      });
      next();
    });
  }

  /**
   * Start the server
   */
  async start(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.server = this.app.listen(this.config.port, this.config.host, () => {
        console.log(
          `Gem API server listening on http://${this.config.host}:${this.config.port}`,
        );
        resolve();
      });

      this.server.on('error', (err: Error) => {
        reject(err);
      });
    });
  }

  /**
   * Stop the server
   */
  async stop(): Promise<void> {
    if (!this.server) return;
    return new Promise((resolve, reject) => {
      this.server!.close((err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }

  /**
   * Get the Express app instance
   */
  getApp(): express.Express {
    return this.app;
  }

  /**
   * Get the server address info
   */
  getAddress(): { host: string; port: number } | null {
    if (!this.server) return null;
    const addr = this.server.address();
    if (!addr || typeof addr === 'string') return null;
    return { host: addr.address, port: addr.port };
  }
}

/**
 * Create and start a server
 */
export async function createServer(
  config: ServerConfig,
  ctx: RouteContext,
): Promise<GemServer> {
  const server = new GemServer(config, ctx);
  await server.start();
  return server;
}

export default GemServer;
