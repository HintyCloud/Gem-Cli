/**
 * HTTP API Server Routes
 * Defines all API endpoints for the Gem CLI server.
 */

import type { Express, Request, Response } from 'express';
import type { ProviderRegistry } from '../provider/index.js';
import type { ToolRegistry } from '../tools/registry.js';
import type { JobQueue } from '../agent/job-queue.js';
import type { MemorySystem } from '../memory/index.js';
import type { GemConfig } from '../config/schema.js';

export interface RouteContext {
  config: GemConfig;
  providers: ProviderRegistry;
  tools: ToolRegistry;
  jobs: JobQueue;
  memory: MemorySystem;
}

/**
 * Register all API routes
 */
export function registerRoutes(app: Express, ctx: RouteContext): void {
  // Health check
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ status: 'ok', version: '1.0.0', timestamp: new Date().toISOString() });
  });

  // --- Status ---
  app.get('/api/status', (_req: Request, res: Response) => {
    res.json({
      version: '1.0.0',
      providers: ctx.providers.listNames(),
      tools: ctx.tools.listAll().map((t) => ({
        name: t.definition.name,
        category: t.definition.category,
        enabled: ctx.tools.isEnabled(t.definition.name),
      })),
      jobs: ctx.jobs.getStats(),
      uptime: process.uptime(),
    });
  });

  // --- Providers ---
  app.get('/api/providers', (_req: Request, res: Response) => {
    const providers = ctx.providers.list().map((p) => ({
      name: p.name,
      type: p.type,
      available: p.isAvailable(),
      defaultModel: p.getDefaultModel(),
      apiKey: p.getMaskedApiKey(),
    }));
    res.json(providers);
  });

  app.get('/api/providers/:name/models', async (req: Request, res: Response) => {
    const provider = ctx.providers.get(req.params.name);
    if (!provider) {
      res.status(404).json({ error: 'Provider not found' });
      return;
    }
    try {
      const models = await provider.listModels();
      res.json(models);
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
    }
  });

  // --- Chat ---
  app.post('/api/chat', async (req: Request, res: Response) => {
    try {
      const { messages, provider: providerName, model, temperature, maxTokens, stream } = req.body;

      const provider = ctx.providers.get(providerName) || ctx.providers.getDefault();
      if (!provider) {
        res.status(400).json({ error: 'No provider available' });
        return;
      }

      if (stream) {
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');

        for await (const chunk of provider.chatStream(messages, { model, temperature, maxTokens })) {
          if (chunk.content) {
            res.write(`data: ${JSON.stringify({ content: chunk.content, done: false })}\n\n`);
          }
          if (chunk.done) {
            res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
            res.end();
            return;
          }
        }
        res.end();
      } else {
        const response = await provider.chat(messages, { model, temperature, maxTokens });
        res.json(response);
      }
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
    }
  });

  // --- Tools ---
  app.get('/api/tools', (_req: Request, res: Response) => {
    const tools = ctx.tools.listAll().map((t) => ({
      ...t.definition,
      enabled: ctx.tools.isEnabled(t.definition.name),
    }));
    res.json(tools);
  });

  app.post('/api/tools/:name/execute', async (req: Request, res: Response) => {
    try {
      const result = await ctx.tools.execute(req.params.name, req.body.args || {}, {
        workingDir: req.body.workingDir || process.cwd(),
        env: req.body.env || {},
      });
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
    }
  });

  app.post('/api/tools/:name/enable', (req: Request, res: Response) => {
    ctx.tools.setEnabled(req.params.name, true);
    res.json({ ok: true });
  });

  app.post('/api/tools/:name/disable', (req: Request, res: Response) => {
    ctx.tools.setEnabled(req.params.name, false);
    res.json({ ok: true });
  });

  // --- Jobs ---
  app.get('/api/jobs', (_req: Request, res: Response) => {
    res.json(ctx.jobs.list());
  });

  app.get('/api/jobs/:id', (req: Request, res: Response) => {
    const job = ctx.jobs.get(req.params.id);
    if (!job) {
      res.status(404).json({ error: 'Job not found' });
      return;
    }
    res.json(job);
  });

  app.post('/api/jobs', (req: Request, res: Response) => {
    const { name, type, payload } = req.body;
    const job = ctx.jobs.enqueue(name, type, payload);
    res.status(201).json(job);
  });

  app.delete('/api/jobs/:id', (req: Request, res: Response) => {
    const cancelled = ctx.jobs.cancel(req.params.id);
    res.json({ ok: cancelled });
  });

  // --- Memory ---
  app.get('/api/memory', (_req: Request, res: Response) => {
    const entries = ctx.memory.persistent.list();
    res.json(entries);
  });

  app.get('/api/memory/:key', (req: Request, res: Response) => {
    const entry = ctx.memory.persistent.get(req.params.key);
    if (!entry) {
      res.status(404).json({ error: 'Key not found' });
      return;
    }
    res.json(entry);
  });

  app.post('/api/memory', async (req: Request, res: Response) => {
    const { key, value, category, tags } = req.body;
    const entry = ctx.memory.persistent.set(key, value, category, tags);
    await ctx.memory.persistent.save();
    res.status(201).json(entry);
  });

  app.delete('/api/memory/:key', async (req: Request, res: Response) => {
    const deleted = ctx.memory.persistent.delete(req.params.key);
    await ctx.memory.persistent.save();
    res.json({ ok: deleted });
  });

  app.get('/api/memory/search/:query', (req: Request, res: Response) => {
    const results = ctx.memory.persistent.search(req.params.query);
    res.json(results);
  });

  // --- Conversations ---
  app.get('/api/conversations', (_req: Request, res: Response) => {
    const conversations = ctx.memory.history.listConversations();
    res.json(conversations);
  });

  app.post('/api/conversations', (req: Request, res: Response) => {
    const { title, model, provider } = req.body;
    const conv = ctx.memory.history.createConversation(title, model, provider);
    res.status(201).json(conv);
  });

  app.get('/api/conversations/active', (_req: Request, res: Response) => {
    const conv = ctx.memory.history.getActive();
    res.json(conv || null);
  });
}

export default registerRoutes;
