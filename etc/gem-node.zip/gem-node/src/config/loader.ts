/**
 * Gem CLI Configuration Loader
 * Loads config from TOML and JSON files with fallback to defaults.
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import type { GemConfig } from './schema.js';
import { createDefaultConfig, validateConfig } from './schema.js';

/**
 * Deep merge two objects
 */
function deepMerge(target: Record<string, unknown>, source: Record<string, unknown>): Record<string, unknown> {
  const result = { ...target };
  for (const key of Object.keys(source)) {
    const srcVal = source[key];
    const tgtVal = result[key];
    if (
      srcVal !== null &&
      typeof srcVal === 'object' &&
      !Array.isArray(srcVal) &&
      tgtVal !== null &&
      typeof tgtVal === 'object' &&
      !Array.isArray(tgtVal)
    ) {
      result[key] = deepMerge(
        tgtVal as Record<string, unknown>,
        srcVal as Record<string, unknown>,
      );
    } else {
      result[key] = srcVal;
    }
  }
  return result;
}

/**
 * Parse TOML content
 */
function parseToml(content: string): Record<string, unknown> {
  try {
    const toml = require('@iarna/toml');
    return toml.parse(content);
  } catch (err) {
    throw new Error(`Failed to parse TOML: ${err instanceof Error ? err.message : String(err)}`);
  }
}

/**
 * Parse JSON content
 */
function parseJson(content: string): Record<string, unknown> {
  try {
    return JSON.parse(content);
  } catch (err) {
    throw new Error(`Failed to parse JSON: ${err instanceof Error ? err.message : String(err)}`);
  }
}

/**
 * Search for config file in standard locations
 */
function findConfigFile(startDir?: string): string | null {
  const searchPaths: string[] = [];

  // Current/project directory
  const cwd = startDir || process.cwd();
  searchPaths.push(
    path.join(cwd, 'gem.toml'),
    path.join(cwd, 'gem.json'),
    path.join(cwd, '.gem', 'config.toml'),
    path.join(cwd, '.gem', 'config.json'),
  );

  // XDG config directory
  const xdgConfig = process.env.XDG_CONFIG_HOME;
  if (xdgConfig) {
    searchPaths.push(
      path.join(xdgConfig, 'gem', 'config.toml'),
      path.join(xdgConfig, 'gem', 'config.json'),
    );
  }

  // Home directory
  const home = require('os').homedir();
  searchPaths.push(
    path.join(home, '.config', 'gem', 'config.toml'),
    path.join(home, '.config', 'gem', 'config.json'),
    path.join(home, '.gemrc.toml'),
    path.join(home, '.gemrc.json'),
  );

  for (const p of searchPaths) {
    if (fs.existsSync(p)) {
      return p;
    }
  }

  return null;
}

/**
 * Load a config file from a specific path
 */
function loadConfigFile(filePath: string): Partial<GemConfig> {
  const content = fs.readFileSync(filePath, 'utf-8');
  const ext = path.extname(filePath).toLowerCase();

  switch (ext) {
    case '.toml':
      return parseToml(content) as Partial<GemConfig>;
    case '.json':
      return parseJson(content) as Partial<GemConfig>;
    default:
      // Try TOML first, then JSON
      try {
        return parseToml(content) as Partial<GemConfig>;
      } catch {
        return parseJson(content) as Partial<GemConfig>;
      }
  }
}

/**
 * Resolve environment variable references in config
 */
function resolveEnvVars(obj: unknown): unknown {
  if (typeof obj === 'string') {
    // Replace ${ENV_VAR} patterns
    return obj.replace(/\$\{([^}]+)\}/g, (_, varName) => {
      return process.env[varName] || '';
    });
  }
  if (Array.isArray(obj)) {
    return obj.map(resolveEnvVars);
  }
  if (obj !== null && typeof obj === 'object') {
    const result: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(obj as Record<string, unknown>)) {
      result[key] = resolveEnvVars(value);
    }
    return result;
  }
  return obj;
}

export interface LoadConfigOptions {
  configPath?: string;
  projectDir?: string;
  resolveEnv?: boolean;
}

/**
 * Load Gem configuration
 * Merges loaded config on top of defaults, validates, and returns.
 */
export function loadConfig(options: LoadConfigOptions = {}): GemConfig {
  const defaults = createDefaultConfig();

  let configPath: string | null = null;

  if (options.configPath) {
    configPath = options.configPath;
  } else {
    configPath = findConfigFile(options.projectDir);
  }

  if (!configPath) {
    return defaults;
  }

  let userConfig: Partial<GemConfig>;
  try {
    userConfig = loadConfigFile(configPath);
  } catch (err) {
    console.warn(`Warning: Failed to load config from ${configPath}: ${err instanceof Error ? err.message : String(err)}`);
    return defaults;
  }

  // Resolve environment variables if requested
  if (options.resolveEnv !== false) {
    userConfig = resolveEnvVars(userConfig) as Partial<GemConfig>;
  }

  // Deep merge with defaults
  const merged = deepMerge(
    defaults as unknown as Record<string, unknown>,
    userConfig as unknown as Record<string, unknown>,
  ) as unknown as GemConfig;

  // Validate
  const { valid, errors } = validateConfig(merged);
  if (!valid) {
    console.warn('Configuration validation warnings:');
    for (const error of errors) {
      console.warn(`  - ${error}`);
    }
  }

  return merged;
}

/**
 * Write config to file
 */
export function writeConfig(config: GemConfig, filePath: string): void {
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  const ext = path.extname(filePath).toLowerCase();
  if (ext === '.toml') {
    try {
      const toml = require('@iarna/toml');
      fs.writeFileSync(filePath, toml.stringify(config as unknown as Record<string, unknown>), 'utf-8');
    } catch {
      throw new Error('TOML serialization not available. Use JSON format instead.');
    }
  } else {
    fs.writeFileSync(filePath, JSON.stringify(config, null, 2), 'utf-8');
  }
}

/**
 * Get the path where config was found
 */
export function getConfigPath(options: LoadConfigOptions = {}): string | null {
  if (options.configPath) return options.configPath;
  return findConfigFile(options.projectDir);
}

export default {
  loadConfig,
  writeConfig,
  getConfigPath,
  findConfigFile,
};
