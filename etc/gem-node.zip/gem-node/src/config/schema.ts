/**
 * Gem CLI Configuration Schema
 * Defines the structure of the gem configuration file.
 */

export interface ProviderConfig {
  name: string;
  type: 'opencode' | 'openai-compat';
  apiKey?: string;
  apiKeyEnv?: string;
  baseUrl: string;
  models?: string[];
  defaultModel?: string;
  maxTokens?: number;
  temperature?: number;
}

export interface ToolConfig {
  name: string;
  enabled: boolean;
  config?: Record<string, unknown>;
}

export interface AgentConfig {
  name: string;
  provider: string;
  model?: string;
  systemPrompt?: string;
  tools?: string[];
  maxIterations?: number;
  temperature?: number;
}

export interface MemoryConfig {
  enabled: boolean;
  maxHistory?: number;
  persistPath?: string;
}

export interface ServerConfig {
  host: string;
  port: number;
  cors?: boolean;
  apiKey?: string;
}

export interface SwarmConfig {
  enabled: boolean;
  maxAgents?: number;
  coordination?: 'central' | 'mesh' | 'hierarchical';
}

export interface GemConfig {
  version: string;
  defaultProvider: string;
  defaultModel: string;
  providers: ProviderConfig[];
  tools: ToolConfig[];
  agents: AgentConfig[];
  memory: MemoryConfig;
  server: ServerConfig;
  swarm: SwarmConfig;
  logLevel?: 'debug' | 'info' | 'warn' | 'error';
  dataDir?: string;
}

/**
 * Default configuration values
 */
export function createDefaultConfig(): GemConfig {
  return {
    version: '1.0.0',
    defaultProvider: 'opencode',
    defaultModel: 'default',
    providers: [
      {
        name: 'opencode',
        type: 'opencode',
        baseUrl: 'https://api.opencode.ai',
        defaultModel: 'default',
        maxTokens: 4096,
        temperature: 0.7,
      },
      {
        name: 'openai',
        type: 'openai-compat',
        apiKeyEnv: 'OPENAI_API_KEY',
        baseUrl: 'https://api.openai.com/v1',
        models: ['gpt-4o', 'gpt-4o-mini', 'o1', 'o1-mini'],
        defaultModel: 'gpt-4o',
        maxTokens: 4096,
        temperature: 0.7,
      },
    ],
    tools: [
      { name: 'shell', enabled: true },
      { name: 'files', enabled: true },
      { name: 'web', enabled: true },
      { name: 'image', enabled: false },
      { name: 'git', enabled: true },
      { name: 'archive', enabled: true },
      { name: 'artifacts', enabled: false },
    ],
    agents: [
      {
        name: 'default',
        provider: 'opencode',
        model: 'default',
        systemPrompt: 'You are a helpful AI assistant.',
        tools: ['shell', 'files', 'web', 'git'],
        maxIterations: 10,
        temperature: 0.7,
      },
    ],
    memory: {
      enabled: true,
      maxHistory: 100,
    },
    server: {
      host: '0.0.0.0',
      port: 8080,
      cors: true,
    },
    swarm: {
      enabled: false,
      maxAgents: 5,
      coordination: 'central',
    },
    logLevel: 'info',
  };
}

/**
 * Validate a configuration object
 */
export function validateConfig(config: Partial<GemConfig>): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (config.version && !/^\d+\.\d+\.\d+$/.test(config.version)) {
    errors.push('version must be in semver format (x.y.z)');
  }

  if (config.providers) {
    for (const provider of config.providers) {
      if (!provider.name) errors.push('provider missing name');
      if (!provider.type) errors.push(`provider ${provider.name} missing type`);
      if (!provider.baseUrl) errors.push(`provider ${provider.name} missing baseUrl`);
    }
  }

  if (config.server) {
    if (config.server.port && (config.server.port < 1 || config.server.port > 65535)) {
      errors.push('server.port must be between 1 and 65535');
    }
  }

  return { valid: errors.length === 0, errors };
}
