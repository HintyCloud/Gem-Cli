/**
 * Agent Loop - Think/Act/Observe cycle
 * The core agent execution loop that processes messages, calls tools, and iterates.
 */

import EventEmitter from 'eventemitter3';
import type { IProvider, ChatMessage, ChatResponse, ProviderChatOptions } from '../provider/interface.js';
import type { ToolRegistry } from '../tools/registry.js';
import type { ToolContext, ToolResult } from '../tools/interface.js';
import type { HistoryStore } from '../memory/history.js';

export interface AgentConfig {
  name: string;
  provider: IProvider;
  toolRegistry: ToolRegistry;
  history?: HistoryStore;
  systemPrompt?: string;
  model?: string;
  maxIterations?: number;
  temperature?: number;
  verbose?: boolean;
}

export interface AgentState {
  status: 'idle' | 'thinking' | 'acting' | 'observing' | 'done' | 'error';
  iteration: number;
  lastResponse: ChatResponse | null;
  lastToolResult: ToolResult | null;
}

export interface AgentEvents {
  'state-change': (state: AgentState) => void;
  'thinking': (messages: ChatMessage[]) => void;
  'response': (response: ChatResponse) => void;
  'tool-call': (name: string, args: Record<string, unknown>) => void;
  'tool-result': (name: string, result: ToolResult) => void;
  'error': (error: Error) => void;
  'complete': (messages: ChatMessage[]) => void;
}

export class AgentLoop extends EventEmitter<AgentEvents> {
  public readonly name: string;
  private provider: IProvider;
  private toolRegistry: ToolRegistry;
  private history?: HistoryStore;
  private systemPrompt: string;
  private model: string;
  private maxIterations: number;
  private temperature: number;
  private verbose: boolean;

  private state: AgentState = {
    status: 'idle',
    iteration: 0,
    lastResponse: null,
    lastToolResult: null,
  };

  private messages: ChatMessage[] = [];

  constructor(config: AgentConfig) {
    super();
    this.name = config.name;
    this.provider = config.provider;
    this.toolRegistry = config.toolRegistry;
    this.history = config.history;
    this.systemPrompt = config.systemPrompt || 'You are a helpful AI assistant.';
    this.model = config.model || config.provider.getDefaultModel();
    this.maxIterations = config.maxIterations || 10;
    this.temperature = config.temperature || 0.7;
    this.verbose = config.verbose || false;
  }

  /**
   * Get current state
   */
  getState(): AgentState {
    return { ...this.state };
  }

  /**
   * Get conversation messages
   */
  getMessages(): ChatMessage[] {
    return [...this.messages];
  }

  /**
   * Run the agent with a user message
   */
  async run(userMessage: string, toolContext?: ToolContext): Promise<ChatMessage[]> {
    this.setState('thinking');
    this.messages = [];

    // Add user message
    const userMsg: ChatMessage = { role: 'user', content: userMessage };
    this.messages.push(userMsg);

    // Save to history
    this.history?.addMessage('user', userMessage);

    const defaultContext: ToolContext = toolContext || {
      workingDir: process.cwd(),
      env: {},
    };

    try {
      // Think/Act/Observe loop
      for (let i = 0; i < this.maxIterations; i++) {
        this.state.iteration = i + 1;

        // THINK: Send messages to provider
        this.setState('thinking');
        this.emit('thinking', this.messages);

        const options: ProviderChatOptions = {
          model: this.model,
          temperature: this.temperature,
          systemPrompt: this.systemPrompt,
          tools: this.toolRegistry.getOpenAITools(),
        };

        const response = await this.provider.chat(this.messages, options);
        this.state.lastResponse = response;
        this.emit('response', response);

        // Add assistant response to messages
        const assistantMsg: ChatMessage = {
          role: 'assistant',
          content: response.content || '',
        };
        this.messages.push(assistantMsg);

        // Save to history
        if (response.content) {
          this.history?.addMessage('assistant', response.content);
        }

        // ACT: Execute tool calls if any
        if (response.toolCalls && response.toolCalls.length > 0) {
          this.setState('acting');

          for (const toolCall of response.toolCalls) {
            this.emit('tool-call', toolCall.name, JSON.parse(toolCall.arguments));

            let args: Record<string, unknown>;
            try {
              args = JSON.parse(toolCall.arguments);
            } catch {
              args = { raw: toolCall.arguments };
            }

            const result = await this.toolRegistry.execute(
              toolCall.name,
              args,
              defaultContext,
            );

            this.state.lastToolResult = result;
            this.emit('tool-result', toolCall.name, result);

            // OBSERVE: Add tool result to messages
            this.setState('observing');
            const toolMsg: ChatMessage = {
              role: 'tool',
              content: result.success
                ? result.output
                : `Error: ${result.error || 'Tool execution failed'}`,
              name: toolCall.name,
              toolCallId: toolCall.id,
            };
            this.messages.push(toolMsg);
          }
        } else {
          // No tool calls - agent is done
          this.setState('done');
          this.emit('complete', this.messages);
          return this.messages;
        }
      }

      // Reached max iterations
      this.setState('done');
      this.emit('complete', this.messages);
      return this.messages;
    } catch (err) {
      this.setState('error');
      const error = err instanceof Error ? err : new Error(String(err));
      this.emit('error', error);
      throw error;
    }
  }

  /**
   * Run agent in streaming mode
   */
  async *runStream(userMessage: string, toolContext?: ToolContext): AsyncGenerator<string> {
    this.messages = [];
    const userMsg: ChatMessage = { role: 'user', content: userMessage };
    this.messages.push(userMsg);

    const defaultContext: ToolContext = toolContext || {
      workingDir: process.cwd(),
      env: {},
    };

    try {
      // For simplicity, first iteration is streaming, tool calls fall back to non-streaming
      this.setState('thinking');

      const options: ProviderChatOptions = {
        model: this.model,
        temperature: this.temperature,
        systemPrompt: this.systemPrompt,
      };

      let fullContent = '';
      for await (const chunk of this.provider.chatStream(this.messages, options)) {
        if (chunk.content) {
          fullContent += chunk.content;
          yield chunk.content;
        }
        if (chunk.done) break;
      }

      // Add assistant response
      this.messages.push({ role: 'assistant', content: fullContent });
      this.history?.addMessage('assistant', fullContent);

      // Check for tool calls (would need a non-streaming call for tool use)
      // For now, streaming just yields text content
    } catch (err) {
      this.setState('error');
      throw err;
    }

    this.setState('done');
  }

  /**
   * Reset the agent state
   */
  reset(): void {
    this.messages = [];
    this.state = {
      status: 'idle',
      iteration: 0,
      lastResponse: null,
      lastToolResult: null,
    };
  }

  /**
   * Set system prompt
   */
  setSystemPrompt(prompt: string): void {
    this.systemPrompt = prompt;
  }

  private setState(status: AgentState['status']): void {
    this.state.status = status;
    this.emit('state-change', { ...this.state });
  }
}

export default AgentLoop;
