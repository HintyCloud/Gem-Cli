/**
 * Swarm / Multi-Agent System
 * Coordinates multiple agents working together on tasks.
 */

import EventEmitter from 'eventemitter3';
import type { AgentLoop, AgentConfig } from './loop.js';
import type { ChatMessage } from '../provider/interface.js';

export type CoordinationMode = 'central' | 'mesh' | 'hierarchical';

export interface SwarmConfig {
  maxAgents: number;
  coordination: CoordinationMode;
  taskTimeout?: number;
}

export interface SwarmTask {
  id: string;
  description: string;
  assignedAgent?: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  result?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SwarmEvents {
  'task-created': (task: SwarmTask) => void;
  'task-assigned': (task: SwarmTask, agentName: string) => void;
  'task-completed': (task: SwarmTask) => void;
  'task-failed': (task: SwarmTask, error: Error) => void;
  'agent-added': (name: string) => void;
  'agent-removed': (name: string) => void;
}

export class Swarm extends EventEmitter<SwarmEvents> {
  private agents: Map<string, AgentLoop> = new Map();
  private tasks: Map<string, SwarmTask> = new Map();
  private config: SwarmConfig;
  private taskQueue: string[] = [];

  constructor(config: SwarmConfig) {
    super();
    this.config = config;
  }

  /**
   * Add an agent to the swarm
   */
  addAgent(agent: AgentLoop): void {
    if (this.agents.size >= this.config.maxAgents) {
      throw new Error(`Maximum agents reached (${this.config.maxAgents})`);
    }
    this.agents.set(agent.name, agent);
    this.emit('agent-added', agent.name);
  }

  /**
   * Remove an agent from the swarm
   */
  removeAgent(name: string): boolean {
    const result = this.agents.delete(name);
    if (result) this.emit('agent-removed', name);
    return result;
  }

  /**
   * Create a new task
   */
  createTask(description: string): SwarmTask {
    const task: SwarmTask = {
      id: `task-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      description,
      status: 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.tasks.set(task.id, task);
    this.taskQueue.push(task.id);
    this.emit('task-created', task);
    return task;
  }

  /**
   * Run all pending tasks
   */
  async runAll(toolContext?: Record<string, unknown>): Promise<SwarmTask[]> {
    const results: SwarmTask[] = [];

    while (this.taskQueue.length > 0) {
      const taskId = this.taskQueue.shift()!;
      const task = this.tasks.get(taskId);
      if (!task) continue;

      task.status = 'running';
      task.updatedAt = new Date().toISOString();

      try {
        // Select agent based on coordination mode
        const agent = this.selectAgent(task);
        if (!agent) {
          task.status = 'failed';
          task.result = 'No available agent';
          this.emit('task-failed', task, new Error('No available agent'));
          results.push(task);
          continue;
        }

        task.assignedAgent = agent.name;
        this.emit('task-assigned', task, agent.name);

        // Execute task
        const messages = await agent.run(task.description, toolContext as any);
        const lastMsg = messages[messages.length - 1];

        task.status = 'completed';
        task.result = lastMsg?.content || '';
        task.updatedAt = new Date().toISOString();
        this.emit('task-completed', task);
      } catch (err) {
        task.status = 'failed';
        task.result = err instanceof Error ? err.message : String(err);
        task.updatedAt = new Date().toISOString();
        this.emit('task-failed', task, err instanceof Error ? err : new Error(String(err)));
      }

      results.push(task);
    }

    return results;
  }

  /**
   * Run a single task
   */
  async runTask(taskId: string, toolContext?: Record<string, unknown>): Promise<SwarmTask | null> {
    const task = this.tasks.get(taskId);
    if (!task) return null;

    task.status = 'running';
    task.updatedAt = new Date().toISOString();

    try {
      const agent = this.selectAgent(task);
      if (!agent) throw new Error('No available agent');

      task.assignedAgent = agent.name;
      this.emit('task-assigned', task, agent.name);

      const messages = await agent.run(task.description, toolContext as any);
      const lastMsg = messages[messages.length - 1];

      task.status = 'completed';
      task.result = lastMsg?.content || '';
      task.updatedAt = new Date().toISOString();
      this.emit('task-completed', task);
    } catch (err) {
      task.status = 'failed';
      task.result = err instanceof Error ? err.message : String(err);
      task.updatedAt = new Date().toISOString();
      this.emit('task-failed', task, err instanceof Error ? err : new Error(String(err)));
    }

    return task;
  }

  /**
   * Select an agent for a task based on coordination mode
   */
  private selectAgent(task: SwarmTask): AgentLoop | undefined {
    const available = Array.from(this.agents.values());
    if (available.length === 0) return undefined;

    switch (this.config.coordination) {
      case 'central': {
        // Use the first (coordinator) agent
        return available[0];
      }
      case 'mesh': {
        // Round-robin assignment
        const idx = Math.floor(Math.random() * available.length);
        return available[idx];
      }
      case 'hierarchical': {
        // Use the first agent for coordination, it may delegate
        return available[0];
      }
      default:
        return available[0];
    }
  }

  /**
   * Get all agents
   */
  getAgents(): AgentLoop[] {
    return Array.from(this.agents.values());
  }

  /**
   * Get all tasks
   */
  getTasks(): SwarmTask[] {
    return Array.from(this.tasks.values());
  }

  /**
   * Get pending tasks
   */
  getPendingTasks(): SwarmTask[] {
    return Array.from(this.tasks.values()).filter((t) => t.status === 'pending');
  }

  /**
   * Get swarm status
   */
  getStatus(): { agents: number; tasks: number; pending: number; completed: number; failed: number } {
    const allTasks = Array.from(this.tasks.values());
    return {
      agents: this.agents.size,
      tasks: allTasks.length,
      pending: allTasks.filter((t) => t.status === 'pending').length,
      completed: allTasks.filter((t) => t.status === 'completed').length,
      failed: allTasks.filter((t) => t.status === 'failed').length,
    };
  }
}

export default Swarm;
