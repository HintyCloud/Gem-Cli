/**
 * Job Queue - Background job execution system
 */

import EventEmitter from 'eventemitter3';

export type JobStatus = 'queued' | 'running' | 'completed' | 'failed' | 'cancelled';

export interface Job {
  id: string;
  name: string;
  type: string;
  payload: Record<string, unknown>;
  status: JobStatus;
  result?: unknown;
  error?: string;
  progress?: number;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
}

export interface JobEvents {
  'job-queued': (job: Job) => void;
  'job-started': (job: Job) => void;
  'job-progress': (job: Job, progress: number) => void;
  'job-completed': (job: Job) => void;
  'job-failed': (job: Job, error: Error) => void;
  'job-cancelled': (job: Job) => void;
}

export type JobHandler = (
  job: Job,
  updateProgress: (progress: number) => void,
) => Promise<unknown>;

export class JobQueue extends EventEmitter<JobEvents> {
  private jobs: Map<string, Job> = new Map();
  private handlers: Map<string, JobHandler> = new Map();
  private queue: string[] = [];
  private activeJobs: Set<string> = new Set();
  private maxConcurrency: number;
  private running: boolean = false;

  constructor(maxConcurrency = 3) {
    super();
    this.maxConcurrency = maxConcurrency;
  }

  /**
   * Register a handler for a job type
   */
  registerHandler(type: string, handler: JobHandler): void {
    this.handlers.set(type, handler);
  }

  /**
   * Enqueue a new job
   */
  enqueue(name: string, type: string, payload: Record<string, unknown> = {}): Job {
    const job: Job = {
      id: `job-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      name,
      type,
      payload,
      status: 'queued',
      createdAt: new Date().toISOString(),
    };

    this.jobs.set(job.id, job);
    this.queue.push(job.id);
    this.emit('job-queued', job);

    // Auto-process if running
    if (this.running) {
      this.processQueue();
    }

    return job;
  }

  /**
   * Start processing the queue
   */
  start(): void {
    this.running = true;
    this.processQueue();
  }

  /**
   * Stop processing (waits for active jobs to complete)
   */
  stop(): void {
    this.running = false;
  }

  /**
   * Process the job queue
   */
  private async processQueue(): Promise<void> {
    while (
      this.running &&
      this.queue.length > 0 &&
      this.activeJobs.size < this.maxConcurrency
    ) {
      const jobId = this.queue.shift()!;
      const job = this.jobs.get(jobId);
      if (!job || job.status === 'cancelled') continue;

      this.executeJob(job).catch(() => {
        // Error handled in executeJob
      });
    }
  }

  /**
   * Execute a single job
   */
  private async executeJob(job: Job): Promise<void> {
    const handler = this.handlers.get(job.type);
    if (!handler) {
      job.status = 'failed';
      job.error = `No handler for job type: ${job.type}`;
      job.completedAt = new Date().toISOString();
      this.emit('job-failed', job, new Error(job.error));
      return;
    }

    this.activeJobs.add(job.id);
    job.status = 'running';
    job.startedAt = new Date().toISOString();
    this.emit('job-started', job);

    const updateProgress = (progress: number) => {
      job.progress = Math.min(1, Math.max(0, progress));
      this.emit('job-progress', job, job.progress);
    };

    try {
      const result = await handler(job, updateProgress);
      job.status = 'completed';
      job.result = result;
      job.completedAt = new Date().toISOString();
      this.emit('job-completed', job);
    } catch (err) {
      job.status = 'failed';
      job.error = err instanceof Error ? err.message : String(err);
      job.completedAt = new Date().toISOString();
      this.emit('job-failed', job, err instanceof Error ? err : new Error(String(err)));
    } finally {
      this.activeJobs.delete(job.id);
      // Continue processing
      if (this.running) {
        this.processQueue();
      }
    }
  }

  /**
   * Cancel a job
   */
  cancel(jobId: string): boolean {
    const job = this.jobs.get(jobId);
    if (!job || job.status === 'running' || job.status === 'completed') {
      return false;
    }
    job.status = 'cancelled';
    job.completedAt = new Date().toISOString();
    this.emit('job-cancelled', job);
    return true;
  }

  /**
   * Get a job by ID
   */
  get(jobId: string): Job | undefined {
    return this.jobs.get(jobId);
  }

  /**
   * List all jobs
   */
  list(): Job[] {
    return Array.from(this.jobs.values());
  }

  /**
   * List jobs by status
   */
  listByStatus(status: JobStatus): Job[] {
    return Array.from(this.jobs.values()).filter((j) => j.status === status);
  }

  /**
   * Get queue statistics
   */
  getStats(): { total: number; queued: number; running: number; completed: number; failed: number } {
    const all = Array.from(this.jobs.values());
    return {
      total: all.length,
      queued: all.filter((j) => j.status === 'queued').length,
      running: all.filter((j) => j.status === 'running').length,
      completed: all.filter((j) => j.status === 'completed').length,
      failed: all.filter((j) => j.status === 'failed').length,
    };
  }

  /**
   * Clear completed and failed jobs
   */
  clear(): number {
    let count = 0;
    for (const [id, job] of this.jobs) {
      if (job.status === 'completed' || job.status === 'failed' || job.status === 'cancelled') {
        this.jobs.delete(id);
        count++;
      }
    }
    return count;
  }
}

export default JobQueue;
