/**
 * Platform Detection Module
 */
export {
  detectPlatform,
  detectOS,
  detectShell,
  formatPlatformInfo,
  type PlatformInfo,
  type OSType,
  type ShellType,
} from './detect.js';
