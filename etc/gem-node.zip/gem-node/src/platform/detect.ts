/**
 * Platform Detection for Gem CLI
 * Detects OS, shell, environment capabilities, and runtime info.
 */

export type OSType = 'linux' | 'macos' | 'windows' | 'wsl' | 'unknown';
export type ShellType = 'bash' | 'zsh' | 'fish' | 'powershell' | 'cmd' | 'sh' | 'unknown';

export interface PlatformInfo {
  os: OSType;
  shell: ShellType;
  arch: string;
  nodeVersion: string;
  isWSL: boolean;
  isDocker: boolean;
  homeDir: string;
  configDir: string;
  dataDir: string;
  hasGit: boolean;
  hasDocker: boolean;
  terminal: string;
  colorSupport: number;
}

/**
 * Detect the operating system type
 */
export function detectOS(): OSType {
  const platform = process.platform;
  if (platform === 'linux') {
    // Check for WSL
    try {
      const release = require('os').release().toLowerCase();
      if (release.includes('microsoft') || release.includes('wsl')) {
        return 'wsl';
      }
    } catch {
      // ignore
    }
    return 'linux';
  }
  if (platform === 'darwin') return 'macos';
  if (platform === 'win32') return 'windows';
  return 'unknown';
}

/**
 * Detect the current shell
 */
export function detectShell(): ShellType {
  const os = detectOS();
  if (os === 'windows') {
    const psModule = process.env.PSModulePath;
    if (psModule) return 'powershell';
    return 'cmd';
  }

  const shell = process.env.SHELL || '';
  if (shell.includes('zsh')) return 'zsh';
  if (shell.includes('fish')) return 'fish';
  if (shell.includes('bash')) return 'bash';
  if (shell.includes('sh')) return 'sh';
  return 'unknown';
}

/**
 * Check if a command is available in PATH
 */
function hasCommand(cmd: string): boolean {
  const { execSync } = require('child_process');
  try {
    const os = detectOS();
    const checkCmd = os === 'windows' ? `where ${cmd}` : `which ${cmd}`;
    execSync(checkCmd, { stdio: 'pipe' });
    return true;
  } catch {
    return false;
  }
}

/**
 * Check if running inside Docker
 */
function isDockerEnv(): boolean {
  try {
    const fs = require('fs');
    if (fs.existsSync('/.dockerenv')) return true;
    const cgroup = fs.readFileSync('/proc/1/cgroup', 'utf8');
    return cgroup.includes('docker');
  } catch {
    return false;
  }
}

/**
 * Get XDG-style config directory
 */
function getConfigDir(os: OSType): string {
  const path = require('path');
  const home = require('os').homedir();

  if (os === 'windows') {
    return process.env.APPDATA
      ? path.join(process.env.APPDATA, 'gem')
      : path.join(home, 'AppData', 'Roaming', 'gem');
  }

  const xdgConfig = process.env.XDG_CONFIG_HOME;
  return xdgConfig
    ? path.join(xdgConfig, 'gem')
    : path.join(home, '.config', 'gem');
}

/**
 * Get XDG-style data directory
 */
function getDataDir(os: OSType): string {
  const path = require('path');
  const home = require('os').homedir();

  if (os === 'windows') {
    return process.env.LOCALAPPDATA
      ? path.join(process.env.LOCALAPPDATA, 'gem')
      : path.join(home, 'AppData', 'Local', 'gem');
  }

  const xdgData = process.env.XDG_DATA_HOME;
  return xdgData
    ? path.join(xdgData, 'gem')
    : path.join(home, '.local', 'share', 'gem');
}

/**
 * Detect color support level
 */
function detectColorSupport(): number {
  const term = process.env.TERM || '';
  const colorterm = process.env.COLORTERM || '';

  if (colorterm === 'truecolor' || colorterm === '24bit') return 24;
  if (term.includes('256color')) return 256;
  if (process.stdout.isTTY) return 16;
  return 0;
}

/**
 * Get full platform information
 */
export function detectPlatform(): PlatformInfo {
  const os = detectOS();
  const shell = detectShell();
  const osModule = require('os');
  const path = require('path');

  return {
    os,
    shell,
    arch: process.arch,
    nodeVersion: process.version,
    isWSL: os === 'wsl',
    isDocker: isDockerEnv(),
    homeDir: osModule.homedir(),
    configDir: getConfigDir(os),
    dataDir: getDataDir(os),
    hasGit: hasCommand('git'),
    hasDocker: hasCommand('docker'),
    terminal: process.env.TERM_PROGRAM || process.env.TERM || 'unknown',
    colorSupport: detectColorSupport(),
  };
}

/**
 * Format platform info as a display string
 */
export function formatPlatformInfo(info: PlatformInfo): string {
  const lines: string[] = [
    `OS:         ${info.os}${info.isWSL ? ' (WSL)' : ''}`,
    `Shell:      ${info.shell}`,
    `Arch:       ${info.arch}`,
    `Node:       ${info.nodeVersion}`,
    `Terminal:   ${info.terminal}`,
    `Color:      ${info.colorSupport}-bit`,
    `Config:     ${info.configDir}`,
    `Data:       ${info.dataDir}`,
    `Git:        ${info.hasGit ? '✓' : '✗'}`,
    `Docker:     ${info.hasDocker ? '✓' : '✗'}`,
    `Docker Env: ${info.isDocker ? 'yes' : 'no'}`,
  ];
  return lines.join('\n');
}

export default {
  detectPlatform,
  detectOS,
  detectShell,
  formatPlatformInfo,
};
