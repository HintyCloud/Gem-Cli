/**
 * Tool Interface
 * Defines the contract for tools that agents can use.
 */

export interface ToolParameter {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'array' | 'object';
  description: string;
  required?: boolean;
  enum?: string[];
  default?: unknown;
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: ToolParameter[];
  category: string;
  dangerous?: boolean;
}

export interface ToolResult {
  success: boolean;
  output: string;
  error?: string;
  metadata?: Record<string, unknown>;
}

export interface ToolContext {
  workingDir: string;
  env: Record<string, string>;
  timeout?: number;
  verbose?: boolean;
  // Allow tools to request confirmation for dangerous operations
  confirm?: (message: string) => Promise<boolean>;
}

/**
 * Tool interface - all tools must implement this
 */
export interface ITool {
  readonly definition: ToolDefinition;

  /**
   * Execute the tool with given arguments
   */
  execute(args: Record<string, unknown>, context: ToolContext): Promise<ToolResult>;

  /**
   * Validate arguments before execution
   */
  validateArgs(args: Record<string, unknown>): { valid: boolean; errors: string[] };
}

/**
 * Base tool class with common functionality
 */
export abstract class BaseTool implements ITool {
  abstract readonly definition: ToolDefinition;

  abstract execute(args: Record<string, unknown>, context: ToolContext): Promise<ToolResult>;

  validateArgs(args: Record<string, unknown>): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    for (const param of this.definition.parameters) {
      if (param.required && !(param.name in args)) {
        errors.push(`Missing required parameter: ${param.name}`);
      }

      if (param.name in args) {
        const value = args[param.name];
        const actualType = Array.isArray(value) ? 'array' : typeof value;

        if (actualType !== param.type && value !== null && value !== undefined) {
          // Allow number strings for number params
          if (!(param.type === 'number' && typeof value === 'string' && !isNaN(Number(value)))) {
            errors.push(`Parameter "${param.name}" expected ${param.type}, got ${actualType}`);
          }
        }

        if (param.enum && !param.enum.includes(String(value))) {
          errors.push(`Parameter "${param.name}" must be one of: ${param.enum.join(', ')}`);
        }
      }
    }

    return { valid: errors.length === 0, errors };
  }

  /**
   * Convert tool definition to OpenAI function calling format
   */
  toOpenAIFormat(): Record<string, unknown> {
    const properties: Record<string, unknown> = {};
    const required: string[] = [];

    for (const param of this.definition.parameters) {
      properties[param.name] = {
        type: param.type,
        description: param.description,
        ...(param.enum ? { enum: param.enum } : {}),
      };
      if (param.required) {
        required.push(param.name);
      }
    }

    return {
      type: 'function',
      function: {
        name: this.definition.name,
        description: this.definition.description,
        parameters: {
          type: 'object',
          properties,
          required,
        },
      },
    };
  }
}
