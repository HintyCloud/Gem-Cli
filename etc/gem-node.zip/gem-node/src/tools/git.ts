/**
 * Git Tool - Git version control operations
 */

import { BaseTool, type ToolDefinition, type ToolResult, type ToolContext } from './interface.js';
import { exec } from 'node:child_process';
import * as path from 'node:path';

export class GitTool extends BaseTool {
  readonly definition: ToolDefinition = {
    name: 'git',
    description: 'Execute git operations: status, log, diff, add, commit, branch, etc.',
    category: 'version-control',
    parameters: [
      {
        name: 'action',
        type: 'string',
        description: 'Git action: status, log, diff, add, commit, branch, checkout, pull, push, stash, remote, init',
        required: true,
        enum: ['status', 'log', 'diff', 'add', 'commit', 'branch', 'checkout', 'pull', 'push', 'stash', 'remote', 'init'],
      },
      {
        name: 'args',
        type: 'string',
        description: 'Additional arguments for the git command',
        required: false,
      },
    ],
  };

  async execute(args: Record<string, unknown>, context: ToolContext): Promise<ToolResult> {
    const action = args.action as string;
    const extraArgs = (args.args as string) || '';
    const cwd = context.workingDir;

    try {
      const gitCommand = this.buildCommand(action, extraArgs);
      const result = await this.runGit(gitCommand, cwd);

      return {
        success: result.code === 0,
        output: result.stdout || result.stderr,
        metadata: { action, exitCode: result.code },
      };
    } catch (err) {
      return {
        success: false,
        output: '',
        error: err instanceof Error ? err.message : String(err),
      };
    }
  }

  private buildCommand(action: string, extraArgs: string): string {
    const commands: Record<string, string> = {
      status: 'git status --porcelain',
      log: 'git log --oneline -20',
      diff: 'git diff',
      add: `git add ${extraArgs || '.'}`,
      commit: `git commit ${extraArgs ? `-m "${extraArgs}"` : ''}`,
      branch: 'git branch -a',
      checkout: `git checkout ${extraArgs}`,
      pull: 'git pull',
      push: `git push ${extraArgs}`,
      stash: `git stash ${extraArgs}`,
      remote: 'git remote -v',
      init: 'git init',
    };
    return commands[action] || `git ${action} ${extraArgs}`;
  }

  private runGit(command: string, cwd: string): Promise<{ stdout: string; stderr: string; code: number }> {
    return new Promise((resolve) => {
      exec(command, { cwd, timeout: 30000 }, (error, stdout, stderr) => {
        resolve({
          stdout: stdout || '',
          stderr: stderr || '',
          code: error ? 1 : 0,
        });
      });
    });
  }
}
