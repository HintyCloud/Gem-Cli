/**
 * Web Tool - HTTP requests and web operations
 */

import { BaseTool, type ToolDefinition, type ToolResult, type ToolContext } from './interface.js';

export class WebTool extends BaseTool {
  readonly definition: ToolDefinition = {
    name: 'web',
    description: 'Make HTTP requests, fetch URLs, and search the web',
    category: 'network',
    parameters: [
      {
        name: 'action',
        type: 'string',
        description: 'Action: fetch, get, post, put, delete, head',
        required: true,
        enum: ['fetch', 'get', 'post', 'put', 'delete', 'head'],
      },
      {
        name: 'url',
        type: 'string',
        description: 'URL to request',
        required: true,
      },
      {
        name: 'headers',
        type: 'object',
        description: 'HTTP headers as key-value pairs',
        required: false,
      },
      {
        name: 'body',
        type: 'string',
        description: 'Request body (for POST/PUT)',
        required: false,
      },
      {
        name: 'timeout',
        type: 'number',
        description: 'Request timeout in milliseconds (default: 30000)',
        required: false,
      },
    ],
  };

  async execute(args: Record<string, unknown>, context: ToolContext): Promise<ToolResult> {
    const action = args.action as string;
    const url = args.url as string;
    const headers = (args.headers as Record<string, string>) || {};
    const timeout = (args.timeout as number) || context.timeout || 30000;

    try {
      const method = action === 'fetch' ? 'GET' : action.toUpperCase();
      const fetchOptions: RequestInit = {
        method,
        headers: {
          'User-Agent': 'GemCLI/1.0.0',
          ...headers,
        },
        signal: AbortSignal.timeout(timeout),
      };

      if (args.body && (method === 'POST' || method === 'PUT')) {
        fetchOptions.body = args.body as string;
        if (!(headers as Record<string, string>)['Content-Type']) {
          (fetchOptions.headers as Record<string, string>)['Content-Type'] = 'application/json';
        }
      }

      const response = await fetch(url, fetchOptions);
      const contentType = response.headers.get('content-type') || '';
      let output: string;

      if (contentType.includes('json')) {
        const json = await response.json();
        output = JSON.stringify(json, null, 2);
      } else {
        output = await response.text();
      }

      // Truncate very long responses
      const maxLen = 50000;
      if (output.length > maxLen) {
        output = output.slice(0, maxLen) + '\n... [truncated]';
      }

      return {
        success: response.ok,
        output,
        metadata: {
          status: response.status,
          statusText: response.statusText,
          contentType,
          url,
        },
      };
    } catch (err) {
      return {
        success: false,
        output: '',
        error: err instanceof Error ? err.message : String(err),
      };
    }
  }
}
