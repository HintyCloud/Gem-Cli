/**
 * Tool Registry
 * Manages tool registration, lookup, and execution.
 */

import type { ITool, ToolDefinition, ToolResult, ToolContext } from './interface.js';
import type { ProviderToolDefinition } from '../provider/interface.js';

export class ToolRegistry {
  private tools: Map<string, ITool> = new Map();
  private enabledTools: Set<string> = new Set();

  /**
   * Register a tool
   */
  register(tool: ITool, enabled = true): void {
    this.tools.set(tool.definition.name, tool);
    if (enabled) {
      this.enabledTools.add(tool.definition.name);
    }
  }

  /**
   * Unregister a tool
   */
  unregister(name: string): boolean {
    this.enabledTools.delete(name);
    return this.tools.delete(name);
  }

  /**
   * Get a tool by name
   */
  get(name: string): ITool | undefined {
    return this.tools.get(name);
  }

  /**
   * Check if a tool is registered and enabled
   */
  isEnabled(name: string): boolean {
    return this.enabledTools.has(name);
  }

  /**
   * Enable or disable a tool
   */
  setEnabled(name: string, enabled: boolean): void {
    if (enabled) {
      this.enabledTools.add(name);
    } else {
      this.enabledTools.delete(name);
    }
  }

  /**
   * List all registered tools
   */
  listAll(): ITool[] {
    return Array.from(this.tools.values());
  }

  /**
   * List only enabled tools
   */
  listEnabled(): ITool[] {
    return Array.from(this.tools.values()).filter((t) =>
      this.enabledTools.has(t.definition.name),
    );
  }

  /**
   * Get definitions for enabled tools
   */
  getEnabledDefinitions(): ToolDefinition[] {
    return this.listEnabled().map((t) => t.definition);
  }

  /**
   * Get tool definitions in OpenAI function calling format
   */
  getOpenAITools(): ProviderToolDefinition[] {
    return this.listEnabled().map((t) => ({
      name: t.definition.name,
      description: t.definition.description,
      parameters: this.toolToOpenAIParams(t),
    }));
  }

  /**
   * Execute a tool by name
   */
  async execute(
    name: string,
    args: Record<string, unknown>,
    context: ToolContext,
  ): Promise<ToolResult> {
    const tool = this.tools.get(name);
    if (!tool) {
      return {
        success: false,
        output: '',
        error: `Tool not found: ${name}`,
      };
    }

    if (!this.enabledTools.has(name)) {
      return {
        success: false,
        output: '',
        error: `Tool is disabled: ${name}`,
      };
    }

    // Validate arguments
    const { valid, errors } = tool.validateArgs(args);
    if (!valid) {
      return {
        success: false,
        output: '',
        error: `Invalid arguments: ${errors.join(', ')}`,
      };
    }

    return tool.execute(args, context);
  }

  /**
   * List tools by category
   */
  listByCategory(category: string): ITool[] {
    return Array.from(this.tools.values()).filter(
      (t) => t.definition.category === category,
    );
  }

  /**
   * Get categories
   */
  getCategories(): string[] {
    const categories = new Set<string>();
    for (const tool of this.tools.values()) {
      categories.add(tool.definition.category);
    }
    return Array.from(categories);
  }

  private toolToOpenAIParams(tool: ITool): Record<string, unknown> {
    const properties: Record<string, unknown> = {};
    const required: string[] = [];

    for (const param of tool.definition.parameters) {
      properties[param.name] = {
        type: param.type,
        description: param.description,
        ...(param.enum ? { enum: param.enum } : {}),
      };
      if (param.required) {
        required.push(param.name);
      }
    }

    return {
      type: 'object',
      properties,
      required,
    };
  }
}

/**
 * Create a default tool registry with all built-in tools
 */
export function createDefaultRegistry(enabledNames?: string[]): ToolRegistry {
  const registry = new ToolRegistry();

  // Import and register all built-in tools
  // We do dynamic imports to avoid circular dependencies
  const { ShellTool } = require('./shell.js') as { ShellTool: new () => ITool };
  const { FilesTool } = require('./files.js') as { FilesTool: new () => ITool };
  const { WebTool } = require('./web.js') as { WebTool: new () => ITool };
  const { ImageTool } = require('./image.js') as { ImageTool: new () => ITool };
  const { GitTool } = require('./git.js') as { GitTool: new () => ITool };
  const { ArchiveTool } = require('./archive.js') as { ArchiveTool: new () => ITool };
  const { ArtifactsTool } = require('./artifacts.js') as { ArtifactsTool: new () => ITool };

  const allTools: ITool[] = [
    new ShellTool(),
    new FilesTool(),
    new WebTool(),
    new ImageTool(),
    new GitTool(),
    new ArchiveTool(),
    new ArtifactsTool(),
  ];

  for (const tool of allTools) {
    const enabled = enabledNames ? enabledNames.includes(tool.definition.name) : true;
    registry.register(tool, enabled);
  }

  return registry;
}

export default ToolRegistry;
