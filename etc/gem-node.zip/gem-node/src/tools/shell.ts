/**
 * Shell Tool - Execute shell commands
 */

import { BaseTool, type ToolDefinition, type ToolResult, type ToolContext } from './interface.js';
import { exec } from 'node:child_process';
import * as path from 'node:path';

export class ShellTool extends BaseTool {
  readonly definition: ToolDefinition = {
    name: 'shell',
    description: 'Execute a shell command and return the output',
    category: 'system',
    dangerous: true,
    parameters: [
      {
        name: 'command',
        type: 'string',
        description: 'The shell command to execute',
        required: true,
      },
      {
        name: 'cwd',
        type: 'string',
        description: 'Working directory for the command (defaults to current directory)',
        required: false,
      },
      {
        name: 'timeout',
        type: 'number',
        description: 'Timeout in milliseconds (default: 30000)',
        required: false,
      },
    ],
  };

  async execute(args: Record<string, unknown>, context: ToolContext): Promise<ToolResult> {
    const command = args.command as string;
    const cwd = (args.cwd as string) || context.workingDir;
    const timeout = (args.timeout as number) || context.timeout || 30000;

    try {
      const result = await new Promise<{ stdout: string; stderr: string; code: number }>(
        (resolve, reject) => {
          const proc = exec(
            command,
            {
              cwd: path.resolve(cwd),
              env: { ...process.env, ...context.env },
              timeout,
              maxBuffer: 1024 * 1024 * 10, // 10MB
            },
            (error, stdout, stderr) => {
              resolve({
                stdout: stdout || '',
                stderr: stderr || '',
                code: error ? (error.code as number) || 1 : 0,
              });
            },
          );

          // Handle timeout
          setTimeout(() => {
            if (!proc.killed) {
              proc.kill('SIGTERM');
            }
          }, timeout);
        },
      );

      const output = result.stdout || result.stderr;
      return {
        success: result.code === 0,
        output: output.trim(),
        metadata: {
          exitCode: result.code,
          cwd,
          command,
        },
      };
    } catch (err) {
      return {
        success: false,
        output: '',
        error: err instanceof Error ? err.message : String(err),
      };
    }
  }
}
