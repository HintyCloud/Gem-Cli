/**
 * Files Tool - Read, write, list, and manage files
 */

import { BaseTool, type ToolDefinition, type ToolResult, type ToolContext } from './interface.js';
import * as fs from 'node:fs/promises';
import * as path from 'node:path';

export class FilesTool extends BaseTool {
  readonly definition: ToolDefinition = {
    name: 'files',
    description: 'Read, write, list, delete, and manage files and directories',
    category: 'filesystem',
    parameters: [
      {
        name: 'action',
        type: 'string',
        description: 'Action to perform: read, write, list, delete, exists, mkdir, copy, move, stat',
        required: true,
        enum: ['read', 'write', 'list', 'delete', 'exists', 'mkdir', 'copy', 'move', 'stat'],
      },
      {
        name: 'path',
        type: 'string',
        description: 'File or directory path',
        required: true,
      },
      {
        name: 'content',
        type: 'string',
        description: 'Content to write (for write action)',
        required: false,
      },
      {
        name: 'destination',
        type: 'string',
        description: 'Destination path (for copy/move actions)',
        required: false,
      },
      {
        name: 'recursive',
        type: 'boolean',
        description: 'Recursive operation (for list/delete/mkdir)',
        required: false,
      },
    ],
  };

  async execute(args: Record<string, unknown>, context: ToolContext): Promise<ToolResult> {
    const action = args.action as string;
    const filePath = path.resolve(context.workingDir, args.path as string);

    try {
      switch (action) {
        case 'read':
          return await this.readFile(filePath);
        case 'write':
          return await this.writeFile(filePath, args.content as string);
        case 'list':
          return await this.listDir(filePath, args.recursive as boolean);
        case 'delete':
          return await this.deletePath(filePath);
        case 'exists':
          return await this.existsPath(filePath);
        case 'mkdir':
          return await this.makeDir(filePath);
        case 'copy':
          return await this.copyPath(filePath, path.resolve(context.workingDir, args.destination as string));
        case 'move':
          return await this.movePath(filePath, path.resolve(context.workingDir, args.destination as string));
        case 'stat':
          return await this.statPath(filePath);
        default:
          return { success: false, output: '', error: `Unknown action: ${action}` };
      }
    } catch (err) {
      return {
        success: false,
        output: '',
        error: err instanceof Error ? err.message : String(err),
      };
    }
  }

  private async readFile(filePath: string): Promise<ToolResult> {
    const content = await fs.readFile(filePath, 'utf-8');
    return { success: true, output: content, metadata: { path: filePath } };
  }

  private async writeFile(filePath: string, content: string): Promise<ToolResult> {
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, content, 'utf-8');
    return { success: true, output: `Written ${content.length} bytes to ${filePath}`, metadata: { path: filePath, bytes: content.length } };
  }

  private async listDir(dirPath: string, recursive?: boolean): Promise<ToolResult> {
    const entries = await fs.readdir(dirPath, { withFileTypes: true, recursive });
    const lines = entries.map((e) => `${e.isDirectory() ? '📁' : '📄'} ${e.name}`);
    return { success: true, output: lines.join('\n'), metadata: { count: entries.length } };
  }

  private async deletePath(filePath: string): Promise<ToolResult> {
    await fs.rm(filePath, { recursive: true, force: true });
    return { success: true, output: `Deleted: ${filePath}` };
  }

  private async existsPath(filePath: string): Promise<ToolResult> {
    const exists = await fs.access(filePath).then(() => true).catch(() => false);
    return { success: true, output: exists ? 'exists' : 'not found', metadata: { exists } };
  }

  private async makeDir(dirPath: string): Promise<ToolResult> {
    await fs.mkdir(dirPath, { recursive: true });
    return { success: true, output: `Created directory: ${dirPath}` };
  }

  private async copyPath(src: string, dest: string): Promise<ToolResult> {
    await fs.mkdir(path.dirname(dest), { recursive: true });
    await fs.copyFile(src, dest);
    return { success: true, output: `Copied: ${src} → ${dest}` };
  }

  private async movePath(src: string, dest: string): Promise<ToolResult> {
    await fs.mkdir(path.dirname(dest), { recursive: true });
    await fs.rename(src, dest);
    return { success: true, output: `Moved: ${src} → ${dest}` };
  }

  private async statPath(filePath: string): Promise<ToolResult> {
    const stat = await fs.stat(filePath);
    const info = [
      `Size: ${stat.size} bytes`,
      `Modified: ${stat.mtime.toISOString()}`,
      `Type: ${stat.isDirectory() ? 'directory' : 'file'}`,
      `Permissions: ${stat.mode.toString(8).slice(-3)}`,
    ].join('\n');
    return { success: true, output: info, metadata: { size: stat.size, modified: stat.mtime.toISOString() } };
  }
}
