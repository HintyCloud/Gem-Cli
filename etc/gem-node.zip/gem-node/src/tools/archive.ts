/**
 * Archive Tool - Create and extract archives (zip, tar, gzip)
 */

import { BaseTool, type ToolDefinition, type ToolResult, type ToolContext } from './interface.js';
import { exec } from 'node:child_process';
import * as path from 'node:path';

export class ArchiveTool extends BaseTool {
  readonly definition: ToolDefinition = {
    name: 'archive',
    description: 'Create and extract archives: zip, tar, tar.gz, tar.bz2',
    category: 'filesystem',
    parameters: [
      {
        name: 'action',
        type: 'string',
        description: 'Action: create or extract',
        required: true,
        enum: ['create', 'extract'],
      },
      {
        name: 'archive',
        type: 'string',
        description: 'Archive file path',
        required: true,
      },
      {
        name: 'target',
        type: 'string',
        description: 'Target path (files to archive or extraction directory)',
        required: true,
      },
      {
        name: 'format',
        type: 'string',
        description: 'Archive format: zip, tar, tar.gz, tar.bz2',
        required: false,
        enum: ['zip', 'tar', 'tar.gz', 'tar.bz2'],
      },
    ],
  };

  async execute(args: Record<string, unknown>, context: ToolContext): Promise<ToolResult> {
    const action = args.action as string;
    const archive = path.resolve(context.workingDir, args.archive as string);
    const target = path.resolve(context.workingDir, args.target as string);
    const format = (args.format as string) || this.detectFormat(archive);

    try {
      let command: string;

      if (action === 'create') {
        command = this.createCommand(format, archive, target);
      } else {
        command = this.extractCommand(format, archive, target);
      }

      const result = await new Promise<{ stdout: string; stderr: string; code: number }>(
        (resolve) => {
          exec(command, { cwd: context.workingDir, timeout: 60000 }, (error, stdout, stderr) => {
            resolve({
              stdout: stdout || '',
              stderr: stderr || '',
              code: error ? 1 : 0,
            });
          });
        },
      );

      return {
        success: result.code === 0,
        output: result.stdout || result.stderr || `Archive ${action}d successfully`,
        metadata: { action, format, archive, target },
      };
    } catch (err) {
      return {
        success: false,
        output: '',
        error: err instanceof Error ? err.message : String(err),
      };
    }
  }

  private detectFormat(archivePath: string): string {
    if (archivePath.endsWith('.zip')) return 'zip';
    if (archivePath.endsWith('.tar.gz') || archivePath.endsWith('.tgz')) return 'tar.gz';
    if (archivePath.endsWith('.tar.bz2')) return 'tar.bz2';
    if (archivePath.endsWith('.tar')) return 'tar';
    return 'tar.gz';
  }

  private createCommand(format: string, archive: string, target: string): string {
    switch (format) {
      case 'zip': return `zip -r "${archive}" "${target}"`;
      case 'tar': return `tar cf "${archive}" "${target}"`;
      case 'tar.gz': return `tar czf "${archive}" "${target}"`;
      case 'tar.bz2': return `tar cjf "${archive}" "${target}"`;
      default: return `tar czf "${archive}" "${target}"`;
    }
  }

  private extractCommand(format: string, archive: string, target: string): string {
    switch (format) {
      case 'zip': return `unzip -o "${archive}" -d "${target}"`;
      case 'tar': return `tar xf "${archive}" -C "${target}"`;
      case 'tar.gz': return `tar xzf "${archive}" -C "${target}"`;
      case 'tar.bz2': return `tar xjf "${archive}" -C "${target}"`;
      default: return `tar xzf "${archive}" -C "${target}"`;
    }
  }
}
