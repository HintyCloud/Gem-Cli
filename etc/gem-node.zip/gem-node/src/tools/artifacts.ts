/**
 * Artifacts Tool - Create and manage code artifacts (documents, diagrams, etc.)
 */

import { BaseTool, type ToolDefinition, type ToolResult, type ToolContext } from './interface.js';
import * as fs from 'node:fs/promises';
import * as path from 'node:path';

interface Artifact {
  id: string;
  type: string;
  title: string;
  content: string;
  createdAt: string;
}

export class ArtifactsTool extends BaseTool {
  readonly definition: ToolDefinition = {
    name: 'artifacts',
    description: 'Create and manage code artifacts: documents, diagrams, and generated content',
    category: 'generation',
    parameters: [
      {
        name: 'action',
        type: 'string',
        description: 'Action: create, list, read, update, delete, export',
        required: true,
        enum: ['create', 'list', 'read', 'update', 'delete', 'export'],
      },
      {
        name: 'type',
        type: 'string',
        description: 'Artifact type: document, code, diagram, svg, html, mermaid',
        required: false,
        enum: ['document', 'code', 'diagram', 'svg', 'html', 'mermaid'],
      },
      {
        name: 'title',
        type: 'string',
        description: 'Artifact title',
        required: false,
      },
      {
        name: 'content',
        type: 'string',
        description: 'Artifact content',
        required: false,
      },
      {
        name: 'id',
        type: 'string',
        description: 'Artifact ID (for read/update/delete)',
        required: false,
      },
      {
        name: 'outputPath',
        type: 'string',
        description: 'Output file path (for export)',
        required: false,
      },
    ],
  };

  private artifacts: Map<string, Artifact> = new Map();

  async execute(args: Record<string, unknown>, context: ToolContext): Promise<ToolResult> {
    const action = args.action as string;

    try {
      switch (action) {
        case 'create':
          return this.create(args);
        case 'list':
          return this.list();
        case 'read':
          return this.read(args.id as string);
        case 'update':
          return this.update(args);
        case 'delete':
          return this.delete(args.id as string);
        case 'export':
          return await this.exportArtifact(args, context);
        default:
          return { success: false, output: '', error: `Unknown action: ${action}` };
      }
    } catch (err) {
      return {
        success: false,
        output: '',
        error: err instanceof Error ? err.message : String(err),
      };
    }
  }

  private create(args: Record<string, unknown>): ToolResult {
    const id = `artifact-${Date.now()}`;
    const artifact: Artifact = {
      id,
      type: (args.type as string) || 'document',
      title: (args.title as string) || 'Untitled',
      content: (args.content as string) || '',
      createdAt: new Date().toISOString(),
    };
    this.artifacts.set(id, artifact);
    return {
      success: true,
      output: `Created artifact: ${artifact.title} (${id})`,
      metadata: { id, type: artifact.type },
    };
  }

  private list(): ToolResult {
    const items = Array.from(this.artifacts.values());
    const output = items.map((a) => `${a.id} | ${a.type} | ${a.title}`).join('\n');
    return { success: true, output: output || 'No artifacts', metadata: { count: items.length } };
  }

  private read(id: string): ToolResult {
    const artifact = this.artifacts.get(id);
    if (!artifact) return { success: false, output: '', error: `Artifact not found: ${id}` };
    return { success: true, output: artifact.content, metadata: { ...artifact } };
  }

  private update(args: Record<string, unknown>): ToolResult {
    const id = args.id as string;
    const artifact = this.artifacts.get(id);
    if (!artifact) return { success: false, output: '', error: `Artifact not found: ${id}` };
    if (args.title) artifact.title = args.title as string;
    if (args.content) artifact.content = args.content as string;
    if (args.type) artifact.type = args.type as string;
    return { success: true, output: `Updated artifact: ${id}` };
  }

  private delete(id: string): ToolResult {
    if (!this.artifacts.delete(id)) {
      return { success: false, output: '', error: `Artifact not found: ${id}` };
    }
    return { success: true, output: `Deleted artifact: ${id}` };
  }

  private async exportArtifact(args: Record<string, unknown>, context: ToolContext): Promise<ToolResult> {
    const id = args.id as string;
    const outputPath = args.outputPath as string;
    const artifact = this.artifacts.get(id);
    if (!artifact) return { success: false, output: '', error: `Artifact not found: ${id}` };

    const fullPath = path.resolve(context.workingDir, outputPath || `${artifact.title}.${this.getExtension(artifact.type)}`);
    await fs.mkdir(path.dirname(fullPath), { recursive: true });
    await fs.writeFile(fullPath, artifact.content, 'utf-8');
    return { success: true, output: `Exported to: ${fullPath}`, metadata: { path: fullPath } };
  }

  private getExtension(type: string): string {
    const extensions: Record<string, string> = {
      document: 'md', code: 'txt', diagram: 'json', svg: 'svg', html: 'html', mermaid: 'mmd',
    };
    return extensions[type] || 'txt';
  }
}
