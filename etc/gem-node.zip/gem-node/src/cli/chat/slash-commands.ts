/**
 * Slash Commands for Chat Mode
 */

import type { GemConfig } from '../../config/schema.js';
import type { ProviderRegistry } from '../../provider/index.js';
import type { ToolRegistry } from '../../tools/registry.js';
import type { MemorySystem } from '../../memory/index.js';
import type { AgentLoop } from '../../agent/loop.js';
import type { Conversation } from '../../memory/history.js';

export interface SlashCommandContext {
  config: GemConfig;
  providers: ProviderRegistry;
  tools: ToolRegistry;
  memory: MemorySystem;
  agent: AgentLoop;
  conversation: Conversation;
}

interface SlashCommand {
  name: string;
  description: string;
  handler: (args: string, ctx: SlashCommandContext) => Promise<void>;
}

const commands: SlashCommand[] = [
  {
    name: '/help',
    description: 'Show available commands',
    handler: async (_args, _ctx) => {
      console.log('\n── Slash Commands ─────────────────────');
      for (const cmd of commands) {
        console.log(`  ${cmd.name.padEnd(20)} ${cmd.description}`);
      }
      console.log('');
    },
  },
  {
    name: '/exit',
    description: 'Exit chat mode',
    handler: async () => {
      // Handled by the chat loop
    },
  },
  {
    name: '/quit',
    description: 'Exit chat mode (alias)',
    handler: async () => {},
  },
  {
    name: '/clear',
    description: 'Clear conversation history',
    handler: async (_args, ctx) => {
      ctx.memory.history.clearActive();
      ctx.agent.reset();
      console.log('Conversation cleared.');
    },
  },
  {
    name: '/model',
    description: 'Show or change model',
    handler: async (args, ctx) => {
      if (args) {
        ctx.agent.reset();
        console.log(`Model changed to: ${args}`);
      } else {
        console.log(`Current model: ${ctx.conversation.model || 'default'}`);
        const provider = ctx.providers.getDefault();
        if (provider) {
          try {
            const models = await provider.listModels();
            console.log('\nAvailable models:');
            for (const m of models) {
              console.log(`  ${m.id} — ${m.name}`);
            }
          } catch {
            console.log('  (Could not fetch model list)');
          }
        }
      }
    },
  },
  {
    name: '/provider',
    description: 'Show or change provider',
    handler: async (args, ctx) => {
      if (args) {
        const provider = ctx.providers.get(args);
        if (provider) {
          console.log(`Provider: ${provider.name} (${provider.type}) — ${provider.getDefaultModel()}`);
        } else {
          console.log(`Provider not found: ${args}`);
        }
      } else {
        const providers = ctx.providers.list();
        console.log('\nAvailable providers:');
        for (const p of providers) {
          const available = p.isAvailable() ? '✓' : '✗';
          console.log(`  ${available} ${p.name} (${p.type})`);
        }
      }
    },
  },
  {
    name: '/tools',
    description: 'List or toggle tools',
    handler: async (args, ctx) => {
      if (args.startsWith('enable ')) {
        const name = args.slice(7).trim();
        ctx.tools.setEnabled(name, true);
        console.log(`Tool "${name}" enabled.`);
      } else if (args.startsWith('disable ')) {
        const name = args.slice(8).trim();
        ctx.tools.setEnabled(name, false);
        console.log(`Tool "${name}" disabled.`);
      } else {
        const tools = ctx.tools.listAll();
        console.log('\n── Tools ─────────────────────────────');
        for (const t of tools) {
          const enabled = ctx.tools.isEnabled(t.definition.name) ? '✓' : '✗';
          console.log(`  ${enabled} ${t.definition.name} [${t.definition.category}] — ${t.definition.description}`);
        }
        console.log('');
      }
    },
  },
  {
    name: '/memory',
    description: 'Search or list memory entries',
    handler: async (args, ctx) => {
      if (args) {
        const results = ctx.memory.persistent.search(args);
        if (results.length === 0) {
          console.log('No results found.');
        } else {
          for (const entry of results) {
            console.log(`  [${entry.category}] ${entry.key}: ${entry.value.slice(0, 100)}`);
          }
        }
      } else {
        const stats = ctx.memory.persistent.getStats();
        console.log(`Memory: ${stats.total} entries, ${Object.keys(stats.categories).length} categories`);
      }
    },
  },
  {
    name: '/history',
    description: 'Show conversation history',
    handler: async (_args, ctx) => {
      const conv = ctx.memory.history.getActive();
      if (!conv || conv.entries.length === 0) {
        console.log('No conversation history.');
        return;
      }
      console.log(`\n── History (${conv.entries.length} messages) ──────`);
      for (const entry of conv.entries) {
        const icon = entry.role === 'user' ? '👤' : entry.role === 'assistant' ? '🤖' : '🔧';
        console.log(`  ${icon} ${entry.content.slice(0, 150)}${entry.content.length > 150 ? '...' : ''}`);
      }
      console.log('');
    },
  },
  {
    name: '/system',
    description: 'Set system prompt',
    handler: async (args, ctx) => {
      if (args) {
        ctx.agent.setSystemPrompt(args);
        console.log('System prompt updated.');
      } else {
        console.log('Usage: /system <prompt>');
      }
    },
  },
  {
    name: '/save',
    description: 'Save memory to disk',
    handler: async (_args, ctx) => {
      await ctx.memory.persistent.save();
      console.log('Memory saved.');
    },
  },
  {
    name: '/status',
    description: 'Show agent status',
    handler: async (_args, ctx) => {
      const state = ctx.agent.getState();
      console.log(`Agent: ${ctx.agent.name}`);
      console.log(`Status: ${state.status}`);
      console.log(`Iteration: ${state.iteration}`);
      const conv = ctx.memory.history.getActive();
      console.log(`Messages: ${conv?.entries.length || 0}`);
    },
  },
  {
    name: '/reset',
    description: 'Reset the agent',
    handler: async (_args, ctx) => {
      ctx.agent.reset();
      ctx.memory.history.clearActive();
      console.log('Agent reset.');
    },
  },
];

/**
 * Handle a slash command
 * Returns true if the command was handled, false if it should exit
 */
export async function handleSlashCommand(
  input: string,
  ctx: SlashCommandContext,
): Promise<boolean> {
  const parts = input.split(' ');
  const cmdName = parts[0].toLowerCase();
  const args = parts.slice(1).join(' ');

  const cmd = commands.find((c) => c.name === cmdName);
  if (!cmd) {
    console.log(`Unknown command: ${cmdName}. Type /help for available commands.`);
    return true;
  }

  await cmd.handler(args, ctx);
  return true;
}

export default { handleSlashCommand };
