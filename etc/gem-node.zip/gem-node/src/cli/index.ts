/**
 * CLI Module - Command registration and setup
 */

import { Command } from 'commander';
import type { GemConfig } from '../config/schema.js';
import type { ProviderRegistry } from '../provider/index.js';
import type { ToolRegistry } from '../tools/registry.js';
import type { JobQueue } from '../agent/job-queue.js';
import type { MemorySystem } from '../memory/index.js';

// Import command creators
import { createStatusCommand } from './commands/status.js';
import { createServeCommand } from './commands/serve.js';
import { createChatCommand } from './commands/chat.js';
import { createProjectCommand } from './commands/project.js';
import { createJobsCommand } from './commands/jobs.js';
import { createModelsCommand } from './commands/models.js';
import { createProvidersCommand } from './commands/providers.js';
import { createToolsCommand } from './commands/tools.js';
import { createAgentsCommand } from './commands/agents.js';

export interface CLITContext {
  config: GemConfig;
  providers: ProviderRegistry;
  tools: ToolRegistry;
  jobs: JobQueue;
  memory: MemorySystem;
}

/**
 * Create and configure the CLI program
 */
export function createCLI(ctx: CLITContext): Command {
  const program = new Command();

  program
    .name('gem')
    .description('Gem CLI — Agentic AI ecosystem by HintyCloud')
    .version('1.0.0')
    .option('-c, --config <path>', 'Path to configuration file')
    .option('-v, --verbose', 'Enable verbose output')
    .option('--no-color', 'Disable colored output');

  // Register all commands
  createStatusCommand(program, ctx);
  createServeCommand(program, ctx);
  createChatCommand(program, ctx);
  createProjectCommand(program, ctx.config);
  createJobsCommand(program, ctx.jobs);
  createModelsCommand(program, ctx.providers);
  createProvidersCommand(program, ctx.providers, ctx.config);
  createToolsCommand(program, ctx.tools);
  createAgentsCommand(program, ctx.config);

  return program;
}

/**
 * Run the CLI
 */
export async function runCLI(ctx: CLITContext): Promise<void> {
  const program = createCLI(ctx);
  await program.parseAsync(process.argv);
}

export default { createCLI, runCLI };
