/**
 * Status Command - Show system status and configuration
 */

import type { GemConfig } from '../../config/schema.js';
import type { ProviderRegistry } from '../../provider/index.js';
import type { ToolRegistry } from '../../tools/registry.js';
import type { JobQueue } from '../../agent/job-queue.js';
import { detectPlatform, formatPlatformInfo } from '../../platform/detect.js';

export interface StatusContext {
  config: GemConfig;
  providers: ProviderRegistry;
  tools: ToolRegistry;
  jobs: JobQueue;
}

export function createStatusCommand(
  program: import('commander').Command,
  ctx: StatusContext,
): void {
  program
    .command('status')
    .description('Show Gem CLI status and configuration')
    .option('-v, --verbose', 'Show detailed information')
    .action((opts) => {
      const platform = detectPlatform();

      console.log('\n═══════════════════════════════════════');
      console.log('  Gem CLI v1.0.0 — HintyCloud');
      console.log('═══════════════════════════════════════\n');

      // Platform info
      console.log('── Platform ──────────────────────────');
      console.log(formatPlatformInfo(platform));

      // Providers
      console.log('\n── Providers ─────────────────────────');
      const providers = ctx.providers.list();
      for (const p of providers) {
        const available = p.isAvailable() ? '✓' : '✗';
        console.log(`  ${available} ${p.name} (${p.type}) — model: ${p.getDefaultModel()}`);
      }

      // Tools
      console.log('\n── Tools ─────────────────────────────');
      const tools = ctx.tools.listAll();
      for (const t of tools) {
        const enabled = ctx.tools.isEnabled(t.definition.name) ? '✓' : '✗';
        const dangerous = t.definition.dangerous ? ' ⚠' : '';
        console.log(`  ${enabled} ${t.definition.name} [${t.definition.category}]${dangerous}`);
      }

      // Jobs
      if (opts.verbose) {
        console.log('\n── Jobs ──────────────────────────────');
        const stats = ctx.jobs.getStats();
        console.log(`  Total: ${stats.total} | Queued: ${stats.queued} | Running: ${stats.running} | Completed: ${stats.completed} | Failed: ${stats.failed}`);
      }

      // Config
      if (opts.verbose) {
        console.log('\n── Configuration ─────────────────────');
        console.log(`  Default Provider: ${ctx.config.defaultProvider}`);
        console.log(`  Default Model: ${ctx.config.defaultModel}`);
        console.log(`  Memory: ${ctx.config.memory.enabled ? 'enabled' : 'disabled'}`);
        console.log(`  Server: ${ctx.config.server.host}:${ctx.config.server.port}`);
        console.log(`  Swarm: ${ctx.config.swarm.enabled ? 'enabled' : 'disabled'}`);
      }

      console.log('');
    });
}
