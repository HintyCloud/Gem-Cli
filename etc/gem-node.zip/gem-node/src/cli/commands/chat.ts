/**
 * Chat Command - Interactive chat mode with slash commands
 */

import * as readline from 'node:readline';
import type { GemConfig } from '../../config/schema.js';
import type { ProviderRegistry } from '../../provider/index.js';
import type { ToolRegistry } from '../../tools/registry.js';
import type { MemorySystem } from '../../memory/index.js';
import { AgentLoop } from '../../agent/loop.js';
import { handleSlashCommand, type SlashCommandContext } from '../chat/slash-commands.js';

export interface ChatContext {
  config: GemConfig;
  providers: ProviderRegistry;
  tools: ToolRegistry;
  memory: MemorySystem;
}

export function createChatCommand(
  program: import('commander').Command,
  ctx: ChatContext,
): void {
  program
    .command('chat')
    .description('Start interactive chat mode')
    .option('-p, --provider <name>', 'Provider to use', ctx.config.defaultProvider)
    .option('-m, --model <model>', 'Model to use', ctx.config.defaultModel)
    .option('-s, --system <prompt>', 'System prompt')
    .option('--no-tools', 'Disable tool use')
    .option('--stream', 'Use streaming mode')
    .action(async (opts) => {
      await startChat(opts, ctx);
    });
}

async function startChat(
  opts: {
    provider: string;
    model: string;
    system?: string;
    tools: boolean;
    stream?: boolean;
  },
  ctx: ChatContext,
): Promise<void> {
  const provider = ctx.providers.get(opts.provider) || ctx.providers.getDefault();
  if (!provider) {
    console.error('No provider available. Check your configuration.');
    process.exit(1);
  }

  // Create conversation
  const conversation = ctx.memory.history.createConversation(
    `Chat ${new Date().toLocaleString()}`,
    opts.model,
    opts.provider,
  );

  // Create agent
  const agent = new AgentLoop({
    name: 'chat-agent',
    provider,
    toolRegistry: opts.tools ? ctx.tools : createEmptyRegistry(),
    history: ctx.memory.history,
    systemPrompt: opts.system || 'You are a helpful AI assistant called Gem.',
    model: opts.model,
    verbose: true,
  });

  // Agent event handlers
  agent.on('thinking', () => {
    // Could show a spinner
  });

  agent.on('response', (response) => {
    if (response.content) {
      console.log(`\n🤖 ${response.content}\n`);
    }
  });

  agent.on('tool-call', (name, args) => {
    console.log(`\n🔧 Tool: ${name}(${JSON.stringify(args).slice(0, 100)}...)`);
  });

  agent.on('tool-result', (name, result) => {
    const status = result.success ? '✓' : '✗';
    console.log(`  ${status} ${name}: ${result.output.slice(0, 200)}${result.output.length > 200 ? '...' : ''}`);
  });

  agent.on('error', (error) => {
    console.error(`\n❌ Error: ${error.message}\n`);
  });

  // Print header
  console.log('\n═══════════════════════════════════════');
  console.log('  Gem Chat — Interactive Mode');
  console.log(`  Provider: ${provider.name} | Model: ${opts.model}`);
  console.log('  Type /help for commands, /exit to quit');
  console.log('═══════════════════════════════════════\n');

  // Slash command context
  const slashCtx: SlashCommandContext = {
    config: ctx.config,
    providers: ctx.providers,
    tools: ctx.tools,
    memory: ctx.memory,
    agent,
    conversation,
  };

  // Readline interface
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: 'you> ',
  });

  rl.prompt();

  rl.on('line', async (line) => {
    const input = line.trim();
    if (!input) {
      rl.prompt();
      return;
    }

    // Handle slash commands
    if (input.startsWith('/')) {
      const handled = await handleSlashCommand(input, slashCtx);
      if (!handled) {
        rl.prompt();
        return;
      }
      if (input === '/exit' || input === '/quit') {
        rl.close();
        return;
      }
      rl.prompt();
      return;
    }

    // Send to agent
    try {
      if (opts.stream) {
        process.stdout.write('\n🤖 ');
        for await (const chunk of agent.runStream(input)) {
          process.stdout.write(chunk);
        }
        console.log('\n');
      } else {
        await agent.run(input, {
          workingDir: process.cwd(),
          env: {},
        });
      }
    } catch (err) {
      console.error(`\n❌ Error: ${err instanceof Error ? err.message : String(err)}\n`);
    }

    rl.prompt();
  });

  rl.on('close', async () => {
    console.log('\nGoodbye! 👋');
    await ctx.memory.shutdown();
    process.exit(0);
  });
}

/**
 * Create an empty tool registry (for --no-tools mode)
 */
function createEmptyRegistry(): import('../../tools/registry.js').ToolRegistry {
  const { ToolRegistry } = require('../../tools/registry.js');
  return new ToolRegistry();
}
