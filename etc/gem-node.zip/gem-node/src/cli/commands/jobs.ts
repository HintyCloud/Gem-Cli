/**
 * Jobs Command - Manage background jobs
 */

import type { JobQueue } from '../../agent/job-queue.js';

export function createJobsCommand(
  program: import('commander').Command,
  jobs: JobQueue,
): void {
  program
    .command('jobs')
    .description('Manage background jobs')
    .argument('[action]', 'Action: list, stats, cancel', 'list')
    .argument('[id]', 'Job ID (for cancel)')
    .action((action, id) => {
      switch (action) {
        case 'list':
          listJobs(jobs);
          break;
        case 'stats':
          showStats(jobs);
          break;
        case 'cancel':
          if (!id) {
            console.error('Job ID required for cancel');
            return;
          }
          cancelJob(jobs, id);
          break;
        default:
          console.error(`Unknown action: ${action}`);
      }
    });
}

function listJobs(jobs: JobQueue): void {
  const all = jobs.list();
  if (all.length === 0) {
    console.log('No jobs.');
    return;
  }

  console.log('\n── Jobs ──────────────────────────────');
  for (const job of all) {
    const icon =
      job.status === 'completed' ? '✓' :
      job.status === 'running' ? '⏳' :
      job.status === 'failed' ? '✗' :
      job.status === 'queued' ? '⏸' : '•';
    console.log(`  ${icon} ${job.id.slice(0, 16)}  ${job.name.padEnd(20)}  ${job.status.padEnd(10)}  ${job.type}`);
  }
  console.log('');
}

function showStats(jobs: JobQueue): void {
  const stats = jobs.getStats();
  console.log('\n── Job Statistics ─────────────────────');
  console.log(`  Total:     ${stats.total}`);
  console.log(`  Queued:    ${stats.queued}`);
  console.log(`  Running:   ${stats.running}`);
  console.log(`  Completed: ${stats.completed}`);
  console.log(`  Failed:    ${stats.failed}`);
  console.log('');
}

function cancelJob(jobs: JobQueue, id: string): void {
  const result = jobs.cancel(id);
  console.log(result ? `Job ${id} cancelled.` : `Could not cancel job ${id}.`);
}
