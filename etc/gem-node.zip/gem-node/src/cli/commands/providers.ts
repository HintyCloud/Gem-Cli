/**
 * Providers Command - Manage AI providers
 */

import type { ProviderRegistry } from '../../provider/index.js';
import type { GemConfig } from '../../config/schema.js';

export function createProvidersCommand(
  program: import('commander').Command,
  providers: ProviderRegistry,
  config: GemConfig,
): void {
  program
    .command('providers')
    .description('Manage AI providers')
    .argument('[action]', 'Action: list, test', 'list')
    .argument('[name]', 'Provider name (for test)')
    .action(async (action, name) => {
      switch (action) {
        case 'list':
          listProviders(providers, config);
          break;
        case 'test':
          await testProvider(providers, name);
          break;
        default:
          console.error(`Unknown action: ${action}`);
      }
    });
}

function listProviders(providers: ProviderRegistry, config: GemConfig): void {
  const all = providers.list();

  console.log('\n── Providers ─────────────────────────');
  for (const p of all) {
    const isDefault = p.name === config.defaultProvider;
    const available = p.isAvailable() ? '✓' : '✗';
    const marker = isDefault ? ' (default)' : '';

    console.log(`  ${available} ${p.name}${marker}`);
    console.log(`      Type: ${p.type}`);
    console.log(`      Model: ${p.getDefaultModel()}`);
    console.log(`      API Key: ${p.getMaskedApiKey()}`);
  }
  console.log('');
}

async function testProvider(providers: ProviderRegistry, name?: string): Promise<void> {
  const provider = name
    ? providers.get(name)
    : providers.getDefault();

  if (!provider) {
    console.error(`Provider not found: ${name || 'default'}`);
    return;
  }

  console.log(`Testing provider: ${provider.name}...`);

  if (!provider.isAvailable()) {
    console.error(`Provider "${provider.name}" is not available (missing API key or configuration).`);
    return;
  }

  try {
    const models = await provider.listModels();
    console.log(`✓ Connection successful! ${models.length} model(s) available.`);
    for (const model of models.slice(0, 5)) {
      console.log(`  - ${model.id}`);
    }
    if (models.length > 5) {
      console.log(`  ... and ${models.length - 5} more`);
    }
  } catch (err) {
    console.error(`✗ Connection failed: ${err instanceof Error ? err.message : String(err)}`);
  }
}
