/**
 * Models Command - List and manage AI models
 */

import type { ProviderRegistry } from '../../provider/index.js';

export function createModelsCommand(
  program: import('commander').Command,
  providers: ProviderRegistry,
): void {
  program
    .command('models')
    .description('List available AI models')
    .option('-p, --provider <name>', 'Filter by provider')
    .action(async (opts) => {
      const providerNames = opts.provider
        ? [opts.provider]
        : providers.listNames();

      console.log('\n── Available Models ──────────────────');

      for (const name of providerNames) {
        const provider = providers.get(name);
        if (!provider) {
          console.log(`  Provider "${name}" not found.`);
          continue;
        }

        console.log(`\n  ${name} (${provider.type}):`);

        if (!provider.isAvailable()) {
          console.log('    ⚠ Not configured (missing API key)');
          continue;
        }

        try {
          const models = await provider.listModels();
          for (const model of models) {
            const tools = model.supportsTools ? '🔧' : '  ';
            const vision = model.supportsVision ? '👁' : '  ';
            const stream = model.supportsStreaming ? '⚡' : '  ';
            console.log(`    ${tools}${vision}${stream} ${model.id}`);
          }
        } catch (err) {
          console.log(`    Error: ${err instanceof Error ? err.message : String(err)}`);
        }
      }

      console.log('\n  Legend: 🔧=tools 👁=vision ⚡=streaming\n');
    });
}
