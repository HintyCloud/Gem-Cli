/**
 * Serve Command - Start the HTTP API server
 */

import type { GemConfig } from '../../config/schema.js';
import type { ProviderRegistry } from '../../provider/index.js';
import type { ToolRegistry } from '../../tools/registry.js';
import type { JobQueue } from '../../agent/job-queue.js';
import type { MemorySystem } from '../../memory/index.js';
import { GemServer } from '../../server/index.js';

export interface ServeContext {
  config: GemConfig;
  providers: ProviderRegistry;
  tools: ToolRegistry;
  jobs: JobQueue;
  memory: MemorySystem;
}

export function createServeCommand(
  program: import('commander').Command,
  ctx: ServeContext,
): void {
  program
    .command('serve')
    .description('Start the Gem HTTP API server')
    .option('-p, --port <port>', 'Server port', String(ctx.config.server.port))
    .option('-h, --host <host>', 'Server host', ctx.config.server.host)
    .option('--no-cors', 'Disable CORS')
    .option('--api-key <key>', 'API key for authentication')
    .action(async (opts) => {
      const serverConfig = {
        host: opts.host || ctx.config.server.host,
        port: parseInt(opts.port, 10) || ctx.config.server.port,
        cors: opts.cors !== false,
        apiKey: opts.apiKey || ctx.config.server.apiKey,
      };

      console.log(`Starting Gem API server on ${serverConfig.host}:${serverConfig.port}...`);

      const server = new GemServer(serverConfig, ctx);

      try {
        await server.start();
        console.log('Server is running. Press Ctrl+C to stop.');

        // Graceful shutdown
        const shutdown = async () => {
          console.log('\nShutting down server...');
          await server.stop();
          await ctx.memory.shutdown();
          process.exit(0);
        };

        process.on('SIGINT', shutdown);
        process.on('SIGTERM', shutdown);
      } catch (err) {
        console.error(`Failed to start server: ${err instanceof Error ? err.message : String(err)}`);
        process.exit(1);
      }
    });
}
