/**
 * Agents Command - Manage agents and swarm
 */

import type { GemConfig } from '../../config/schema.js';

export function createAgentsCommand(
  program: import('commander').Command,
  config: GemConfig,
): void {
  program
    .command('agents')
    .description('Manage agents and swarm configuration')
    .argument('[action]', 'Action: list, info', 'list')
    .argument('[name]', 'Agent name (for info)')
    .action((action, name) => {
      switch (action) {
        case 'list':
          listAgents(config);
          break;
        case 'info':
          showAgentInfo(config, name);
          break;
        default:
          console.error(`Unknown action: ${action}`);
      }
    });
}

function listAgents(config: GemConfig): void {
  console.log('\n── Agents ────────────────────────────');
  for (const agent of config.agents) {
    console.log(`  • ${agent.name}`);
    console.log(`      Provider: ${agent.provider}`);
    console.log(`      Model: ${agent.model || 'default'}`);
    console.log(`      Tools: ${agent.tools?.join(', ') || 'none'}`);
    console.log(`      Max Iterations: ${agent.maxIterations || 10}`);
  }

  console.log('\n── Swarm ─────────────────────────────');
  console.log(`  Enabled:      ${config.swarm.enabled ? 'yes' : 'no'}`);
  console.log(`  Max Agents:   ${config.swarm.maxAgents || 5}`);
  console.log(`  Coordination: ${config.swarm.coordination || 'central'}`);
  console.log('');
}

function showAgentInfo(config: GemConfig, name?: string): void {
  if (!name) {
    name = 'default';
  }

  const agent = config.agents.find((a) => a.name === name);
  if (!agent) {
    console.error(`Agent not found: ${name}`);
    return;
  }

  console.log(`\n── Agent: ${agent.name} ──────────────────────`);
  console.log(`  Provider:       ${agent.provider}`);
  console.log(`  Model:          ${agent.model || 'default'}`);
  console.log(`  System Prompt:  ${agent.systemPrompt || 'default'}`);
  console.log(`  Tools:          ${agent.tools?.join(', ') || 'none'}`);
  console.log(`  Max Iterations: ${agent.maxIterations || 10}`);
  console.log(`  Temperature:    ${agent.temperature || 0.7}`);
  console.log('');
}
