/**
 * Tools Command - Manage tools
 */

import type { ToolRegistry } from '../../tools/registry.js';

export function createToolsCommand(
  program: import('commander').Command,
  tools: ToolRegistry,
): void {
  program
    .command('tools')
    .description('Manage available tools')
    .argument('[action]', 'Action: list, enable, disable, info', 'list')
    .argument('[name]', 'Tool name (for enable/disable/info)')
    .action((action, name) => {
      switch (action) {
        case 'list':
          listTools(tools);
          break;
        case 'enable':
          if (!name) { console.error('Tool name required'); return; }
          tools.setEnabled(name, true);
          console.log(`Tool "${name}" enabled.`);
          break;
        case 'disable':
          if (!name) { console.error('Tool name required'); return; }
          tools.setEnabled(name, false);
          console.log(`Tool "${name}" disabled.`);
          break;
        case 'info':
          showToolInfo(tools, name);
          break;
        default:
          console.error(`Unknown action: ${action}`);
      }
    });
}

function listTools(tools: ToolRegistry): void {
  const all = tools.listAll();
  const categories = tools.getCategories();

  console.log('\n── Tools ─────────────────────────────');
  for (const category of categories) {
    console.log(`\n  [${category}]`);
    const categoryTools = all.filter((t) => t.definition.category === category);
    for (const t of categoryTools) {
      const enabled = tools.isEnabled(t.definition.name) ? '✓' : '✗';
      const dangerous = t.definition.dangerous ? ' ⚠' : '';
      console.log(`    ${enabled} ${t.definition.name}${dangerous} — ${t.definition.description}`);
    }
  }
  console.log('\n  ⚠ = dangerous tool\n');
}

function showToolInfo(tools: ToolRegistry, name?: string): void {
  if (!name) {
    console.error('Tool name required');
    return;
  }

  const tool = tools.get(name);
  if (!tool) {
    console.error(`Tool not found: ${name}`);
    return;
  }

  const def = tool.definition;
  console.log(`\n── Tool: ${def.name} ──────────────────────`);
  console.log(`  Description: ${def.description}`);
  console.log(`  Category:    ${def.category}`);
  console.log(`  Enabled:     ${tools.isEnabled(name) ? 'yes' : 'no'}`);
  console.log(`  Dangerous:   ${def.dangerous ? 'yes' : 'no'}`);
  console.log(`\n  Parameters:`);
  for (const param of def.parameters) {
    const required = param.required ? '(required)' : '(optional)';
    const enumStr = param.enum ? ` [${param.enum.join('|')}]` : '';
    console.log(`    ${param.name}: ${param.type} ${required}${enumStr}`);
    console.log(`      ${param.description}`);
  }
  console.log('');
}
