/**
 * Project Command - Manage Gem projects
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import type { GemConfig } from '../../config/schema.js';
import { writeConfig } from '../../config/loader.js';
import { createDefaultConfig } from '../../config/schema.js';

export function createProjectCommand(
  program: import('commander').Command,
  _config: GemConfig,
): void {
  program
    .command('project')
    .description('Manage Gem projects')
    .argument('[action]', 'Action: init, info', 'info')
    .option('-n, --name <name>', 'Project name')
    .option('-d, --dir <dir>', 'Project directory', process.cwd())
    .action((action, opts) => {
      switch (action) {
        case 'init':
          initProject(opts);
          break;
        case 'info':
          projectInfo(opts);
          break;
        default:
          console.error(`Unknown action: ${action}`);
      }
    });
}

function initProject(opts: { name?: string; dir: string }): void {
  const dir = opts.dir || process.cwd();
  const name = opts.name || path.basename(dir);

  console.log(`Initializing Gem project: ${name}`);

  // Create .gem directory
  const gemDir = path.join(dir, '.gem');
  if (!fs.existsSync(gemDir)) {
    fs.mkdirSync(gemDir, { recursive: true });
  }

  // Create config file
  const configPath = path.join(gemDir, 'config.json');
  if (!fs.existsSync(configPath)) {
    const config = createDefaultConfig();
    writeConfig(config, configPath);
    console.log(`  Created: ${configPath}`);
  } else {
    console.log(`  Config already exists: ${configPath}`);
  }

  // Create .gitignore entries
  const gitignorePath = path.join(dir, '.gitignore');
  const gemIgnore = '\n# Gem CLI\n.gem/memory.json\n.gem/sessions/\n';
  if (fs.existsSync(gitignorePath)) {
    const content = fs.readFileSync(gitignorePath, 'utf-8');
    if (!content.includes('.gem/')) {
      fs.appendFileSync(gitignorePath, gemIgnore);
      console.log('  Updated .gitignore');
    }
  } else {
    fs.writeFileSync(gitignorePath, gemIgnore);
    console.log('  Created .gitignore');
  }

  console.log(`\nProject "${name}" initialized successfully!`);
}

function projectInfo(opts: { dir: string }): void {
  const dir = opts.dir || process.cwd();
  const gemDir = path.join(dir, '.gem');
  const configPath = path.join(gemDir, 'config.json');

  console.log('\n── Project Info ──────────────────────');
  console.log(`  Directory: ${dir}`);
  console.log(`  Name: ${path.basename(dir)}`);
  console.log(`  Gem Config: ${fs.existsSync(configPath) ? configPath : 'not found'}`);
  console.log(`  Git: ${fs.existsSync(path.join(dir, '.git')) ? 'yes' : 'no'}`);
  console.log(`  Package: ${fs.existsSync(path.join(dir, 'package.json')) ? 'yes' : 'no'}`);
  console.log('');
}
