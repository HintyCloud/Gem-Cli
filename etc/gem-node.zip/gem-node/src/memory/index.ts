/**
 * Memory Module
 */

export { HistoryStore, type HistoryEntry, type Conversation } from './history.js';
export { PersistentMemory, type MemoryEntry } from './persistent.js';

import { HistoryStore } from './history.js';
import { PersistentMemory } from './persistent.js';

/**
 * Combined memory system
 */
export class MemorySystem {
  public history: HistoryStore;
  public persistent: PersistentMemory;
  private autoSaveInterval: NodeJS.Timeout | null = null;

  constructor(options: {
    maxHistory?: number;
    persistPath?: string;
    autoSave?: boolean;
    autoSaveIntervalMs?: number;
  } = {}) {
    this.history = new HistoryStore(options.maxHistory || 100);
    this.persistent = new PersistentMemory(
      options.persistPath || `${require('os').homedir()}/.config/gem/memory.json`,
    );

    if (options.autoSave) {
      this.startAutoSave(options.autoSaveIntervalMs || 30000);
    }
  }

  /**
   * Initialize the memory system
   */
  async init(): Promise<void> {
    await this.persistent.load();
  }

  /**
   * Start auto-save timer
   */
  startAutoSave(intervalMs: number): void {
    this.stopAutoSave();
    this.autoSaveInterval = setInterval(() => {
      this.persistent.save().catch((err) => {
        console.error(`Auto-save failed: ${err instanceof Error ? err.message : String(err)}`);
      });
    }, intervalMs);
  }

  /**
   * Stop auto-save timer
   */
  stopAutoSave(): void {
    if (this.autoSaveInterval) {
      clearInterval(this.autoSaveInterval);
      this.autoSaveInterval = null;
    }
  }

  /**
   * Save and shutdown
   */
  async shutdown(): Promise<void> {
    this.stopAutoSave();
    await this.persistent.save();
  }
}

export default MemorySystem;
