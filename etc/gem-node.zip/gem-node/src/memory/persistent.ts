/**
 * Persistent Memory Store
 * Long-term memory that persists across sessions using file storage.
 */

import * as fs from 'node:fs/promises';
import * as path from 'node:path';

export interface MemoryEntry {
  key: string;
  value: string;
  category: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  accessCount: number;
}

export class PersistentMemory {
  private entries: Map<string, MemoryEntry> = new Map();
  private storePath: string;
  private dirty: boolean = false;

  constructor(storePath: string) {
    this.storePath = storePath;
  }

  /**
   * Load memory from disk
   */
  async load(): Promise<void> {
    try {
      const content = await fs.readFile(this.storePath, 'utf-8');
      const data = JSON.parse(content) as MemoryEntry[];
      for (const entry of data) {
        this.entries.set(entry.key, entry);
      }
    } catch {
      // File doesn't exist or is invalid - start fresh
      this.entries.clear();
    }
  }

  /**
   * Save memory to disk
   */
  async save(): Promise<void> {
    if (!this.dirty) return;

    try {
      const dir = path.dirname(this.storePath);
      await fs.mkdir(dir, { recursive: true });
      const data = Array.from(this.entries.values());
      await fs.writeFile(this.storePath, JSON.stringify(data, null, 2), 'utf-8');
      this.dirty = false;
    } catch (err) {
      console.error(`Failed to save memory: ${err instanceof Error ? err.message : String(err)}`);
    }
  }

  /**
   * Store a memory entry
   */
  set(key: string, value: string, category = 'general', tags: string[] = []): MemoryEntry {
    const existing = this.entries.get(key);
    const now = new Date().toISOString();

    const entry: MemoryEntry = {
      key,
      value,
      category,
      tags,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
      accessCount: (existing?.accessCount || 0) + 1,
    };

    this.entries.set(key, entry);
    this.dirty = true;
    return entry;
  }

  /**
   * Retrieve a memory entry
   */
  get(key: string): MemoryEntry | undefined {
    const entry = this.entries.get(key);
    if (entry) {
      entry.accessCount++;
      entry.updatedAt = new Date().toISOString();
      this.dirty = true;
    }
    return entry;
  }

  /**
   * Delete a memory entry
   */
  delete(key: string): boolean {
    const result = this.entries.delete(key);
    if (result) this.dirty = true;
    return result;
  }

  /**
   * Search memories by category
   */
  getByCategory(category: string): MemoryEntry[] {
    return Array.from(this.entries.values()).filter((e) => e.category === category);
  }

  /**
   * Search memories by tags
   */
  getByTags(tags: string[]): MemoryEntry[] {
    return Array.from(this.entries.values()).filter((e) =>
      tags.some((tag) => e.tags.includes(tag)),
    );
  }

  /**
   * Search memories by keyword in value
   */
  search(query: string): MemoryEntry[] {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.entries.values()).filter(
      (e) =>
        e.value.toLowerCase().includes(lowerQuery) ||
        e.key.toLowerCase().includes(lowerQuery),
    );
  }

  /**
   * List all entries
   */
  list(): MemoryEntry[] {
    return Array.from(this.entries.values());
  }

  /**
   * Get memory statistics
   */
  getStats(): { total: number; categories: Record<string, number>; totalSize: number } {
    const categories: Record<string, number> = {};
    let totalSize = 0;

    for (const entry of this.entries.values()) {
      categories[entry.category] = (categories[entry.category] || 0) + 1;
      totalSize += entry.value.length;
    }

    return {
      total: this.entries.size,
      categories,
      totalSize,
    };
  }

  /**
   * Clear all memories
   */
  clear(): void {
    this.entries.clear();
    this.dirty = true;
  }
}

export default PersistentMemory;
