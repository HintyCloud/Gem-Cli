/**
 * Conversation History Store
 * In-memory conversation history with optional size limits.
 */

import type { ChatMessage } from '../provider/interface.js';

export interface HistoryEntry {
  id: string;
  role: ChatMessage['role'];
  content: string;
  timestamp: string;
  metadata?: Record<string, unknown>;
}

export interface Conversation {
  id: string;
  title: string;
  entries: HistoryEntry[];
  createdAt: string;
  updatedAt: string;
  model?: string;
  provider?: string;
}

export class HistoryStore {
  private conversations: Map<string, Conversation> = new Map();
  private activeConversationId: string | null = null;
  private maxHistory: number;

  constructor(maxHistory = 100) {
    this.maxHistory = maxHistory;
  }

  /**
   * Create a new conversation
   */
  createConversation(title?: string, model?: string, provider?: string): Conversation {
    const id = `conv-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const now = new Date().toISOString();
    const conversation: Conversation = {
      id,
      title: title || `Conversation ${this.conversations.size + 1}`,
      entries: [],
      createdAt: now,
      updatedAt: now,
      model,
      provider,
    };
    this.conversations.set(id, conversation);
    this.activeConversationId = id;
    return conversation;
  }

  /**
   * Get the active conversation
   */
  getActive(): Conversation | undefined {
    if (!this.activeConversationId) return undefined;
    return this.conversations.get(this.activeConversationId);
  }

  /**
   * Set the active conversation
   */
  setActive(id: string): boolean {
    if (!this.conversations.has(id)) return false;
    this.activeConversationId = id;
    return true;
  }

  /**
   * Add a message to the active conversation
   */
  addMessage(role: ChatMessage['role'], content: string, metadata?: Record<string, unknown>): HistoryEntry | null {
    const conversation = this.getActive();
    if (!conversation) return null;

    const entry: HistoryEntry = {
      id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      role,
      content,
      timestamp: new Date().toISOString(),
      metadata,
    };

    conversation.entries.push(entry);
    conversation.updatedAt = new Date().toISOString();

    // Trim if exceeds max
    if (conversation.entries.length > this.maxHistory) {
      conversation.entries = conversation.entries.slice(-this.maxHistory);
    }

    return entry;
  }

  /**
   * Get messages as ChatMessage array for provider
   */
  getMessages(conversationId?: string): ChatMessage[] {
    const conv = conversationId
      ? this.conversations.get(conversationId)
      : this.getActive();
    if (!conv) return [];

    return conv.entries.map((e) => ({
      role: e.role,
      content: e.content,
      ...(e.metadata?.name ? { name: e.metadata.name as string } : {}),
      ...(e.metadata?.toolCallId ? { toolCallId: e.metadata.toolCallId as string } : {}),
    }));
  }

  /**
   * List all conversations
   */
  listConversations(): Conversation[] {
    return Array.from(this.conversations.values())
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }

  /**
   * Get a conversation by ID
   */
  getConversation(id: string): Conversation | undefined {
    return this.conversations.get(id);
  }

  /**
   * Delete a conversation
   */
  deleteConversation(id: string): boolean {
    if (this.activeConversationId === id) {
      this.activeConversationId = null;
    }
    return this.conversations.delete(id);
  }

  /**
   * Clear the active conversation
   */
  clearActive(): void {
    const conversation = this.getActive();
    if (conversation) {
      conversation.entries = [];
      conversation.updatedAt = new Date().toISOString();
    }
  }

  /**
   * Get conversation summary for display
   */
  getSummary(conversationId?: string): string {
    const conv = conversationId
      ? this.conversations.get(conversationId)
      : this.getActive();
    if (!conv) return 'No active conversation';

    const lines = [
      `Conversation: ${conv.title} (${conv.entries.length} messages)`,
      `Model: ${conv.model || 'default'}`,
      `Provider: ${conv.provider || 'default'}`,
      `Created: ${conv.createdAt}`,
      `Updated: ${conv.updatedAt}`,
    ];
    return lines.join('\n');
  }

  /**
   * Export conversation as JSON
   */
  exportConversation(conversationId?: string): string {
    const conv = conversationId
      ? this.conversations.get(conversationId)
      : this.getActive();
    if (!conv) return '{}';
    return JSON.stringify(conv, null, 2);
  }
}

export default HistoryStore;
