#!/usr/bin/env node
/**
 * Gem CLI — Agentic AI Ecosystem
 * Entry point for the Gem CLI application.
 *
 * Copyright (C) 2024 HintyCloud
 * License: GPL-3.0
 */

import { loadConfig } from './config/loader.js';
import { ProviderRegistry } from './provider/index.js';
import { createDefaultRegistry } from './tools/registry.js';
import { JobQueue } from './agent/job-queue.js';
import { MemorySystem } from './memory/index.js';
import { createCLI } from './cli/index.js';

async function main(): Promise<void> {
  try {
    // Load configuration
    const config = loadConfig({
      configPath: process.env.GEM_CONFIG_PATH,
      resolveEnv: true,
    });

    // Initialize provider registry
    const providers = new ProviderRegistry(
      config.providers,
      config.defaultProvider,
    );

    // Initialize tool registry
    const enabledToolNames = config.tools
      .filter((t) => t.enabled)
      .map((t) => t.name);
    const tools = createDefaultRegistry(enabledToolNames);

    // Initialize job queue
    const jobs = new JobQueue(3);
    jobs.start();

    // Initialize memory system
    const memory = new MemorySystem({
      maxHistory: config.memory.maxHistory || 100,
      persistPath: config.memory.persistPath,
      autoSave: config.memory.enabled,
      autoSaveIntervalMs: 30000,
    });
    await memory.init();

    // Create CLI context
    const ctx = {
      config,
      providers,
      tools,
      jobs,
      memory,
    };

    // Create and run CLI
    const program = createCLI(ctx);

    // If no arguments, show help
    if (process.argv.length <= 2) {
      program.help();
      return;
    }

    await program.parseAsync(process.argv);

    // Cleanup
    await memory.shutdown();
  } catch (err) {
    console.error('Fatal error:', err instanceof Error ? err.message : String(err));
    process.exit(1);
  }
}

// Run main
main().catch((err) => {
  console.error('Unhandled error:', err);
  process.exit(1);
});
