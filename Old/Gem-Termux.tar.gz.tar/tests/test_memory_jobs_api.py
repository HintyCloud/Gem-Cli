"""Tests for memory (history + memory + search), jobs, sandbox, config, platform, API."""
import asyncio
import json
import os

import pytest

from gem.memory.history import History, create_chat, list_chats, rename_chat, delete_chat
from gem.memory.memory import Memory


def run(coro):
    import asyncio as _a; return _a.new_event_loop().run_until_complete(coro)


# ---------------- history ----------------
def test_history_create_add_persist(tmp_workspace):
    cdir = os.path.join(tmp_workspace, "chats")
    h = History(cdir)
    h.add("user", "hello")
    h.add_assistant("hi there")
    assert h.path.exists()
    # reload
    h2 = History(cdir, h.chat_id)
    assert len(h2.messages) == 2
    assert h2.messages[0].content == "hello"
    assert h2.messages[1].content == "hi there"


def test_history_list_rename_delete(tmp_workspace):
    cdir = os.path.join(tmp_workspace, "chats")
    h = create_chat(cdir, "First")
    h.add("user", "msg")
    chats = list_chats(cdir)
    assert len(chats) == 1
    assert chats[0]["title"] == "First"
    rename_chat(cdir, h.chat_id, "Renamed")
    chats = list_chats(cdir)
    assert chats[0]["title"] == "Renamed"
    assert delete_chat(cdir, h.chat_id) is True
    assert list_chats(cdir) == []


def test_history_to_provider_messages_skips_events(tmp_workspace):
    cdir = os.path.join(tmp_workspace, "chats")
    h = History(cdir)
    h.add("user", "q")
    h.add_event("completed")
    h.add_assistant("a")
    msgs = h.to_provider_messages()
    roles = [m["role"] for m in msgs]
    assert roles == ["user", "assistant"]


# ---------------- memory ----------------
def test_memory_remember_search_forget(tmp_workspace):
    m = Memory(os.path.join(tmp_workspace, "memory"))
    e = m.remember("The project uses Python 3.12", tags=["project", "python"])
    assert len(m.all()) == 1
    results = m.search("python")
    assert len(results) == 1
    assert "Python 3.12" in results[0]["text"]
    relevant = m.relevant("python")
    assert "Python 3.12" in relevant
    assert m.forget(e["id"]) is True
    assert m.all() == []


def test_memory_relevance_no_match(tmp_workspace):
    m = Memory(os.path.join(tmp_workspace, "memory"))
    m.remember("unrelated fact about cats")
    assert m.relevant("quantum physics") == ""


# ---------------- search ----------------
def test_search_history_and_memory(tmp_workspace):
    from gem.memory.search import search_history, search_memory
    cdir = os.path.join(tmp_workspace, "chats")
    mdir = os.path.join(tmp_workspace, "memory")
    h = History(cdir)
    h.add("user", "deploy the server to production")
    m = Memory(mdir)
    m.remember("production url is example.com")
    hres = search_history(cdir, "deploy")
    assert len(hres) == 1
    assert "deploy" in hres[0]["snippet"].lower()
    mres = search_memory(mdir, "production")
    assert len(mres) == 1


# ---------------- jobs ----------------
def test_job_state_persist(tmp_workspace):
    from gem.jobs.state import JobState, JobStatus, JobStore
    jdir = os.path.join(tmp_workspace, "jobs")
    store = JobStore(jdir)
    s = JobState(task="build it", project="p1")
    s.status = JobStatus.RUNNING
    store.save(s)
    loaded = store.load(s.job_id)
    assert loaded is not None
    assert loaded.status == JobStatus.RUNNING
    assert loaded.task == "build it"
    all_jobs = store.list_all()
    assert len(all_jobs) == 1


def test_job_queue_concurrency():
    from gem.jobs.queue import JobQueue
    q = JobQueue(max_concurrent=2)
    q.enqueue("a")
    q.enqueue("b")
    assert q.pending == 2
    assert q.dequeue() == "a"
    assert q.dequeue() == "b"


def test_job_recovery_marks_interrupted(tmp_workspace):
    from gem.jobs.state import JobState, JobStatus, JobStore
    from gem.jobs.recovery import recover_jobs
    jdir = os.path.join(tmp_workspace, "jobs")
    store = JobStore(jdir)
    s = JobState(task="long", project="p")
    s.status = JobStatus.RUNNING
    store.save(s)
    recovered = recover_jobs(jdir)
    assert s.job_id in recovered
    loaded = store.load(s.job_id)
    assert loaded.status == JobStatus.RECOVERING


# ---------------- sandbox ----------------
def test_local_sandbox_runs(tmp_workspace):
    from gem.sandbox.local import LocalSandbox
    sb = LocalSandbox(tmp_workspace)
    res = run(sb.run("echo sandboxed"))
    assert res.exit_code == 0
    assert "sandboxed" in res.stdout


def test_local_sandbox_blocks_destructive(tmp_workspace):
    from gem.exceptions import CommandBlockedError
    from gem.sandbox.local import LocalSandbox
    sb = LocalSandbox(tmp_workspace)
    with pytest.raises(CommandBlockedError):
        run(sb.run("rm -rf /"))


def test_local_sandbox_timeout(tmp_workspace):
    from gem.sandbox.local import LocalSandbox
    sb = LocalSandbox(tmp_workspace)
    res = run(sb.run("sleep 3", timeout=1))
    assert res.timed_out is True


# ---------------- config ----------------
def test_config_loads():
    from gem.config import get_config, reload_config
    cfg = reload_config()
    assert cfg.provider.name == "opencode"
    assert cfg.provider.model == "longcat-2.0-free"
    assert cfg.provider.base_url == "https://opencode.ai/zen/v1"
    assert cfg.agent.max_iterations == 50
    assert cfg.workspace_path.exists()


def test_config_paths_exist():
    from gem.config import get_config
    cfg = get_config()
    assert cfg.chats_path.exists()
    assert cfg.memory_path.exists()
    assert cfg.checkpoints_path.exists()
    assert cfg.jobs_path.exists()
    assert cfg.artifacts_path.exists()


# ---------------- platform ----------------
def test_platform_detect():
    from gem.platform.detect import current_platform, Platform
    info = current_platform()
    assert info.platform in (Platform.LINUX, Platform.WINDOWS, Platform.TERMUX, Platform.DARWIN, Platform.UNKNOWN)
    assert isinstance(info.is_arm32, bool)
    assert isinstance(info.is_arm64, bool)


def test_termux_helpers():
    from gem.platform import termux
    # prefix should be a string; open_url returns a list
    assert isinstance(termux.termux_prefix(), str)
    assert isinstance(termux.open_url("https://x"), list)


# ---------------- API (FastAPI TestClient) ----------------
def test_api_status_endpoint():
    from fastapi.testclient import TestClient
    from gem.api.app import create_app
    app = create_app()
    with TestClient(app) as client:
        r = client.get("/status")
        assert r.status_code == 200
        data = r.json()
        assert data["ok"] is True
        assert data["version"] == "1.0.0"
        assert "platform" in data


def test_api_chats_crud():
    from fastapi.testclient import TestClient
    from gem.api.app import create_app
    import tempfile
    tmp = tempfile.mkdtemp(prefix="gem-api-")
    # Point config at temp dirs by monkeypatching the routes module.
    from gem.api import routes as R
    from gem.config import get_config
    R._config = get_config()
    R._config.workspace = tmp
    R._memory = Memory(os.path.join(tmp, "memory"))
    app = create_app()
    with TestClient(app) as client:
        r = client.get("/chats")
        assert r.status_code == 200
        assert isinstance(r.json(), list)


def test_api_providers_tools_agents():
    from fastapi.testclient import TestClient
    from gem.api.app import create_app
    app = create_app()
    with TestClient(app) as client:
        assert client.get("/providers").status_code == 200
        assert client.get("/tools").status_code == 200
        assert client.get("/agents").status_code == 200
        agents = client.get("/agents").json()
        names = [a["name"] for a in agents]
        assert "coder" in names
