"""Tests for the agent loop, planner, context/checkpoints, executor, swarm."""
import asyncio
import os

import pytest

from gem.agent.context import AgentContext
from gem.agent.executor import Executor
from gem.agent.loop import AgentLoop
from gem.agent.planner import Planner
from gem.memory.history import History
from gem.memory.memory import Memory
from gem.providers.base import GenerateResult, ToolCall


def run(coro):
    import asyncio as _a; return _a.new_event_loop().run_until_complete(coro)


# ---------------- context / checkpoints ----------------
def test_checkpoint_save_load(tmp_workspace):
    cdir = os.path.join(tmp_workspace, "checkpoints")
    ctx = AgentContext(project="proj", checkpoints_dir=cdir)
    ctx.set_plan([{"title": "a", "goal": "g", "agent": "general"}])
    ctx.iterations = 3
    ctx.add_tool_result("shell", {"command": "ls"}, "file1\nfile2")
    ctx.save()
    assert ctx.checkpoint_path().exists()

    loaded = AgentContext.load(cdir, ctx.task_id)
    assert loaded.project == "proj"
    assert loaded.iterations == 3
    assert loaded.current_step == 0
    assert len(loaded.tool_results) == 1
    assert loaded.status == "recovering"  # running -> recovering on load


def test_checkpoint_list(tmp_workspace):
    cdir = os.path.join(tmp_workspace, "checkpoints")
    c1 = AgentContext(project="p1", checkpoints_dir=cdir)
    c1.save()
    c2 = AgentContext(project="p2", checkpoints_dir=cdir)
    c2.save()
    items = AgentContext.list_checkpoints(cdir)
    assert len(items) == 2
    projs = {i["project"] for i in items}
    assert projs == {"p1", "p2"}


# ---------------- planner ----------------
def test_planner_trivial(mock_provider):
    p = Planner(mock_provider)
    plan = run(p.plan("hi"))
    assert plan["complexity"] == "simple"
    assert len(plan["steps"]) == 1


def test_planner_complex(mock_provider):
    mock_provider.queue(content='{"complexity":"complex","steps":[{"title":"build","goal":"make site","agent":"coder"},{"title":"test","goal":"run tests","agent":"tester"}]}')
    p = Planner(mock_provider)
    plan = run(p.plan("Build a full web application with tests"))
    assert plan["complexity"] == "complex"
    assert len(plan["steps"]) == 2
    assert plan["steps"][0]["agent"] in ("coder", "tester")


def test_planner_fallback_on_bad_json(mock_provider):
    mock_provider.queue(content="not json at all")
    p = Planner(mock_provider)
    plan = run(p.plan("Build something complex here please"))
    assert "steps" in plan


# ---------------- executor ----------------
def test_executor_runs_tool(tools_registry):
    ex = Executor(tools_registry)
    tc = ToolCall(id="1", name="shell", arguments={"command": "echo ok"})
    res = run(ex.execute(tc))
    assert res.is_error is False
    assert "ok" in res.content


def test_executor_tool_error_becomes_result(tools_registry):
    ex = Executor(tools_registry)
    tc = ToolCall(id="1", name="files", arguments={"action": "read", "path": "missing.txt"})
    res = run(ex.execute(tc))
    assert res.is_error is True
    assert "ERROR" in res.content


# ---------------- agent loop ----------------
def test_loop_text_response(tmp_workspace, mock_provider, tools_registry):
    # No tool calls -> immediate done.
    mock_provider.queue(content="Hello! How can I help?")
    history = History(os.path.join(tmp_workspace, "chats"))
    memory = Memory(os.path.join(tmp_workspace, "memory"))
    ctx = AgentContext(project="proj", checkpoints_dir=os.path.join(tmp_workspace, "cp"))
    loop = AgentLoop(mock_provider, tools_registry, history, memory, ctx, max_iterations=3)
    events = []
    async def go():
        async for ev in loop.run("hi"):
            events.append(ev)
    run(go())
    types = [e["type"] for e in events]
    assert "user" in types
    assert "assistant" in types
    assert "done" in types
    assert ctx.status == "completed"


def test_loop_tool_call_then_done(tmp_workspace, mock_provider, tools_registry):
    # The planner shares the provider and consumes one response first.
    # Queue: [planner JSON, tool_call, final summary].
    mock_provider.queue(content='{"complexity":"simple","steps":[{"title":"do","goal":"create file","agent":"general"}]}')
    mock_provider.queue(
        content="",
        tool_calls=[ToolCall(id="c1", name="files",
                             arguments={"action": "write", "path": "out.txt", "content": "done"})],
        finish="tool_calls",
    )
    mock_provider.queue(content="I created out.txt.")
    history = History(os.path.join(tmp_workspace, "chats"))
    memory = Memory(os.path.join(tmp_workspace, "memory"))
    ctx = AgentContext(project="proj", checkpoints_dir=os.path.join(tmp_workspace, "cp"))
    loop = AgentLoop(mock_provider, tools_registry, history, memory, ctx, max_iterations=5)
    events = []
    async def go():
        async for ev in loop.run("Create out.txt with 'done'"):
            events.append(ev)
    run(go())
    types = [e["type"] for e in events]
    assert "tool_call" in types
    assert "file_created" in types
    assert "tool_result" in types
    assert "done" in types
    # File actually created by real tool execution in the workspace.
    assert os.path.exists(os.path.join(tmp_workspace, "out.txt")) is True
    with open(os.path.join(tmp_workspace, "out.txt")) as fh:
        assert fh.read() == "done"
    assert ctx.status == "completed"


def test_loop_handles_provider_error(tmp_workspace, mock_provider, tools_registry):
    from gem.exceptions import ProviderError
    from gem.providers.base import Provider

    class FailProvider(Provider):
        name = "fail"
        def is_configured(self):
            return True
        async def generate(self, *a, **kw):
            raise ProviderError("boom")
    fp = FailProvider(model="fail")
    history = History(os.path.join(tmp_workspace, "chats"))
    memory = Memory(os.path.join(tmp_workspace, "memory"))
    ctx = AgentContext(project="proj", checkpoints_dir=os.path.join(tmp_workspace, "cp"))
    loop = AgentLoop(fp, tools_registry, history, memory, ctx, max_iterations=5)
    events = []
    async def go():
        async for ev in loop.run("do something"):
            events.append(ev)
    run(go())
    assert any(e["type"] == "error" for e in events)
    assert ctx.status == "failed"


# ---------------- swarm ----------------
def test_swarm_profiles():
    from gem.swarm.worker import AGENT_PROFILES
    expected = {"general", "coder", "researcher", "tester", "frontend",
                "backend", "reviewer", "planner", "minicoder", "minireviewer",
                "miniresearcher", "minitester"}
    assert expected.issubset(set(AGENT_PROFILES.keys()))
    for p in AGENT_PROFILES.values():
        assert p.system_prompt  # real prompt, not empty


def test_swarm_strategies():
    from gem.swarm.strategies import ParallelStrategy, SequentialStrategy, TaskUnit
    seq = SequentialStrategy()
    units = [TaskUnit("general", "a"), TaskUnit("general", "b")]
    results = run(seq.execute(units, lambda a, t: _sync_runner(a, t)))
    assert len(results) == 2
    par = ParallelStrategy(max_concurrent=2)
    results = run(par.execute(units, lambda a, t: _sync_runner(a, t)))
    assert len(results) == 2


async def _sync_runner(agent, task):
    return {"agent": agent, "task": task, "result": "ok", "status": "completed"}


def test_supervisor_plan_fallback(mock_provider, tmp_workspace, tools_registry):
    from gem.swarm.coordinator import Supervisor
    mock_provider.queue(content="not json")
    sup = Supervisor(mock_provider, tools_registry, os.path.join(tmp_workspace, "chats"),
                     Memory(os.path.join(tmp_workspace, "memory")),
                     os.path.join(tmp_workspace, "cp"), "proj")
    plan = run(sup.plan_swarm("do a thing"))
    assert "tasks" in plan
    assert len(plan["tasks"]) >= 1
