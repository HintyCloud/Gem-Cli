"""Tests for tools: shell, files, archive, artifacts, and security guards."""
import asyncio
import os

import pytest

from gem.exceptions import CommandBlockedError, PathSecurityError, ToolError


def run(coro):
    import asyncio as _a; return _a.new_event_loop().run_until_complete(coro)


# ---------------- shell ----------------
def test_shell_success(tmp_workspace, tools_registry):
    out = run(tools_registry.execute("shell", {"command": "echo hello"}))
    assert "hello" in out
    assert "exit_code: 0" in out
    assert "status: success" in out


def test_shell_timeout(tmp_workspace):
    from gem.tools.shell import ShellTool
    t = ShellTool(tmp_workspace, default_timeout=10)
    out = run(t.run(command="sleep 5", timeout=1))
    assert "timed_out: True" in out


def test_shell_blocks_destructive(tmp_workspace):
    from gem.tools.shell import ShellTool
    t = ShellTool(tmp_workspace)
    with pytest.raises(CommandBlockedError):
        run(t.run(command="rm -rf /"))


def test_shell_blocks_fork_bomb(tmp_workspace):
    from gem.tools.shell import ShellTool
    t = ShellTool(tmp_workspace)
    with pytest.raises(CommandBlockedError):
        run(t.run(command=":(){ :|:& };:"))


def test_shell_cwd_inside_workspace(tmp_workspace):
    from gem.tools.shell import ShellTool
    t = ShellTool(tmp_workspace)
    out = run(t.run(command="pwd"))
    assert tmp_workspace in out


def test_shell_cwd_escape_blocked(tmp_workspace):
    from gem.tools.shell import ShellTool
    t = ShellTool(tmp_workspace)
    with pytest.raises(ToolError):
        run(t.run(command="pwd", cwd="../../etc"))


def test_shell_secret_redaction(tmp_workspace):
    from gem.tools.shell import ShellTool
    t = ShellTool(tmp_workspace)
    # Placeholder key (contains "example") so the packager's secret scan ignores it.
    fake_key = "sk-exampleexampleexampleexample1234"
    out = run(t.run(command=f"echo {fake_key}"))
    assert "REDACTED" in out
    assert fake_key[3:] not in out  # the secret portion must not appear


# ---------------- files ----------------
def test_files_write_read(tmp_workspace, tools_registry):
    run(tools_registry.execute("files", {"action": "write", "path": "a.txt", "content": "hello"}))
    out = run(tools_registry.execute("files", {"action": "read", "path": "a.txt"}))
    assert out == "hello"


def test_files_traversal_blocked(tmp_workspace):
    from gem.tools.files import FilesTool
    t = FilesTool(tmp_workspace)
    with pytest.raises(PathSecurityError):
        run(t.run(action="read", path="../../etc/passwd"))


def test_files_edit(tmp_workspace, tools_registry):
    run(tools_registry.execute("files", {"action": "write", "path": "b.txt", "content": "foo bar baz"}))
    run(tools_registry.execute("files", {"action": "edit", "path": "b.txt", "old_str": "bar", "new_str": "QUX"}))
    out = run(tools_registry.execute("files", {"action": "read", "path": "b.txt"}))
    assert out == "foo QUX baz"


def test_files_edit_missing_old_str(tmp_workspace, tools_registry):
    run(tools_registry.execute("files", {"action": "write", "path": "c.txt", "content": "x"}))
    with pytest.raises(ToolError):
        run(tools_registry.execute("files", {"action": "edit", "path": "c.txt", "old_str": "nope", "new_str": "y"}))


def test_files_list_mkdir_remove(tmp_workspace, tools_registry):
    run(tools_registry.execute("files", {"action": "mkdir", "path": "sub"}))
    run(tools_registry.execute("files", {"action": "write", "path": "sub/f.txt", "content": "1"}))
    out = run(tools_registry.execute("files", {"action": "list", "path": "."}))
    assert "sub" in out
    run(tools_registry.execute("files", {"action": "remove", "path": "sub"}))
    out = run(tools_registry.execute("files", {"action": "exists", "path": "sub"}))
    assert "false" in out


def test_files_metadata(tmp_workspace, tools_registry):
    run(tools_registry.execute("files", {"action": "write", "path": "m.txt", "content": "data"}))
    out = run(tools_registry.execute("files", {"action": "metadata", "path": "m.txt"}))
    assert "size: 4" in out
    assert "type: file" in out


# ---------------- archive ----------------
def test_archive_create_extract_zip(tmp_workspace, tools_registry):
    run(tools_registry.execute("files", {"action": "write", "path": "src.txt", "content": "abc"}))
    run(tools_registry.execute("archive", {"action": "create", "archive": "out.zip", "target": "src.txt", "format": "zip"}))
    assert os.path.exists(os.path.join(tmp_workspace, "out.zip"))
    run(tools_registry.execute("files", {"action": "remove", "path": "src.txt"}))
    run(tools_registry.execute("archive", {"action": "extract", "archive": "out.zip", "target": "restored"}))
    out = run(tools_registry.execute("files", {"action": "read", "path": "restored/src.txt"}))
    assert out == "abc"


def test_archive_traversal_blocked(tmp_workspace):
    from gem.tools.archive import ArchiveTool
    t = ArchiveTool(tmp_workspace)
    with pytest.raises(PathSecurityError):
        run(t.run(action="create", archive="../../escape.zip", target="."))


# ---------------- artifacts ----------------
def test_artifacts_register_list(tmp_workspace):
    from gem.tools.artifacts import ArtifactsTool
    adir = os.path.join(tmp_workspace, "art")
    t = ArtifactsTool(adir)
    p = os.path.join(adir, "thing.bin")
    os.makedirs(adir, exist_ok=True)
    with open(p, "wb") as fh:
        fh.write(b"data")
    run(t.run(action="register", name="thing.bin", kind="build", path=p))
    out = run(t.run(action="list"))
    assert "thing.bin" in out
    gout = run(t.run(action="get", name="thing.bin"))
    assert "build" in gout


# ---------------- tool registry ----------------
def test_registry_unknown_tool(tools_registry):
    with pytest.raises(ToolError):
        run(tools_registry.execute("nonexistent", {}))


def test_registry_schemas(tools_registry):
    schemas = tools_registry.schemas()
    names = [s["function"]["name"] for s in schemas]
    assert "shell" in names
    assert "files" in names
