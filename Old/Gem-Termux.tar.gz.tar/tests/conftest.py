"""Shared test fixtures: a deterministic mock provider + temp workspace."""
import asyncio
import os
import sys
import tempfile
from typing import Any

import pytest

# Make sure the project root is importable.
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from gem.providers.base import GenerateResult, Message, Provider, ToolCall  # noqa: E402
from gem.tools.registry import ToolRegistry  # noqa: E402
from gem.tools.shell import ShellTool  # noqa: E402
from gem.tools.files import FilesTool  # noqa: E402
from gem.tools.archive import ArchiveTool  # noqa: E402
from gem.tools.artifacts import ArtifactsTool  # noqa: E402


class MockProvider(Provider):
    """A provider that returns scripted responses, for deterministic tests."""

    name = "mock"

    def __init__(self, script: list[GenerateResult] | None = None, model: str = "mock-1") -> None:
        super().__init__(model=model, api_key="mock", base_url="http://mock")
        self._script = list(script or [])
        self._calls: list[tuple] = []
        self._index = 0

    def is_configured(self) -> bool:
        return True

    def queue(self, content: str = "", tool_calls: list[ToolCall] | None = None,
              finish: str = "stop") -> None:
        self._script.append(GenerateResult(content=content, tool_calls=tool_calls or [],
                                           finish_reason=finish))

    async def generate(self, messages, tools=None, system=None, temperature=0.3, max_tokens=4096):
        self._calls.append((messages, tools, system))
        if self._index >= len(self._script):
            return GenerateResult(content="(no more scripted responses)", finish_reason="stop")
        r = self._script[self._index]
        self._index += 1
        return r


@pytest.fixture
def tmp_workspace():
    d = tempfile.mkdtemp(prefix="gem-test-")
    yield d


@pytest.fixture
def mock_provider():
    return MockProvider()


@pytest.fixture
def tools_registry(tmp_workspace):
    reg = ToolRegistry()
    reg.register(ShellTool(tmp_workspace, default_timeout=10))
    reg.register(FilesTool(tmp_workspace))
    reg.register(ArchiveTool(tmp_workspace))
    reg.register(ArtifactsTool(os.path.join(tmp_workspace, "artifacts")))
    return reg
