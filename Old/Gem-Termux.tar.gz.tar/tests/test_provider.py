"""Tests for the OpenCode provider: longcat parser, config, error mapping."""
import json

import pytest

from gem.providers.base import Message, ToolCall
from gem.providers.opencode import OpenCodeProvider, _parse_longcat_tool_calls


def test_opencode_provider_config():
    p = OpenCodeProvider(model="longcat-2.0-free", api_key="sk-test",
                         base_url="https://opencode.ai/zen/v1")
    assert p.name == "opencode"
    assert p.model == "longcat-2.0-free"
    assert p.is_configured() is True
    desc = p.describe()
    assert desc["configured"] is True
    assert desc["base_url"] == "https://opencode.ai/zen/v1"


def test_opencode_not_configured_without_key():
    from gem.exceptions import ProviderNotConfiguredError
    p = OpenCodeProvider(api_key="")
    assert p.is_configured() is False
    with pytest.raises(ProviderNotConfiguredError):
        p._headers()


def test_parse_longcat_tool_calls_single():
    content = (
        "<longcat_tool_call>files\n"
        "<longcat_arg_key>action</longcat_arg_key><longcat_arg_value>write</longcat_arg_value>\n"
        "<longcat_arg_key>path</longcat_arg_key><longcat_arg_value>demo.txt</longcat_arg_value>\n"
        "<longcat_arg_key>content</longcat_arg_key><longcat_arg_value>hello world</longcat_arg_value>\n"
    )
    calls = _parse_longcat_tool_calls(content)
    assert len(calls) == 1
    assert calls[0].name == "files"
    assert calls[0].arguments["action"] == "write"
    assert calls[0].arguments["path"] == "demo.txt"
    assert calls[0].arguments["content"] == "hello world"


def test_parse_longcat_tool_calls_multiple():
    content = (
        "<longcat_tool_call>shell\n"
        "<longcat_arg_key>command</longcat_arg_key><longcat_arg_value>ls -la</longcat_arg_value>\n"
        "<longcat_tool_call>files\n"
        "<longcat_arg_key>action</longcat_arg_key><longcat_arg_value>read</longcat_arg_value>\n"
        "<longcat_arg_key>path</longcat_arg_key><longcat_arg_value>out.txt</longcat_arg_value>\n"
    )
    calls = _parse_longcat_tool_calls(content)
    assert len(calls) == 2
    assert calls[0].name == "shell"
    assert calls[0].arguments["command"] == "ls -la"
    assert calls[1].name == "files"
    assert calls[1].arguments["action"] == "read"


def test_parse_longcat_number_coercion():
    content = (
        "<longcat_tool_call>image\n"
        "<longcat_arg_key>prompt</longcat_arg_key><longcat_arg_value>a cat</longcat_arg_value>\n"
        "<longcat_arg_key>width</longcat_arg_key><longcat_arg_value>512</longcat_arg_value>\n"
    )
    calls = _parse_longcat_tool_calls(content)
    assert calls[0].arguments["width"] == 512
    assert calls[0].arguments["prompt"] == "a cat"


def test_parse_response_uses_longcat_fallback():
    p = OpenCodeProvider(api_key="sk-test")
    data = {
        "choices": [{
            "message": {
                "role": "assistant",
                "content": (
                    "<longcat_tool_call>files\n"
                    "<longcat_arg_key>action</longcat_arg_key><longcat_arg_value>write</longcat_arg_value>\n"
                    "<longcat_arg_key>path</longcat_arg_key><longcat_arg_value>x.txt</longcat_arg_value>\n"
                    "<longcat_arg_key>content</longcat_arg_key><longcat_arg_value>hi</longcat_arg_value>\n"
                ),
            },
            "finish_reason": "stop",
        }],
        "usage": {"prompt_tokens": 1, "completion_tokens": 1},
    }
    result = p._parse_response(data)
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0].name == "files"
    assert result.finish_reason == "tool_calls"


def test_parse_response_openai_tool_calls():
    p = OpenCodeProvider(api_key="sk-test")
    data = {
        "choices": [{
            "message": {
                "role": "assistant",
                "content": "",
                "tool_calls": [{
                    "id": "call_1",
                    "function": {"name": "shell", "arguments": json.dumps({"command": "echo hi"})},
                }],
            },
            "finish_reason": "tool_calls",
        }],
    }
    result = p._parse_response(data)
    assert len(result.tool_calls) == 1
    assert result.tool_calls[0].name == "shell"
    assert result.tool_calls[0].arguments["command"] == "echo hi"


def test_gem_provider_config():
    from gem.providers.gem import GemProvider
    g = GemProvider(model="longcat-2.0-free", base_url="http://127.0.0.1:8000", token="t")
    assert g.is_configured() is True
    assert g._headers()["Authorization"] == "Bearer t"


def test_provider_registry_lists():
    from gem.providers.registry import list_providers
    names = list_providers()
    assert "opencode" in names
    assert "gem" in names
