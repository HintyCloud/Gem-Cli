# Gem — Termux (Android)

Optimized for Termux on Android (ARM32/armv8l compatible + ARM64).

## Install
```bash
pkg update && pkg install python git
# (optional) termux-setup-storage   # enables ~/storage/downloads
tar xzf Gem-Termux.tar.gz
cd Gem-Termux
pip install -e .
./termux-setup.sh
```

## Run
```bash
./run.sh                 # Gem API on 127.0.0.1:8000
# Open http://127.0.0.1:8000/status in the Android browser, or use:
gem chat
```

## Keeping it alive
Termux cannot guarantee infinite background execution. Use `termux-wake-lock`
when available. Gem RECOVERS interrupted tasks from checkpoints when restarted:
```bash
gem jobs      # shows recovering jobs, auto-resumed
```

If shared storage is available, distribution archives are copied to
`~/storage/downloads/`.

## Notes
- No systemd, sudo or Docker assumed.
- Degrades clearly when a native dependency is unavailable.
