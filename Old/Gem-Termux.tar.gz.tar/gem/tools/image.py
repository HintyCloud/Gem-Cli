"""Image generation tool.

Architecture:
    Agent -> ImageTool -> ImageProvider -> Pollinations

Pollinations serves generated images directly via a URL, no API key required,
which makes it the perfect default that works out-of-the-box. Other providers
can be added behind the same ``ImageProvider`` interface.

Generated images are saved to the project's ``data/artifacts`` dir and registered
as artifacts so the Web UI can display/download them.
"""
from __future__ import annotations

import os
import time
from typing import Any
from urllib.parse import quote_plus

import httpx

from ..exceptions import ToolError
from .registry import Tool


class ImageProvider:
    """Abstract image provider. Subclasses implement ``generate``."""

    name = "base"

    async def generate(self, prompt: str, width: int, height: int) -> bytes:
        raise NotImplementedError


class PollinationsProvider(ImageProvider):
    name = "pollinations"
    base_url = "https://image.pollinations.ai/prompt"

    async def generate(self, prompt: str, width: int, height: int) -> bytes:
        seed = int(time.time()) % 1_000_000
        url = f"{self.base_url}/{quote_plus(prompt)}?width={width}&height={height}&seed={seed}&nologo=true"
        async with httpx.AsyncClient(timeout=90.0, follow_redirects=True) as client:
            resp = await client.get(url)
        if resp.status_code != 200 or not resp.content:
            raise ToolError(f"Pollinations HTTP {resp.status_code}")
        return resp.content


class ImageTool(Tool):
    name = "image"
    description = (
        "Generate an image from a text prompt using Pollinations. The image is "
        "saved to artifacts and a path/URL is returned. Use for logos, assets, "
        "illustrations - do not generate images unless requested or clearly useful."
    )
    parameters = {
        "type": "object",
        "properties": {
            "prompt": {"type": "string", "description": "Image description."},
            "width": {"type": "integer", "default": 1024},
            "height": {"type": "integer", "default": 1024},
            "filename": {"type": "string", "description": "Output filename (without path)."},
        },
        "required": ["prompt"],
    }

    def __init__(self, artifacts_dir: str, provider: ImageProvider | None = None,
                 default_width: int = 1024, default_height: int = 1024) -> None:
        self.artifacts_dir = os.path.abspath(artifacts_dir)
        os.makedirs(self.artifacts_dir, exist_ok=True)
        self.provider = provider or PollinationsProvider()
        self.default_width = default_width
        self.default_height = default_height

    async def run(self, prompt: str, width: int | None = None, height: int | None = None,
                  filename: str | None = None) -> str:
        width = width or self.default_width
        height = height or self.default_height
        try:
            data = await self.provider.generate(prompt, width, height)
        except httpx.TransportError as e:
            raise ToolError(f"Image generation failed (offline?): {e}") from e

        if not filename:
            safe = "".join(c if c.isalnum() or c in "-_" else "-" for c in prompt[:30]).strip("-")
            filename = f"gem-{safe or 'image'}-{int(time.time())}.png"
        if not filename.lower().endswith((".png", ".jpg", ".jpeg", ".webp")):
            filename += ".png"
        path = os.path.join(self.artifacts_dir, filename)
        with open(path, "wb") as fh:
            fh.write(data)

        # Register as an artifact (best-effort; avoid circular import).
        try:
            from .artifacts import ArtifactsTool
            ArtifactsTool.register_sync(
                self.artifacts_dir, name=filename, kind="image",
                path=path, meta={"prompt": prompt, "width": width, "height": height},
            )
        except Exception:
            pass

        return f"Image generated and saved: {filename} ({len(data)} bytes, {width}x{height})"
