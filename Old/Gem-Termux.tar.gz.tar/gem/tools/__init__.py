"""Gem tools package.

Tools are the agent's hands. Each tool is a self-contained, security-checked
callable registered in the registry. The agent loop discovers tools via the
registry and never imports a concrete tool directly.
"""
from .registry import Tool, ToolRegistry, registry, get_tool_schemas
from .shell import ShellTool
from .files import FilesTool
from .web import WebTool
from .image import ImageTool
from .git import GitTool
from .archive import ArchiveTool
from .artifacts import ArtifactsTool

__all__ = [
    "Tool",
    "ToolRegistry",
    "registry",
    "get_tool_schemas",
    "ShellTool",
    "FilesTool",
    "WebTool",
    "ImageTool",
    "GitTool",
    "ArchiveTool",
    "ArtifactsTool",
]
