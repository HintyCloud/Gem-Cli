"""Artifacts tool - register and list build outputs (code, images, docs, zips).

Artifacts live in ``data/artifacts`` and are described by a small JSON index so
the Web UI can list and offer downloads. This tool both records new artifacts
(the image tool calls into it) and lets the agent query them.
"""
from __future__ import annotations

import json
import os
import time
from typing import Any

from ..exceptions import ToolError
from .registry import Tool


def _index_path(artifacts_dir: str) -> str:
    return os.path.join(artifacts_dir, "index.json")


def _load_index(artifacts_dir: str) -> list[dict[str, Any]]:
    p = _index_path(artifacts_dir)
    if not os.path.exists(p):
        return []
    try:
        with open(p, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (json.JSONDecodeError, OSError):
        return []


def _save_index(artifacts_dir: str, index: list[dict[str, Any]]) -> None:
    p = _index_path(artifacts_dir)
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(index, fh, indent=2)


class ArtifactsTool(Tool):
    name = "artifacts"
    description = (
        "Register or list project artifacts (generated code, images, documents, "
        "archives, builds). Actions: list, register, get."
    )
    parameters = {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["list", "register", "get"]},
            "name": {"type": "string", "description": "Artifact name (register/get)."},
            "kind": {"type": "string", "description": "Kind: code, image, document, archive, build, other."},
            "path": {"type": "string", "description": "Filesystem path of the artifact (register)."},
            "meta": {"type": "object", "description": "Extra metadata."},
        },
        "required": ["action"],
    }

    def __init__(self, artifacts_dir: str) -> None:
        self.artifacts_dir = os.path.abspath(artifacts_dir)
        os.makedirs(self.artifacts_dir, exist_ok=True)

    @staticmethod
    def register_sync(artifacts_dir: str, name: str, kind: str, path: str,
                      meta: dict[str, Any] | None = None) -> dict[str, Any]:
        index = _load_index(artifacts_dir)
        entry = {
            "id": f"art-{len(index) + 1:04d}",
            "name": name,
            "kind": kind,
            "path": path,
            "size": os.path.getsize(path) if os.path.exists(path) else 0,
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "meta": meta or {},
        }
        index.append(entry)
        _save_index(artifacts_dir, index)
        return entry

    async def run(self, action: str, name: str | None = None, kind: str = "other",
                  path: str | None = None, meta: dict[str, Any] | None = None) -> str:
        if action == "list":
            index = _load_index(self.artifacts_dir)
            if not index:
                return "No artifacts registered."
            lines = [f"{a['id']}\t{a['kind']}\t{a['name']}\t{a['size']}B\t{a['created_at']}" for a in index]
            return "\n".join(lines)

        if action == "register":
            if not name or not path:
                raise ToolError("register requires name and path")
            entry = self.register_sync(self.artifacts_dir, name=name, kind=kind, path=path, meta=meta)
            return f"Registered artifact {entry['id']}: {name}"

        if action == "get":
            index = _load_index(self.artifacts_dir)
            for a in index:
                if a["name"] == name or a["id"] == name:
                    return json.dumps(a, indent=2)
            raise ToolError(f"Artifact not found: {name}")

        raise ToolError(f"Unknown artifacts action: {action}")
