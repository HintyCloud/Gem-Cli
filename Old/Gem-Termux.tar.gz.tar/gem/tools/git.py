"""Git tool - lightweight git operations within a project workspace.

Wraps the ``git`` CLI for init, status, add, commit, log, diff. Uses the shell
tool's subprocess approach but scoped to git only. Returns structured text.
"""
from __future__ import annotations

import asyncio
import os
import shutil
from typing import Any

from ..exceptions import ToolError
from .registry import Tool


class GitTool(Tool):
    name = "git"
    description = (
        "Run git operations in the project workspace: init, status, add, "
        "commit, log, diff, branch. Useful for versioning agent-created work."
    )
    parameters = {
        "type": "object",
        "properties": {
            "args": {"type": "string", "description": "Arguments passed to git (e.g. 'status', 'add .')."},
        },
        "required": ["args"],
    }

    def __init__(self, workspace: str) -> None:
        self.workspace = os.path.abspath(workspace)

    async def run(self, args: str) -> str:
        if not shutil.which("git"):
            raise ToolError("git is not installed")
        # Block obviously dangerous git ops.
        banned = ["push --force", "reset --hard", "clean -fd"]
        if any(b in args for b in banned):
            raise ToolError(f"Blocked git args: {args}")
        proc = await asyncio.create_subprocess_exec(
            "git", *args.split(),
            cwd=self.workspace,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        out_b, err_b = await asyncio.wait_for(proc.communicate(), timeout=60)
        out = out_b.decode("utf-8", "replace")[:8000]
        err = err_b.decode("utf-8", "replace")[:4000]
        return f"$ git {args}\nexit: {proc.returncode}\n{out}\n{err}".strip()
