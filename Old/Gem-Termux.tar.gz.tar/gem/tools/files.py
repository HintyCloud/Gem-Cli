"""File tools - create/read/edit/list/move/copy/remove within the workspace.

All paths are validated against the workspace boundary to prevent traversal.
Implements the full set: create, read, edit (find/replace), list, move, copy,
remove, mkdir, exists, metadata.
"""
from __future__ import annotations

import os
import shutil
import time
from typing import Any

from ..exceptions import PathSecurityError, ToolError
from .registry import Tool

MAX_READ = 200_000  # chars


class FilesTool(Tool):
    name = "files"
    description = (
        "Read, create, edit and manage files inside the project workspace. "
        "Actions: read, write, edit (find/replace), list, mkdir, move, copy, "
        "remove, exists, metadata. All paths are workspace-bound."
    )
    parameters = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["read", "write", "edit", "list", "mkdir", "move", "copy", "remove", "exists", "metadata"],
                "description": "The file operation to perform.",
            },
            "path": {"type": "string", "description": "Path relative to the workspace."},
            "content": {"type": "string", "description": "For write: full file content."},
            "old_str": {"type": "string", "description": "For edit: text to find."},
            "new_str": {"type": "string", "description": "For edit: replacement text."},
            "dest": {"type": "string", "description": "For move/copy: destination path."},
        },
        "required": ["action", "path"],
    }

    def __init__(self, workspace: str) -> None:
        self.workspace = os.path.abspath(workspace)

    def _resolve(self, path: str) -> str:
        # Disallow absolute paths that escape; allow only within workspace.
        full = os.path.abspath(os.path.join(self.workspace, path))
        if full != self.workspace and not full.startswith(self.workspace + os.sep):
            raise PathSecurityError(path, "resolves outside the workspace")
        return full

    async def run(self, action: str, path: str, content: str | None = None,
                  old_str: str | None = None, new_str: str | None = None,
                  dest: str | None = None) -> str:
        full = self._resolve(path)
        if action == "read":
            if not os.path.isfile(full):
                raise ToolError(f"File not found: {path}")
            with open(full, "r", encoding="utf-8", errors="replace") as fh:
                data = fh.read(MAX_READ + 1)
            truncated = len(data) > MAX_READ
            return data[:MAX_READ] + ("\n...[truncated]" if truncated else "")

        if action == "write":
            os.makedirs(os.path.dirname(full), exist_ok=True)
            with open(full, "w", encoding="utf-8") as fh:
                fh.write(content or "")
            return f"Wrote {len(content or '')} bytes to {path}"

        if action == "edit":
            if not os.path.isfile(full):
                raise ToolError(f"File not found: {path}")
            with open(full, "r", encoding="utf-8") as fh:
                data = fh.read()
            if old_str is None or old_str not in data:
                raise ToolError(f"old_str not found in {path}")
            count = data.count(old_str)
            data = data.replace(old_str, new_str or "")
            with open(full, "w", encoding="utf-8") as fh:
                fh.write(data)
            return f"Edited {path}: replaced {count} occurrence(s)"

        if action == "list":
            if not os.path.isdir(full):
                raise ToolError(f"Not a directory: {path}")
            entries = []
            for name in sorted(os.listdir(full)):
                p = os.path.join(full, name)
                kind = "dir" if os.path.isdir(p) else "file"
                size = os.path.getsize(p) if os.path.isfile(p) else 0
                entries.append(f"{kind}\t{size}\t{name}")
            return "\n".join(entries) or "(empty)"

        if action == "mkdir":
            os.makedirs(full, exist_ok=True)
            return f"Created directory {path}"

        if action == "move":
            if dest is None:
                raise ToolError("move requires 'dest'")
            d = self._resolve(dest)
            os.makedirs(os.path.dirname(d), exist_ok=True)
            shutil.move(full, d)
            return f"Moved {path} -> {dest}"

        if action == "copy":
            if dest is None:
                raise ToolError("copy requires 'dest'")
            d = self._resolve(dest)
            os.makedirs(os.path.dirname(d), exist_ok=True)
            if os.path.isdir(full):
                shutil.copytree(full, d)
            else:
                shutil.copy2(full, d)
            return f"Copied {path} -> {dest}"

        if action == "remove":
            if not os.path.exists(full):
                raise ToolError(f"Not found: {path}")
            if os.path.isdir(full):
                shutil.rmtree(full)
            else:
                os.remove(full)
            return f"Removed {path}"

        if action == "exists":
            return f"{'true' if os.path.exists(full) else 'false'}"

        if action == "metadata":
            if not os.path.exists(full):
                raise ToolError(f"Not found: {path}")
            st = os.stat(full)
            return (
                f"path: {path}\n"
                f"type: {'dir' if os.path.isdir(full) else 'file'}\n"
                f"size: {st.st_size}\n"
                f"modified: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(st.st_mtime))}\n"
                f"mode: {oct(st.st_mode)}"
            )

        raise ToolError(f"Unknown files action: {action}")
