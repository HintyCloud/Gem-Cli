"""Archive tool - create and extract zip/tar archives in the workspace."""
from __future__ import annotations

import os
import tarfile
import zipfile
from typing import Any

from ..exceptions import PathSecurityError, ToolError
from .registry import Tool


class ArchiveTool(Tool):
    name = "archive"
    description = (
        "Create or extract archives (zip, tar.gz) within the workspace. "
        "Actions: create, extract. All paths validated against the workspace."
    )
    parameters = {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["create", "extract"]},
            "archive": {"type": "string", "description": "Archive path (relative to workspace)."},
            "target": {"type": "string", "description": "For create: dir/file to archive. For extract: dest dir."},
            "format": {"type": "string", "enum": ["zip", "tar.gz"], "default": "zip"},
        },
        "required": ["action", "archive"],
    }

    def __init__(self, workspace: str) -> None:
        self.workspace = os.path.abspath(workspace)

    def _resolve(self, path: str) -> str:
        full = os.path.abspath(os.path.join(self.workspace, path))
        if full != self.workspace and not full.startswith(self.workspace + os.sep):
            raise PathSecurityError(path, "resolves outside the workspace")
        return full

    async def run(self, action: str, archive: str, target: str | None = None,
                  format: str = "zip") -> str:
        arc_path = self._resolve(archive)
        if action == "create":
            if not target:
                raise ToolError("create requires 'target'")
            src = self._resolve(target)
            if not os.path.exists(src):
                raise ToolError(f"Not found: {target}")
            os.makedirs(os.path.dirname(arc_path), exist_ok=True)
            if format == "zip":
                with zipfile.ZipFile(arc_path, "w", zipfile.ZIP_DEFLATED) as zf:
                    if os.path.isdir(src):
                        for root, _, files in os.walk(src):
                            for f in files:
                                fp = os.path.join(root, f)
                                zf.write(fp, os.path.relpath(fp, src))
                    else:
                        zf.write(src, os.path.basename(src))
            else:
                with tarfile.open(arc_path, "w:gz") as tf:
                    tf.add(src, arcname=os.path.basename(src))
            return f"Created archive {archive} ({os.path.getsize(arc_path)} bytes)"

        if action == "extract":
            dest = self._resolve(target or ".")
            os.makedirs(dest, exist_ok=True)
            if archive.endswith(".zip"):
                with zipfile.ZipFile(arc_path) as zf:
                    # prevent path traversal in zip entries
                    for member in zf.namelist():
                        mp = os.path.abspath(os.path.join(dest, member))
                        if not mp.startswith(dest + os.sep) and mp != dest:
                            raise PathSecurityError(member, "zip entry escapes dest")
                    zf.extractall(dest)
            else:
                with tarfile.open(arc_path, "r:*") as tf:
                    tf.extractall(dest)
            return f"Extracted {archive} -> {target or '.'}"

        raise ToolError(f"Unknown archive action: {action}")
