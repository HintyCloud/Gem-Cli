"""Web tool - structured web search.

The implementation is substitutable: it calls a search backend and returns
structured results. The default backend uses the DuckDuckGo HTML endpoint (no
API key required) so the tool works out-of-the-box and offline tests can mock
``_search``. The agent loop never mixes web search logic with its own state.
"""
from __future__ import annotations

import re
from typing import Any
from urllib.parse import quote_plus

import httpx

from ..exceptions import ToolError
from .registry import Tool


class WebTool(Tool):
    name = "web_search"
    description = (
        "Search the web and return structured results (title, url, snippet). "
        "Use for up-to-date information. Returns an error when offline."
    )
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "The search query."},
            "limit": {"type": "integer", "description": "Max results.", "default": 5},
        },
        "required": ["query"],
    }

    async def _search(self, query: str, limit: int) -> list[dict[str, str]]:
        url = f"https://html.duckduckgo.com/html/?q={quote_plus(query)}"
        headers = {"User-Agent": "Mozilla/5.0 (compatible; GemAgent/1.0)"}
        async with httpx.AsyncClient(timeout=20.0, follow_redirects=True) as client:
            resp = await client.get(url, headers=headers)
        if resp.status_code != 200:
            raise ToolError(f"Search HTTP {resp.status_code}")
        html = resp.text
        results: list[dict[str, str]] = []
        # Lightweight HTML scraping of result blocks.
        blocks = re.findall(r'<a[^>]+class="result__a"[^>]*>(.*?)</a>.*?<a[^>]+class="result__snippet"[^>]*>(.*?)</a>', html, re.S)
        seen = set()
        for title, snippet in blocks:
            t = re.sub(r"<[^>]+>", "", title).strip()
            s = re.sub(r"<[^>]+>", "", snippet).strip()
            if t and t not in seen:
                seen.add(t)
                results.append({"title": t, "snippet": s})
                if len(results) >= limit:
                    break
        return results

    async def run(self, query: str, limit: int = 5) -> str:
        try:
            results = await self._search(query, limit)
        except httpx.TransportError as e:
            raise ToolError(f"Web search failed (offline?): {e}") from e
        if not results:
            return f"No results for: {query}"
        out = [f"Web search: {query}"]
        for i, r in enumerate(results, 1):
            out.append(f"{i}. {r['title']}\n   {r['snippet']}")
        return "\n".join(out)
