"""Shell tool - execute commands inside the workspace sandbox.

Security:
  * Commands run with ``cwd`` set to the active project workspace.
  * A denylist blocks obviously destructive commands (rm -rf /, mkfs, dd to disk,
    shutdown, fork bombs) unless explicitly allowed.
  * Process tree is killed on timeout.
  * Output is truncated to keep context small.
  * Secrets in the environment are redacted from output.

Returns stdout, stderr, exit_code, duration, status, timed_out.
"""
from __future__ import annotations

import asyncio
import os
import re
import shlex
import time
from typing import Any

from ..exceptions import CommandBlockedError, ToolError
from .registry import Tool

# Commands that are flat-out blocked (destructive / system-level).
_BLOCKED = [
    re.compile(r"\brm\s+-rf?\s+/(?:\s|$)"),
    re.compile(r"\brm\s+-rf?\s+/\*"),
    re.compile(r"\bmkfs\b"),
    re.compile(r"\bdd\b.*\bof=/dev/(?:sd|nvme|hd|disk)"),
    re.compile(r"\bshutdown\b"),
    re.compile(r"\breboot\b"),
    re.compile(r"\bhalt\b"),
    re.compile(r":\(\)\s*\{.*\}"),  # fork bomb
    re.compile(r"\bchmod\s+-R\s+777\s+/\s*$"),
]

# Patterns whose output may leak secrets.
_SECRET_PATTERNS = [
    re.compile(r"(sk-[A-Za-z0-9]{10,})"),
    re.compile(r"(AIza[A-Za-z0-9_\-]{20,})"),
    re.compile(r"(gh[pousr]_[A-Za-z0-9]{20,})"),
    re.compile(r"(AKIA[0-9A-Z]{16})"),
]

MAX_OUTPUT = 20_000  # chars per stream


def _redact(text: str) -> str:
    for pat in _SECRET_PATTERNS:
        text = pat.sub(lambda m: m.group(1)[:6] + "...REDACTED", text)
    return text


def _is_blocked(cmd: str) -> str | None:
    for pat in _BLOCKED:
        if pat.search(cmd):
            return "destructive/system command denied by safety policy"
    return None


class ShellTool(Tool):
    name = "shell"
    description = (
        "Execute a shell command inside the current project workspace. "
        "Returns stdout, stderr, exit_code, duration_ms and timed_out. "
        "Use this to run builds, tests, git and inspect the project."
    )
    parameters = {
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "The shell command to run."},
            "timeout": {"type": "integer", "description": "Max seconds before killing the process.", "default": 120},
            "cwd": {"type": "string", "description": "Subdirectory of the workspace to run in. Defaults to workspace root."},
        },
        "required": ["command"],
    }

    def __init__(self, workspace: str, default_timeout: int = 120, allow_destructive: bool = False) -> None:
        self.workspace = os.path.abspath(workspace)
        self.default_timeout = default_timeout
        self.allow_destructive = allow_destructive

    async def run(self, command: str, timeout: int | None = None, cwd: str | None = None) -> str:
        if not self.allow_destructive:
            blocked = _is_blocked(command)
            if blocked:
                raise CommandBlockedError(command, blocked)

        work_dir = self.workspace
        if cwd:
            candidate = os.path.abspath(os.path.join(self.workspace, cwd))
            if not (candidate == self.workspace or candidate.startswith(self.workspace + os.sep)):
                raise ToolError(f"cwd '{cwd}' escapes the workspace")
            work_dir = candidate

        timeout = timeout or self.default_timeout
        start = time.time()
        timed_out = False

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=work_dir,
                env={**os.environ, "CI": "1"},
            )
        except FileNotFoundError as e:
            raise ToolError(f"Failed to spawn shell: {e}") from e

        try:
            stdout_b, stderr_b = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            timed_out = True
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            await proc.wait()
            stdout_b, stderr_b = await proc.communicate()

        stdout = _redact(stdout_b.decode("utf-8", "replace"))[:MAX_OUTPUT]
        stderr = _redact(stderr_b.decode("utf-8", "replace"))[:MAX_OUTPUT]
        duration_ms = int((time.time() - start) * 1000)

        status = "timeout" if timed_out else ("success" if proc.returncode == 0 else "error")
        # Redact the command echo too - it may contain secrets the user passed.
        safe_cmd = _redact(command)
        return (
            f"$ {safe_cmd}\n"
            f"exit_code: {proc.returncode if proc.returncode is not None else -1}\n"
            f"duration_ms: {duration_ms}\n"
            f"status: {status}\n"
            f"timed_out: {timed_out}\n"
            f"--- stdout ---\n{stdout}\n"
            f"--- stderr ---\n{stderr}"
        )
