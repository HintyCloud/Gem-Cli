"""Tool base class and registry.

A Tool exposes:
  * ``schema``  - the OpenAI function-calling JSON schema the model sees.
  * ``run``     - the actual (async) execution.

The global ``registry`` is pre-populated with the built-in tools and is the
single place the agent loop asks for available tools.
"""
from __future__ import annotations

import inspect
from abc import ABC, abstractmethod
from typing import Any, Callable, Awaitable

from ..exceptions import ToolError


class Tool(ABC):
    """Abstract tool. Subclasses set ``name``/``description``/``parameters``."""

    name: str = "tool"
    description: str = ""
    # JSON-schema for the tool's arguments (OpenAI function-calling shape).
    parameters: dict[str, Any] = {"type": "object", "properties": {}, "required": []}

    @abstractmethod
    async def run(self, **kwargs: Any) -> str:
        """Execute the tool and return a string result for the model."""

    @property
    def schema(self) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        self._tools[tool.name] = tool

    def register_callable(
        self, name: str, fn: Callable[..., Awaitable[str]], description: str, parameters: dict[str, Any]
    ) -> None:
        schema = {"type": "function", "function": {"name": name, "description": description, "parameters": parameters}}

        class _CallableTool(Tool):
            pass

        t = _CallableTool()
        t.name = name
        t.description = description
        t.parameters = parameters
        t.run = fn  # type: ignore[assignment]
        t.schema = schema  # type: ignore[misc]
        self._tools[name] = t

    def get(self, name: str) -> Tool:
        if name not in self._tools:
            raise ToolError(f"Unknown tool: {name}")
        return self._tools[name]

    def names(self) -> list[str]:
        return sorted(self._tools.keys())

    def all(self) -> list[Tool]:
        return [self._tools[n] for n in self.names()]

    def schemas(self) -> list[dict[str, Any]]:
        return [t.schema for t in self.all()]

    async def execute(self, name: str, arguments: dict[str, Any]) -> str:
        tool = self.get(name)
        try:
            # Support both sync and async run via inspect.
            res = tool.run(**arguments)
            if inspect.isawaitable(res):
                res = await res
            return res
        except ToolError:
            raise
        except Exception as e:  # surface as a tool error with context
            raise ToolError(f"Tool '{name}' failed: {e}") from e


# Global registry used by the agent loop and the API.
registry = ToolRegistry()


def get_tool_schemas(names: list[str] | None = None) -> list[dict[str, Any]]:
    """Return OpenAI function-calling schemas for the requested tools (or all)."""
    if names is None:
        return registry.schemas()
    return [registry.get(n).schema for n in names]
