"""Structured logging - writes to data/logs/, never dumps huge traces to UI."""
from __future__ import annotations

import logging
import time
from pathlib import Path

_logger: logging.Logger | None = None


def get_logger() -> logging.Logger:
    global _logger
    if _logger is not None:
        return _logger
    from .config import get_config
    cfg = get_config()
    log_dir = cfg.logs_path
    log_file = log_dir / f"gem-{time.strftime('%Y%m%d')}.log"
    logger = logging.getLogger("gem")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    # A conservative stream handler so the server console stays readable.
    ch = logging.StreamHandler()
    ch.setLevel(logging.WARNING)
    ch.setFormatter(fmt)
    logger.addHandler(ch)
    _logger = logger
    return logger
