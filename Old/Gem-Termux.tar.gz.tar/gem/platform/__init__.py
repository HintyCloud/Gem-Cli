"""Gem platform package - cross-platform detection and adapters."""
from .detect import detect_platform, Platform, current_platform

__all__ = ["detect_platform", "Platform", "current_platform"]
