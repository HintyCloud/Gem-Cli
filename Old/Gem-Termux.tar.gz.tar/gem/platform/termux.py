"""Termux / Android platform helpers.

Important: Gem never claims Android guarantees infinite background execution.
Termux can keep a process alive while it stays foregrounded / via ``termux-wake-lock``.
Gem is designed to RECOVER interrupted tasks from checkpoints instead.
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path


def default_shell() -> str:
    return os.environ.get("SHELL", os.environ.get("PREFIX", "/data/data/com.termux/files/usr") + "/bin/bash")


def termux_prefix() -> str:
    return os.environ.get("PREFIX", "/data/data/com.termux/files/usr")


def home() -> Path:
    return Path(os.environ.expanduser("~"))


def shared_storage() -> Path | None:
    """Return the shared downloads dir if ``termux-setup-storage`` was run."""
    downloads = home() / "storage" / "downloads"
    if downloads.exists():
        return downloads
    return None


def wake_lock_available() -> bool:
    return shutil.which("termux-wake-lock") is not None


def open_url(url: str) -> list[str]:
    if shutil.which("termux-open-url"):
        return ["termux-open-url", url]
    return ["am", "start", "-a", "android.intent.action.VIEW", "-d", url]
