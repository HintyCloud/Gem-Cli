"""Detect the host platform (Linux / Windows / Termux-Android).

Gem must run on Linux, Windows and Termux/Android (ARM32-compat + ARM64) without
assuming systemd, sudo, Docker or a traditional Linux filesystem. Detection is
dynamic so the SAME core works everywhere.
"""
from __future__ import annotations

import os
import platform
import shutil
import sys
from dataclasses import dataclass
from enum import Enum


class Platform(str, Enum):
    LINUX = "linux"
    WINDOWS = "windows"
    TERMUX = "termux"
    DARWIN = "darwin"
    UNKNOWN = "unknown"


@dataclass
class PlatformInfo:
    platform: Platform
    system: str
    machine: str
    is_android: bool
    is_termux: bool
    shell: str
    home: str
    prefix: str
    has_sudo: bool
    has_docker: bool
    has_systemd: bool

    @property
    def is_windows(self) -> bool:
        return self.platform == Platform.WINDOWS

    @property
    def is_linux(self) -> bool:
        return self.platform == Platform.LINUX

    @property
    def is_arm32(self) -> bool:
        m = self.machine.lower()
        return m in ("armv7l", "armv8l", "arm", "aarch32")

    @property
    def is_arm64(self) -> bool:
        return self.machine.lower() in ("aarch64", "arm64")


def _is_termux() -> bool:
    # Termux sets PREFIX and a distinctive path; also the termux-info binary exists.
    if os.environ.get("PREFIX", "").startswith("/data/data/com.termux"):
        return True
    return shutil.which("termux-info") is not None


def detect_platform() -> PlatformInfo:
    system = platform.system().lower()
    machine = platform.machine().lower()
    is_termux = _is_termux()
    is_android = is_termux or "ANDROID_ROOT" in os.environ

    if is_termux:
        plat = Platform.TERMUX
    elif system == "windows":
        plat = Platform.WINDOWS
    elif system == "linux":
        plat = Platform.LINUX
    elif system == "darwin":
        plat = Platform.DARWIN
    else:
        plat = Platform.UNKNOWN

    # Shell preference: bash on unix, cmd/powershell on windows.
    if plat == Platform.WINDOWS:
        shell = os.environ.get("COMSPEC", "cmd.exe")
    else:
        shell = os.environ.get("SHELL") or shutil.which("bash") or "/bin/sh"

    home = os.path.expanduser("~")
    prefix = os.environ.get("PREFIX", "/usr" if plat != Platform.WINDOWS else os.environ.get("LOCALAPPDATA", home))

    has_sudo = shutil.which("sudo") is not None and plat != Platform.TERMUX
    has_docker = shutil.which("docker") is not None
    has_systemd = (
        plat == Platform.LINUX
        and os.path.exists("/run/systemd/system")
    )

    return PlatformInfo(
        platform=plat,
        system=system,
        machine=machine,
        is_android=is_android,
        is_termux=is_termux,
        shell=shell,
        home=home,
        prefix=prefix,
        has_sudo=has_sudo,
        has_docker=has_docker,
        has_systemd=has_systemd,
    )


_current: PlatformInfo | None = None


def current_platform() -> PlatformInfo:
    global _current
    if _current is None:
        _current = detect_platform()
    return _current
