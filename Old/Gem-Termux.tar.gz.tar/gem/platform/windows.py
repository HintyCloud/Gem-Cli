"""Windows-specific platform helpers. Gem does NOT assume Bash here."""
from __future__ import annotations

import os
import shutil


def default_shell() -> str:
    pwsh = shutil.which("pwsh") or shutil.which("powershell")
    return pwsh or os.environ.get("COMSPEC", "cmd.exe")


def open_url(url: str) -> list[str]:
    return ["cmd", "/c", "start", "", url]
