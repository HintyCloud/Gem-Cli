"""Linux-specific platform helpers."""
from __future__ import annotations

import shutil


def default_shell() -> str:
    return shutil.which("bash") or "/bin/sh"


def open_url(url: str) -> list[str]:
    for tool in ("xdg-open", "gio", "wslview"):
        if shutil.which(tool):
            return [tool, url]
    return ["xdg-open", url]
