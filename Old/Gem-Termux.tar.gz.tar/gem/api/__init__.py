"""Gem API - the public layer of the ecosystem.

Architecture:
    Client -> Gem API (this) -> Gem Core -> Agent -> Tools/Providers/Swarm

The API is reusable by the Web UI, the CLI and external clients. It exposes
chat (with SSE streaming), jobs, projects, memory, history, agents, models,
tools, images and artifacts over a modern HTTP API.
"""
from .app import create_app, app

__all__ = ["create_app", "app"]
