"""Simple token auth for the Gem API.

A single shared token read from ``GEM_API_TOKEN`` env var or
``config/secrets.toml``. When unset, auth is disabled (local-only default).
The server binds to 127.0.0.1 by default so this is safe for local use; remote
deployment must set a token.
"""
from __future__ import annotations

import os
from typing import Any

from ..config import SECRETS_PATH, _load_toml


def get_api_token() -> str | None:
    env = os.environ.get("GEM_API_TOKEN")
    if env:
        return env
    secrets = _load_toml(SECRETS_PATH)
    return secrets.get("gem", {}).get("api_token")


def check_token(provided: str | None) -> bool:
    expected = get_api_token()
    if not expected:
        return True  # auth disabled locally
    return bool(provided) and provided == expected
