"""Gem API HTTP routes - chat, streaming, jobs, projects, memory, history,
agents, models, tools, images, artifacts.

All routes are JSON except the SSE stream and the artifact download.
"""
from __future__ import annotations

import asyncio
import json
import os
import time
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse, FileResponse, JSONResponse

from ..config import get_config
from ..exceptions import GemError, ProviderNotConfiguredError
from ..jobs.manager import JobManager
from ..jobs.recovery import recover_jobs
from ..memory.history import History, create_chat, delete_chat, list_chats, rename_chat
from ..memory.memory import Memory
from ..memory.search import search_history, search_memory
from ..platform.detect import current_platform
from ..providers.registry import get_provider, list_providers, try_get_provider
from ..runtime import build_memory, build_provider, build_tools, project_workspace
from ..tools.artifacts import _load_index
from ..agent.context import AgentContext
from ..agent.loop import AgentLoop

router = APIRouter()

# ---- module-level singletons (initialised in create_app) ----
_config = None
_memory: Memory | None = None
_job_manager: JobManager | None = None


def init_runtime() -> None:
    global _config, _memory, _job_manager
    _config = get_config()
    _memory = build_memory(_config)
    # Provider is optional at startup (so the API still serves offline).
    provider = try_get_provider()
    if provider is None:
        # Use a dummy registry; the API still works for non-LLM endpoints.
        _job_manager = None
        return
    tools = build_tools(_config, "_default")
    _job_manager = JobManager(
        jobs_dir=str(_config.jobs_path),
        chats_dir=str(_config.chats_path),
        checkpoints_dir=str(_config.checkpoints_path),
        memory=_memory,
        provider=provider,
        tools=tools,
    )
    recover_jobs(str(_config.jobs_path), _job_manager)


def _require_job_manager() -> JobManager:
    if _job_manager is None:
        raise HTTPException(503, "No provider configured. Set OPENCODE_API_KEY to enable agent jobs.")
    return _job_manager


# ===================== status =====================
@router.get("/status")
async def status() -> dict[str, Any]:
    provider = try_get_provider()
    plat = current_platform()
    return {
        "ok": True,
        "version": "1.0.0",
        "platform": {
            "name": plat.platform.value,
            "system": plat.system,
            "machine": plat.machine,
            "is_termux": plat.is_termux,
            "is_android": plat.is_android,
            "shell": plat.shell,
        },
        "provider": provider.describe() if provider else {"configured": False, "name": _config.provider.name if _config else "opencode"},
        "providers_available": list_providers(),
        "model": _config.provider.model if _config else "longcat-2.0-free",
        "jobs_running": _job_manager.queue.running if _job_manager else 0,
        "jobs_pending": _job_manager.queue.pending if _job_manager else 0,
    }


# ===================== chat (SSE streaming) =====================
@router.post("/chat")
async def chat(req: Request) -> StreamingResponse:
    """Run an inline (non-job) agent turn with SSE streaming events."""
    body = await req.json()
    message = body.get("message", "")
    project = body.get("project", "default")
    chat_id = body.get("chat_id")
    use_swarm = bool(body.get("swarm", False))
    if not message:
        raise HTTPException(400, "message is required")

    cfg = get_config()
    provider = try_get_provider()
    if provider is None:
        raise HTTPException(503, "No provider configured. Set OPENCODE_API_KEY.")

    tools = build_tools(cfg, project)
    memory = build_memory(cfg)
    history = History(str(cfg.chats_path), chat_id)
    from ..agent.context import AgentContext
    context = AgentContext(project=project, checkpoints_dir=str(cfg.checkpoints_path))

    async def event_stream():
        try:
            if use_swarm:
                from ..swarm.coordinator import Supervisor
                sup = Supervisor(provider, tools, str(cfg.chats_path), memory,
                                 str(cfg.checkpoints_path), project)
                async for ev in sup.run(message):
                    yield f"data: {json.dumps(ev, ensure_ascii=False, default=str)}\n\n"
                yield "data: [DONE]\n\n"
                return

            loop = AgentLoop(provider, tools, history, memory, context,
                             max_iterations=cfg.agent.max_iterations)
            async for ev in loop.run(message):
                yield f"data: {json.dumps(ev, ensure_ascii=False, default=str)}\n\n"
            yield "data: [DONE]\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)}, ensure_ascii=False)}\n\n"
            yield "data: [DONE]\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


# ===================== OpenAI-compatible endpoint =====================
@router.post("/v1/chat/completions")
async def openai_completions(req: Request) -> Any:
    """OpenAI-compatible endpoint that routes through the Gem core -> OpenCode."""
    body = await req.json()
    provider = try_get_provider()
    if provider is None:
        raise HTTPException(503, "No provider configured.")
    from ..providers.base import Message
    messages = [Message(**m) if isinstance(m, dict) else m for m in body.get("messages", [])]
    system = None
    if messages and messages[0].role == "system":
        system = messages[0].content
        messages = messages[1:]
    tools = body.get("tools")
    stream = body.get("stream", False)

    if stream:
        async def sse():
            async for piece in provider.stream(messages, tools=tools, system=system,
                                               temperature=body.get("temperature", 0.3),
                                               max_tokens=body.get("max_tokens", 4096)):
                chunk = {"choices": [{"delta": {"content": piece}, "finish_reason": None}]}
                yield f"data: {json.dumps(chunk)}\n\n"
            yield "data: [DONE]\n\n"
        return StreamingResponse(sse(), media_type="text/event-stream")

    result = await provider.generate(messages, tools=tools, system=system,
                                     temperature=body.get("temperature", 0.3),
                                     max_tokens=body.get("max_tokens", 4096))
    return {
        "id": f"chatcmpl-{int(time.time())}",
        "object": "chat.completion",
        "model": provider.model,
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": result.content,
                        **({"tool_calls": [tc.to_dict() for tc in result.tool_calls]} if result.tool_calls else {})},
            "finish_reason": result.finish_reason,
        }],
        "usage": result.usage,
    }


# ===================== jobs =====================
@router.get("/jobs")
async def jobs_list() -> list[dict[str, Any]]:
    jm = _require_job_manager()
    return [j.to_dict() for j in jm.list()]


@router.post("/jobs")
async def jobs_create(req: Request) -> dict[str, Any]:
    jm = _require_job_manager()
    body = await req.json()
    task = body.get("task", "")
    project = body.get("project", "default")
    use_swarm = bool(body.get("swarm", False))
    if not task:
        raise HTTPException(400, "task is required")
    state = jm.create(task, project, use_swarm=use_swarm)
    return state.to_dict()


@router.get("/jobs/{job_id}")
async def jobs_get(job_id: str) -> dict[str, Any]:
    jm = _require_job_manager()
    return jm.get(job_id).to_dict()


@router.delete("/jobs/{job_id}")
async def jobs_cancel(job_id: str) -> dict[str, Any]:
    jm = _require_job_manager()
    return jm.cancel(job_id).to_dict()


@router.get("/jobs/{job_id}/stream")
async def jobs_stream(job_id: str) -> StreamingResponse:
    jm = _require_job_manager()
    q = jm.subscribe(job_id)

    async def event_stream():
        try:
            while True:
                try:
                    ev = await asyncio.wait_for(q.get(), timeout=25.0)
                except asyncio.TimeoutError:
                    yield f": keepalive\n\n"
                    continue
                yield f"data: {json.dumps(ev, ensure_ascii=False, default=str)}\n\n"
                if ev.get("type") == "status" and ev.get("status") in ("completed", "failed", "cancelled"):
                    break
        finally:
            jm.unsubscribe(job_id, q)

    return StreamingResponse(event_stream(), media_type="text/event-stream")


# ===================== chats / history =====================
@router.get("/chats")
async def chats_list() -> list[dict[str, Any]]:
    return list_chats(str(get_config().chats_path))


@router.post("/chats")
async def chats_create(req: Request) -> dict[str, Any]:
    body = await req.json()
    title = body.get("title", "New chat")
    h = create_chat(str(get_config().chats_path), title)
    return h.summary()


@router.get("/chats/{chat_id}")
async def chats_get(chat_id: str) -> dict[str, Any]:
    cfg = get_config()
    h = History(str(cfg.chats_path), chat_id)
    return {"id": h.chat_id, "title": h.title, "messages": [m.to_dict() for m in h.messages]}


@router.patch("/chats/{chat_id}")
async def chats_rename(chat_id: str, req: Request) -> dict[str, Any]:
    body = await req.json()
    h = rename_chat(str(get_config().chats_path), chat_id, body.get("title", "New chat"))
    return h.summary() if h else {}


@router.delete("/chats/{chat_id}")
async def chats_delete(chat_id: str) -> dict[str, Any]:
    ok = delete_chat(str(get_config().chats_path), chat_id)
    return {"deleted": ok}


@router.get("/search")
async def search(q: str) -> dict[str, Any]:
    cfg = get_config()
    return {
        "history": search_history(str(cfg.chats_path), q),
        "memory": search_memory(str(cfg.memory_path), q),
    }


# ===================== memory =====================
@router.get("/memory")
async def memory_list() -> list[dict[str, Any]]:
    return _memory.all() if _memory else []


@router.post("/memory")
async def memory_add(req: Request) -> dict[str, Any]:
    body = await req.json()
    return _memory.remember(body.get("text", ""), body.get("tags", []), body.get("project"))


@router.delete("/memory/{memory_id}")
async def memory_delete(memory_id: str) -> dict[str, Any]:
    return {"deleted": _memory.forget(memory_id) if _memory else False}


# ===================== projects =====================
@router.get("/projects")
async def projects_list() -> list[dict[str, Any]]:
    cfg = get_config()
    ws = cfg.workspace_path
    out = []
    if ws.exists():
        for name in sorted(ws.iterdir()):
            if name.is_dir() and not name.name.startswith("."):
                out.append({"name": name.name, "path": str(name)})
    return out


@router.post("/projects")
async def projects_create(req: Request) -> dict[str, Any]:
    body = await req.json()
    name = body.get("name", "")
    if not name or "/" in name or ".." in name:
        raise HTTPException(400, "invalid project name")
    cfg = get_config()
    p = cfg.workspace_path / name
    p.mkdir(parents=True, exist_ok=True)
    return {"name": name, "path": str(p)}


@router.get("/projects/{name}/files")
async def project_files(name: str, req: Request) -> dict[str, Any]:
    cfg = get_config()
    ws = project_workspace(cfg, name)
    rel = req.query_params.get("path", "")
    target = os.path.join(ws, rel) if rel else ws
    target = os.path.abspath(target)
    if not target.startswith(ws + os.sep) and target != ws:
        raise HTTPException(400, "path escapes project")
    if not os.path.exists(target):
        raise HTTPException(404, "not found")
    if os.path.isfile(target):
        with open(target, "r", encoding="utf-8", errors="replace") as fh:
            return {"type": "file", "path": rel, "content": fh.read()[:500000]}
    entries = []
    for n in sorted(os.listdir(target)):
        full = os.path.join(target, n)
        entries.append({"name": n, "type": "dir" if os.path.isdir(full) else "file",
                        "size": os.path.getsize(full) if os.path.isfile(full) else 0})
    return {"type": "dir", "path": rel, "entries": entries}


# ===================== providers / models =====================
@router.get("/providers")
async def providers_list() -> list[dict[str, Any]]:
    return [{"name": n} for n in list_providers()]


@router.get("/models")
async def models_list() -> list[dict[str, Any]]:
    cfg = get_config()
    return [{"id": cfg.provider.model, "provider": cfg.provider.name, "current": True}]


# ===================== tools / agents =====================
@router.get("/tools")
async def tools_list() -> list[dict[str, Any]]:
    cfg = get_config()
    tools = build_tools(cfg, "_default")
    return [{"name": t.name, "description": t.description} for t in tools.all()]


@router.get("/agents")
async def agents_list() -> list[dict[str, Any]]:
    from ..swarm.worker import AGENT_PROFILES
    return [{"name": p.name, "role": p.role} for p in AGENT_PROFILES.values()]


# ===================== artifacts =====================
@router.get("/artifacts")
async def artifacts_list() -> list[dict[str, Any]]:
    cfg = get_config()
    return _load_index(str(cfg.artifacts_path))


@router.get("/artifacts/{name}")
async def artifacts_download(name: str) -> Any:
    cfg = get_config()
    index = _load_index(str(cfg.artifacts_path))
    for a in index:
        if a["name"] == name:
            path = a["path"]
            if os.path.exists(path):
                return FileResponse(path, filename=name)
    raise HTTPException(404, "artifact not found")


# ===================== checkpoints =====================
@router.get("/checkpoints")
async def checkpoints_list() -> list[dict[str, Any]]:
    cfg = get_config()
    return AgentContext.list_checkpoints(str(cfg.checkpoints_path))
