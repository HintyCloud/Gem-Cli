"""WebSocket endpoint for live job/chat event streaming."""
from __future__ import annotations

import asyncio
import json
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from ..config import get_config
from ..jobs.manager import JobManager
from .routes import _job_manager

ws_router = APIRouter()


@ws_router.websocket("/ws/jobs/{job_id}")
async def ws_jobs(websocket: WebSocket, job_id: str) -> None:
    await websocket.accept()
    if _job_manager is None:
        await websocket.send_json({"type": "error", "content": "No provider configured."})
        await websocket.close()
        return
    q = _job_manager.subscribe(job_id)
    try:
        while True:
            try:
                ev = await asyncio.wait_for(q.get(), timeout=25.0)
            except asyncio.TimeoutError:
                await websocket.send_text(": keepalive")
                continue
            await websocket.send_text(json.dumps(ev, ensure_ascii=False, default=str))
            if ev.get("type") == "status" and ev.get("status") in ("completed", "failed", "cancelled"):
                break
    except WebSocketDisconnect:
        pass
    finally:
        _job_manager.unsubscribe(job_id, q)
        try:
            await websocket.close()
        except Exception:
            pass
