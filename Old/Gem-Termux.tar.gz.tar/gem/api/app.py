"""FastAPI application factory for the Gem API."""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routes import init_runtime, router
from .websocket import ws_router


def create_app() -> FastAPI:
    app = FastAPI(title="Gem API", version="1.0.0",
                  description="Public API layer of the Gem agentic AI ecosystem.")
    # CORS open for local dev (Web UI on :3000 calls API on :8000 via gateway).
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(router)
    app.include_router(ws_router)

    @app.on_event("startup")
    async def _startup() -> None:
        init_runtime()

    return app


# Module-level app for ``uvicorn gem.api.app:app``.
app = create_app()
