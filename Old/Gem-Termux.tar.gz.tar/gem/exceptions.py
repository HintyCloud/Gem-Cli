"""Gem exception hierarchy.

No bare ``except: pass`` anywhere in the codebase - errors carry useful context
through these typed exceptions.
"""


class GemError(Exception):
    """Base class for all Gem errors."""


class ConfigError(GemError):
    """Configuration missing or invalid."""


class ProviderError(GemError):
    """A provider failed to generate a response."""


class ProviderNotConfiguredError(ProviderError):
    """The selected provider has no credentials/endpoint configured."""

    def __init__(self, provider: str, hint: str = ""):
        msg = f"Provider '{provider}' is not configured."
        if hint:
            msg += f" {hint}"
        super().__init__(msg)


class ToolError(GemError):
    """A tool failed to execute."""


class SecurityError(ToolError):
    """A tool was asked to operate outside its allowed boundaries."""


class PathSecurityError(SecurityError):
    """Path traversal / workspace boundary violation."""

    def __init__(self, path: str, reason: str = "outside workspace"):
        super().__init__(f"Blocked path '{path}': {reason}")


class CommandBlockedError(SecurityError):
    """A shell command was blocked by the safety policy."""

    def __init__(self, cmd: str, reason: str):
        super().__init__(f"Blocked command '{cmd}': {reason}")


class TimeoutError(GemError):  # noqa: A001 - intentional shared name
    """An operation exceeded its time budget."""


class JobError(GemError):
    """A background job failed."""


class JobNotFoundError(JobError):
    def __init__(self, job_id: str):
        super().__init__(f"Job not found: {job_id}")


class SwarmError(GemError):
    """A swarm/subagent operation failed."""


class CheckpointError(GemError):
    """Checkpoint save/restore failed."""


class PlannerError(GemError):
    """Planning failed."""


class SandboxError(GemError):
    """Sandbox setup or execution failed."""
