"""Supervisor - orchestrates the swarm and consolidates results.

The supervisor takes a complex task, optionally asks the planner to decompose it,
dispatches subtasks to specialised workers (sequentially or in parallel), and
consolidates their outputs into a final result. It yields live events so the UI
can show the swarm working.

Architecture:
            Supervisor
                |
     +----------+----------+
     v          v          v
  Agent A    Agent B    Agent C
     |          |          |
   coding    research    tests
     |          |          |
     +----------+----------+
                v
           Supervisor
                v
             Result
"""
from __future__ import annotations

import asyncio
from typing import Any, AsyncIterator

from ..agent.context import AgentContext
from ..agent.planner import Planner
from ..config import get_config
from ..exceptions import SwarmError
from ..memory.history import History
from ..memory.memory import Memory
from ..providers.base import Provider
from ..tools.registry import ToolRegistry
from .pool import AgentPool
from .strategies import ParallelStrategy, SequentialStrategy, Strategy, TaskUnit
from .worker import AGENT_PROFILES


SWARM_PLAN_SYSTEM = (
    "You are Gem's swarm supervisor. Decompose the task into subtasks, each assigned to ONE "
    "specialised agent. Choose from: coder, researcher, tester, frontend, backend, reviewer, planner, "
    "minicoder, miniresearcher, minitester. Respond ONLY with JSON: "
    '{"parallel": true|false, "tasks": [{"agent": str, "task": str}]}. '
    "Prefer parallel=true only when subtasks are independent. Keep it minimal."
)


class Supervisor:
    def __init__(
        self,
        provider: Provider,
        tools: ToolRegistry,
        chats_dir: str,
        memory: Memory,
        checkpoints_dir: str,
        project: str,
        max_agents: int | None = None,
    ) -> None:
        self.provider = provider
        self.tools = tools
        self.chats_dir = chats_dir
        self.memory = memory
        self.checkpoints_dir = checkpoints_dir
        self.project = project
        self.pool = AgentPool(provider, tools, chats_dir, memory, checkpoints_dir, max_agents)
        self.planner = Planner(provider)

    async def plan_swarm(self, task: str) -> dict[str, Any]:
        """Ask the model for a swarm decomposition. Falls back to a single general task."""
        import json, re
        try:
            result = await self.provider.generate(
                [{"role": "user", "content": f"Task: {task}"}],
                system=SWARM_PLAN_SYSTEM,
                temperature=0.1,
                max_tokens=800,
            )
            match = re.search(r"\{[\s\S]*\}", result.content)
            if not match:
                raise ValueError("no json")
            data = json.loads(match.group(0))
            tasks = data.get("tasks", [])
            if not tasks:
                raise ValueError("no tasks")
            return {"parallel": bool(data.get("parallel", False)),
                    "tasks": [{"agent": t.get("agent", "general"), "task": t.get("task", "")} for t in tasks]}
        except Exception as e:
            # Fallback: one general agent handles the whole task.
            return {"parallel": False, "tasks": [{"agent": "general", "task": task}]}

    async def run(self, task: str, strategy: str = "auto") -> AsyncIterator[dict[str, Any]]:
        """Yield events as the swarm works through the task."""
        yield {"type": "swarm_start", "task": task}

        plan = await self.plan_swarm(task)
        yield {"type": "swarm_plan", "plan": plan}

        units = [TaskUnit(agent=t["agent"], task=t["task"]) for t in plan["tasks"]]
        if strategy == "auto":
            strat: Strategy = (ParallelStrategy(self.pool.max_agents) if plan["parallel"]
                               else SequentialStrategy())
        elif strategy == "parallel":
            strat = ParallelStrategy(self.pool.max_agents)
        else:
            strat = SequentialStrategy()

        results: list[dict[str, Any]] = []

        async def runner(agent: str, subtask: str) -> dict[str, Any]:
            profile = AGENT_PROFILES.get(agent, AGENT_PROFILES["general"])
            yield_event_prefix = f"[{profile.role}]"
            yield_msg = {"type": "agent_start", "agent": agent, "role": profile.role, "task": subtask}
            # We can't yield from here directly; collect and emit after.
            worker = self.pool.acquire(agent, self.project)
            try:
                res = await worker.run(subtask)
                res["prefix"] = yield_event_prefix
                return res
            finally:
                self.pool.release(worker)

        # Run sequentially so we can stream events; parallel uses gather inside strategy.
        if isinstance(strat, SequentialStrategy):
            for u in units:
                yield {"type": "agent_start", "agent": u.agent,
                       "role": AGENT_PROFILES.get(u.agent, AGENT_PROFILES["general"]).role, "task": u.task}
                res = await runner(u.agent, u.task)
                results.append(res)
                yield {"type": "agent_done", "agent": u.agent, "result": res["result"][:1000],
                       "status": res["status"]}
        else:
            yield {"type": "event", "content": f"Running {len(units)} agents in parallel..."}
            raw_results = await strat.execute(units, runner)
            for u, res in zip(units, raw_results):
                results.append(res)
                yield {"type": "agent_done", "agent": u.agent, "result": res["result"][:1000],
                       "status": res["status"]}

        # Consolidate.
        summary_parts = [f"- [{r['agent']}] {r['task'][:60]} => {r['result'][:200]}" for r in results]
        consolidation = "Swarm complete. Results:\n" + "\n".join(summary_parts)
        yield {"type": "swarm_done", "result": consolidation, "results": results}


async def run_swarm(
    provider: Provider, tools: ToolRegistry, task: str, project: str,
    chats_dir: str, memory: Memory, checkpoints_dir: str,
) -> dict[str, Any]:
    """Convenience: run a swarm and return the final consolidation."""
    sup = Supervisor(provider, tools, chats_dir, memory, checkpoints_dir, project)
    final = None
    async for ev in sup.run(task):
        if ev["type"] == "swarm_done":
            final = ev
    return final or {"result": "no result", "results": []}
