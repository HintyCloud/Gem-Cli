"""AgentPool - bounded pool of reusable worker contexts.

Keeps memory/context pressure low by reusing a bounded set of agent contexts
rather than spawning unbounded subagents. Respects the configured max_agents.
"""
from __future__ import annotations

from typing import Any

from ..config import get_config
from ..memory.history import History
from ..memory.memory import Memory
from ..providers.base import Provider
from ..tools.registry import ToolRegistry
from .worker import Worker, AGENT_PROFILES


class AgentPool:
    def __init__(
        self,
        provider: Provider,
        tools: ToolRegistry,
        chats_dir: str,
        memory: Memory,
        checkpoints_dir: str,
        max_agents: int | None = None,
    ) -> None:
        self.provider = provider
        self.tools = tools
        self.chats_dir = chats_dir
        self.memory = memory
        self.checkpoints_dir = checkpoints_dir
        cfg = get_config()
        self.max_agents = max_agents or cfg.swarm.max_agents
        self._active = 0

    def available_profiles(self) -> list[str]:
        return sorted(AGENT_PROFILES.keys())

    def acquire(self, profile: str, project: str) -> Worker:
        if self._active >= self.max_agents:
            from ..exceptions import SwarmError
            raise SwarmError(f"Agent pool exhausted (max {self.max_agents}). Wait for workers to finish.")
        self._active += 1
        from ..agent.context import AgentContext
        history = History(self.chats_dir)
        context = AgentContext(project=project, checkpoints_dir=self.checkpoints_dir)
        return Worker(profile, self.provider, self.tools, history, self.memory, context)

    def release(self, worker: Worker) -> None:
        if self._active > 0:
            self._active -= 1

    @property
    def active_count(self) -> int:
        return self._active
