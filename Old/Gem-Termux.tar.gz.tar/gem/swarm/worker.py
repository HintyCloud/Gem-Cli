"""Worker - a specialised subagent with its own scoped context.

Each agent profile has a real system prompt defining its responsibility. The
worker is a thin wrapper that runs an AgentLoop with a scoped context and a
profile-specific system prompt, then returns a consolidated result.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..agent.context import AgentContext
from ..agent.loop import AgentLoop
from ..memory.history import History
from ..memory.memory import Memory
from ..providers.base import Provider
from ..tools.registry import ToolRegistry


@dataclass
class AgentProfile:
    name: str
    role: str
    system_prompt: str
    tools: list[str] = field(default_factory=list)  # empty = all tools


AGENT_PROFILES: dict[str, AgentProfile] = {
    "general": AgentProfile(
        name="general", role="General Agent",
        system_prompt="You are a general-purpose Gem agent. Handle the task directly using the available tools.",
    ),
    "coder": AgentProfile(
        name="coder", role="Coding Agent",
        system_prompt=(
            "You are Gem's Coding Agent. You write, read and edit code with the files and shell tools. "
            "Always run builds/tests after changes and fix failures. Produce correct, minimal diffs."
        ),
        tools=["files", "shell", "git", "archive"],
    ),
    "researcher": AgentProfile(
        name="researcher", role="Research Agent",
        system_prompt=(
            "You are Gem's Research Agent. You investigate using web_search and file reading. "
            "Summarise findings concisely with sources. Do not write production code."
        ),
        tools=["web_search", "files"],
    ),
    "tester": AgentProfile(
        name="tester", role="Testing Agent",
        system_prompt=(
            "You are Gem's Testing Agent. You run tests via shell, interpret failures, and report "
            "pass/fail with details. Suggest fixes but do not apply them unless asked."
        ),
        tools=["shell", "files"],
    ),
    "frontend": AgentProfile(
        name="frontend", role="Frontend Agent",
        system_prompt=(
            "You are Gem's Frontend Agent. You build UI: HTML/CSS/JS, components, responsive layouts. "
            "Validate by opening/serving the page when possible."
        ),
        tools=["files", "shell", "image"],
    ),
    "backend": AgentProfile(
        name="backend", role="Backend Agent",
        system_prompt=(
            "You are Gem's Backend Agent. You build APIs, services and data layers. Run the server "
            "and smoke-test endpoints. Keep it simple and correct."
        ),
        tools=["files", "shell", "git"],
    ),
    "reviewer": AgentProfile(
        name="reviewer", role="Reviewer Agent",
        system_prompt=(
            "You are Gem's Reviewer Agent. You read the produced code/files and report issues: "
            "bugs, security, style, missing tests. Be specific and actionable."
        ),
        tools=["files", "shell"],
    ),
    "planner": AgentProfile(
        name="planner", role="Planner Agent",
        system_prompt=(
            "You are Gem's Planner Agent. Decompose the task into ordered, atomic steps and assign "
            "each to the right agent type. Output a concise plan."
        ),
    ),
    # Mini agents - lighter scope for small tasks.
    "minicoder": AgentProfile(
        name="minicoder", role="Mini Coder",
        system_prompt="You are a lightweight coding helper. Make the single requested change quickly.",
        tools=["files"],
    ),
    "minireviewer": AgentProfile(
        name="minireviewer", role="Mini Reviewer",
        system_prompt="You are a lightweight reviewer. Check the given file for obvious issues only.",
        tools=["files"],
    ),
    "miniresearcher": AgentProfile(
        name="miniresearcher", role="Mini Researcher",
        system_prompt="You are a lightweight researcher. Do a quick web search and summarise.",
        tools=["web_search"],
    ),
    "minitester": AgentProfile(
        name="minitester", role="Mini Tester",
        system_prompt="You are a lightweight tester. Run the given test command and report.",
        tools=["shell"],
    ),
}


class Worker:
    """A single specialised subagent."""

    def __init__(
        self,
        profile: str,
        provider: Provider,
        tools: ToolRegistry,
        history: History,
        memory: Memory,
        context: AgentContext,
        max_iterations: int = 20,
    ) -> None:
        self.profile_name = profile
        self.profile = AGENT_PROFILES.get(profile, AGENT_PROFILES["general"])
        self.loop = AgentLoop(
            provider=provider, tools=tools, history=history, memory=memory,
            context=context, max_iterations=max_iterations,
        )

    async def run(self, task: str) -> dict[str, Any]:
        """Run the worker on a scoped task. Returns a summary of activity."""
        events: list[dict[str, Any]] = []
        final = ""
        async for ev in self.loop.run(task):
            events.append(ev)
            if ev.get("type") == "done":
                final = ev.get("content", "")
        return {
            "agent": self.profile_name,
            "role": self.profile.role,
            "task": task,
            "result": final,
            "events": events,
            "status": self.loop.context.status,
        }
