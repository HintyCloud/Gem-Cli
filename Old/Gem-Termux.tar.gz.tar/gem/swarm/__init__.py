"""Gem swarm - real multi-agent orchestration.

A Supervisor coordinates specialised workers (coder, researcher, tester,
frontend, backend, reviewer, planner). Workers are real agent loops with their
own scoped context; results are consolidated by the supervisor. This is not a
list of names - each agent type has a distinct system prompt and role.
"""
from .coordinator import Supervisor, run_swarm
from .worker import Worker, AGENT_PROFILES
from .pool import AgentPool
from .strategies import Strategy, SequentialStrategy, ParallelStrategy

__all__ = [
    "Supervisor", "run_swarm", "Worker", "AGENT_PROFILES",
    "AgentPool", "Strategy", "SequentialStrategy", "ParallelStrategy",
]
