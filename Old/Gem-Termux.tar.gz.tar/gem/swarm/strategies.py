"""Strategies for running a swarm - sequential vs parallel.

A Strategy decides how a list of (agent, task) units is executed. Sequential
runs them one after another (good when later steps depend on earlier output).
Parallel runs them concurrently up to a max-agent limit, then consolidates.
"""
from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


@dataclass
class TaskUnit:
    agent: str
    task: str


class Strategy(ABC):
    @abstractmethod
    async def execute(self, units: list[TaskUnit], runner) -> list[dict[str, Any]]:
        ...


class SequentialStrategy(Strategy):
    async def execute(self, units, runner) -> list[dict[str, Any]]:
        results = []
        for u in units:
            results.append(await runner(u.agent, u.task))
        return results


class ParallelStrategy(Strategy):
    def __init__(self, max_concurrent: int = 4) -> None:
        self.sem = asyncio.Semaphore(max_concurrent)

    async def execute(self, units, runner) -> list[dict[str, Any]]:
        async def guarded(u):
            async with self.sem:
                return await runner(u.agent, u.task)
        return await asyncio.gather(*(guarded(u) for u in units))
