"""Gem CLI - a full alternative interface to the Web UI.

Commands:
  gem serve          start the persistent Gem API
  gem chat           interactive chat (with slash commands)
  gem project        manage projects (list/create)
  gem jobs           list/inspect background jobs
  gem models         show configured model
  gem providers      list providers
  gem tools          list available tools
  gem status         show system status

In-chat slash commands: /help /model /provider /chats /new /clear /status
                          /jobs /agents /tools /exit
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from typing import Any

from .config import PROJECT_ROOT, get_config
from .platform.detect import current_platform


def _cmd_status(args) -> int:
    cfg = get_config()
    plat = current_platform()
    from .providers.registry import list_providers, try_get_provider
    provider = try_get_provider()
    print("=== Gem Status ===")
    print(f"version: 1.0.0")
    print(f"platform: {plat.platform.value} ({plat.system}/{plat.machine}) termux={plat.is_termux}")
    print(f"workspace: {cfg.workspace_path}")
    print(f"data: {cfg.data_path}")
    print(f"provider: {cfg.provider.name}  model: {cfg.provider.model}")
    print(f"configured: {bool(provider)}")
    print(f"providers available: {', '.join(list_providers())}")
    print(f"server: {cfg.server.host}:{cfg.server.port}")
    return 0


def _cmd_serve(args) -> int:
    from .server import serve
    serve(args.host, args.port, reload=args.reload)
    return 0


def _cmd_providers(args) -> int:
    from .providers.registry import list_providers, try_get_provider
    cfg = get_config()
    print("Providers:")
    for p in list_providers():
        mark = " (current)" if p == cfg.provider.name else ""
        print(f"  - {p}{mark}")
    provider = try_get_provider()
    print(f"\nCurrent: {cfg.provider.name} / {cfg.provider.model}")
    print(f"Configured: {bool(provider)}")
    if not provider:
        print("Set OPENCODE_API_KEY env var or edit config/secrets.toml to enable.")
    return 0


def _cmd_models(args) -> int:
    cfg = get_config()
    print(f"Current model: {cfg.provider.model} (provider: {cfg.provider.name})")
    print("Configure via config/config.toml [provider].model")
    return 0


def _cmd_tools(args) -> int:
    from .runtime import build_tools
    cfg = get_config()
    tools = build_tools(cfg, "_default")
    print("Tools:")
    for t in tools.all():
        print(f"  - {t.name}: {t.description[:80]}")
    return 0


def _cmd_agents(args) -> int:
    from .swarm.worker import AGENT_PROFILES
    print("Agents:")
    for p in AGENT_PROFILES.values():
        print(f"  - {p.name:14s} {p.role}")
    return 0


def _cmd_projects(args) -> int:
    cfg = get_config()
    ws = cfg.workspace_path
    if args.action in (None, "list"):
        print("Projects:")
        for name in sorted(d.name for d in ws.iterdir() if d.is_dir() and not d.name.startswith(".")):
            print(f"  - {name}")
    elif args.action == "create":
        name = args.name
        if not name or "/" in name:
            print("invalid name")
            return 1
        (ws / name).mkdir(parents=True, exist_ok=True)
        print(f"Created project: {name}")
    return 0


def _cmd_jobs(args) -> int:
    cfg = get_config()
    from .jobs.state import JobStore
    store = JobStore(str(cfg.jobs_path))
    jobs = store.list_all()
    if not jobs:
        print("No jobs.")
        return 0
    for j in jobs:
        print(f"  {j.job_id}  {j.status.value:12s}  {j.project:12s}  {j.task[:50]}")
    return 0


async def _achat(message: str, project: str, chat_id: str | None, swarm: bool) -> None:
    from .agent.context import AgentContext
    from .agent.loop import AgentLoop
    from .memory.history import History
    from .memory.memory import Memory
    from .providers.registry import try_get_provider
    from .runtime import build_memory, build_tools
    cfg = get_config()
    provider = try_get_provider()
    if provider is None:
        print("[error] No provider configured. Set OPENCODE_API_KEY.")
        return
    tools = build_tools(cfg, project)
    memory = build_memory(cfg)
    history = History(str(cfg.chats_path), chat_id)
    context = AgentContext(project=project, checkpoints_dir=str(cfg.checkpoints_path))

    if swarm:
        from .swarm.coordinator import Supervisor
        sup = Supervisor(provider, tools, str(cfg.chats_path), memory,
                         str(cfg.checkpoints_path), project)
        async for ev in sup.run(message):
            _render_event(ev)
        return

    loop = AgentLoop(provider, tools, history, memory, context,
                     max_iterations=cfg.agent.max_iterations)
    async for ev in loop.run(message):
        _render_event(ev)


def _render_event(ev: dict[str, Any]) -> None:
    t = ev.get("type")
    if t == "user":
        print(f"\n[user] {ev['content']}")
    elif t == "plan":
        print("\n[plan]")
        for i, s in enumerate(ev["steps"], 1):
            print(f"  {i}. {s.get('title')} ({s.get('agent')})")
    elif t == "assistant":
        if ev.get("content"):
            print(f"\n[gem] {ev['content']}")
    elif t == "activity":
        print(f"  ... {ev['label']}")
    elif t == "tool_result" and ev.get("is_error"):
        print(f"  [tool error] {ev.get('content', '')[:200]}")
    elif t == "done":
        print(f"\n[done] {ev.get('content', '')[:500]}")
    elif t == "error":
        print(f"\n[error] {ev.get('content')}")


def _cmd_chat(args) -> int:
    import shlex
    cfg = get_config()
    project = args.project or "default"
    chat_id = args.chat
    print(f"Gem chat  (project={project})  type /help for commands, /exit to quit")
    while True:
        try:
            line = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if not line:
            continue
        if line.startswith("/"):
            cmd, *rest = shlex.split(line[1:])
            if cmd == "exit":
                return 0
            elif cmd == "help":
                print("Commands: /help /model /provider /chats /new /clear /status /jobs /agents /tools /exit")
            elif cmd == "model":
                print(f"model: {cfg.provider.model}")
            elif cmd == "provider":
                print(f"provider: {cfg.provider.name}")
            elif cmd == "new":
                chat_id = None
                print("Started a new chat.")
            elif cmd == "clear":
                chat_id = None
                print("Cleared.")
            elif cmd == "status":
                _cmd_status(None)
            elif cmd == "jobs":
                _cmd_jobs(None)
            elif cmd == "agents":
                _cmd_agents(None)
            elif cmd == "tools":
                _cmd_tools(None)
            elif cmd == "chats":
                from .memory.history import list_chats
                for c in list_chats(str(cfg.chats_path)):
                    print(f"  {c['id']}  {c['title']}  ({c['message_count']} msgs)")
            else:
                print(f"unknown command: /{cmd}")
            continue
        # Normal message -> run the agent.
        swarm = line.startswith("@swarm ")
        if swarm:
            line = line[len("@swarm "):]
        try:
            asyncio.run(_achat(line, project, chat_id, swarm))
        except KeyboardInterrupt:
            print("\n[interrupted]")
        except Exception as e:
            print(f"\n[error] {e}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="gem", description="Gem - agentic AI ecosystem")
    sub = p.add_subparsers(dest="command")

    sub.add_parser("status", help="show system status").set_defaults(func=_cmd_status)

    sp = sub.add_parser("serve", help="start the Gem API server")
    sp.add_argument("--host", default=None)
    sp.add_argument("--port", type=int, default=None)
    sp.add_argument("--reload", action="store_true")
    sp.set_defaults(func=_cmd_serve)

    sp = sub.add_parser("chat", help="interactive chat")
    sp.add_argument("--project", default="default")
    sp.add_argument("--chat", default=None, help="existing chat id")
    sp.set_defaults(func=_cmd_chat)

    sp = sub.add_parser("project", help="manage projects")
    sp.add_argument("action", nargs="?", default="list", choices=["list", "create"])
    sp.add_argument("name", nargs="?", default=None)
    sp.set_defaults(func=_cmd_projects)

    sub.add_parser("jobs", help="list jobs").set_defaults(func=_cmd_jobs)
    sub.add_parser("models", help="show model").set_defaults(func=_cmd_models)
    sub.add_parser("providers", help="list providers").set_defaults(func=_cmd_providers)
    sub.add_parser("tools", help="list tools").set_defaults(func=_cmd_tools)
    sub.add_parser("agents", help="list agents").set_defaults(func=_cmd_agents)

    return p


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    if not getattr(args, "command", None):
        parser.print_help()
        return 0
    return args.func(args) or 0


if __name__ == "__main__":
    sys.exit(main())
