"""Gem memory package.

Two distinct stores:
  * history  - the full conversation log per chat (data/chats/)
  * memory   - persistent facts the agent chose to remember (data/memory/)

We do NOT auto-promote every message to permanent memory. The agent decides what
is worth remembering, keeping memory small and relevant.
"""
from .history import History, ChatMessage, list_chats, create_chat, delete_chat, rename_chat
from .memory import Memory
from .search import search_history, search_memory

__all__ = [
    "History", "ChatMessage", "list_chats", "create_chat", "delete_chat", "rename_chat",
    "Memory", "search_history", "search_memory",
]
