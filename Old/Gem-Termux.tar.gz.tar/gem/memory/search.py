"""Search across history and memory."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def search_history(chats_dir: str, query: str, limit: int = 20) -> list[dict[str, Any]]:
    q = query.lower()
    hits: list[dict[str, Any]] = []
    d = Path(chats_dir)
    if not d.exists():
        return hits
    for f in d.glob("*.json"):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        chat_id = data.get("id", f.stem)
        title = data.get("title", f.stem)
        for i, m in enumerate(data.get("messages", [])):
            if q in (m.get("content") or "").lower():
                hits.append({
                    "chat_id": chat_id,
                    "title": title,
                    "index": i,
                    "role": m.get("role"),
                    "snippet": (m.get("content") or "")[:200],
                })
                if len(hits) >= limit:
                    return hits
    return hits


def search_memory(memory_dir: str, query: str, limit: int = 20) -> list[dict[str, Any]]:
    p = Path(memory_dir) / "memory.json"
    if not p.exists():
        return []
    try:
        entries = json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []
    q = query.lower()
    hits = [e for e in entries if q in (e.get("text") or "").lower() or any(q in t.lower() for t in e.get("tags", []))]
    return hits[:limit]
