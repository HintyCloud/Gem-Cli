"""Persistent memory - facts the agent chose to remember.

Stored as ``data/memory/memory.json``: a list of {id, text, tags, created_at}.
Unlike history (the full transcript), memory is small, curated and searched by
relevance. We never auto-dump the whole conversation into memory.
"""
from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any


class Memory:
    def __init__(self, memory_dir: str) -> None:
        self.memory_dir = Path(memory_dir)
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.memory_dir / "memory.json"
        self.entries: list[dict[str, Any]] = []
        self.load()

    def load(self) -> None:
        if self.path.exists():
            try:
                self.entries = json.loads(self.path.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                self.entries = []
        else:
            self.entries = []

    def save(self) -> None:
        self.path.write_text(json.dumps(self.entries, indent=2, ensure_ascii=False), encoding="utf-8")

    def remember(self, text: str, tags: list[str] | None = None, project: str | None = None) -> dict[str, Any]:
        entry = {
            "id": f"mem-{uuid.uuid4().hex[:8]}",
            "text": text,
            "tags": tags or [],
            "project": project,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        }
        self.entries.append(entry)
        self.save()
        return entry

    def forget(self, memory_id: str) -> bool:
        before = len(self.entries)
        self.entries = [e for e in self.entries if e["id"] != memory_id]
        if len(self.entries) != before:
            self.save()
            return True
        return False

    def all(self) -> list[dict[str, Any]]:
        return list(self.entries)

    def search(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        """Naive substring + tag relevance search. Good enough without embeddings."""
        q = query.lower()
        scored: list[tuple[int, dict[str, Any]]] = []
        for e in self.entries:
            text = e["text"].lower()
            score = 0
            if q in text:
                score += 10
            for tag in e.get("tags", []):
                if q in tag.lower():
                    score += 5
            for word in q.split():
                if word in text:
                    score += 1
            if score > 0:
                scored.append((score, e))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [e for _, e in scored[:limit]]

    def relevant(self, query: str, limit: int = 5) -> str:
        """Return a compact string of relevant memories for the agent context."""
        results = self.search(query, limit)
        if not results:
            return ""
        lines = [f"- [{e['id']}] {e['text']}" for e in results]
        return "Relevant memories:\n" + "\n".join(lines)
