"""Chat history - the complete conversation log, persisted to data/chats/.

Each chat is a JSON file. Chats survive restarts and can be listed, loaded,
renamed, deleted and searched.
"""
from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any


@dataclass
class ChatMessage:
    role: str  # user | assistant | tool | system | event
    content: str
    timestamp: str = field(default_factory=lambda: time.strftime("%Y-%m-%dT%H:%M:%S"))
    meta: dict[str, Any] = field(default_factory=dict)
    # For assistant messages that carried tool calls / activity.
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    activity: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class History:
    """A single chat's history, backed by a JSON file."""

    def __init__(self, chats_dir: str, chat_id: str | None = None) -> None:
        self.chats_dir = Path(chats_dir)
        self.chats_dir.mkdir(parents=True, exist_ok=True)
        self.chat_id = chat_id or f"chat-{uuid.uuid4().hex[:8]}"
        self.path = self.chats_dir / f"{self.chat_id}.json"
        self.title: str = "New chat"
        self.created_at: str = time.strftime("%Y-%m-%dT%H:%M:%S")
        self.updated_at: str = self.created_at
        self.messages: list[ChatMessage] = []
        self.load()

    def load(self) -> None:
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text(encoding="utf-8"))
                self.title = data.get("title", self.title)
                self.created_at = data.get("created_at", self.created_at)
                self.updated_at = data.get("updated_at", self.updated_at)
                self.messages = [ChatMessage(**m) for m in data.get("messages", [])]
            except (json.JSONDecodeError, TypeError):
                self.messages = []

    def save(self) -> None:
        self.updated_at = time.strftime("%Y-%m-%dT%H:%M:%S")
        data = {
            "id": self.chat_id,
            "title": self.title,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "messages": [m.to_dict() for m in self.messages],
        }
        self.path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    def add(self, role: str, content: str, **meta: Any) -> ChatMessage:
        msg = ChatMessage(role=role, content=content, meta=meta)
        self.messages.append(msg)
        # Auto-title from first user message.
        if role == "user" and self.title == "New chat":
            self.title = content[:60].strip() or "New chat"
        self.save()
        return msg

    def add_assistant(self, content: str, tool_calls: list[dict] | None = None,
                      activity: list[dict] | None = None) -> ChatMessage:
        msg = ChatMessage(
            role="assistant", content=content,
            tool_calls=tool_calls or [], activity=activity or [],
        )
        self.messages.append(msg)
        self.save()
        return msg

    def add_event(self, content: str, **meta: Any) -> ChatMessage:
        msg = ChatMessage(role="event", content=content, meta=meta)
        self.messages.append(msg)
        self.save()
        return msg

    def rename(self, title: str) -> None:
        self.title = title
        self.save()

    def clear(self) -> None:
        self.messages = []
        self.save()

    def to_provider_messages(self) -> list[dict[str, Any]]:
        """Return messages in provider-ready dict form (excluding events)."""
        out: list[dict[str, Any]] = []
        for m in self.messages:
            if m.role == "event":
                continue
            d: dict[str, Any] = {"role": m.role, "content": m.content}
            if m.tool_calls:
                d["tool_calls"] = m.tool_calls
            out.append(d)
        return out

    def summary(self) -> dict[str, Any]:
        return {
            "id": self.chat_id,
            "title": self.title,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "message_count": len(self.messages),
        }


def list_chats(chats_dir: str) -> list[dict[str, Any]]:
    d = Path(chats_dir)
    if not d.exists():
        return []
    chats = []
    for f in sorted(d.glob("*.json"), key=os.path.getmtime, reverse=True):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            chats.append({
                "id": data.get("id", f.stem),
                "title": data.get("title", f.stem),
                "created_at": data.get("created_at", ""),
                "updated_at": data.get("updated_at", ""),
                "message_count": len(data.get("messages", [])),
            })
        except (json.JSONDecodeError, OSError):
            continue
    return chats


def create_chat(chats_dir: str, title: str = "New chat") -> History:
    h = History(chats_dir)
    h.title = title
    h.save()
    return h


def delete_chat(chats_dir: str, chat_id: str) -> bool:
    p = Path(chats_dir) / f"{chat_id}.json"
    if p.exists():
        p.unlink()
        return True
    return False


def rename_chat(chats_dir: str, chat_id: str, title: str) -> History | None:
    h = History(chats_dir, chat_id)
    h.rename(title)
    return h
