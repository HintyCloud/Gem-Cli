"""Runtime factory - wires the core for a given project.

Centralises construction of the tool registry, provider, memory and history so
the API, CLI and server all build identical runtimes.
"""
from __future__ import annotations

import os
from typing import Any

from .config import Config, get_config
from .memory.history import History
from .memory.memory import Memory
from .providers.base import Provider
from .providers.registry import get_provider, try_get_provider
from .tools.artifacts import ArtifactsTool
from .tools.archive import ArchiveTool
from .tools.files import FilesTool
from .tools.git import GitTool
from .tools.image import ImageTool
from .tools.registry import ToolRegistry, registry as global_registry
from .tools.shell import ShellTool
from .tools.web import WebTool


def project_workspace(cfg: Config, project: str) -> str:
    ws = cfg.workspace_path
    # Validate project name (no traversal).
    safe = os.path.basename(project) or project
    p = ws / safe
    p.mkdir(parents=True, exist_ok=True)
    return str(p)


def build_tools(cfg: Config, project: str) -> ToolRegistry:
    """Build a fresh tool registry scoped to a project workspace."""
    ws = project_workspace(cfg, project)
    reg = ToolRegistry()
    reg.register(ShellTool(ws, default_timeout=cfg.agent.command_timeout))
    reg.register(FilesTool(ws))
    reg.register(WebTool())
    reg.register(ImageTool(str(cfg.artifacts_path),
                           default_width=cfg.image.width, default_height=cfg.image.height))
    reg.register(GitTool(ws))
    reg.register(ArchiveTool(ws))
    reg.register(ArtifactsTool(str(cfg.artifacts_path)))
    return reg


def build_provider(cfg: Config | None = None) -> Provider:
    """Get the configured provider. Raises if not configured."""
    return get_provider()


def build_memory(cfg: Config) -> Memory:
    return Memory(str(cfg.memory_path))


def build_history(cfg: Config, chat_id: str | None = None) -> History:
    return History(str(cfg.chats_path), chat_id)
