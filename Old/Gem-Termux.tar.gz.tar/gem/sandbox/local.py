"""Local sandbox - workspace-bound subprocess execution.

The default sandbox. It is NOT a true VM, but it enforces: cwd inside the
workspace, timeout, a destructive-command denylist, secret redaction and output
truncation. The architecture lets us swap in a container/VM later.
"""
from __future__ import annotations

import asyncio
import os
import re
import time
from typing import Any

from ..exceptions import CommandBlockedError, SandboxError
from .base import Sandbox, SandboxResult

_BLOCKED = [
    re.compile(r"\brm\s+-rf?\s+/(?:\s|$)"),
    re.compile(r"\bmkfs\b"),
    re.compile(r"\bdd\b.*\bof=/dev/"),
    re.compile(r"\bshutdown\b|\breboot\b|\bhalt\b"),
    re.compile(r":\(\)\s*\{.*\}"),
]
_SECRET = [re.compile(r"(sk-[A-Za-z0-9]{10,})"), re.compile(r"(gh[pousr]_[A-Za-z0-9]{20,})")]


def _redact(text: str) -> str:
    for p in _SECRET:
        text = p.sub(lambda m: m.group(1)[:6] + "...REDACTED", text)
    return text


class LocalSandbox(Sandbox):
    def __init__(self, workspace: str, allow_destructive: bool = False) -> None:
        self.workspace = os.path.abspath(workspace)
        self.allow_destructive = allow_destructive

    async def run(self, command: str, timeout: int = 120) -> SandboxResult:
        if not self.allow_destructive:
            for pat in _BLOCKED:
                if pat.search(command):
                    raise CommandBlockedError(command, "destructive command denied")
        start = time.time()
        timed_out = False
        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.workspace,
            )
            try:
                out_b, err_b = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            except asyncio.TimeoutError:
                timed_out = True
                proc.kill()
                await proc.wait()
                out_b, err_b = await proc.communicate()
        except FileNotFoundError as e:
            raise SandboxError(f"shell not available: {e}") from e
        return SandboxResult(
            exit_code=proc.returncode if proc.returncode is not None else -1,
            stdout=_redact(out_b.decode("utf-8", "replace"))[:20000],
            stderr=_redact(err_b.decode("utf-8", "replace"))[:8000],
            duration_ms=int((time.time() - start) * 1000),
            timed_out=timed_out,
        )


def get_sandbox(workspace: str, **kw: Any) -> Sandbox:
    return LocalSandbox(workspace, **kw)
