"""Gem sandbox - controlled execution environments.

A local sandbox (cwd-bound subprocess with timeout + denylist) is the default.
The architecture allows future VM/container/remote sandboxes without changing
the agent - tools just request a Sandbox and get the local one when nothing
fancier is available.
"""
from .base import Sandbox, SandboxResult
from .local import LocalSandbox, get_sandbox

__all__ = ["Sandbox", "SandboxResult", "LocalSandbox", "get_sandbox"]
