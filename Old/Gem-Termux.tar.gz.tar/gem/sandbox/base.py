"""Sandbox base interface."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class SandboxResult:
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: int
    timed_out: bool


class Sandbox(ABC):
    """Abstract sandbox. Implementations run commands in an isolated scope."""

    @abstractmethod
    async def run(self, command: str, timeout: int = 120) -> SandboxResult:
        ...
