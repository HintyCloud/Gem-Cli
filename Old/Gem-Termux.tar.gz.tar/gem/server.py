"""Gem persistent server - ``gem serve``.

Launches the Gem API (FastAPI/uvicorn). Binds to 127.0.0.1 by default - never
exposes the API to the public internet automatically.
"""
from __future__ import annotations

import uvicorn

from .config import get_config


def serve(host: str | None = None, port: int | None = None, reload: bool = False) -> None:
    cfg = get_config()
    h = host or cfg.server.host
    p = port or cfg.server.port
    print(f"Gem API starting on http://{h}:{p}  (reload={reload})")
    uvicorn.run("gem.api.app:app", host=h, port=p, reload=reload, log_level="info")


if __name__ == "__main__":
    serve()
