"""The agent loop - the think/act/observe cycle.

Flow:
  receive message -> load context -> load memory -> load project ->
  send to model -> interpret -> detect tool calls -> execute ->
  observe results -> detect errors -> correct -> update context ->
  save checkpoint -> continue until done -> respond.

The loop is an async generator that yields structured EVENTS so the CLI, Web UI
and API can all render live activity (planning, creating files, running tests,
fixing, completed...). Multiple tools per iteration are supported.
"""
from __future__ import annotations

import json
import time
from typing import Any, AsyncIterator

from ..exceptions import (
    GemError, ProviderError, ProviderNotConfiguredError, ToolError,
)
from ..memory.history import History
from ..memory.memory import Memory
from ..providers.base import GenerateResult, Message, Provider, ToolCall
from ..tools.registry import ToolRegistry
from .context import AgentContext
from .executor import Executor
from .planner import Planner

SYSTEM_PROMPT = """You are Gem, an agentic AI for development, automation, research and task execution.

You work inside a project workspace. You MUST use your tools to perform real actions. You have these tools available as function calls:
- files: read/write/edit/list/move/copy/remove/mkdir/exists/metadata (paths are relative to the workspace)
- shell: run a shell command in the workspace (returns stdout, stderr, exit_code, duration)
- web_search: search the web
- image: generate an image from a prompt (saves to artifacts)
- git: run git commands
- archive: create/extract zip or tar.gz
- artifacts: register/list project artifacts

CRITICAL RULES (follow strictly):
1. NEVER describe a command or file change in prose or markdown code blocks. You MUST actually CALL the tool to perform the action. Writing `echo ... > file` in a code block is FORBIDDEN - call the shell or files tool instead.
2. To create or edit a file: call the `files` tool with action "write" (full content) or "edit" (find/replace).
3. To run a command: call the `shell` tool.
4. To search the web: call the `web_search` tool.
5. After each tool call, OBSERVE its result. If it failed, read the error and call a tool to FIX it - do not give up and do not pretend it succeeded.
6. Keep calling tools until the task is genuinely complete, THEN write a brief final summary as plain text (no code blocks).
7. All paths are relative to the current project workspace.
8. Never fabricate results. If you did not run a command, you do not know its output.

Remember: a response that only describes work without calling tools is a FAILURE. Always act via tools first."""


class AgentLoop:
    def __init__(
        self,
        provider: Provider,
        tools: ToolRegistry,
        history: History,
        memory: Memory,
        context: AgentContext,
        max_iterations: int = 50,
        auto_continue: bool = True,
    ) -> None:
        self.provider = provider
        self.tools = tools
        self.history = history
        self.memory = memory
        self.context = context
        self.executor = Executor(tools)
        self.planner = Planner(provider)
        self.max_iterations = max_iterations
        self.auto_continue = auto_continue

    async def run(self, user_message: str) -> AsyncIterator[dict[str, Any]]:
        """Run the loop for one user turn. Yields events."""
        self.history.add("user", user_message)
        yield {"type": "user", "content": user_message}

        # Plan complex tasks.
        try:
            plan_data = await self.planner.plan(user_message)
            if plan_data["complexity"] == "complex" and len(plan_data["steps"]) > 1:
                self.context.set_plan(plan_data["steps"])
                yield {"type": "plan", "steps": plan_data["steps"]}
        except Exception as e:
            yield {"type": "event", "content": f"Planning skipped: {e}"}

        # Build the working message list from history + relevant memory.
        memory_hint = self.memory.relevant(user_message)
        system = SYSTEM_PROMPT
        if memory_hint:
            system += "\n\n" + memory_hint
        system += f"\n\nCurrent project workspace: {self.context.project}"

        tool_schemas = self.tools.schemas()
        consecutive_errors = 0

        for iteration in range(1, self.max_iterations + 1):
            self.context.iterations = iteration
            yield {"type": "iteration", "n": iteration}

            # Compose messages: recent history (token budget aware).
            messages = self._compose_messages(system)

            try:
                result = await self.provider.generate(
                    messages, tools=tool_schemas, temperature=0.3, max_tokens=4096,
                )
            except ProviderNotConfiguredError as e:
                yield {"type": "error", "content": str(e)}
                self.history.add("assistant", f"I'm not fully configured: {e}")
                self.context.status = "failed"
                self.context.save()
                return
            except ProviderError as e:
                consecutive_errors += 1
                yield {"type": "event", "content": f"Provider error (try {consecutive_errors}): {e}"}
                if consecutive_errors >= 5:
                    yield {"type": "error", "content": f"Provider unavailable after retries: {e}"}
                    self.context.status = "failed"
                    self.context.save()
                    return
                # Backoff to ride out transient upstream (503) outages.
                import asyncio as _aio
                await _aio.sleep(2.0 * consecutive_errors)
                continue

            consecutive_errors = 0

            # Record assistant message (with tool calls for the transcript).
            assistant_msg = Message(
                role="assistant", content=result.content, tool_calls=result.tool_calls,
            )
            self.history.messages.append(assistant_msg)
            self.history.save()

            # No tool calls => the model is done talking for this turn.
            if not result.tool_calls:
                self.history.add_event("Completed")
                yield {"type": "assistant", "content": result.content}
                yield {"type": "done", "content": result.content}
                self.context.status = "completed"
                self.context.summary = result.content[:300]
                self.context.save()
                return

            # We have tool calls - execute them.
            if result.content:
                yield {"type": "assistant", "content": result.content}

            for tc in result.tool_calls:
                yield {"type": "tool_call", "name": tc.name, "arguments": tc.arguments}
                yield {"type": "activity", "label": self._activity_label(tc.name, tc.arguments)}

            results = await self.executor.execute_all(result.tool_calls)

            for tc, tr in zip(result.tool_calls, results):
                # Activity events for the UI.
                if tc.name == "files":
                    action = tc.arguments.get("action", "")
                    path = tc.arguments.get("path", "")
                    if action == "write":
                        yield {"type": "file_created", "path": path, "content": tc.arguments.get("content", "")}
                    elif action == "edit":
                        yield {"type": "file_edited", "path": path,
                               "old": tc.arguments.get("old_str", ""), "new": tc.arguments.get("new_str", "")}
                elif tc.name == "shell":
                    yield {"type": "command", "command": tc.arguments.get("command", ""),
                           "result": tr.content[:1500], "is_error": tr.is_error}

                self.context.add_tool_result(tc.name, dict(tc.arguments), tr.content, tr.is_error)
                yield {"type": "tool_result", "name": tc.name, "is_error": tr.is_error,
                       "content": tr.content[:1500]}
                self.history.messages.append(tr.to_message())
                self.history.save()

            # Periodic checkpoint.
            if iteration % 5 == 0:
                self.context.save()
                yield {"type": "checkpoint", "iteration": iteration}

        # Exceeded max iterations.
        yield {"type": "event", "content": f"Reached max iterations ({self.max_iterations}). Pausing."}
        self.context.status = "paused"
        self.context.save()

    def _compose_messages(self, system: str) -> list[Message]:
        """Build the message list with a token budget (rough char-based)."""
        budget = 24000
        msgs: list[Message] = []
        # Take the last N messages that fit the budget.
        recent = self.history.messages[-30:]
        total = len(system)
        kept: list[Message] = []
        for m in reversed(recent):
            size = len(m.content) + 200
            if total + size > budget:
                break
            kept.append(m)
            total += size
        kept.reverse()
        return kept

    def _activity_label(self, name: str, args: dict[str, Any]) -> str:
        if name == "shell":
            return f"Running: {args.get('command', '')[:50]}"
        if name == "files":
            action = args.get("action", "")
            path = args.get("path", "")
            return {"write": "Creating file", "edit": "Editing file", "read": "Reading file",
                    "list": "Listing files", "mkdir": "Creating directory"}.get(action, f"{action} {path}")
        if name == "web_search":
            return f"Searching web: {args.get('query', '')[:50]}"
        if name == "image":
            return f"Generating image: {args.get('prompt', '')[:50]}"
        if name == "git":
            return f"Git: {args.get('args', '')[:50]}"
        if name == "archive":
            return f"Archive: {args.get('action', '')}"
        if name == "artifacts":
            return f"Artifacts: {args.get('action', '')}"
        return name
