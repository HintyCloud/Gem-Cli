"""Agent-side Supervisor facade.

Wraps the swarm coordinator so callers using the ``gem.agent`` package get a
single Supervisor entry point. Delegates to ``gem.swarm.Supervisor``.
"""
from __future__ import annotations

from ..swarm.coordinator import Supervisor as _SwarmSupervisor, run_swarm


class Supervisor(_SwarmSupervisor):
    """Supervisor for orchestrating subagents. See gem.swarm.coordinator.Supervisor."""

    pass


__all__ = ["Supervisor", "run_swarm"]
