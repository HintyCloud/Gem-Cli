"""Agent context and checkpoints.

A Context tracks everything about a single task: the active project, the plan,
accumulated tool results, agent state and iteration count. It can be saved to
``data/checkpoints`` and restored so an interrupted task continues seamlessly.
"""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any


@dataclass
class Checkpoint:
    task_id: str
    project: str
    plan: list[dict[str, Any]] = field(default_factory=list)
    current_step: int = 0
    iterations: int = 0
    summary: str = ""
    status: str = "running"  # running | completed | failed | paused | recovering
    created_at: str = field(default_factory=lambda: time.strftime("%Y-%m-%dT%H:%M:%S"))
    tool_results: list[dict[str, Any]] = field(default_factory=list)
    artifacts: list[str] = field(default_factory=list)
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class AgentContext:
    """Per-task context. Serialises to a checkpoint for recovery."""

    def __init__(self, project: str, checkpoints_dir: str, task_id: str | None = None) -> None:
        self.project = project
        self.checkpoints_dir = Path(checkpoints_dir)
        self.checkpoints_dir.mkdir(parents=True, exist_ok=True)
        self.task_id = task_id or f"task-{uuid.uuid4().hex[:8]}"
        self.plan: list[dict[str, Any]] = []
        self.current_step = 0
        self.iterations = 0
        self.summary = ""
        self.status = "running"
        self.tool_results: list[dict[str, Any]] = []
        self.artifacts: list[str] = []
        self.meta: dict[str, Any] = {}
        self.created_at = time.strftime("%Y-%m-%dT%H:%M:%S")

    # ---- plan management ----
    def set_plan(self, steps: list[dict[str, Any]]) -> None:
        self.plan = steps
        self.current_step = 0

    def advance_step(self) -> dict[str, Any] | None:
        if self.current_step < len(self.plan):
            step = self.plan[self.current_step]
            self.current_step += 1
            return step
        return None

    def current_plan_step(self) -> dict[str, Any] | None:
        if self.current_step < len(self.plan):
            return self.plan[self.current_step]
        return None

    # ---- tool results ----
    def add_tool_result(self, name: str, arguments: dict, result: str, is_error: bool = False) -> None:
        self.tool_results.append({
            "name": name, "arguments": arguments, "result": result[:2000],
            "is_error": is_error, "at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        })

    def add_artifact(self, artifact_id: str) -> None:
        if artifact_id not in self.artifacts:
            self.artifacts.append(artifact_id)

    # ---- checkpoints ----
    def checkpoint_path(self) -> Path:
        return self.checkpoints_dir / f"{self.task_id}.json"

    def save(self) -> Path:
        cp = Checkpoint(
            task_id=self.task_id, project=self.project, plan=self.plan,
            current_step=self.current_step, iterations=self.iterations,
            summary=self.summary, status=self.status,
            tool_results=self.tool_results, artifacts=self.artifacts,
            meta={**self.meta, "created_at": self.created_at},
        )
        path = self.checkpoint_path()
        path.write_text(json.dumps(cp.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
        return path

    @classmethod
    def load(cls, checkpoints_dir: str, task_id: str) -> "AgentContext":
        path = Path(checkpoints_dir) / f"{task_id}.json"
        if not path.exists():
            from ..exceptions import CheckpointError
            raise CheckpointError(f"No checkpoint for task {task_id}")
        data = json.loads(path.read_text(encoding="utf-8"))
        ctx = cls(project=data["project"], checkpoints_dir=checkpoints_dir, task_id=task_id)
        ctx.plan = data.get("plan", [])
        ctx.current_step = data.get("current_step", 0)
        ctx.iterations = data.get("iterations", 0)
        ctx.summary = data.get("summary", "")
        ctx.status = data.get("status", "running")
        ctx.tool_results = data.get("tool_results", [])
        ctx.artifacts = data.get("artifacts", [])
        ctx.meta = data.get("meta", {})
        ctx.created_at = data.get("meta", {}).get("created_at", ctx.created_at)
        if ctx.status == "running":
            ctx.status = "recovering"
        return ctx

    @classmethod
    def list_checkpoints(cls, checkpoints_dir: str) -> list[dict[str, Any]]:
        d = Path(checkpoints_dir)
        if not d.exists():
            return []
        out = []
        for f in d.glob("*.json"):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                out.append({
                    "task_id": data.get("task_id"),
                    "project": data.get("project"),
                    "status": data.get("status"),
                    "iterations": data.get("iterations"),
                    "current_step": data.get("current_step"),
                    "summary": (data.get("summary") or "")[:80],
                    "created_at": data.get("created_at"),
                })
            except (json.JSONDecodeError, OSError):
                continue
        return out

    def summary_dict(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "project": self.project,
            "status": self.status,
            "iterations": self.iterations,
            "current_step": self.current_step,
            "plan_steps": len(self.plan),
            "tool_calls": len(self.tool_results),
            "artifacts": len(self.artifacts),
        }
