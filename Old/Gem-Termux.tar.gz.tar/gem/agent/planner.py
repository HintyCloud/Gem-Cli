"""Planner - decomposes complex tasks into ordered steps.

For simple tasks the planner returns a single step. For complex tasks it asks
the model to produce a JSON plan, then validates it. This keeps the agent from
over-planning trivia while still structuring big work.
"""
from __future__ import annotations

import json
import re
from typing import Any

from ..exceptions import PlannerError, ProviderNotConfiguredError
from ..providers.base import Message, Provider

PLAN_SYSTEM = (
    "You are Gem's planner. Given a task, decide if it is SIMPLE (one action) or "
    "COMPLEX (multiple ordered steps). Respond ONLY with a JSON object:\n"
    '{"complexity": "simple"|"complex", "steps": [{"title": str, "goal": str, "agent": str}]}\n'
    "Keep steps atomic and ordered. 'agent' is one of: general, coder, researcher, "
    "tester, frontend, backend, reviewer, planner. Prefer fewer steps."
)


class Planner:
    def __init__(self, provider: Provider | None = None) -> None:
        self.provider = provider

    async def plan(self, task: str) -> dict[str, Any]:
        """Return {'complexity', 'steps'} for the task."""
        # Heuristic: short, single-action tasks skip the model entirely.
        if self._is_trivial(task):
            return {
                "complexity": "simple",
                "steps": [{"title": "Handle request", "goal": task, "agent": "general"}],
            }
        if self.provider is None:
            # No provider: fall back to a single general step.
            return {
                "complexity": "simple",
                "steps": [{"title": "Handle request", "goal": task, "agent": "general"}],
            }
        try:
            result = await self.provider.generate(
                [Message(role="user", content=f"Task: {task}")],
                system=PLAN_SYSTEM,
                temperature=0.1,
                max_tokens=800,
            )
            return self._parse(result.content)
        except (ProviderNotConfiguredError, PlannerError, Exception):
            # Degrade gracefully: a single general step handles the whole task.
            return {
                "complexity": "simple",
                "steps": [{"title": "Handle request", "goal": task, "agent": "general"}],
            }

    def _is_trivial(self, task: str) -> bool:
        t = task.strip().lower()
        trivial_markers = ["hello", "hi ", "thanks", "what is your name", "who are you"]
        if any(t.startswith(m) for m in trivial_markers):
            return True
        if len(t) < 25 and not any(k in t for k in ["create", "build", "implement", "fix", "test", "deploy", "write", "make", "analyze"]):
            return True
        return False

    def _parse(self, text: str) -> dict[str, Any]:
        # Extract JSON even if wrapped in prose / code fences.
        match = re.search(r"\{[\s\S]*\}", text)
        if not match:
            raise PlannerError("Planner did not return JSON")
        try:
            data = json.loads(match.group(0))
        except json.JSONDecodeError as e:
            raise PlannerError(f"Planner JSON invalid: {e}") from e
        steps = data.get("steps", [])
        if not isinstance(steps, list) or not steps:
            return {"complexity": "simple", "steps": [{"title": "Handle request", "goal": "task", "agent": "general"}]}
        # Normalise each step.
        norm = []
        valid_agents = {"general", "coder", "researcher", "tester", "frontend", "backend", "reviewer", "planner"}
        for s in steps:
            if not isinstance(s, dict):
                continue
            agent = s.get("agent", "general")
            if agent not in valid_agents:
                agent = "general"
            norm.append({"title": s.get("title", "step"), "goal": s.get("goal", ""), "agent": agent})
        return {"complexity": data.get("complexity", "complex" if len(norm) > 1 else "simple"), "steps": norm}
