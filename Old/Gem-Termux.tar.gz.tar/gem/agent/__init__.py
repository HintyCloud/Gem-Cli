"""Gem agent package - the agentic core.

The same loop powers CLI, Web UI and API. Components are decoupled:
  * Context   - per-task state + checkpoints
  * Planner   - decomposes complex tasks into steps
  * Executor  - runs tool calls safely
  * Loop      - the think/act/observe cycle
  * Supervisor- orchestrates the swarm of subagents
"""
from .context import AgentContext, Checkpoint
from .planner import Planner
from .executor import Executor
from .loop import AgentLoop
from .supervisor import Supervisor

__all__ = ["AgentContext", "Checkpoint", "Planner", "Executor", "AgentLoop", "Supervisor"]
