"""Executor - runs tool calls requested by the model and returns ToolResults.

The executor is the bridge between the model's tool_calls and the tool registry.
It enforces the workspace boundary and turns failures into ToolResult messages
(is_error=True) so the agent can observe and self-correct, rather than crashing.
"""
from __future__ import annotations

from typing import Any

from ..exceptions import ToolError
from ..providers.base import ToolCall, ToolResult
from ..tools.registry import ToolRegistry


class Executor:
    def __init__(self, registry: ToolRegistry) -> None:
        self.registry = registry

    async def execute(self, call: ToolCall) -> ToolResult:
        try:
            output = await self.registry.execute(call.name, dict(call.arguments))
            return ToolResult(tool_call_id=call.id, name=call.name, content=output, is_error=False)
        except ToolError as e:
            # Surface tool errors back to the model so it can correct course.
            return ToolResult(tool_call_id=call.id, name=call.name, content=f"ERROR: {e}", is_error=True)
        except Exception as e:  # never crash the loop on a tool bug
            return ToolResult(
                tool_call_id=call.id, name=call.name,
                content=f"INTERNAL ERROR in tool '{call.name}': {e}", is_error=True,
            )

    async def execute_all(self, calls: list[ToolCall]) -> list[ToolResult]:
        # Execute sequentially for safety/predictability; parallelism is the
        # swarm's job, not the single-agent tool layer.
        results: list[ToolResult] = []
        for c in calls:
            results.append(await self.execute(c))
        return results
