"""Auto-recovery - on startup, detect interrupted jobs and resume them.

A job left in RUNNING/RECOVERING/PAUSED state from a previous process is marked
RECOVERING and re-queued. The agent loop restores from its checkpoint so the
task continues from where it left off.
"""
from __future__ import annotations

import time
from typing import Any

from .state import JobStatus, JobStore


def recover_jobs(jobs_dir: str, manager: Any | None = None) -> list[str]:
    """Mark interrupted jobs as RECOVERING. If a manager is given, re-queue them."""
    store = JobStore(jobs_dir)
    recovered: list[str] = []
    for state in store.list_all():
        if state.status in (JobStatus.RUNNING, JobStatus.RECOVERING, JobStatus.PAUSED):
            state.status = JobStatus.RECOVERING
            store.save(state)
            recovered.append(state.job_id)
            if manager is not None:
                try:
                    manager.queue.enqueue(state.job_id)
                    manager._spawn(state.job_id)
                except Exception:
                    pass
    return recovered
