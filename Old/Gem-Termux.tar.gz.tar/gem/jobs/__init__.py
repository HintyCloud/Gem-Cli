"""Gem jobs - persistent background task execution.

Jobs survive restarts via on-disk state + checkpoints. States:
  queued -> running -> completed | failed | cancelled | paused | recovering
"""
from .state import JobState, JobStatus
from .manager import JobManager
from .queue import JobQueue
from .recovery import recover_jobs

__all__ = ["JobState", "JobStatus", "JobManager", "JobQueue", "recover_jobs"]
