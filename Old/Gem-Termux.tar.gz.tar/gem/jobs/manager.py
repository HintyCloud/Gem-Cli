"""Job manager - create/run/cancel/poll background jobs.

A job runs an agent (or a swarm) on a task in a project. The manager keeps
on-disk state updated so a restart can recover unfinished jobs. Each running job
appends events that the API/UI can stream.
"""
from __future__ import annotations

import asyncio
import time
from typing import Any, Awaitable, Callable

from ..agent.context import AgentContext
from ..config import get_config
from ..exceptions import JobError, JobNotFoundError
from ..memory.history import History
from ..memory.memory import Memory
from ..providers.base import Provider
from ..tools.registry import ToolRegistry
from .queue import JobQueue
from .state import JobState, JobStatus, JobStore


# A job runner is an async callable(job_state, provider, tools) -> AsyncIterator[events]
JobRunner = Callable[..., Any]


class JobManager:
    def __init__(
        self,
        jobs_dir: str,
        chats_dir: str,
        checkpoints_dir: str,
        memory: Memory,
        provider: Provider,
        tools: ToolRegistry,
        max_concurrent: int | None = None,
    ) -> None:
        self.store = JobStore(jobs_dir)
        self.queue = JobQueue(max_concurrent or get_config().jobs.max_concurrent)
        self.chats_dir = chats_dir
        self.checkpoints_dir = checkpoints_dir
        self.memory = memory
        self.provider = provider
        self.tools = tools
        self._tasks: dict[str, asyncio.Task] = {}
        self._subs: dict[str, list[asyncio.Queue]] = {}

    # ---- lifecycle ----
    def create(self, task: str, project: str, use_swarm: bool = False) -> JobState:
        state = JobState(task=task, project=project, use_swarm=use_swarm)
        self.store.save(state)
        self.queue.enqueue(state.job_id)
        self._spawn(state.job_id)
        return state

    def get(self, job_id: str) -> JobState:
        s = self.store.load(job_id)
        if s is None:
            raise JobNotFoundError(job_id)
        return s

    def list(self) -> list[JobState]:
        return self.store.list_all()

    def cancel(self, job_id: str) -> JobState:
        s = self.get(job_id)
        if s.status in (JobStatus.QUEUED, JobStatus.RUNNING, JobStatus.PAUSED, JobStatus.RECOVERING):
            s.status = JobStatus.CANCELLED
            s.finished_at = time.strftime("%Y-%m-%dT%H:%M:%S")
            self.store.save(s)
            task = self._tasks.get(job_id)
            if task and not task.done():
                task.cancel()
        return s

    def delete(self, job_id: str) -> bool:
        self.cancel(job_id)
        return self.store.delete(job_id)

    # ---- streaming ----
    def subscribe(self, job_id: str) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue()
        self._subs.setdefault(job_id, []).append(q)
        # replay existing events
        s = self.store.load(job_id)
        if s:
            for ev in s.events:
                q.put_nowait(ev)
        return q

    def unsubscribe(self, job_id: str, q: asyncio.Queue) -> None:
        if job_id in self._subs and q in self._subs[job_id]:
            self._subs[job_id].remove(q)

    def _emit(self, job_id: str, event: dict[str, Any]) -> None:
        for q in self._subs.get(job_id, []):
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                pass

    # ---- execution ----
    def _spawn(self, job_id: str) -> None:
        if job_id in self._tasks and not self._tasks[job_id].done():
            return
        self._tasks[job_id] = asyncio.create_task(self._run_job(job_id))

    async def _run_job(self, job_id: str) -> None:
        await self.queue.acquire()
        try:
            state = self.get(job_id)
            if state.status == JobStatus.CANCELLED:
                return
            state.status = JobStatus.RUNNING
            state.started_at = time.strftime("%Y-%m-%dT%H:%M:%S")
            self.store.save(state)
            self._emit(job_id, {"type": "status", "status": "running"})

            try:
                async for ev in self._execute(state):
                    state.events.append(ev)
                    state.progress = min(1.0, len(state.events) / 30.0)
                    self.store.save(state)
                    self._emit(job_id, ev)
                    if state.status == JobStatus.CANCELLED:
                        break
                if state.status != JobStatus.CANCELLED:
                    state.status = JobStatus.COMPLETED
            except asyncio.CancelledError:
                state.status = JobStatus.CANCELLED
                raise
            except Exception as e:
                state.status = JobStatus.FAILED
                state.error = str(e)
                self._emit(job_id, {"type": "error", "content": str(e)})
            state.finished_at = time.strftime("%Y-%m-%dT%H:%M:%S")
            state.progress = 1.0
            self.store.save(state)
            self._emit(job_id, {"type": "status", "status": state.status.value})
        finally:
            self.queue.release()

    async def _execute(self, state: JobState):
        """Run the agent (or swarm) and yield events."""
        history = History(self.chats_dir)
        context = AgentContext(project=state.project, checkpoints_dir=self.checkpoints_dir,
                               task_id=state.task_id or None)
        state.task_id = context.task_id

        if state.use_swarm:
            from ..swarm.coordinator import Supervisor
            sup = Supervisor(self.provider, self.tools, self.chats_dir, self.memory,
                             self.checkpoints_dir, state.project)
            async for ev in sup.run(state.task):
                yield ev
            return

        from ..agent.loop import AgentLoop
        loop = AgentLoop(
            provider=self.provider, tools=self.tools, history=history,
            memory=self.memory, context=context,
            max_iterations=get_config().agent.max_iterations,
        )
        async for ev in loop.run(state.task):
            yield ev
            if ev.get("type") == "done":
                state.result = ev.get("content", "")
        state.result = state.result or (context.summary or "Task finished.")
