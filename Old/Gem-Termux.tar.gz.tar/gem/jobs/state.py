"""Job state model and persistence."""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any


class JobStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PAUSED = "paused"
    RECOVERING = "recovering"


@dataclass
class JobState:
    job_id: str = field(default_factory=lambda: f"job-{uuid.uuid4().hex[:8]}")
    task: str = ""
    project: str = ""
    status: JobStatus = JobStatus.QUEUED
    created_at: str = field(default_factory=lambda: time.strftime("%Y-%m-%dT%H:%M:%S"))
    started_at: str = ""
    finished_at: str = ""
    result: str = ""
    error: str = ""
    task_id: str = ""  # links to a checkpoint
    events: list[dict[str, Any]] = field(default_factory=list)
    progress: float = 0.0
    use_swarm: bool = False

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["status"] = self.status.value
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "JobState":
        data = dict(data)
        if "status" in data and isinstance(data["status"], str):
            data["status"] = JobStatus(data["status"])
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


class JobStore:
    def __init__(self, jobs_dir: str) -> None:
        self.jobs_dir = Path(jobs_dir)
        self.jobs_dir.mkdir(parents=True, exist_ok=True)

    def path(self, job_id: str) -> Path:
        return self.jobs_dir / f"{job_id}.json"

    def save(self, state: JobState) -> Path:
        p = self.path(state.job_id)
        p.write_text(json.dumps(state.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
        return p

    def load(self, job_id: str) -> JobState | None:
        p = self.path(job_id)
        if not p.exists():
            return None
        try:
            return JobState.from_dict(json.loads(p.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, TypeError):
            return None

    def delete(self, job_id: str) -> bool:
        p = self.path(job_id)
        if p.exists():
            p.unlink()
            return True
        return False

    def list_all(self) -> list[JobState]:
        out = []
        for f in self.jobs_dir.glob("*.json"):
            try:
                out.append(JobState.from_dict(json.loads(f.read_text(encoding="utf-8"))))
            except (json.JSONDecodeError, TypeError):
                continue
        return out
