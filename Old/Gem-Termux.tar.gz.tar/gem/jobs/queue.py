"""Job queue - simple FIFO with max concurrency."""
from __future__ import annotations

import asyncio
from collections import deque
from typing import Any


class JobQueue:
    def __init__(self, max_concurrent: int = 2) -> None:
        self._q: deque[str] = deque()
        self.max_concurrent = max_concurrent
        self._running = 0
        self._wakeup = asyncio.Event()
        self._wakeup.set()

    def enqueue(self, job_id: str) -> None:
        self._q.append(job_id)
        self._wakeup.set()

    def dequeue(self) -> str | None:
        if self._q:
            return self._q.popleft()
        return None

    async def acquire(self) -> None:
        while self._running >= self.max_concurrent:
            self._wakeup.clear()
            await self._wakeup.wait()
        self._running += 1

    def release(self) -> None:
        self._running = max(0, self._running - 1)
        self._wakeup.set()

    @property
    def pending(self) -> int:
        return len(self._q)

    @property
    def running(self) -> int:
        return self._running
