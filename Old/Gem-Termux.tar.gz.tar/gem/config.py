"""Typed configuration loading for Gem.

Reads ``config/config.toml`` for public settings and ``config/secrets.toml``
(gitignored) and/or environment variables for credentials. Secrets NEVER live in
source code or in the versioned config file.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:  # Python 3.11+
    import tomllib  # type: ignore
except ModuleNotFoundError:  # pragma: no cover - py<3.11 fallback
    import tomli as tomllib  # type: ignore


PROJECT_ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = PROJECT_ROOT / "config" / "config.toml"
SECRETS_PATH = PROJECT_ROOT / "config" / "secrets.toml"


class ConfigError(Exception):
    """Raised when configuration is missing or invalid."""


@dataclass
class ProviderConfig:
    name: str = "opencode"
    model: str = "longcat-2.0-free"
    base_url: str = "https://api.opencode.ai/v1"
    api_key: str = ""
    temperature: float = 0.3
    max_tokens: int = 4096


@dataclass
class AgentConfig:
    max_iterations: int = 50
    command_timeout: int = 120
    auto_continue: bool = True
    context_token_budget: int = 24000


@dataclass
class SwarmConfig:
    max_agents: int = 4
    agent_timeout: int = 300


@dataclass
class ServerConfig:
    host: str = "127.0.0.1"
    port: int = 8000


@dataclass
class ImageConfig:
    provider: str = "pollinations"
    width: int = 1024
    height: int = 1024


@dataclass
class JobsConfig:
    max_concurrent: int = 2
    checkpoint_interval: int = 5


@dataclass
class Config:
    workspace: str = "./projects"
    data_dir: str = "./data"
    provider: ProviderConfig = field(default_factory=ProviderConfig)
    agent: AgentConfig = field(default_factory=AgentConfig)
    swarm: SwarmConfig = field(default_factory=SwarmConfig)
    server: ServerConfig = field(default_factory=ServerConfig)
    image: ImageConfig = field(default_factory=ImageConfig)
    jobs: JobsConfig = field(default_factory=JobsConfig)
    raw: dict[str, Any] = field(default_factory=dict)

    # ----- derived paths -----
    @property
    def workspace_path(self) -> Path:
        p = Path(self.workspace)
        if not p.is_absolute():
            p = PROJECT_ROOT / p
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def data_path(self) -> Path:
        p = Path(self.data_dir)
        if not p.is_absolute():
            p = PROJECT_ROOT / p
        for sub in ("chats", "memory", "checkpoints", "jobs", "artifacts", "logs"):
            (p / sub).mkdir(parents=True, exist_ok=True)
        return p

    @property
    def chats_path(self) -> Path:
        return self.data_path / "chats"

    @property
    def memory_path(self) -> Path:
        return self.data_path / "memory"

    @property
    def checkpoints_path(self) -> Path:
        return self.data_path / "checkpoints"

    @property
    def jobs_path(self) -> Path:
        return self.data_path / "jobs"

    @property
    def artifacts_path(self) -> Path:
        return self.data_path / "artifacts"

    @property
    def logs_path(self) -> Path:
        return self.data_path / "logs"


def _load_toml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("rb") as fh:
        return tomllib.load(fh)


def load_config() -> Config:
    """Load and merge config from file, secrets file and environment."""
    raw = _load_toml(CONFIG_PATH)
    secrets = _load_toml(SECRETS_PATH)

    cfg = Config(
        workspace=raw.get("gem", {}).get("workspace", "./projects"),
        data_dir=raw.get("gem", {}).get("data_dir", "./data"),
        raw=raw,
    )

    p = raw.get("provider", {})
    opencode_secrets = secrets.get("opencode", {})
    cfg.provider = ProviderConfig(
        name=p.get("name", "opencode"),
        model=p.get("model", "longcat-2.0-free"),
        base_url=p.get("base_url", "https://opencode.ai/zen/v1"),
        api_key=os.environ.get(
            "OPENCODE_API_KEY", opencode_secrets.get("api_key", "")
        ),
        temperature=float(p.get("temperature", 0.3)),
        max_tokens=int(p.get("max_tokens", 4096)),
    )

    a = raw.get("agent", {})
    cfg.agent = AgentConfig(
        max_iterations=int(a.get("max_iterations", 50)),
        command_timeout=int(a.get("command_timeout", 120)),
        auto_continue=bool(a.get("auto_continue", True)),
        context_token_budget=int(a.get("context_token_budget", 24000)),
    )

    s = raw.get("swarm", {})
    cfg.swarm = SwarmConfig(
        max_agents=int(s.get("max_agents", 4)),
        agent_timeout=int(s.get("agent_timeout", 300)),
    )

    srv = raw.get("server", {})
    cfg.server = ServerConfig(
        host=srv.get("host", "127.0.0.1"), port=int(srv.get("port", 8000))
    )

    i = raw.get("image", {})
    cfg.image = ImageConfig(
        provider=i.get("provider", "pollinations"),
        width=int(i.get("width", 1024)),
        height=int(i.get("height", 1024)),
    )

    j = raw.get("jobs", {})
    cfg.jobs = JobsConfig(
        max_concurrent=int(j.get("max_concurrent", 2)),
        checkpoint_interval=int(j.get("checkpoint_interval", 5)),
    )

    return cfg


# Singleton-style accessor with lazy load.
_cached: Config | None = None


def get_config() -> Config:
    global _cached
    if _cached is None:
        _cached = load_config()
    return _cached


def reload_config() -> Config:
    global _cached
    _cached = load_config()
    return _cached
