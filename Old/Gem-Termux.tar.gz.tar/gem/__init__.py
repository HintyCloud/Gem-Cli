"""Gem - a complete agentic AI ecosystem.

Shared core used by the CLI, the Web UI (via the Gem API) and external clients.
All interfaces (CLI / Web UI / API) drive the SAME core so behaviour is
consistent across every distribution (Linux, Windows, Termux, Latest, Cli, Dev).
"""

__version__ = "1.0.0"
__all__ = ["__version__"]
