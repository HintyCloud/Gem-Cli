"""Gem provider - uses the Gem API itself as an LLM backend.

Architecture:
    Gem Client -> Gem API (HTTP) -> Gem Core -> OpenCode Provider -> model

This lets external clients treat Gem as just another provider, while Gem
internally routes through its own core (and from there to OpenCode by default).
"""
from __future__ import annotations

import json
from typing import Any, AsyncIterator

import httpx

from ..exceptions import ProviderError, ProviderNotConfiguredError
from .base import GenerateResult, Message, Provider, ToolCall, ToolSchema


class GemProvider(Provider):
    name = "gem"

    def __init__(
        self,
        model: str = "longcat-2.0-free",
        api_key: str = "",
        base_url: str = "http://127.0.0.1:8000",
        token: str = "",
        timeout: float = 120.0,
        **opts: Any,
    ) -> None:
        super().__init__(model, api_key, base_url, **opts)
        # ``token`` is the Gem API auth token (separate from upstream LLM keys).
        self.token = token or api_key
        self.timeout = timeout

    def is_configured(self) -> bool:
        return bool(self.base_url)

    def _headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        return h

    async def generate(
        self,
        messages: list[Message],
        tools: list[ToolSchema] | None = None,
        system: str | None = None,
        temperature: float = 0.3,
        max_tokens: int = 4096,
    ) -> GenerateResult:
        url = f"{self.base_url}/v1/chat/completions"
        payload = {
            "model": self.model,
            "messages": ([{"role": "system", "content": system}] if system else [])
            + [m.to_dict() for m in messages],
            "tools": tools,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(url, headers=self._headers(), json=payload)
        if resp.status_code != 200:
            raise ProviderError(f"Gem API HTTP {resp.status_code}: {resp.text[:300]}")
        data = resp.json()
        choice = (data.get("choices") or [{}])[0]
        msg = choice.get("message", {})
        tool_calls = [
            ToolCall(
                id=tc.get("id", ""),
                name=tc.get("function", {}).get("name", ""),
                arguments=json.loads(tc.get("function", {}).get("arguments", "{}") or "{}"),
            )
            for tc in msg.get("tool_calls") or []
        ]
        return GenerateResult(
            content=msg.get("content") or "",
            tool_calls=tool_calls,
            finish_reason=choice.get("finish_reason", "stop"),
            usage=data.get("usage", {}),
            raw=data,
        )

    async def stream(
        self,
        messages: list[Message],
        tools: list[ToolSchema] | None = None,
        system: str | None = None,
        temperature: float = 0.3,
        max_tokens: int = 4096,
    ) -> AsyncIterator[str]:
        url = f"{self.base_url}/v1/chat/completions"
        payload = {
            "model": self.model,
            "messages": ([{"role": "system", "content": system}] if system else [])
            + [m.to_dict() for m in messages],
            "tools": tools,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": True,
        }
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            async with client.stream("POST", url, headers=self._headers(), json=payload) as resp:
                if resp.status_code != 200:
                    raise ProviderError(f"Gem API stream HTTP {resp.status_code}")
                async for line in resp.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    chunk = line[5:].strip()
                    if chunk == "[DONE]":
                        break
                    try:
                        data = json.loads(chunk)
                    except json.JSONDecodeError:
                        continue
                    choices = data.get("choices") or []
                    if choices:
                        piece = choices[0].get("delta", {}).get("content")
                        if piece:
                            yield piece
