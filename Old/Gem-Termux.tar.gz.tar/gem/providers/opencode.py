"""OpenCode provider - the default backend for Gem.

Speaks the OpenAI-compatible Chat Completions API exposed by the OpenCode zen
plan. The default model is ``longcat-2.0-free``. Credentials come from the
``OPENCODE_API_KEY`` env var or ``config/secrets.toml`` - NEVER from source.

Architecture:
    Agent -> Provider (this) -> OpenCode API -> configured model
"""
from __future__ import annotations

import json
import re
import time
from typing import Any, AsyncIterator

import httpx

from ..exceptions import ProviderError, ProviderNotConfiguredError, TimeoutError as GemTimeout
from .base import (
    GenerateResult,
    Message,
    Provider,
    ToolCall,
    ToolSchema,
)


_LONGCAT_CALL = re.compile(r"<longcat_tool_call>\s*([A-Za-z0-9_]+)\s*(.*?)(?=<longcat_tool_call>|$)", re.S)
_LONGCAT_KV = re.compile(r"<longcat_arg_key>(.*?)</longcat_arg_key>\s*<longcat_arg_value>(.*?)</longcat_arg_value>", re.S)


def _parse_longcat_tool_calls(content: str) -> list[ToolCall]:
    """Parse the longcat native text tool-call format from content.

    Format:
        <longcat_tool_call>tool_name
        <longcat_arg_key>k</longcat_arg_key><longcat_arg_value>v</longcat_arg_value>
        ...
    """
    calls: list[ToolCall] = []
    for m in _LONGCAT_CALL.finditer(content):
        name = m.group(1).strip()
        body = m.group(2)
        args: dict[str, Any] = {}
        for km in _LONGCAT_KV.finditer(body):
            key = km.group(1).strip()
            val = km.group(2).strip()
            # try to coerce numbers/bools/json
            try:
                val = json.loads(val)
            except (json.JSONDecodeError, ValueError):
                pass
            args[key] = val
        calls.append(ToolCall(id=f"call_{len(calls)}", name=name, arguments=args))
    return calls


class OpenCodeProvider(Provider):
    name = "opencode"

    def __init__(
        self,
        model: str = "longcat-2.0-free",
        api_key: str = "",
        base_url: str = "https://opencode.ai/zen/v1",
        timeout: float = 120.0,
        max_retries: int = 3,
        **opts: Any,
    ) -> None:
        super().__init__(model, api_key, base_url, **opts)
        self.timeout = timeout
        self.max_retries = max_retries

    def _headers(self) -> dict[str, str]:
        if not self.api_key:
            raise ProviderNotConfiguredError(
                "opencode",
                "Set OPENCODE_API_KEY env var or [opencode].api_key in config/secrets.toml.",
            )
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _build_payload(
        self,
        messages: list[Message],
        tools: list[ToolSchema] | None,
        system: str | None,
        temperature: float,
        max_tokens: int,
        stream: bool = False,
    ) -> dict[str, Any]:
        msg_list: list[dict[str, Any]] = []
        if system:
            msg_list.append({"role": "system", "content": system})
        for m in messages:
            msg_list.append(m.to_dict())
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": msg_list,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
        }
        if tools:
            payload["tools"] = [
                {"type": "function", "function": t} if "function" not in t else t
                for t in tools
            ]
        return payload

    async def generate(
        self,
        messages: list[Message],
        tools: list[ToolSchema] | None = None,
        system: str | None = None,
        temperature: float = 0.3,
        max_tokens: int = 4096,
    ) -> GenerateResult:
        payload = self._build_payload(messages, tools, system, temperature, max_tokens, stream=False)
        url = f"{self.base_url}/chat/completions"

        last_err: Exception | None = None
        for attempt in range(1, self.max_retries + 1):
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    resp = await client.post(url, headers=self._headers(), json=payload)
                if resp.status_code >= 500:
                    raise ProviderError(f"OpenCode server error {resp.status_code}: {resp.text[:200]}")
                if resp.status_code == 401 or resp.status_code == 403:
                    raise ProviderNotConfiguredError("opencode", "API key rejected by OpenCode.")
                if resp.status_code != 200:
                    raise ProviderError(f"OpenCode HTTP {resp.status_code}: {resp.text[:300]}")
                return self._parse_response(resp.json())
            except ProviderNotConfiguredError:
                raise
            except (httpx.TimeoutException, httpx.TransportError) as e:
                last_err = e
                # backoff then retry
                time.sleep(0.5 * attempt)
            except ProviderError as e:
                last_err = e
                if attempt < self.max_retries:
                    time.sleep(0.5 * attempt)
                else:
                    raise
        raise GemTimeout(f"OpenCode request timed out after {self.max_retries} retries: {last_err}")

    def _parse_response(self, data: dict[str, Any]) -> GenerateResult:
        choices = data.get("choices") or []
        if not choices:
            raise ProviderError(f"OpenCode returned no choices: {data}")
        choice = choices[0]
        msg = choice.get("message", {})
        content = msg.get("content") or ""
        tool_calls: list[ToolCall] = []
        for raw_tc in msg.get("tool_calls") or []:
            fn = raw_tc.get("function", {})
            args_raw = fn.get("arguments", "{}")
            try:
                args = json.loads(args_raw) if isinstance(args_raw, str) else args_raw
            except json.JSONDecodeError:
                args = {"_raw": args_raw}
            tool_calls.append(
                ToolCall(id=raw_tc.get("id", ""), name=fn.get("name", ""), arguments=args)
            )
        # Fallback: longcat models sometimes emit a native text tool-call format
        # in `content` instead of OpenAI tool_calls. Parse it so the agent still acts.
        if not tool_calls and "<longcat_tool_call>" in content:
            parsed = _parse_longcat_tool_calls(content)
            if parsed:
                tool_calls = parsed
                content = ""  # consume - the agent will execute the calls
        return GenerateResult(
            content=content,
            tool_calls=tool_calls,
            finish_reason=choice.get("finish_reason", "stop") if not tool_calls else "tool_calls",
            usage=data.get("usage", {}),
            raw=data,
        )

    async def stream(
        self,
        messages: list[Message],
        tools: list[ToolSchema] | None = None,
        system: str | None = None,
        temperature: float = 0.3,
        max_tokens: int = 4096,
    ) -> AsyncIterator[str]:
        payload = self._build_payload(messages, tools, system, temperature, max_tokens, stream=True)
        url = f"{self.base_url}/chat/completions"
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            async with client.stream("POST", url, headers=self._headers(), json=payload) as resp:
                if resp.status_code != 200:
                    body = await resp.aread()
                    raise ProviderError(f"OpenCode stream HTTP {resp.status_code}: {body.decode()[:300]}")
                async for line in resp.aiter_lines():
                    if not line or not line.startswith("data:"):
                        continue
                    chunk = line[5:].strip()
                    if chunk == "[DONE]":
                        break
                    try:
                        data = json.loads(chunk)
                    except json.JSONDecodeError:
                        continue
                    choices = data.get("choices") or []
                    if choices:
                        delta = choices[0].get("delta", {})
                        piece = delta.get("content")
                        if piece:
                            yield piece
