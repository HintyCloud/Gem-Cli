"""Gem provider system.

Providers abstract away specific LLM APIs. The agent never talks to a vendor
API directly - it calls ``provider.generate(...)``. This keeps the core portable
across OpenCode, the Gem API itself, and future external providers.
"""
from .base import Provider, Message, GenerateResult, ToolCall, ToolResult
from .registry import get_provider, register_provider, list_providers
from .opencode import OpenCodeProvider
from .gem import GemProvider

__all__ = [
    "Provider",
    "Message",
    "GenerateResult",
    "ToolCall",
    "ToolResult",
    "get_provider",
    "register_provider",
    "list_providers",
    "OpenCodeProvider",
    "GemProvider",
]
