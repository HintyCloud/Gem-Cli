"""Provider base interface and shared data models.

Every provider implements ``generate`` (and optionally ``stream``). The models
here are provider-agnostic so the agent loop is identical no matter which
backend is selected.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Literal


Role = Literal["system", "user", "assistant", "tool"]


@dataclass
class ToolCall:
    """A tool invocation requested by the model."""
    id: str
    name: str
    arguments: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "name": self.name, "arguments": self.arguments}


@dataclass
class Message:
    role: Role
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    tool_call_id: str | None = None  # for role=="tool"
    name: str | None = None  # tool name for role=="tool"

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"role": self.role, "content": self.content}
        if self.tool_calls:
            d["tool_calls"] = [tc.to_dict() for tc in self.tool_calls]
        if self.tool_call_id:
            d["tool_call_id"] = self.tool_call_id
        if self.name:
            d["name"] = self.name
        return d


@dataclass
class ToolResult:
    tool_call_id: str
    name: str
    content: str
    is_error: bool = False

    def to_message(self) -> Message:
        return Message(
            role="tool",
            content=self.content,
            tool_call_id=self.tool_call_id,
            name=self.name,
        )


@dataclass
class GenerateResult:
    content: str
    tool_calls: list[ToolCall] = field(default_factory=list)
    finish_reason: str = "stop"
    usage: dict[str, int] = field(default_factory=dict)
    raw: Any = None


# Tool schema as passed to providers (OpenAI function-calling shape).
ToolSchema = dict[str, Any]


class Provider(ABC):
    """Abstract provider. Implementations talk to a concrete LLM API."""

    name: str = "base"

    def __init__(self, model: str, api_key: str = "", base_url: str = "", **opts: Any) -> None:
        self.model = model
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.opts = opts

    @abstractmethod
    async def generate(
        self,
        messages: list[Message],
        tools: list[ToolSchema] | None = None,
        system: str | None = None,
        temperature: float = 0.3,
        max_tokens: int = 4096,
    ) -> GenerateResult:
        """Generate a completion. Must raise ProviderError on failure."""

    async def stream(
        self,
        messages: list[Message],
        tools: list[ToolSchema] | None = None,
        system: str | None = None,
        temperature: float = 0.3,
        max_tokens: int = 4096,
    ) -> AsyncIterator[str]:
        """Stream text tokens. Default: generate then yield once."""
        result = await self.generate(messages, tools, system, temperature, max_tokens)
        yield result.content

    def is_configured(self) -> bool:
        """Return True when the provider has the credentials it needs."""
        return bool(self.api_key)

    def describe(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "model": self.model,
            "base_url": self.base_url,
            "configured": self.is_configured(),
        }
