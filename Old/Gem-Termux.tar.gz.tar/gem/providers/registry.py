"""Provider registry - instantiate providers by name."""
from __future__ import annotations

from typing import Any

from ..config import get_config
from ..exceptions import ProviderNotConfiguredError
from .base import Provider
from .opencode import OpenCodeProvider
from .gem import GemProvider


_REGISTRY: dict[str, type[Provider]] = {
    "opencode": OpenCodeProvider,
    "gem": GemProvider,
}


def register_provider(name: str, cls: type[Provider]) -> None:
    _REGISTRY[name] = cls


def list_providers() -> list[str]:
    return sorted(_REGISTRY.keys())


def get_provider(name: str | None = None, **overrides: Any) -> Provider:
    """Build a provider instance from config. Raises if not configured."""
    cfg = get_config()
    pname = name or cfg.provider.name
    if pname not in _REGISTRY:
        raise ProviderNotConfiguredError(pname, f"Unknown provider. Available: {list_providers()}")
    cls = _REGISTRY[pname]
    kwargs: dict[str, Any] = {
        "model": cfg.provider.model,
        "api_key": cfg.provider.api_key,
        "base_url": cfg.provider.base_url,
    }
    if pname == "gem":
        kwargs["base_url"] = f"http://{cfg.server.host}:{cfg.server.port}"
    kwargs.update(overrides)
    provider = cls(**kwargs)
    if not provider.is_configured():
        raise ProviderNotConfiguredError(
            pname,
            "No API key/credentials found. Set OPENCODE_API_KEY or edit config/secrets.toml.",
        )
    return provider


def try_get_provider(name: str | None = None, **overrides: Any) -> Provider | None:
    """Like get_provider but returns None instead of raising when unconfigured."""
    try:
        return get_provider(name, **overrides)
    except ProviderNotConfiguredError:
        return None
