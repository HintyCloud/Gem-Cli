# Gem

**Gem** is a complete agentic AI ecosystem for development, automation, programming, research and task execution. It is a genuine agent (not just a chatbot): it understands a task, plans it, selects tools/agents, executes, observes results, analyzes and corrects errors, and continues until the task is done.

```
User → Gem → understand → plan → select tools/agents → execute → observe →
       analyze errors → correct → continue → test → conclude → deliver
```

## Architecture (shared-core monorepo)

The core is shared across every distribution. The CLI, Web UI and API all drive the **same** core, so behaviour is identical everywhere.

```
Gem/
├── gem/                  # shared Python core
│   ├── agent/            # loop, planner, context, executor, supervisor
│   ├── swarm/            # coordinator, worker, pool, strategies (12 agent profiles)
│   ├── tools/            # registry, shell, files, web, image, git, archive, artifacts
│   ├── memory/           # history, memory, search
│   ├── providers/        # base, opencode, gem, registry
│   ├── api/              # FastAPI app, routes, websocket, auth
│   ├── jobs/             # manager, queue, state, recovery (persistent background jobs)
│   ├── sandbox/          # base, local (workspace-bound execution)
│   ├── platform/         # detect (Linux/Windows/Termux/Android), linux, windows, termux
│   ├── cli.py            # `gem` CLI
│   ├── server.py         # `gem serve`
│   ├── config.py         # config + secrets loading
│   └── exceptions.py     # typed error hierarchy (no bare except: pass)
├── src/                  # Next.js 16 Web UI (chat, projects, activity, diff, artifacts)
├── projects/             # isolated project workspaces
├── data/                 # chats/, memory/, checkpoints/, jobs/, artifacts/, logs/
├── config/               # config.toml (public) + secrets.toml (gitignored)
├── tests/                # 59 real tests (mocks for external services)
├── scripts/              # build_all.py (generates all distributions)
├── packaging/            # per-distro install/run scripts
├── pyproject.toml        # `pip install -e .` then `gem`
└── README.md
```

### Layering

```
Client  →  Gem API (HTTP/SSE)  →  Gem Core  →  Agent  →  Tools / Providers / Swarm
                                                          ↓
                                               OpenCode Provider  →  configured model
```

The **Gem API** is the public entry point of the ecosystem. The **Gem provider** (`gem/providers/gem.py`) lets external clients use Gem itself as a provider:

```
Gem Client → Gem API → Gem Core → OpenCode Provider → model
```

## Install

```bash
pip install -e .
gem status          # verify install
```

Put your OpenCode zen key in `config/secrets.toml` (gitignored) or `export OPENCODE_API_KEY=...`:

```toml
[opencode]
api_key = "sk-..."
```

## Configuration (`config/config.toml`)

```toml
[gem]
workspace = "./projects"

[agent]
max_iterations = 50
command_timeout = 120
auto_continue = true

[provider]
name = "opencode"
model = "longcat-2.0-free"
base_url = "https://opencode.ai/zen/v1"

[server]
host = "127.0.0.1"   # never exposed to public internet by default
port = 8000

[swarm]
max_agents = 4

[image]
provider = "pollinations"
```

Secrets NEVER go in source or versioned config — only env vars or `config/secrets.toml`.

## CLI

```bash
gem serve              # start the Gem API (127.0.0.1:8000)
gem chat               # interactive chat (project workspace)
gem project list       # list projects
gem project create foo # create a project
gem jobs               # list background jobs
gem models             # show configured model
gem providers          # list providers
gem tools              # list tools
gem agents             # list swarm agent profiles
gem status             # system status
```

In-chat slash commands: `/help /model /provider /chats /new /clear /status /jobs /agents /tools /exit`.
Use `@swarm <task>` in chat to run a task through the swarm supervisor.

## Web UI

```bash
gem serve        # API on :8000
bun run dev      # Web UI on :3000 (Next.js)
```

Open the Web UI. It warms up the API automatically and provides:
- Chat with streaming agent activity (planning, creating files, running commands, diff view, completed).
- Chats: new / continue / rename / delete / search.
- Projects: create, browse file trees, set active workspace.
- File upload (validated, workspace-bound).
- Artifacts: list and download generated images/code/builds.
- Jobs: live status with progress.
- System status (provider, model, platform).

## Agent loop (`gem/agent/loop.py`)

1. receive message → 2. load context → 3. load relevant memory → 4. load project →
5. send to model → 6. interpret → 7. detect tool calls → 8. execute → 9. return results →
10. continue → 11. detect errors → 12. correct → 13. update context → 14. save checkpoint →
15. continue until done → 16. respond.

Multiple tools per iteration. Checkpoints every 5 iterations. Auto-continue across token/session limits via checkpoint summaries.

## Tools

`shell` · `files` (read/write/edit/list/move/copy/remove/mkdir/exists/metadata) · `web_search` · `image` (Pollinations) · `git` · `archive` (zip/tar.gz) · `artifacts`. The registry is extensible — interfaces are real for future `browser/sandbox/vm/upload/download/video/audio/database/docker/cloud` providers.

## Swarm / Subagents

A Supervisor decomposes complex tasks and dispatches to specialised workers (sequential or parallel, bounded by `max_agents`):

```
            Supervisor
                │
   ┌────────────┼────────────┐
   v            v            v
 Agent A     Agent B      Agent C
 coding     research      tests
   └────────────┼────────────┘
                v
           Supervisor → Result
```

Real agent profiles: `general, coder, researcher, tester, frontend, backend, reviewer, planner` + mini agents (`minicoder, miniresearcher, minitester, minireviewer`) for lighter tasks. Each has a distinct system prompt and scoped toolset.

## Jobs

Persistent background tasks. States: `queued → running → completed | failed | cancelled | paused | recovering`. On restart, interrupted jobs are auto-detected and resumed from checkpoints.

## Memory vs History

- **History** (`data/chats/`) — the full conversation log per chat.
- **Memory** (`data/memory/`) — curated persistent facts the agent chose to remember. We do NOT auto-promote every message to permanent memory.

## Image generation

```
Agent → Image Tool → Image Provider → Pollinations
```

Generated images are saved to `data/artifacts/` and registered for download/display. Other providers can be added behind the same interface.

## Security

- Path traversal / workspace boundary enforcement in `files`, `archive`, `shell` cwd.
- Destructive command denylist (`rm -rf /`, `mkfs`, `dd to disk`, fork bombs, shutdown/reboot).
- Command timeout + process kill.
- Secret redaction in command output (API keys, tokens).
- Upload/download validation.
- Local-only server by default (`127.0.0.1`).
- Typed exceptions — no bare `except: pass` anywhere.

## Termux / Android

Gem detects Termux dynamically and adapts paths/shell. It does NOT assume systemd, sudo or Docker. Background execution is best-effort: Gem is designed to **recover interrupted tasks from checkpoints** when the process is restarted (Android does not guarantee infinite background execution). `termux-wake-lock` is used when available.

## Distributions

`scripts/build_all.py` generates six tarballs + `Gem.zip` in `dist/`:

| Distribution | Focus |
|---|---|
| `Gem-Linux.tar.gz` | Full Gem for Linux |
| `Gem-Windows.tar.gz` | Full Gem with Windows adapters (no Bash assumed) |
| `Gem-Termux.tar.gz` | Mobile-optimized for Termux/Android (ARM32/ARM64) |
| `Gem-Latest.tar.gz` | Primary distro: core + API + Web UI + CLI + swarm + OpenCode/longcat config |
| `Gem-Cli.tar.gz` | Terminal-first |
| `Gem-Development.tar.gz` | Source + tests + dev tooling |
| `Gem.zip` | Complete project |

All share the same `gem/` core. Each excludes `.git`, `__pycache__`, caches, venvs, secrets and temp files. A secret scan runs before packaging.

## Development

```bash
python3 -m pytest tests/ -q     # 59 tests
bun run lint                    # Web UI lint
```

## License

MIT.
