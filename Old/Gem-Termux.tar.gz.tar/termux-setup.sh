#!/data/data/com.termux/files/usr/bin/bash
# Termux setup helper for Gem.
set -e
echo "Setting up Gem for Termux..."
pkg install -y python git 2>/dev/null || true
pip install -e . --quiet || pip install -e .
# Enable wake lock if available (keeps CPU alive while foregrounded).
command -v termux-wake-lock >/dev/null 2>&1 && termmux-wake-lock 2>/dev/null || true
echo "Done. Run: ./run.sh  (or: gem chat)"
