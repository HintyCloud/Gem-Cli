"use client";

/**
 * useGemChat - owns the active chat, the message/turn stream, and the live
 * SSE connection to the Gem /chat endpoint.
 *
 * A "turn" is one user message + all the agent activity that follows it
 * (planning, tool calls, file ops, assistant chunks, swarm events) until the
 * `done` or `error` terminator arrives. Each turn carries a flat list of
 * events that the UI renders as activity cards inline in the conversation.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { gemApi, streamChat, type ChatDetail, type ChatMessage, type ChatSummary, type GemEvent } from "@/lib/gem";
import { toast } from "sonner";

export interface Turn {
  id: string;
  userMessage: string;
  events: GemEvent[];
  /** Accumulated assistant text from `assistant` events. */
  assistantContent: string;
  status: "streaming" | "done" | "error";
  isSwarm: boolean;
  startedAt: number;
}

interface UseGemChatOptions {
  project: string;
  onChatsChanged?: () => void;
}

function makeId(): string {
  return `turn-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

/** Convert a stored ChatDetail into a list of turns (for history loading). */
export function turnsFromChat(detail: ChatDetail): Turn[] {
  const turns: Turn[] = [];
  let current: Turn | null = null;
  const pushCurrent = () => {
    if (current) {
      current.status = "done";
      turns.push(current);
      current = null;
    }
  };
  for (const msg of detail.messages) {
    if (msg.role === "user") {
      pushCurrent();
      current = {
        id: makeId(),
        userMessage: msg.content,
        events: [{ type: "user", content: msg.content }],
        assistantContent: "",
        status: "done",
        isSwarm: false,
        startedAt: new Date(msg.timestamp).getTime() || Date.now(),
      };
    } else if (msg.role === "assistant") {
      if (!current) {
        // Orphan assistant message - create an empty turn.
        current = {
          id: makeId(),
          userMessage: "",
          events: [],
          assistantContent: "",
          status: "done",
          isSwarm: false,
          startedAt: Date.now(),
        };
      }
      current.assistantContent += (current.assistantContent ? "\n" : "") + msg.content;
      current.events.push({ type: "assistant", content: msg.content });
      if (msg.tool_calls?.length) {
        for (const tc of msg.tool_calls) {
          const name = (tc.name as string) || "tool";
          const args = (tc.arguments as Record<string, unknown>) || {};
          current.events.push({ type: "tool_call", name, arguments: args });
        }
      }
      if (msg.activity?.length) {
        for (const a of msg.activity) {
          const label = (a.label as string) || (a.content as string) || "activity";
          current.events.push({ type: "activity", label });
        }
      }
    } else if (msg.role === "event") {
      const text = msg.content || (msg.meta?.content as string) || "";
      if (current) {
        current.events.push({ type: "event", content: text });
      }
    } else if (msg.role === "tool") {
      // Tool result - reconstruct as a tool_result event if we can.
      if (current) {
        const isErr = Boolean(msg.meta?.is_error);
        current.events.push({ type: "tool_result", name: "tool", is_error: isErr, content: msg.content });
      }
    }
  }
  pushCurrent();
  return turns;
}

export function useGemChat({ project, onChatsChanged }: UseGemChatOptions) {
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [activeChatTitle, setActiveChatTitle] = useState<string>("");
  const [turns, setTurns] = useState<Turn[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [isLoadingChat, setIsLoadingChat] = useState(false);

  const abortRef = useRef<AbortController | null>(null);
  // Keep latest project for use inside the stream callback without re-subscribing.
  const projectRef = useRef(project);
  useEffect(() => {
    projectRef.current = project;
  }, [project]);
  const onChatsChangedRef = useRef(onChatsChanged);
  useEffect(() => {
    onChatsChangedRef.current = onChatsChanged;
  }, [onChatsChanged]);

  const newChat = useCallback(async (silent = false): Promise<string | null> => {
    try {
      const c = await gemApi.createChat("New chat");
      setActiveChatId(c.id);
      setActiveChatTitle(c.title);
      setTurns([]);
      onChatsChangedRef.current?.();
      if (!silent) toast.success("New chat created");
      return c.id;
    } catch (e) {
      toast.error("Failed to create chat", { description: (e as Error).message });
      return null;
    }
  }, []);

  const loadChat = useCallback(async (id: string) => {
    if (abortRef.current) {
      abortRef.current.abort();
      abortRef.current = null;
    }
    setIsStreaming(false);
    setIsLoadingChat(true);
    try {
      const detail = await gemApi.getChat(id);
      setActiveChatId(detail.id);
      setActiveChatTitle(detail.title);
      setTurns(turnsFromChat(detail));
    } catch (e) {
      toast.error("Failed to load chat", { description: (e as Error).message });
    } finally {
      setIsLoadingChat(false);
    }
  }, []);

  const selectChat = useCallback(
    async (id: string | null) => {
      if (!id) {
        setActiveChatId(null);
        setActiveChatTitle("");
        setTurns([]);
        return;
      }
      await loadChat(id);
    },
    [loadChat],
  );

  const renameChat = useCallback(
    async (id: string, title: string) => {
      try {
        const updated = await gemApi.renameChat(id, title);
        if (id === activeChatId) setActiveChatTitle(updated.title);
        onChatsChangedRef.current?.();
        toast.success("Chat renamed");
      } catch (e) {
        toast.error("Failed to rename chat", { description: (e as Error).message });
      }
    },
    [activeChatId],
  );

  const deleteChat = useCallback(
    async (id: string) => {
      try {
        await gemApi.deleteChat(id);
        if (id === activeChatId) {
          setActiveChatId(null);
          setActiveChatTitle("");
          setTurns([]);
        }
        onChatsChangedRef.current?.();
        toast.success("Chat deleted");
      } catch (e) {
        toast.error("Failed to delete chat", { description: (e as Error).message });
      }
    },
    [activeChatId],
  );

  const stop = useCallback(() => {
    if (abortRef.current) {
      abortRef.current.abort();
      abortRef.current = null;
    }
    setIsStreaming(false);
    setTurns((prev) => {
      if (prev.length === 0) return prev;
      const next = [...prev];
      const last = next[next.length - 1];
      if (last.status === "streaming") {
        next[next.length - 1] = { ...last, status: "done" };
      }
      return next;
    });
  }, []);

  const send = useCallback(
    async (message: string, opts?: { swarm?: boolean; chatId?: string }) => {
      const text = message.trim();
      if (!text || isStreaming) return;

      // Determine target chat id (create lazily if none active).
      let chatId = opts?.chatId ?? activeChatId;
      if (!chatId) {
        chatId = await newChat(true) ?? undefined;
      }
      if (!chatId) return;

      const turnId = makeId();
      const turn: Turn = {
        id: turnId,
        userMessage: text,
        events: [{ type: "user", content: text }],
        assistantContent: "",
        status: "streaming",
        isSwarm: !!opts?.swarm,
        startedAt: Date.now(),
      };
      setTurns((prev) => [...prev, turn]);

      const controller = new AbortController();
      abortRef.current = controller;
      setIsStreaming(true);

      // Patch the turn by id.
      const patch = (fn: (t: Turn) => Turn) => {
        setTurns((prev) =>
          prev.map((t) => (t.id === turnId ? fn(t) : t)),
        );
      };

      try {
        await streamChat(
          { message: text, project: projectRef.current || "default", chat_id: chatId, swarm: !!opts?.swarm },
          (ev) => {
            patch((t) => {
              const events = [...t.events, ev];
              let assistantContent = t.assistantContent;
              let status = t.status;
              if (ev.type === "assistant" && typeof ev.content === "string") {
                assistantContent = assistantContent + (assistantContent ? "\n" : "") + ev.content;
              } else if (ev.type === "done") {
                status = "done";
              } else if (ev.type === "error") {
                status = "error";
              } else if (ev.type === "swarm_done") {
                status = "done";
              }
              return { ...t, events, assistantContent, status };
            });
          },
          controller.signal,
        );
        // Mark done if the stream ended without an explicit done/error event.
        patch((t) => (t.status === "streaming" ? { ...t, status: "done" } : t));
        onChatsChangedRef.current?.();
      } catch (e) {
        const err = e as Error;
        if (err.name === "AbortError") {
          patch((t) => (t.status === "streaming" ? { ...t, status: "done" } : t));
        } else {
          patch((t) => ({
            ...t,
            status: "error",
            events: [...t.events, { type: "error", content: err.message }],
          }));
          toast.error("Chat error", { description: err.message });
        }
      } finally {
        if (abortRef.current === controller) abortRef.current = null;
        setIsStreaming(false);
      }
    },
    [activeChatId, isStreaming, newChat],
  );

  // Cleanup on unmount.
  useEffect(() => {
    return () => {
      if (abortRef.current) abortRef.current.abort();
    };
  }, []);

  return {
    activeChatId,
    activeChatTitle,
    turns,
    isStreaming,
    isLoadingChat,
    setActiveChatTitle,
    newChat,
    selectChat,
    loadChat,
    renameChat,
    deleteChat,
    send,
    stop,
  };
}

export type UseGemChat = ReturnType<typeof useGemChat>;

// Re-export for convenience.
export type { ChatSummary, ChatMessage, ChatDetail, GemEvent };
