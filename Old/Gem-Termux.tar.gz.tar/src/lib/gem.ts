/**
 * Gem API client.
 *
 * All requests go through the Caddy gateway on port 81, which routes any
 * request carrying `?XTransformPort=N` to port N. The Gem Python API lives on
 * port 8000, so every URL we build here appends `?XTransformPort=8000`.
 *
 * We never use absolute URLs (no http://localhost:8000) so the page works in
 * the sandbox preview without CORS issues.
 */

export const GEM_PORT = "8000";

/** Build a relative URL that the gateway will forward to the Gem API. */
export function gemUrl(path: string, params?: Record<string, string | number | boolean | undefined>): string {
  const url = new URL(path, window.location.origin);
  url.searchParams.set("XTransformPort", GEM_PORT);
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null) url.searchParams.set(k, String(v));
    }
  }
  // Return only the relative part (pathname + search) so it works behind any host.
  return url.pathname + url.search;
}

async function gemJson<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(gemUrl(path), {
    headers: { "Content-Type": "application/json", ...(init?.headers || {}) },
    ...init,
  });
  if (!res.ok) {
    let detail = "";
    try {
      const j = await res.json();
      detail = j?.detail || j?.message || JSON.stringify(j).slice(0, 200);
    } catch {
      detail = await res.text().catch(() => "");
    }
    throw new Error(`Gem API ${res.status}: ${detail || res.statusText}`);
  }
  return res.json() as Promise<T>;
}

/**
 * Warm up the Python Gem API. The sandbox kills processes spawned from bash
 * tool calls, so the API is launched as a child of the persistent Next.js Node
 * process via the /api/gem-bridge route (port 3000, no XTransformPort). Calling
 * this on app mount ensures port 8000 is alive before any Gem API request.
 */
let _warmPromise: Promise<void> | null = null;
export async function ensureGemApi(): Promise<void> {
  if (_warmPromise) return _warmPromise;
  _warmPromise = (async () => {
    const deadline = Date.now() + 20000;
    while (Date.now() < deadline) {
      try {
        // Hit the bridge (port 3000) which spawns + keeps the API alive.
        await fetch("/api/gem-bridge", { method: "POST" }).catch(() => {});
        // Now verify the API itself responds.
        const r = await fetch(gemUrl("/status"), { method: "GET" });
        if (r.ok) return;
      } catch {
        // keep retrying
      }
      await new Promise((r) => setTimeout(r, 1000));
    }
  })();
  return _warmPromise;
}

// ===================== Types =====================

/** Discriminated union of all SSE events emitted by the Gem /chat endpoint. */
export type GemEvent =
  | { type: "user"; content: string }
  | { type: "plan"; steps: Array<{ title: string; goal: string; agent: string }> }
  | { type: "iteration"; n: number }
  | { type: "assistant"; content: string }
  | { type: "tool_call"; name: string; arguments: Record<string, unknown> }
  | { type: "activity"; label: string }
  | { type: "file_created"; path: string; content: string }
  | { type: "file_edited"; path: string; old: string; new: string }
  | { type: "command"; command: string; result: string; is_error: boolean }
  | { type: "tool_result"; name: string; is_error: boolean; content: string }
  | { type: "checkpoint"; iteration: number }
  | { type: "done"; content: string }
  | { type: "error"; content: string }
  | { type: "event"; content: string }
  | { type: "swarm_start"; task: string }
  | { type: "swarm_plan"; plan: unknown }
  | { type: "agent_start"; agent: string; role: string; task: string }
  | { type: "agent_done"; agent: string; result: string; status: string }
  | { type: "swarm_done"; result: string; results: unknown }
  | { type: string; [k: string]: unknown };

export interface PlatformInfo {
  name: string;
  system: string;
  machine: string;
  is_termux: boolean;
  is_android: boolean;
  shell: string;
}
export interface ProviderInfo {
  name: string;
  model?: string;
  base_url?: string;
  configured: boolean;
}
export interface StatusInfo {
  ok: boolean;
  version: string;
  platform: PlatformInfo;
  provider: ProviderInfo;
  providers_available: string[];
  model: string;
  jobs_running: number;
  jobs_pending: number;
}

export interface ChatSummary {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
  message_count: number;
}

export interface ChatMessage {
  role: "user" | "assistant" | "tool" | "system" | "event";
  content: string;
  timestamp: string;
  meta: Record<string, unknown>;
  tool_calls: Array<Record<string, unknown>>;
  activity: Array<Record<string, unknown>>;
}
export interface ChatDetail {
  id: string;
  title: string;
  messages: ChatMessage[];
}

export interface MemoryEntry {
  id: string;
  text: string;
  tags: string[];
  project?: string;
  created_at: string;
}

export interface ProjectInfo {
  name: string;
  path: string;
}

export interface FileEntry {
  name: string;
  type: "file" | "dir";
  size: number;
}
export interface ProjectFile {
  type: "file" | "dir";
  path: string;
  content?: string;
  entries?: FileEntry[];
}

export interface ToolInfo {
  name: string;
  description: string;
}
export interface AgentInfo {
  name: string;
  role: string;
}
export interface ModelInfo {
  id: string;
  provider: string;
  current: boolean;
}

export interface ArtifactInfo {
  name: string;
  path?: string;
  type?: string;
  size?: number;
  created_at?: string;
}

export interface SearchHit {
  chat_id: string;
  title: string;
  index: number;
  role: string;
  snippet: string;
}
export interface SearchResults {
  history: SearchHit[];
  memory: MemoryEntry[];
}

export type JobStatus =
  | "queued"
  | "running"
  | "completed"
  | "failed"
  | "cancelled"
  | "paused"
  | "recovering";

export interface JobState {
  job_id: string;
  task: string;
  project: string;
  status: JobStatus;
  created_at: string;
  started_at?: string;
  finished_at?: string;
  result?: string;
  error?: string;
  task_id?: string;
  events: Array<Record<string, unknown>>;
  progress: number;
  use_swarm: boolean;
}

export interface CheckpointInfo {
  id: string;
  project: string;
  status?: string;
  created_at?: string;
  [k: string]: unknown;
}

// ===================== Endpoint wrappers =====================
export const gemApi = {
  ensureGemApi,
  status: () => gemJson<StatusInfo>("/status"),
  // chats
  listChats: () => gemJson<ChatSummary[]>("/chats"),
  createChat: (title = "New chat") =>
    gemJson<ChatSummary>("/chats", { method: "POST", body: JSON.stringify({ title }) }),
  getChat: (id: string) => gemJson<ChatDetail>(`/chats/${encodeURIComponent(id)}`),
  renameChat: (id: string, title: string) =>
    gemJson<ChatSummary>(`/chats/${encodeURIComponent(id)}`, {
      method: "PATCH",
      body: JSON.stringify({ title }),
    }),
  deleteChat: (id: string) =>
    gemJson<{ deleted: boolean }>(`/chats/${encodeURIComponent(id)}`, { method: "DELETE" }),
  // search
  search: (q: string) => gemJson<SearchResults>(`/search?q=${encodeURIComponent(q)}`),
  // memory
  listMemory: () => gemJson<MemoryEntry[]>("/memory"),
  addMemory: (text: string, tags: string[] = [], project?: string) =>
    gemJson<MemoryEntry>("/memory", { method: "POST", body: JSON.stringify({ text, tags, project }) }),
  deleteMemory: (id: string) =>
    gemJson<{ deleted: boolean }>(`/memory/${encodeURIComponent(id)}`, { method: "DELETE" }),
  // projects
  listProjects: () => gemJson<ProjectInfo[]>("/projects"),
  createProject: (name: string) =>
    gemJson<ProjectInfo>("/projects", { method: "POST", body: JSON.stringify({ name }) }),
  projectFiles: (name: string, path = "") =>
    gemJson<ProjectFile>(`/projects/${encodeURIComponent(name)}/files`, { params: { path } }),
  // jobs
  listJobs: () => gemJson<JobState[]>("/jobs"),
  createJob: (task: string, project: string, swarm = false) =>
    gemJson<JobState>("/jobs", {
      method: "POST",
      body: JSON.stringify({ task, project, swarm }),
    }),
  getJob: (id: string) => gemJson<JobState>(`/jobs/${encodeURIComponent(id)}`),
  cancelJob: (id: string) =>
    gemJson<JobState>(`/jobs/${encodeURIComponent(id)}`, { method: "DELETE" }),
  // misc
  listTools: () => gemJson<ToolInfo[]>("/tools"),
  listAgents: () => gemJson<AgentInfo[]>("/agents"),
  listModels: () => gemJson<ModelInfo[]>("/models"),
  listProviders: () => gemJson<{ name: string }[]>("/providers"),
  listArtifacts: () => gemJson<ArtifactInfo[]>("/artifacts"),
  listCheckpoints: () => gemJson<CheckpointInfo[]>("/checkpoints"),
};

// ===================== SSE streaming for /chat =====================
export interface ChatRequestBody {
  message: string;
  project?: string;
  chat_id?: string;
  swarm?: boolean;
}

/**
 * POST to /chat and stream SSE events via a ReadableStream reader.
 * We can't use EventSource because /chat is POST.
 *
 * Calls `onEvent` for every parsed event, returns when the stream ends
 * ([DONE] or connection close). The provided AbortSignal lets the caller stop.
 */
export async function streamChat(
  body: ChatRequestBody,
  onEvent: (ev: GemEvent) => void,
  signal?: AbortSignal,
): Promise<void> {
  const res = await fetch(gemUrl("/chat"), {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "text/event-stream",
    },
    body: JSON.stringify(body),
    signal,
  });

  if (!res.ok) {
    let detail = "";
    try {
      const j = await res.json();
      detail = j?.detail || j?.message || "";
    } catch {
      detail = await res.text().catch(() => "");
    }
    throw new Error(`Gem chat ${res.status}: ${detail || res.statusText}`);
  }
  if (!res.body) throw new Error("No response body for chat stream");

  const reader = res.body.getReader();
  const decoder = new TextDecoder("utf-8");
  let buffer = "";

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      // SSE frames are separated by a blank line. Each frame may carry one or
      // more `data:` lines (we only ever get one per frame from the server).
      let sep: number;
      while ((sep = buffer.indexOf("\n\n")) !== -1) {
        const frame = buffer.slice(0, sep);
        buffer = buffer.slice(sep + 2);
        // Skip keepalive comments (`: keepalive`).
        if (frame.startsWith(":")) continue;

        for (const line of frame.split("\n")) {
          const trimmed = line.trim();
          if (!trimmed.startsWith("data:")) continue;
          const payload = trimmed.slice(5).trim();
          if (payload === "[DONE]") return;
          if (!payload) continue;
          try {
            const ev = JSON.parse(payload) as GemEvent;
            onEvent(ev);
          } catch {
            // Ignore malformed lines (shouldn't happen).
          }
        }
      }
    }
  } finally {
    try {
      reader.releaseLock();
    } catch {
      /* noop */
    }
  }
}

// ===================== Simple LCS line diff =====================
export interface DiffLine {
  type: "add" | "del" | "ctx";
  text: string;
}

/** Compute a unified line diff between two strings. */
export function lineDiff(oldStr: string, newStr: string): DiffLine[] {
  const a = oldStr.split("\n");
  const b = newStr.split("\n");
  const n = a.length;
  const m = b.length;
  // dp[i][j] = LCS length of a[i..] and b[j..]
  const dp: number[][] = Array.from({ length: n + 1 }, () => new Array<number>(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  const out: DiffLine[] = [];
  let i = 0;
  let j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) {
      out.push({ type: "ctx", text: a[i] });
      i++;
      j++;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      out.push({ type: "del", text: a[i] });
      i++;
    } else {
      out.push({ type: "add", text: b[j] });
      j++;
    }
  }
  while (i < n) {
    out.push({ type: "del", text: a[i++] });
  }
  while (j < m) {
    out.push({ type: "add", text: b[j++] });
  }
  return out;
}

// ===================== Helpers =====================
export function formatBytes(n: number): string {
  if (!n) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
}

export function timeAgo(iso: string): string {
  if (!iso) return "";
  const t = new Date(iso.replace(" ", "T")).getTime();
  if (Number.isNaN(t)) return "";
  const diff = Date.now() - t;
  const s = Math.floor(diff / 1000);
  if (s < 60) return "just now";
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  return new Date(t).toLocaleDateString();
}

export function copyToClipboard(text: string): Promise<void> {
  if (navigator?.clipboard?.writeText) return navigator.clipboard.writeText(text);
  return new Promise((resolve) => {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand("copy");
    } catch {
      /* noop */
    }
    document.body.removeChild(ta);
    resolve();
  });
}
