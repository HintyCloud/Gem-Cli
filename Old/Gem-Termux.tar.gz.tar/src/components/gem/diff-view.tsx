"use client";

import { useMemo } from "react";
import { lineDiff, type DiffLine } from "@/lib/gem";
import { cn } from "@/lib/utils";

interface DiffViewProps {
  oldStr: string;
  newStr: string;
  /** Max lines before the body scrolls. */
  maxLines?: number;
  className?: string;
}

/**
 * Compact unified-diff renderer. Computes a simple LCS line diff between the
 * `old` and `new` strings and renders removed lines in red, added lines in
 * green, unchanged lines muted.
 */
export function DiffView({ oldStr, newStr, maxLines = 24, className }: DiffViewProps) {
  const diff = useMemo<DiffLine[]>(() => lineDiff(oldStr || "", newStr || ""), [oldStr, newStr]);
  const added = diff.filter((d) => d.type === "add").length;
  const removed = diff.filter((d) => d.type === "del").length;

  return (
    <div className={cn("rounded-md border border-border overflow-hidden bg-zinc-950 text-zinc-100", className)}>
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-zinc-800 bg-zinc-900/60 text-[11px] font-mono">
        <span className="text-zinc-400">
          <span className="text-emerald-400">+{added}</span>
          <span className="mx-2 text-zinc-600">·</span>
          <span className="text-rose-400">-{removed}</span>
        </span>
        <span className="text-zinc-500">unified diff</span>
      </div>
      <pre
        className="gem-scroll overflow-auto text-[12px] leading-relaxed font-mono p-0 m-0"
        style={{ maxHeight: `${maxLines * 1.5}rem` }}
      >
        {diff.length === 0 ? (
          <div className="px-3 py-2 text-zinc-500 italic">No changes</div>
        ) : (
          diff.map((line, i) => (
            <div
              key={i}
              className={cn(
                "px-3 py-0.5 whitespace-pre-wrap break-all",
                line.type === "add" && "bg-emerald-500/15 text-emerald-300",
                line.type === "del" && "bg-rose-500/15 text-rose-300",
                line.type === "ctx" && "text-zinc-400",
              )}
            >
              <span className="inline-block w-4 select-none opacity-60">
                {line.type === "add" ? "+" : line.type === "del" ? "-" : " "}
              </span>
              <span className="whitespace-pre-wrap">{line.text || " "}</span>
            </div>
          ))
        )}
      </pre>
    </div>
  );
}
