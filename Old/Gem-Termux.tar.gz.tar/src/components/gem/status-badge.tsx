"use client";

import { cn } from "@/lib/utils";
import type { StatusInfo } from "@/lib/gem";

interface StatusDotProps {
  ok: boolean;
  className?: string;
}

export function StatusDot({ ok, className }: StatusDotProps) {
  return (
    <span
      className={cn(
        "inline-block h-2 w-2 rounded-full",
        ok ? "bg-emerald-500" : "bg-rose-500",
        ok && "shadow-[0_0_0_3px_rgba(16,185,129,0.18)]",
        className,
      )}
      aria-label={ok ? "configured" : "not configured"}
    />
  );
}

interface StatusBadgeProps {
  status: StatusInfo | null | undefined;
  className?: string;
}

export function ModelBadge({ status, className }: StatusBadgeProps) {
  const model = status?.model || "—";
  const provider = status?.provider?.name || "—";
  const configured = !!status?.provider?.configured;
  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs",
        className,
      )}
      title={`Provider: ${provider} · Model: ${model}`}
    >
      <StatusDot ok={configured} />
      <span className="font-medium text-foreground/90">{provider}</span>
      <span className="text-muted-foreground">/</span>
      <span className="font-mono text-[11px] text-muted-foreground">{model}</span>
    </div>
  );
}
