"use client";

import { useState } from "react";
import {
  AlertTriangle,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock,
  Copy,
  FileEdit,
  FilePlus,
  FolderTree,
  GitBranch,
  Globe,
  Hammer,
  ImageIcon,
  Loader2,
  Network,
  Package,
  Sparkles,
  Terminal,
  Wrench,
  Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { DiffView } from "./diff-view";
import { copyToClipboard } from "@/lib/gem";
import type { GemEvent } from "@/lib/gem";
import { toast } from "sonner";

// ===================== Render model =====================
// We flatten the raw SSE event stream into a list of "render items". This lets
// us group a tool_call + its activity label into a single step, skip redundant
// tool_result events (when a specialised card already showed the content), and
// decide whether an activity step is still "running".

export type RenderItem =
  | { kind: "plan"; steps: Array<{ title: string; goal: string; agent: string }> }
  | { kind: "activity_step"; toolName: string; label: string; running: boolean; args?: Record<string, unknown> }
  | { kind: "file_created"; path: string; content: string }
  | { kind: "file_edited"; path: string; old: string; new: string }
  | { kind: "command"; command: string; result: string; isError: boolean }
  | { kind: "tool_result"; name: string; isError: boolean; content: string }
  | { kind: "swarm_start"; task: string }
  | { kind: "swarm_plan"; plan: unknown }
  | { kind: "agent_start"; agent: string; role: string; task: string }
  | { kind: "agent_done"; agent: string; result: string; status: string }
  | { kind: "swarm_done"; result: string }
  | { kind: "checkpoint"; iteration: number }
  | { kind: "event"; content: string }
  | { kind: "error"; content: string };

const SPECIALIZED = new Set(["file_created", "file_edited", "command"]);

export function groupEvents(events: GemEvent[], isStreaming: boolean): RenderItem[] {
  const items: RenderItem[] = [];
  // Track activity steps that haven't yet been "closed" by a specialised card
  // or tool_result. Each entry is the index in `items` of the activity_step.
  let pendingActivityIdx: number | null = null;

  for (let i = 0; i < events.length; i++) {
    const ev = events[i] as GemEvent & Record<string, unknown>;
    const t = ev.type as string;

    if (t === "plan" && Array.isArray(ev.steps)) {
      items.push({
        kind: "plan",
        steps: (ev.steps as Array<{ title: string; goal: string; agent: string }>).map((s) => ({
          title: String(s?.title ?? ""),
          goal: String(s?.goal ?? ""),
          agent: String(s?.agent ?? ""),
        })),
      });
      continue;
    }
    if (t === "tool_call") {
      // The following activity event (if any) carries the friendly label.
      const next = events[i + 1] as GemEvent | undefined;
      let label = "";
      if (next && (next as GemEvent & { type: string }).type === "activity") {
        label = String((next as { label?: string }).label || "");
        i++; // consume the activity event
      }
      items.push({
        kind: "activity_step",
        toolName: String(ev.name || "tool"),
        label: label || String(ev.name || "tool"),
        running: false, // resolved below
        args: ev.arguments as Record<string, unknown> | undefined,
      });
      pendingActivityIdx = items.length - 1;
      continue;
    }
    if (t === "activity") {
      // Standalone activity event (no preceding tool_call) - rare but possible.
      items.push({
        kind: "activity_step",
        toolName: "activity",
        label: String(ev.label || "working"),
        running: false,
      });
      pendingActivityIdx = items.length - 1;
      continue;
    }
    if (t === "file_created") {
      items.push({ kind: "file_created", path: String(ev.path || ""), content: String(ev.content || "") });
      if (pendingActivityIdx !== null) pendingActivityIdx = null;
      continue;
    }
    if (t === "file_edited") {
      items.push({
        kind: "file_edited",
        path: String(ev.path || ""),
        old: String(ev.old || ""),
        new: String(ev.new || ""),
      });
      if (pendingActivityIdx !== null) pendingActivityIdx = null;
      continue;
    }
    if (t === "command") {
      items.push({
        kind: "command",
        command: String(ev.command || ""),
        result: String(ev.result || ""),
        isError: !!ev.is_error,
      });
      if (pendingActivityIdx !== null) pendingActivityIdx = null;
      continue;
    }
    if (t === "tool_result") {
      // If a specialised card already covered this result, skip the duplicate.
      const prev = items[items.length - 1];
      if (prev && SPECIALIZED.has(prev.kind)) {
        continue;
      }
      items.push({
        kind: "tool_result",
        name: String(ev.name || "tool"),
        isError: !!ev.is_error,
        content: String(ev.content || ""),
      });
      if (pendingActivityIdx !== null) pendingActivityIdx = null;
      continue;
    }
    if (t === "swarm_start") {
      items.push({ kind: "swarm_start", task: String(ev.task || "") });
      continue;
    }
    if (t === "swarm_plan") {
      items.push({ kind: "swarm_plan", plan: ev.plan });
      continue;
    }
    if (t === "agent_start") {
      items.push({
        kind: "agent_start",
        agent: String(ev.agent || ""),
        role: String(ev.role || ""),
        task: String(ev.task || ""),
      });
      continue;
    }
    if (t === "agent_done") {
      items.push({
        kind: "agent_done",
        agent: String(ev.agent || ""),
        result: String(ev.result || ""),
        status: String(ev.status || ""),
      });
      continue;
    }
    if (t === "swarm_done") {
      items.push({ kind: "swarm_done", result: String(ev.result || "") });
      continue;
    }
    if (t === "checkpoint") {
      items.push({ kind: "checkpoint", iteration: Number(ev.iteration || 0) });
      continue;
    }
    if (t === "event") {
      items.push({ kind: "event", content: String(ev.content || "") });
      continue;
    }
    if (t === "error") {
      items.push({ kind: "error", content: String(ev.content || "") });
      continue;
    }
    // Skip: user, assistant, iteration, done (rendered elsewhere).
  }

  // Resolve "running" state: an activity_step is running if the turn is still
  // streaming AND it is the last item in the list (no result followed).
  if (isStreaming && pendingActivityIdx !== null) {
    const item = items[pendingActivityIdx];
    if (item && item.kind === "activity_step") item.running = true;
  }

  return items;
}

// ===================== Tool icon helper =====================
function ToolIcon({ name, className }: { name: string; className?: string }) {
  const n = name.toLowerCase();
  if (n === "shell") return <Terminal className={className} />;
  if (n === "files") return <FolderTree className={className} />;
  if (n === "web_search" || n === "web") return <Globe className={className} />;
  if (n === "image") return <ImageIcon className={className} />;
  if (n === "git") return <GitBranch className={className} />;
  if (n === "archive") return <Package className={className} />;
  if (n === "artifacts") return <Hammer className={className} />;
  return <Wrench className={className} />;
}

// ===================== Individual cards =====================
function PlanCard({ steps }: { steps: Array<{ title: string; goal: string; agent: string }> }) {
  return (
    <div className="gem-fade-up rounded-xl border border-border bg-card/60 p-4 shadow-sm">
      <div className="mb-3 flex items-center gap-2 text-sm font-medium text-foreground">
        <Sparkles className="h-4 w-4 text-gem" />
        Plan
        <Badge variant="secondary" className="ml-1">{steps.length} steps</Badge>
      </div>
      <ol className="space-y-2">
        {steps.map((s, i) => (
          <li key={i} className="flex gap-3">
            <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gem-soft text-gem-soft-foreground text-xs font-semibold">
              {i + 1}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm font-medium text-foreground">{s.title || s.goal || `Step ${i + 1}`}</span>
                {s.agent && (
                  <Badge variant="outline" className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    {s.agent}
                  </Badge>
                )}
              </div>
              {s.goal && s.goal !== s.title && (
                <p className="mt-0.5 text-xs text-muted-foreground">{s.goal}</p>
              )}
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}

function ActivityStep({ toolName, label, running, args }: {
  toolName: string;
  label: string;
  running: boolean;
  args?: Record<string, unknown>;
}) {
  const argPreview = args ? formatArgs(args) : "";
  return (
    <div className="gem-fade-up flex items-center gap-2.5 rounded-lg border border-border bg-card/40 px-3 py-2 text-sm">
      <span className={cn("flex h-6 w-6 shrink-0 items-center justify-center rounded-md", running ? "bg-gem-soft text-gem" : "bg-muted text-muted-foreground")}>
        {running ? (
          <Loader2 className="h-3.5 w-3.5 animate-spin" />
        ) : (
          <Check className="h-3.5 w-3.5 text-emerald-500" />
        )}
      </span>
      <ToolIcon name={toolName} className="h-3.5 w-3.5 text-muted-foreground" />
      <span className={cn("truncate", running ? "text-foreground" : "text-muted-foreground")}>
        {label}
      </span>
      {argPreview && (
        <span className="ml-auto hidden sm:inline truncate max-w-[40%] font-mono text-[11px] text-muted-foreground/70">
          {argPreview}
        </span>
      )}
    </div>
  );
}

function formatArgs(args: Record<string, unknown>): string {
  const keys = Object.keys(args).filter((k) => !["content", "old_str", "new_str"].includes(k));
  const parts = keys.slice(0, 2).map((k) => {
    const v = args[k];
    const s = typeof v === "string" ? v : JSON.stringify(v);
    return `${k}=${s.length > 40 ? s.slice(0, 40) + "…" : s}`;
  });
  return parts.join(" · ");
}

function CopyButton({ text, label = "Copy" }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <Button
      size="sm"
      variant="ghost"
      className="h-6 gap-1.5 px-2 text-[11px] text-muted-foreground hover:text-foreground"
      onClick={async () => {
        await copyToClipboard(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 1200);
      }}
    >
      {copied ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
      {copied ? "Copied" : label}
    </Button>
  );
}

function FileCreatedCard({ path, content }: { path: string; content: string }) {
  const [open, setOpen] = useState(false);
  const lineCount = content ? content.split("\n").length : 0;
  return (
    <Collapsible open={open} onOpenChange={setOpen} className="gem-fade-up overflow-hidden rounded-xl border border-emerald-200 bg-emerald-50/40 shadow-sm dark:border-emerald-900/50 dark:bg-emerald-950/10">
      <CollapsibleTrigger className="flex w-full items-center gap-2.5 px-3 py-2.5 text-left hover:bg-emerald-50/60 dark:hover:bg-emerald-950/20">
        <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">
          <FilePlus className="h-3.5 w-3.5" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-foreground">Created file</span>
            <Badge variant="outline" className="text-[10px] text-muted-foreground">{lineCount} lines</Badge>
          </div>
          <code className="block truncate font-mono text-xs text-emerald-800 dark:text-emerald-300">{path}</code>
        </div>
        <ChevronRight className={cn("h-4 w-4 shrink-0 text-muted-foreground transition-transform", open && "rotate-90")} />
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="border-t border-emerald-200/60 dark:border-emerald-900/40">
          <div className="flex items-center justify-end gap-1 px-3 py-1.5">
            <CopyButton text={content} label="Copy content" />
            <Button
              size="sm"
              variant="ghost"
              className="h-6 gap-1.5 px-2 text-[11px] text-muted-foreground hover:text-foreground"
              onClick={() => {
                const blob = new Blob([content], { type: "text/plain" });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = path.split("/").pop() || "file.txt";
                a.click();
                URL.revokeObjectURL(url);
              }}
            >
              <Package className="h-3 w-3" /> Download
            </Button>
          </div>
          <pre className="gem-scroll max-h-96 overflow-auto border-t border-emerald-200/60 bg-zinc-950 p-3 text-[12px] leading-relaxed text-zinc-100 dark:border-emerald-900/40">
            <code className="font-mono whitespace-pre-wrap break-all">{content || "(empty file)"}</code>
          </pre>
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}

function FileEditedCard({ path, old: oldStr, new: newStr }: { path: string; old: string; new: string }) {
  const [open, setOpen] = useState(false);
  return (
    <Collapsible open={open} onOpenChange={setOpen} className="gem-fade-up overflow-hidden rounded-xl border border-violet-200 bg-violet-50/40 shadow-sm dark:border-violet-900/50 dark:bg-violet-950/10">
      <CollapsibleTrigger className="flex w-full items-center gap-2.5 px-3 py-2.5 text-left hover:bg-violet-50/60 dark:hover:bg-violet-950/20">
        <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300">
          <FileEdit className="h-3.5 w-3.5" />
        </span>
        <div className="min-w-0 flex-1">
          <span className="text-sm font-medium text-foreground">Edited file</span>
          <code className="block truncate font-mono text-xs text-violet-800 dark:text-violet-300">{path}</code>
        </div>
        <ChevronRight className={cn("h-4 w-4 shrink-0 text-muted-foreground transition-transform", open && "rotate-90")} />
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="border-t border-violet-200/60 p-3 dark:border-violet-900/40">
          <DiffView oldStr={oldStr} newStr={newStr} />
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}

function CommandCard({ command, result, isError }: { command: string; result: string; isError: boolean }) {
  const [open, setOpen] = useState(!!isError);
  return (
    <Collapsible open={open} onOpenChange={setOpen} className={cn(
      "gem-fade-up overflow-hidden rounded-xl border shadow-sm",
      isError ? "border-rose-300 bg-rose-50/40 dark:border-rose-900/50 dark:bg-rose-950/10" : "border-border bg-card/40",
    )}>
      <CollapsibleTrigger className="flex w-full items-center gap-2.5 px-3 py-2.5 text-left hover:bg-muted/40">
        <span className={cn(
          "flex h-6 w-6 shrink-0 items-center justify-center rounded-md",
          isError ? "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300" : "bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300",
        )}>
          <Terminal className="h-3.5 w-3.5" />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-foreground">Command</span>
            {isError ? (
              <Badge variant="destructive" className="text-[10px]">failed</Badge>
            ) : (
              <Badge variant="outline" className="text-[10px] text-emerald-600 dark:text-emerald-400">ok</Badge>
            )}
          </div>
          <code className="block truncate font-mono text-xs text-foreground/80">$ {command}</code>
        </div>
        <ChevronRight className={cn("h-4 w-4 shrink-0 text-muted-foreground transition-transform", open && "rotate-90")} />
      </CollapsibleTrigger>
      <CollapsibleContent>
        <pre className={cn(
          "gem-scroll max-h-80 overflow-auto border-t p-3 font-mono text-[12px] leading-relaxed",
          isError ? "border-rose-200/60 bg-rose-950 text-rose-100 dark:border-rose-900/40" : "border-border bg-zinc-950 text-zinc-100",
        )}>
          <code className="whitespace-pre-wrap break-all">{result || "(no output)"}</code>
        </pre>
      </CollapsibleContent>
    </Collapsible>
  );
}

function ToolResultCard({ name, isError, content }: { name: string; isError: boolean; content: string }) {
  const [open, setOpen] = useState(false);
  const preview = content.length > 200 ? content.slice(0, 200) + "…" : content;
  return (
    <Collapsible open={open} onOpenChange={setOpen} className="gem-fade-up rounded-lg border border-border bg-muted/30 px-3 py-2">
      <CollapsibleTrigger className="flex w-full items-center gap-2 text-left">
        <ToolIcon name={name} className="h-3.5 w-3.5 text-muted-foreground" />
        <span className="text-xs font-medium text-muted-foreground">{name} result</span>
        {isError ? (
          <Badge variant="destructive" className="text-[10px]">error</Badge>
        ) : (
          <Check className="h-3.5 w-3.5 text-emerald-500" />
        )}
        <ChevronRight className={cn("ml-auto h-3.5 w-3.5 text-muted-foreground transition-transform", open && "rotate-90")} />
      </CollapsibleTrigger>
      {!open && (
        <pre className="mt-1.5 truncate font-mono text-[11px] text-muted-foreground/80">{preview || "(empty)"}</pre>
      )}
      <CollapsibleContent>
        <pre className="gem-scroll mt-2 max-h-72 overflow-auto rounded-md bg-zinc-950 p-2.5 font-mono text-[11px] leading-relaxed text-zinc-100">
          <code className="whitespace-pre-wrap break-all">{content || "(empty)"}</code>
        </pre>
      </CollapsibleContent>
    </Collapsible>
  );
}

function SwarmStartCard({ task }: { task: string }) {
  return (
    <div className="gem-fade-up flex items-center gap-2.5 rounded-xl border border-violet-200 bg-gradient-to-r from-violet-50 to-emerald-50/40 px-3 py-2.5 shadow-sm dark:border-violet-900/50 dark:from-violet-950/20 dark:to-emerald-950/10">
      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-violet-gem text-white">
        <Network className="h-3.5 w-3.5" />
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-foreground">Swarm dispatched</span>
          <Badge variant="outline" className="text-[10px] text-violet-gem">parallel agents</Badge>
        </div>
        <p className="truncate text-xs text-muted-foreground">{task}</p>
      </div>
    </div>
  );
}

function SwarmPlanCard({ plan }: { plan: unknown }) {
  let tasks: Array<{ agent?: string; task?: string }> = [];
  let parallel = false;
  if (plan && typeof plan === "object") {
    const p = plan as { parallel?: boolean; tasks?: Array<{ agent?: string; task?: string }> };
    parallel = !!p.parallel;
    if (Array.isArray(p.tasks)) tasks = p.tasks;
  }
  return (
    <div className="gem-fade-up rounded-xl border border-border bg-card/40 p-3 shadow-sm">
      <div className="mb-2 flex items-center gap-2 text-sm font-medium">
        <Sparkles className="h-3.5 w-3.5 text-violet-gem" />
        Swarm plan
        <Badge variant="secondary" className="text-[10px]">{parallel ? "parallel" : "sequential"} · {tasks.length} tasks</Badge>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {tasks.map((t, i) => (
          <span key={i} className="inline-flex items-center gap-1.5 rounded-full border border-border bg-background px-2.5 py-1 text-xs">
            <Badge variant="outline" className="text-[10px] uppercase tracking-wide text-violet-gem">{t.agent || "agent"}</Badge>
            <span className="truncate max-w-[200px] text-muted-foreground">{t.task}</span>
          </span>
        ))}
      </div>
    </div>
  );
}

function AgentStartCard({ agent, role, task }: { agent: string; role: string; task: string }) {
  return (
    <div className="gem-fade-up flex items-start gap-2.5 rounded-lg border border-border bg-card/40 px-3 py-2">
      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-violet-soft text-violet-gem">
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-foreground">{agent}</span>
          <Badge variant="outline" className="text-[10px] uppercase tracking-wide text-muted-foreground">{role}</Badge>
        </div>
        <p className="truncate text-xs text-muted-foreground">{task}</p>
      </div>
    </div>
  );
}

function AgentDoneCard({ agent, result, status }: { agent: string; result: string; status: string }) {
  const ok = status !== "failed" && status !== "error";
  const [open, setOpen] = useState(false);
  const preview = result.length > 160 ? result.slice(0, 160) + "…" : result;
  return (
    <Collapsible open={open} onOpenChange={setOpen} className="gem-fade-up rounded-lg border border-border bg-card/40 px-3 py-2">
      <CollapsibleTrigger className="flex w-full items-center gap-2.5 text-left">
        <span className={cn(
          "flex h-6 w-6 shrink-0 items-center justify-center rounded-md",
          ok ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300" : "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300",
        )}>
          {ok ? <CheckCircle2 className="h-3.5 w-3.5" /> : <AlertTriangle className="h-3.5 w-3.5" />}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-foreground">{agent}</span>
            <Badge variant="outline" className={cn("text-[10px] uppercase tracking-wide", ok ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400")}>
              {status || (ok ? "done" : "failed")}
            </Badge>
          </div>
          {!open && <p className="truncate text-xs text-muted-foreground">{preview}</p>}
        </div>
        <ChevronRight className={cn("h-4 w-4 shrink-0 text-muted-foreground transition-transform", open && "rotate-90")} />
      </CollapsibleTrigger>
      <CollapsibleContent>
        <pre className="gem-scroll mt-2 max-h-72 overflow-auto rounded-md bg-zinc-950 p-2.5 font-mono text-[11px] leading-relaxed text-zinc-100">
          <code className="whitespace-pre-wrap break-all">{result || "(no output)"}</code>
        </pre>
      </CollapsibleContent>
    </Collapsible>
  );
}

function SwarmDoneCard({ result }: { result: string }) {
  return (
    <div className="gem-fade-up flex items-start gap-2.5 rounded-xl border border-emerald-200 bg-emerald-50/40 px-3 py-2.5 shadow-sm dark:border-emerald-900/50 dark:bg-emerald-950/10">
      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">
        <CheckCircle2 className="h-3.5 w-3.5" />
      </span>
      <div className="min-w-0 flex-1">
        <span className="text-sm font-semibold text-foreground">Swarm completed</span>
        <p className="mt-0.5 line-clamp-3 whitespace-pre-wrap text-xs text-muted-foreground">{result}</p>
      </div>
    </div>
  );
}

function CheckpointCard({ iteration }: { iteration: number }) {
  return (
    <div className="flex items-center gap-2 px-2 py-1 text-[11px] text-muted-foreground">
      <Clock className="h-3 w-3" />
      <span>Checkpoint saved at iteration {iteration}</span>
    </div>
  );
}

function EventLine({ content }: { content: string }) {
  return (
    <div className="flex items-center gap-2 px-2 py-1 text-xs text-muted-foreground">
      <Zap className="h-3 w-3 shrink-0" />
      <span className="whitespace-pre-wrap break-words">{content}</span>
    </div>
  );
}

function ErrorCard({ content }: { content: string }) {
  return (
    <div className="gem-fade-up flex items-start gap-2.5 rounded-xl border border-rose-300 bg-rose-50/60 px-3 py-2.5 shadow-sm dark:border-rose-900/50 dark:bg-rose-950/20">
      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-rose-100 text-rose-700 dark:bg-rose-900/50 dark:text-rose-300">
        <AlertTriangle className="h-3.5 w-3.5" />
      </span>
      <div className="min-w-0 flex-1">
        <span className="text-sm font-semibold text-rose-900 dark:text-rose-200">Error</span>
        <pre className="mt-0.5 whitespace-pre-wrap break-words font-mono text-xs text-rose-800 dark:text-rose-300">{content}</pre>
      </div>
      <Button
        size="sm"
        variant="ghost"
        className="h-6 px-2 text-[11px] text-rose-700 hover:text-rose-900 dark:text-rose-300"
        onClick={() => {
          copyToClipboard(content);
          toast.success("Error copied to clipboard");
        }}
      >
        <Copy className="h-3 w-3" />
      </Button>
    </div>
  );
}

// ===================== Dispatcher =====================
export function ActivityCard({ item }: { item: RenderItem }) {
  switch (item.kind) {
    case "plan":
      return <PlanCard steps={item.steps} />;
    case "activity_step":
      return <ActivityStep toolName={item.toolName} label={item.label} running={item.running} args={item.args} />;
    case "file_created":
      return <FileCreatedCard path={item.path} content={item.content} />;
    case "file_edited":
      return <FileEditedCard path={item.path} old={item.old} new={item.new} />;
    case "command":
      return <CommandCard command={item.command} result={item.result} isError={item.isError} />;
    case "tool_result":
      return <ToolResultCard name={item.name} isError={item.isError} content={item.content} />;
    case "swarm_start":
      return <SwarmStartCard task={item.task} />;
    case "swarm_plan":
      return <SwarmPlanCard plan={item.plan} />;
    case "agent_start":
      return <AgentStartCard agent={item.agent} role={item.role} task={item.task} />;
    case "agent_done":
      return <AgentDoneCard agent={item.agent} result={item.result} status={item.status} />;
    case "swarm_done":
      return <SwarmDoneCard result={item.result} />;
    case "checkpoint":
      return <CheckpointCard iteration={item.iteration} />;
    case "event":
      return <EventLine content={item.content} />;
    case "error":
      return <ErrorCard content={item.content} />;
    default:
      return null;
  }
}
