"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Check,
  MessageSquarePlus,
  MoreHorizontal,
  Pencil,
  Search,
  Trash2,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { timeAgo } from "@/lib/gem";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ProjectsPanel } from "./projects-panel";
import { StatusDot } from "./status-badge";
import { gemApi, type ChatSummary, type ProjectInfo, type SearchResults, type StatusInfo } from "@/lib/gem";
import { toast } from "sonner";

interface SidebarProps {
  chats: ChatSummary[] | null;
  activeChatId: string | null;
  loadingChats: boolean;
  onSelectChat: (id: string) => void;
  onNewChat: () => void;
  onRenameChat: (id: string, title: string) => void;
  onDeleteChat: (id: string) => void;

  projects: ProjectInfo[] | null;
  loadingProjects: boolean;
  activeProject: string | null;
  onSelectProject: (name: string) => void;
  onCreateProject: (name: string) => Promise<void>;
  refreshKey: number;

  status: StatusInfo | null;
}

export function Sidebar({
  chats,
  activeChatId,
  loadingChats,
  onSelectChat,
  onNewChat,
  onRenameChat,
  onDeleteChat,
  projects,
  loadingProjects,
  activeProject,
  onSelectProject,
  onCreateProject,
  refreshKey,
  status,
}: SidebarProps) {
  const [search, setSearch] = useState("");
  const [searchResults, setSearchResults] = useState<SearchResults | null>(null);
  const [searching, setSearching] = useState(false);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [deleteTarget, setDeleteTarget] = useState<ChatSummary | null>(null);

  // Debounced search.
  useEffect(() => {
    const q = search.trim();
    if (!q) {
      setSearchResults(null);
      setSearching(false);
      return;
    }
    setSearching(true);
    const t = setTimeout(async () => {
      try {
        const res = await gemApi.search(q);
        setSearchResults(res);
      } catch (e) {
        toast.error("Search failed", { description: (e as Error).message });
      } finally {
        setSearching(false);
      }
    }, 250);
    return () => clearTimeout(t);
  }, [search]);

  const sortedChats = useMemo(() => {
    if (!chats) return null;
    return [...chats].sort((a, b) => (b.updated_at || "").localeCompare(a.updated_at || ""));
  }, [chats]);

  const commitRename = (id: string) => {
    const v = renameValue.trim();
    if (v) onRenameChat(id, v);
    setRenamingId(null);
    setRenameValue("");
  };

  return (
    <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
      {/* New chat */}
      <div className="p-3">
        <Button
          onClick={onNewChat}
          className="w-full justify-start gap-2 rounded-xl bg-zinc-900 text-white hover:bg-zinc-800"
          size="default"
        >
          <MessageSquarePlus className="h-4 w-4" />
          New chat
        </Button>
      </div>

      {/* Search */}
      <div className="px-3 pb-2">
        <div className="relative">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search chats & memory"
            className="h-8 rounded-lg border-border bg-background pl-8 pr-7 text-xs"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded p-0.5 text-muted-foreground hover:text-foreground"
              aria-label="Clear search"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Search results OR chats list */}
      <div className="gem-scroll min-h-0 flex-1 overflow-y-auto px-2">
        {search ? (
          <SearchResultsView
            results={searchResults}
            searching={searching}
            query={search}
            onSelectChat={(id) => {
              onSelectChat(id);
              setSearch("");
            }}
          />
        ) : (
          <ChatsList
            chats={sortedChats}
            loading={loadingChats}
            activeChatId={activeChatId}
            renamingId={renamingId}
            renameValue={renameValue}
            onSelectChat={onSelectChat}
            onStartRename={(c) => {
              setRenamingId(c.id);
              setRenameValue(c.title);
            }}
            onChangeRename={setRenameValue}
            onCommitRename={commitRename}
            onCancelRename={() => setRenamingId(null)}
            onDeleteChat={(c) => setDeleteTarget(c)}
          />
        )}
      </div>

      {/* Projects panel */}
      <div className="border-t border-sidebar-border p-2">
        <ProjectsPanel
          projects={projects || []}
          activeProject={activeProject}
          onSelectProject={onSelectProject}
          onCreateProject={onCreateProject}
          loading={loadingProjects}
          refreshKey={refreshKey}
        />
      </div>

      {/* Status footer */}
      <div className="border-t border-sidebar-border px-3 py-2">
        <div className="flex items-center justify-between text-[11px]">
          <div className="flex min-w-0 items-center gap-2">
            <StatusDot ok={!!status?.provider?.configured} />
            <span className="truncate font-medium text-foreground/80">
              {status?.provider?.name || "no provider"}
            </span>
          </div>
          <code className="truncate font-mono text-[10px] text-muted-foreground">
            {status?.model || "—"}
          </code>
        </div>
        {(status?.jobs_running > 0 || status?.jobs_pending > 0) && (
          <div className="mt-1 flex items-center gap-2 text-[10px] text-muted-foreground">
            <Badge variant="outline" className="text-[9px]">{status?.jobs_running} running</Badge>
            <Badge variant="outline" className="text-[9px]">{status?.jobs_pending} queued</Badge>
          </div>
        )}
      </div>

      {/* Delete confirmation */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete chat?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete <span className="font-medium text-foreground">{deleteTarget?.title}</span> and all its messages. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-rose-600 hover:bg-rose-700"
              onClick={() => {
                if (deleteTarget) onDeleteChat(deleteTarget.id);
                setDeleteTarget(null);
              }}
            >
              <Trash2 className="h-4 w-4 mr-1.5" /> Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ===================== Chats list =====================
function ChatsList({
  chats,
  loading,
  activeChatId,
  renamingId,
  renameValue,
  onSelectChat,
  onStartRename,
  onChangeRename,
  onCommitRename,
  onCancelRename,
  onDeleteChat,
}: {
  chats: ChatSummary[] | null;
  loading: boolean;
  activeChatId: string | null;
  renamingId: string | null;
  renameValue: string;
  onSelectChat: (id: string) => void;
  onStartRename: (c: ChatSummary) => void;
  onChangeRename: (v: string) => void;
  onCommitRename: (id: string) => void;
  onCancelRename: () => void;
  onDeleteChat: (c: ChatSummary) => void;
}) {
  if (loading && !chats) {
    return (
      <div className="space-y-1 p-1">
        {[0, 1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-9 w-full rounded-md" />
        ))}
      </div>
    );
  }
  if (chats && chats.length === 0) {
    return (
      <div className="px-3 py-6 text-center text-xs text-muted-foreground">
        No chats yet.
        <div className="mt-1 text-[11px] text-muted-foreground/70">Click “New chat” to begin.</div>
      </div>
    );
  }
  return (
    <ul className="space-y-0.5 py-1">
      {chats?.map((c) => {
        const isActive = c.id === activeChatId;
        const isRenaming = renamingId === c.id;
        return (
          <li key={c.id}>
            {isRenaming ? (
              <div className="flex items-center gap-1 rounded-md bg-background px-1.5 py-1">
                <Input
                  autoFocus
                  value={renameValue}
                  onChange={(e) => onChangeRename(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") onCommitRename(c.id);
                    if (e.key === "Escape") onCancelRename();
                  }}
                  className="h-6 text-xs"
                />
                <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => onCommitRename(c.id)} aria-label="Save">
                  <Check className="h-3 w-3 text-emerald-500" />
                </Button>
                <Button size="icon" variant="ghost" className="h-6 w-6" onClick={onCancelRename} aria-label="Cancel">
                  <X className="h-3 w-3" />
                </Button>
              </div>
            ) : (
              <div
                className={cn(
                  "group flex items-center rounded-md transition",
                  isActive ? "bg-gem-soft/70" : "hover:bg-accent",
                )}
              >
                <button
                  type="button"
                  onClick={() => onSelectChat(c.id)}
                  onDoubleClick={() => onStartRename(c)}
                  className="flex min-w-0 flex-1 items-center gap-2 px-2 py-1.5 text-left"
                  title={c.title}
                >
                  <div className="min-w-0 flex-1">
                    <div className={cn("truncate text-xs", isActive ? "font-medium text-gem-soft-foreground" : "text-foreground/90")}>
                      {c.title || "Untitled"}
                    </div>
                    <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                      <span>{timeAgo(c.updated_at)}</span>
                      {c.message_count > 0 && (
                        <>
                          <span>·</span>
                          <span>{c.message_count} msg</span>
                        </>
                      )}
                    </div>
                  </div>
                </button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-6 w-6 shrink-0 opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-foreground"
                      aria-label="Chat actions"
                    >
                      <MoreHorizontal className="h-3.5 w-3.5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-40">
                    <DropdownMenuItem onClick={() => onStartRename(c)}>
                      <Pencil className="h-3.5 w-3.5" /> Rename
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      className="text-rose-600 focus:text-rose-700"
                      onClick={() => onDeleteChat(c)}
                    >
                      <Trash2 className="h-3.5 w-3.5" /> Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            )}
          </li>
        );
      })}
    </ul>
  );
}

// ===================== Search results =====================
function SearchResultsView({
  results,
  searching,
  query,
  onSelectChat,
}: {
  results: SearchResults | null;
  searching: boolean;
  query: string;
  onSelectChat: (id: string) => void;
}) {
  if (searching && !results) {
    return (
      <div className="flex items-center justify-center py-8 text-xs text-muted-foreground">
        <Search className="mr-2 h-3.5 w-3.5 animate-pulse" /> searching…
      </div>
    );
  }
  if (results && results.history.length === 0 && results.memory.length === 0) {
    return (
      <div className="px-3 py-6 text-center text-xs text-muted-foreground">
        No matches for <span className="font-medium text-foreground">“{query}”</span>
      </div>
    );
  }
  return (
    <div className="py-1">
      {results && results.history.length > 0 && (
        <div className="mb-2">
          <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
            Chats · {results.history.length}
          </div>
          <ul className="space-y-0.5">
            {results.history.map((h, i) => (
              <li key={`${h.chat_id}-${i}`}>
                <button
                  type="button"
                  onClick={() => onSelectChat(h.chat_id)}
                  className="group block w-full rounded-md px-2 py-1.5 text-left hover:bg-accent"
                >
                  <div className="flex items-center gap-1.5">
                    <Badge variant="outline" className="text-[9px] uppercase">{h.role}</Badge>
                    <span className="truncate text-xs font-medium text-foreground/90">{h.title}</span>
                  </div>
                  <p className="mt-0.5 line-clamp-2 text-[11px] text-muted-foreground">{h.snippet}</p>
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
      {results && results.memory.length > 0 && (
        <div>
          <div className="px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
            Memory · {results.memory.length}
          </div>
          <ul className="space-y-0.5">
            {results.memory.map((m, i) => (
              <li key={m.id || i} className="rounded-md px-2 py-1.5 hover:bg-accent">
                <p className="line-clamp-2 text-xs text-foreground/90">{m.text}</p>
                {m.tags && m.tags.length > 0 && (
                  <div className="mt-1 flex flex-wrap gap-1">
                    {m.tags.map((t) => (
                      <Badge key={t} variant="secondary" className="text-[9px]">{t}</Badge>
                    ))}
                  </div>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
