"use client";

import { useEffect, useMemo, useRef } from "react";
import { Gem, Sparkles } from "lucide-react";
import type { Turn } from "@/hooks/use-gem-chat";
import { MessageBubble } from "./message-bubble";
import { ActivityCard, groupEvents, type RenderItem } from "./activity-card";

interface ChatViewProps {
  turns: Turn[];
  isStreaming: boolean;
  isLoadingChat: boolean;
  activeChatTitle: string;
  hasActiveChat: boolean;
}

function TurnView({ turn }: { turn: Turn }) {
  const items = useMemo<RenderItem[]>(
    () => groupEvents(turn.events, turn.status === "streaming"),
    [turn.events, turn.status],
  );

  return (
    <div className="space-y-4">
      {/* User message */}
      {turn.userMessage && <MessageBubble role="user" content={turn.userMessage} />}

      {/* Activity cards + inline assistant bubbles */}
      <div className="space-y-2.5 pl-0 sm:pl-11">
        {items.map((item, i) => (
          <ActivityCard key={i} item={item} />
        ))}
      </div>

      {/* Final/accumulated assistant bubble */}
      {turn.assistantContent && (
        <MessageBubble
          role="assistant"
          content={turn.assistantContent}
          streaming={turn.status === "streaming"}
          isFinal={turn.status === "done"}
        />
      )}

      {/* Working indicator while streaming with no assistant content yet */}
      {turn.status === "streaming" && !turn.assistantContent && items.length === 0 && (
        <div className="flex items-center gap-2 pl-0 sm:pl-11 text-sm text-muted-foreground">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-zinc-900 text-white shadow-sm">
            <Gem className="h-4 w-4" />
          </span>
          <span className="inline-flex items-center gap-2 rounded-2xl rounded-bl-md border border-border bg-card px-4 py-2.5 shadow-sm">
            <span className="text-gem gem-dots" aria-label="working">
              <span />
              <span />
              <span />
            </span>
            <span className="text-xs">Gem is thinking…</span>
          </span>
        </div>
      )}

      {/* Completed badge */}
      {turn.status === "done" && turn.assistantContent && (
        <div className="flex items-center gap-1.5 pl-0 sm:pl-11 text-[11px] text-emerald-600 dark:text-emerald-400">
          <Sparkles className="h-3 w-3" />
          <span>Completed</span>
        </div>
      )}
    </div>
  );
}

function EmptyState() {
  return (
    <div className="flex h-full flex-col items-center justify-center px-6 text-center">
      <div className="relative mb-5">
        <div className="absolute inset-0 rounded-2xl bg-gem/20 blur-2xl" aria-hidden />
        <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-zinc-900 to-zinc-700 text-white shadow-lg">
          <Gem className="h-8 w-8" />
        </div>
      </div>
      <h1 className="text-2xl font-semibold tracking-tight text-foreground">Meet Gem</h1>
      <p className="mt-2 max-w-md text-sm text-muted-foreground">
        An agentic AI ecosystem for development, automation, research and execution.
        Describe a task and Gem will plan, use tools, and ship — solo or with a swarm of specialised agents.
      </p>
      <div className="mt-6 grid w-full max-w-lg grid-cols-1 gap-2 sm:grid-cols-2">
        {[
          { title: "Build something", body: "Create a snake game in one HTML file" },
          { title: "Automate", body: "List files and summarize the project structure" },
          { title: "Research", body: "Find the latest news about Rust 1.80" },
          { title: "Swarm", body: "Toggle the Swarm switch and dispatch parallel agents" },
        ].map((s) => (
          <div key={s.title} className="rounded-lg border border-border bg-card/40 p-3 text-left">
            <div className="text-xs font-semibold text-foreground">{s.title}</div>
            <div className="mt-0.5 text-xs text-muted-foreground">{s.body}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="space-y-4">
      {[0, 1, 2].map((i) => (
        <div key={i} className="flex gap-3">
          <div className="h-8 w-8 shrink-0 animate-pulse rounded-full bg-muted" />
          <div className="flex-1 space-y-2">
            <div className="h-3 w-3/4 animate-pulse rounded bg-muted" />
            <div className="h-3 w-1/2 animate-pulse rounded bg-muted" />
          </div>
        </div>
      ))}
    </div>
  );
}

export function ChatView({ turns, isStreaming, isLoadingChat, activeChatTitle, hasActiveChat }: ChatViewProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const autoScroll = useRef(true);

  // Track whether the user is near the bottom; only auto-scroll then.
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onScroll = () => {
      const near = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
      autoScroll.current = near;
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    return () => el.removeEventListener("scroll", onScroll);
  }, []);

  // Scroll to bottom when new content arrives (if user hasn't scrolled up).
  useEffect(() => {
    if (autoScroll.current) {
      bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
    }
  }, [turns]);

  // Reset auto-scroll when switching chats.
  useEffect(() => {
    autoScroll.current = true;
    bottomRef.current?.scrollIntoView({ behavior: "auto", block: "end" });
  }, [hasActiveChat]);

  const showEmpty = !hasActiveChat && turns.length === 0 && !isLoadingChat;

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col">
      {activeChatTitle && (
        <div className="flex items-center justify-between border-b border-border bg-background/80 px-4 py-2.5 backdrop-blur sm:px-6">
          <div className="flex min-w-0 items-center gap-2">
            <span className="truncate text-sm font-medium text-foreground">{activeChatTitle}</span>
            {isStreaming && (
              <span className="inline-flex items-center gap-1 rounded-full bg-gem-soft px-2 py-0.5 text-[10px] font-medium text-gem-soft-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-gem gem-pulse" />
                streaming
              </span>
            )}
          </div>
        </div>
      )}
      <div ref={scrollRef} className="gem-scroll flex-1 overflow-y-auto px-4 py-6 sm:px-6">
        <div className="mx-auto max-w-3xl">
          {showEmpty ? (
            <EmptyState />
          ) : isLoadingChat ? (
            <LoadingState />
          ) : turns.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center py-16 text-center text-sm text-muted-foreground">
              <Gem className="mb-3 h-8 w-8 text-muted-foreground/40" />
              No messages yet. Send a message below to start.
            </div>
          ) : (
            <div className="space-y-8">
              {turns.map((t) => (
                <TurnView key={t.id} turn={t} />
              ))}
            </div>
          )}
          <div ref={bottomRef} className="h-1" />
        </div>
      </div>
    </div>
  );
}
