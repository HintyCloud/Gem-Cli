"use client";

import ReactMarkdown, { type Components } from "react-markdown";
import { Check, Copy, Gem, User } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { copyToClipboard } from "@/lib/gem";
import { Button } from "@/components/ui/button";

interface MessageBubbleProps {
  role: "user" | "assistant";
  content: string;
  streaming?: boolean;
  isFinal?: boolean;
}

const mdComponents: Components = {
  p: ({ children }) => <p className="my-2 leading-relaxed first:mt-0 last:mb-0">{children}</p>,
  h1: ({ children }) => <h1 className="mt-4 mb-2 text-lg font-semibold first:mt-0">{children}</h1>,
  h2: ({ children }) => <h2 className="mt-3 mb-2 text-base font-semibold first:mt-0">{children}</h2>,
  h3: ({ children }) => <h3 className="mt-3 mb-1.5 text-sm font-semibold first:mt-0">{children}</h3>,
  ul: ({ children }) => <ul className="my-2 list-disc pl-5 space-y-0.5">{children}</ul>,
  ol: ({ children }) => <ol className="my-2 list-decimal pl-5 space-y-0.5">{children}</ol>,
  li: ({ children }) => <li className="leading-relaxed">{children}</li>,
  a: ({ children, href }) => (
    <a href={href} target="_blank" rel="noopener noreferrer" className="text-gem underline underline-offset-2 hover:opacity-80">
      {children}
    </a>
  ),
  strong: ({ children }) => <strong className="font-semibold text-foreground">{children}</strong>,
  em: ({ children }) => <em className="italic">{children}</em>,
  blockquote: ({ children }) => (
    <blockquote className="my-2 border-l-2 border-border pl-3 italic text-muted-foreground">{children}</blockquote>
  ),
  hr: () => <hr className="my-3 border-border" />,
  code: ({ className, children, ...props }) => {
    const isBlock = typeof className === "string" && className.includes("language-");
    if (isBlock) {
      return (
        <code className="font-mono text-[12px]" {...props}>
          {children}
        </code>
      );
    }
    return (
      <code className="rounded bg-muted px-1 py-0.5 font-mono text-[0.85em]" {...props}>
        {children}
      </code>
    );
  },
  pre: ({ children }) => (
    <pre className="gem-scroll my-3 overflow-auto rounded-md border border-zinc-800 bg-zinc-950 p-3 text-[12px] leading-relaxed text-zinc-100">
      {children}
    </pre>
  ),
  table: ({ children }) => (
    <div className="my-3 overflow-x-auto">
      <table className="w-full border-collapse text-xs">{children}</table>
    </div>
  ),
  th: ({ children }) => <th className="border border-border bg-muted px-2 py-1 text-left font-semibold">{children}</th>,
  td: ({ children }) => <td className="border border-border px-2 py-1">{children}</td>,
};

function Markdown({ children }: { children: string }) {
  return (
    <div className="text-sm text-card-foreground">
      <ReactMarkdown components={mdComponents}>{children}</ReactMarkdown>
    </div>
  );
}

export function MessageBubble({ role, content, streaming, isFinal }: MessageBubbleProps) {
  const [copied, setCopied] = useState(false);
  const isUser = role === "user";
  const text = content || "";

  const onCopy = async () => {
    await copyToClipboard(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className={cn("flex w-full gap-3", isUser ? "justify-end" : "justify-start")}>
      {!isUser && (
        <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-zinc-900 text-white shadow-sm">
          <Gem className="h-4 w-4" />
        </div>
      )}
      <div className={cn("group relative max-w-[85%] sm:max-w-[78%]", isUser && "order-1")}>
        <div
          className={cn(
            "rounded-2xl px-4 py-2.5 text-sm shadow-sm border",
            isUser
              ? "bg-zinc-900 text-white border-zinc-900 rounded-br-md"
              : "bg-card text-card-foreground border-border rounded-bl-md",
          )}
        >
          {isUser ? (
            <div className="whitespace-pre-wrap break-words">{text}</div>
          ) : text ? (
            <Markdown>{text}</Markdown>
          ) : (
            <div className="text-muted-foreground italic text-xs">…</div>
          )}
          {streaming && !isUser && (
            <span className="ml-1 inline-flex items-center align-middle text-gem gem-dots" aria-label="streaming">
              <span />
              <span />
              <span />
            </span>
          )}
        </div>
        {!isUser && isFinal && text && (
          <div className="absolute -bottom-2 -right-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              size="icon"
              variant="outline"
              className="h-7 w-7 rounded-full bg-background shadow-md"
              onClick={onCopy}
              aria-label="Copy message"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
            </Button>
          </div>
        )}
      </div>
      {isUser && (
        <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground border border-border">
          <User className="h-4 w-4" />
        </div>
      )}
    </div>
  );
}
