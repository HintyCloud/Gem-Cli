"use client";

import { useEffect, useState } from "react";
import { Download, Hammer, Loader2, Package } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { gemApi, gemUrl, type ArtifactInfo, formatBytes } from "@/lib/gem";
import { toast } from "sonner";

export function ArtifactsMenu() {
  const [open, setOpen] = useState(false);
  const [artifacts, setArtifacts] = useState<ArtifactInfo[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open && artifacts === null) {
      gemApi
        .listArtifacts()
        .then(setArtifacts)
        .catch((e) => {
          setError(e.message);
          setArtifacts([]);
        });
    }
  }, [open, artifacts]);

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-1.5 text-muted-foreground hover:text-foreground">
          <Hammer className="h-4 w-4" />
          <span className="hidden sm:inline">Artifacts</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-72">
        <DropdownMenuLabel className="flex items-center gap-2 text-xs">
          <Package className="h-3.5 w-3.5" />
          Artifacts
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {artifacts === null ? (
          <div className="flex items-center justify-center py-4 text-xs text-muted-foreground">
            <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> loading…
          </div>
        ) : error ? (
          <div className="px-3 py-3 text-xs text-rose-600">{error}</div>
        ) : artifacts.length === 0 ? (
          <div className="px-3 py-4 text-center text-xs text-muted-foreground">
            No artifacts yet.
            <div className="mt-1 text-[11px] text-muted-foreground/70">Generated files, images and builds will appear here.</div>
          </div>
        ) : (
          artifacts.map((a) => (
            <DropdownMenuItem key={a.name} asChild>
              <a
                href={gemUrl(`/artifacts/${encodeURIComponent(a.name)}`)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2"
                onClick={() => toast.success(`Downloading ${a.name}`)}
              >
                <Download className="h-3.5 w-3.5 text-muted-foreground" />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-xs font-medium">{a.name}</div>
                  {a.size ? (
                    <div className="text-[10px] text-muted-foreground">{formatBytes(a.size)}</div>
                  ) : null}
                </div>
              </a>
            </DropdownMenuItem>
          ))
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
