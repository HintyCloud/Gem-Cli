"use client";

import { useEffect, useState } from "react";
import {
  ChevronRight,
  File as FileIcon,
  Folder,
  FolderOpen,
  FolderPlus,
  Loader2,
  Plus,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { gemApi, type ProjectFile, type ProjectInfo } from "@/lib/gem";
import { toast } from "sonner";

interface ProjectsPanelProps {
  projects: ProjectInfo[];
  activeProject: string | null;
  onSelectProject: (name: string) => void;
  onCreateProject: (name: string) => Promise<void>;
  loading: boolean;
  /** Bumped by the parent to force a re-fetch after a tool creates files. */
  refreshKey: number;
}

interface TreeNode {
  name: string;
  type: "file" | "dir";
  path: string;
  size: number;
  loaded?: boolean;
  loading?: boolean;
  children?: TreeNode[];
  error?: string;
}

function findAndMutate(
  nodes: TreeNode[],
  dirPath: string,
  mutator: (n: TreeNode) => void,
): boolean {
  if (dirPath === "") {
    // Root level - not represented as a node here; handled separately.
    return false;
  }
  for (const n of nodes) {
    if (n.path === dirPath && n.type === "dir") {
      mutator(n);
      return true;
    }
    if (n.type === "dir" && n.children && dirPath.startsWith(n.path + "/")) {
      if (findAndMutate(n.children, dirPath, mutator)) return true;
    }
  }
  return false;
}

export function ProjectsPanel({
  projects,
  activeProject,
  onSelectProject,
  onCreateProject,
  loading,
  refreshKey,
}: ProjectsPanelProps) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [trees, setTrees] = useState<Record<string, TreeNode[]>>({});
  const [filePreview, setFilePreview] = useState<{ path: string; content: string; loading: boolean } | null>(null);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");

  // Reset cached trees when projects list changes.
  useEffect(() => {
    setTrees({});
    setExpanded(new Set());
  }, [projects.map((p) => p.name).join(",")]);

  // Force-refresh expanded trees when the parent bumps refreshKey (e.g. after a chat turn).
  useEffect(() => {
    if (activeProject && expanded.has(activeProject)) {
      // Re-fetch the active project's tree.
      void loadDir(activeProject, "");
    }
     
  }, [refreshKey]);

  const loadDir = async (project: string, dirPath: string) => {
    // Optimistically mark loading.
    setTrees((prev) => {
      const next = { ...prev };
      const list = next[project] ? structuredCloneSafe(next[project]) : [];
      if (dirPath === "") {
        next[project] = list; // root - loading handled by parent state
      } else {
        findAndMutate(list, dirPath, (n) => {
          n.loading = true;
        });
        next[project] = list;
      }
      return next;
    });

    try {
      const res = await gemApi.projectFiles(project, dirPath);
      if (res.type !== "dir") return;
      const children: TreeNode[] = (res.entries || []).map((e) => ({
        name: e.name,
        type: e.type,
        path: dirPath ? `${dirPath}/${e.name}` : e.name,
        size: e.size,
      }));
      setTrees((prev) => {
        const next = { ...prev };
        if (dirPath === "") {
          next[project] = children;
        } else {
          const list = next[project] ? structuredCloneSafe(next[project]) : [];
          findAndMutate(list, dirPath, (n) => {
            n.children = children;
            n.loaded = true;
            n.loading = false;
          });
          next[project] = list;
        }
        return next;
      });
    } catch (e) {
      setTrees((prev) => {
        const next = { ...prev };
        const list = next[project] ? structuredCloneSafe(next[project]) : [];
        findAndMutate(list, dirPath, (n) => {
          n.loading = false;
          n.error = (e as Error).message;
        });
        next[project] = list;
        return next;
      });
    }
  };

  const toggleExpand = async (project: string, dirPath: string) => {
    const key = `${project}::${dirPath}`;
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
    // Lazy-load if not yet loaded.
    const list = trees[project] || [];
    let already = false;
    if (dirPath !== "") {
      findAndMutate(list, dirPath, (n) => {
        already = !!n.loaded;
      });
    } else {
      already = list.length > 0;
    }
    if (!already) await loadDir(project, dirPath);
  };

  const openFile = async (project: string, filePath: string) => {
    setFilePreview({ path: filePath, content: "", loading: true });
    try {
      const res = await gemApi.projectFiles(project, filePath);
      if (res.type === "file") {
        setFilePreview({ path: filePath, content: res.content || "", loading: false });
      } else {
        setFilePreview({ path: filePath, content: "(not a file)", loading: false });
      }
    } catch (e) {
      setFilePreview({ path: filePath, content: `Error: ${(e as Error).message}`, loading: false });
    }
  };

  const handleCreate = async () => {
    const name = newName.trim();
    if (!name) return;
    setCreating(false);
    setNewName("");
    await onCreateProject(name);
  };

  const renderTree = (project: string, nodes: TreeNode[], depth = 0) => {
    if (!nodes.length) {
      return (
        <div className="px-3 py-2 text-xs italic text-muted-foreground/70">Empty project</div>
      );
    }
    return (
      <ul className={cn(depth === 0 ? "" : "pl-2")}>
        {nodes.map((node) => {
          const key = `${project}::${node.path}`;
          const isOpen = expanded.has(key);
          if (node.type === "dir") {
            return (
              <li key={key}>
                <Collapsible open={isOpen} onOpenChange={() => toggleExpand(project, node.path)}>
                  <CollapsibleTrigger className="flex w-full items-center gap-1.5 rounded-md px-2 py-1 text-left text-xs hover:bg-accent group">
                    <ChevronRight className={cn("h-3 w-3 shrink-0 text-muted-foreground transition-transform", isOpen && "rotate-90")} />
                    {isOpen ? (
                      <FolderOpen className="h-3.5 w-3.5 shrink-0 text-amber-500" />
                    ) : (
                      <Folder className="h-3.5 w-3.5 shrink-0 text-amber-500" />
                    )}
                    <span className="truncate text-foreground/90">{node.name}</span>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    {node.loading ? (
                      <div className="flex items-center gap-1.5 px-3 py-1 text-xs text-muted-foreground">
                        <Loader2 className="h-3 w-3 animate-spin" /> loading…
                      </div>
                    ) : node.children ? (
                      renderTree(project, node.children, depth + 1)
                    ) : null}
                  </CollapsibleContent>
                </Collapsible>
              </li>
            );
          }
          return (
            <li key={key}>
              <button
                type="button"
                onClick={() => openFile(project, node.path)}
                className="flex w-full items-center gap-1.5 rounded-md px-2 py-1 text-left text-xs hover:bg-accent group"
              >
                <span className="w-3 shrink-0" />
                <FileIcon className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                <span className="truncate text-foreground/80 group-hover:text-foreground">{node.name}</span>
              </button>
            </li>
          );
        })}
      </ul>
    );
  };

  if (loading) {
    return (
      <div className="space-y-2 px-2">
        {[0, 1].map((i) => (
          <div key={i} className="h-8 animate-pulse rounded-md bg-muted" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between px-2">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Projects</span>
        <Button
          size="icon"
          variant="ghost"
          className="h-6 w-6 text-muted-foreground hover:text-foreground"
          onClick={() => setCreating((v) => !v)}
          aria-label="New project"
        >
          {creating ? <FolderPlus className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
        </Button>
      </div>

      {creating && (
        <div className="px-2 pb-1">
          <input
            autoFocus
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleCreate();
              if (e.key === "Escape") {
                setCreating(false);
                setNewName("");
              }
            }}
            placeholder="project-name"
            className="w-full rounded-md border border-border bg-background px-2 py-1.5 text-xs outline-none focus:border-gem/50 focus:ring-2 focus:ring-gem/20"
          />
          <div className="mt-1 flex gap-1.5">
            <Button size="sm" className="h-6 flex-1 text-[11px]" onClick={handleCreate} disabled={!newName.trim()}>
              Create
            </Button>
            <Button size="sm" variant="ghost" className="h-6 text-[11px]" onClick={() => setCreating(false)}>
              Cancel
            </Button>
          </div>
        </div>
      )}

      <div className="space-y-0.5">
        {projects.length === 0 && !creating && (
          <div className="px-3 py-2 text-xs italic text-muted-foreground/70">No projects yet</div>
        )}
        {projects.map((p) => {
          const isActive = p.name === activeProject;
          const isExpanded = expanded.has(`${p.name}::`);
          return (
            <Collapsible
              key={p.name}
              open={isExpanded}
              onOpenChange={() => toggleExpand(p.name, "")}
            >
              <div
                className={cn(
                  "group flex items-center rounded-md",
                  isActive && "bg-gem-soft/60",
                )}
              >
                <CollapsibleTrigger className="flex flex-1 items-center gap-1.5 px-2 py-1.5 text-left">
                  <ChevronRight className={cn("h-3 w-3 shrink-0 text-muted-foreground transition-transform", isExpanded && "rotate-90")} />
                  <Folder className="h-3.5 w-3.5 shrink-0 text-amber-500" />
                  <span className={cn("truncate text-xs", isActive ? "font-medium text-gem-soft-foreground" : "text-foreground/90")}>
                    {p.name}
                  </span>
                </CollapsibleTrigger>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 shrink-0 px-2 text-[10px] text-muted-foreground hover:text-foreground"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectProject(p.name);
                    toast.success(`Active project: ${p.name}`);
                  }}
                >
                  {isActive ? <Badge variant="outline" className="text-[9px] text-emerald-600">active</Badge> : "use"}
                </Button>
              </div>
              <CollapsibleContent>
                <div className="mt-0.5 mb-1 border-l border-border/60 ml-3 pl-1">
                  {renderTree(p.name, trees[p.name] || [])}
                </div>
              </CollapsibleContent>
            </Collapsible>
          );
        })}
      </div>

      <Dialog open={!!filePreview} onOpenChange={(o) => !o && setFilePreview(null)}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-sm">
              <FileIcon className="h-4 w-4 text-muted-foreground" />
              <code className="font-mono text-xs">{filePreview?.path}</code>
            </DialogTitle>
            <DialogDescription className="sr-only">File preview</DialogDescription>
          </DialogHeader>
          <div className="min-h-0 flex-1 overflow-hidden rounded-md border border-zinc-800 bg-zinc-950">
            {filePreview?.loading ? (
              <div className="flex h-32 items-center justify-center text-muted-foreground">
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> loading…
              </div>
            ) : (
              <pre className="gem-scroll h-full max-h-[60vh] overflow-auto p-3 font-mono text-[12px] leading-relaxed text-zinc-100">
                <code className="whitespace-pre-wrap break-all">{filePreview?.content || "(empty)"}</code>
              </pre>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/** Safe structuredClone fallback (older browsers / non-cloneable). */
function structuredCloneSafe<T>(v: T): T {
  try {
    return structuredClone(v);
  } catch {
    return JSON.parse(JSON.stringify(v)) as T;
  }
}
