"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUp, Loader2, Paperclip, Square, Users } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";

interface InputBarProps {
  onSend: (message: string, opts: { swarm?: boolean }) => void;
  onStop: () => void;
  isStreaming: boolean;
  activeProject: string | null;
  pendingUploadRef: React.MutableRefObject<string | null>;
}

const MAX_UPLOAD = 1024 * 1024; // 1 MB

export function InputBar({ onSend, onStop, isStreaming, activeProject, pendingUploadRef }: InputBarProps) {
  const [value, setValue] = useState("");
  const [swarm, setSwarm] = useState(false);
  const [uploadName, setUploadName] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-resize the textarea up to a max height.
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 220)}px`;
  }, [value]);

  // If a previous step stashed an uploaded file's text, surface it as a chip.
  useEffect(() => {
    if (pendingUploadRef.current && !uploadName) {
      // The ref holds "name|||content"; we just show the name.
      const raw = pendingUploadRef.current;
      const name = raw.split("|||")[0];
      setUploadName(name);
    }
  }, [pendingUploadRef, uploadName]);

  const submit = () => {
    let text = value.trim();
    if (!text || isStreaming) return;
    if (pendingUploadRef.current) {
      const [name, content] = pendingUploadRef.current.split("|||");
      text = `Here is the uploaded file \`${name}\`:\n\n\`\`\`\n${content}\n\`\`\`\n\n${text}`;
      pendingUploadRef.current = null;
      setUploadName(null);
    }
    onSend(text, { swarm });
    setValue("");
    requestAnimationFrame(() => textareaRef.current?.focus());
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  const onFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ""; // reset so the same file can be picked again later
    if (!file) return;
    if (file.size > MAX_UPLOAD) {
      toast.error("File too large", { description: "Please keep uploads under 1 MB." });
      return;
    }
    try {
      const content = await file.text();
      // Reject obvious binary content (many null bytes).
      if (/\x00/.test(content)) {
        toast.error("Binary file not supported", { description: `${file.name} looks like a binary file.` });
        return;
      }
      pendingUploadRef.current = `${file.name}|||${content}`;
      setUploadName(file.name);
      toast.success(`Attached ${file.name}`, { description: "It will be included in your next message." });
      textareaRef.current?.focus();
    } catch (err) {
      toast.error("Could not read file", { description: (err as Error).message });
    }
  };

  const clearUpload = () => {
    pendingUploadRef.current = null;
    setUploadName(null);
  };

  return (
    <div className="border-t border-border bg-background/95 backdrop-blur">
      <div className="mx-auto max-w-3xl px-4 py-3 sm:px-6">
        {uploadName && (
          <div className="mb-2 flex items-center gap-2">
            <Badge variant="secondary" className="gap-1.5 py-1">
              <Paperclip className="h-3 w-3" />
              {uploadName}
            </Badge>
            <Button size="sm" variant="ghost" className="h-6 px-2 text-[11px] text-muted-foreground" onClick={clearUpload}>
              Remove
            </Button>
          </div>
        )}
        <div className="flex items-end gap-2 rounded-2xl border border-border bg-card p-2 shadow-sm focus-within:ring-2 focus-within:ring-gem/30 focus-within:border-gem/40 transition">
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            onChange={onFileChange}
            accept="text/*,.md,.json,.yaml,.yml,.toml,.csv,.tsv,.txt,.py,.js,.ts,.tsx,.jsx,.go,.rs,.java,.c,.cpp,.h,.rb,.php,.sh,.sql,.html,.css,.xml"
          />
          <TooltipProvider delayDuration={200}>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-9 w-9 shrink-0 rounded-xl text-muted-foreground hover:text-foreground"
                  onClick={() => fileInputRef.current?.click()}
                  aria-label="Attach file"
                >
                  <Paperclip className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Attach a text file (&lt;1MB)</TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <textarea
            ref={textareaRef}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={onKeyDown}
            rows={1}
            placeholder={activeProject ? `Message Gem · working in ${activeProject}…` : "Message Gem…"}
            className="gem-scroll flex-1 resize-none bg-transparent px-2 py-2 text-sm leading-relaxed outline-none placeholder:text-muted-foreground max-h-[220px]"
            aria-label="Message input"
          />

          <div className="flex items-center gap-2">
            <TooltipProvider delayDuration={200}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <label className="flex h-9 cursor-pointer select-none items-center gap-1.5 rounded-xl px-2 text-xs text-muted-foreground hover:bg-muted hover:text-foreground transition">
                    <Switch checked={swarm} onCheckedChange={setSwarm} className="data-[state=checked]:bg-violet-gem" />
                    <Users className={cn("h-3.5 w-3.5", swarm && "text-violet-gem")} />
                    <span className={cn("hidden sm:inline", swarm && "text-violet-gem font-medium")}>Swarm</span>
                  </label>
                </TooltipTrigger>
                <TooltipContent>Dispatch a swarm of specialised agents</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            {isStreaming ? (
              <Button
                size="icon"
                variant="destructive"
                className="h-9 w-9 shrink-0 rounded-xl"
                onClick={onStop}
                aria-label="Stop"
              >
                <Square className="h-4 w-4" fill="currentColor" />
              </Button>
            ) : (
              <Button
                size="icon"
                className="h-9 w-9 shrink-0 rounded-xl bg-zinc-900 hover:bg-zinc-800"
                onClick={submit}
                disabled={!value.trim()}
                aria-label="Send message"
              >
                {value.trim() ? <ArrowUp className="h-4 w-4" /> : <Loader2 className="h-4 w-4 opacity-40" />}
              </Button>
            )}
          </div>
        </div>
        <div className="mt-1.5 flex items-center justify-between px-1">
          <p className="text-[11px] text-muted-foreground">
            <kbd className="rounded border border-border bg-muted px-1 font-mono text-[10px]">Enter</kbd> to send ·{" "}
            <kbd className="rounded border border-border bg-muted px-1 font-mono text-[10px]">Shift+Enter</kbd> for newline
          </p>
          {activeProject && (
            <Badge variant="outline" className="text-[10px] font-normal text-muted-foreground">
              project: <span className="ml-1 font-mono text-foreground/80">{activeProject}</span>
            </Badge>
          )}
        </div>
      </div>
    </div>
  );
}
