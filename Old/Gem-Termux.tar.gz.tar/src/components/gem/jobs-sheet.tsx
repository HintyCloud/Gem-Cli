"use client";

import { useEffect, useState } from "react";
import { Briefcase, Loader2, RefreshCw, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { gemApi, type JobState, type JobStatus } from "@/lib/gem";
import { toast } from "sonner";

interface JobsSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Set true to signal there are active jobs (badge counter). */
  hasActive?: boolean;
}

const STATUS_COLORS: Record<JobStatus, string> = {
  queued: "bg-zinc-200 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300",
  running: "bg-gem-soft text-gem-soft-foreground",
  completed: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  failed: "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300",
  cancelled: "bg-zinc-100 text-zinc-500 dark:bg-zinc-900 dark:text-zinc-400",
  paused: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  recovering: "bg-violet-soft text-violet-gem",
};

export function JobsSheet({ open, onOpenChange, hasActive }: JobsSheetProps) {
  const [jobs, setJobs] = useState<JobState[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [polling, setPolling] = useState(false);

  const refresh = async () => {
    setLoading(true);
    try {
      const list = await gemApi.listJobs();
      setJobs(list);
    } catch (e) {
      toast.error("Failed to load jobs", { description: (e as Error).message });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) refresh();
  }, [open]);

  // Poll while there are active jobs and the sheet is open.
  useEffect(() => {
    if (!open) return;
    const hasActiveJob = jobs?.some((j) => j.status === "running" || j.status === "queued" || j.status === "recovering");
    if (!hasActiveJob) return;
    setPolling(true);
    const t = setInterval(refresh, 2000);
    return () => {
      clearInterval(t);
      setPolling(false);
    };
     
  }, [open, jobs]);

  const cancel = async (id: string) => {
    try {
      await gemApi.cancelJob(id);
      toast.success("Job cancelled");
      refresh();
    } catch (e) {
      toast.error("Cancel failed", { description: (e as Error).message });
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-md flex flex-col gap-0 p-0">
        <SheetHeader className="border-b border-border px-4 py-3">
          <SheetTitle className="flex items-center gap-2 text-sm">
            <Briefcase className="h-4 w-4" />
            Jobs
            {hasActive && (
              <span className="inline-flex items-center gap-1 rounded-full bg-gem-soft px-1.5 py-0.5 text-[10px] font-medium text-gem-soft-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-gem gem-pulse" />
                live
              </span>
            )}
            {polling && <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />}
          </SheetTitle>
          <SheetDescription className="sr-only">Background agent jobs</SheetDescription>
        </SheetHeader>

        <div className="flex items-center justify-between px-4 py-2 border-b border-border">
          <span className="text-xs text-muted-foreground">
            {jobs ? `${jobs.length} job${jobs.length === 1 ? "" : "s"}` : "loading…"}
          </span>
          <Button size="sm" variant="ghost" className="h-7 gap-1.5 text-xs" onClick={refresh} disabled={loading}>
            <RefreshCw className={cn("h-3 w-3", loading && "animate-spin")} /> Refresh
          </Button>
        </div>

        <div className="gem-scroll flex-1 overflow-y-auto p-3 space-y-3">
          {jobs === null ? (
            <div className="flex items-center justify-center py-8 text-sm text-muted-foreground">
              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> loading…
            </div>
          ) : jobs.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center text-sm text-muted-foreground">
              <Briefcase className="mb-2 h-8 w-8 text-muted-foreground/40" />
              No jobs yet.
              <div className="mt-1 text-xs text-muted-foreground/70">Background agent tasks will appear here.</div>
            </div>
          ) : (
            jobs.map((j) => (
              <div key={j.job_id} className="rounded-lg border border-border bg-card p-3 shadow-sm">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={cn(
                          "inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium",
                          STATUS_COLORS[j.status],
                        )}
                      >
                        {j.status}
                      </span>
                      {j.use_swarm && (
                        <Badge variant="outline" className="text-[10px] text-violet-gem">swarm</Badge>
                      )}
                    </div>
                    <p className="mt-1.5 line-clamp-2 text-xs text-foreground/90">{j.task}</p>
                    <div className="mt-1 flex items-center gap-2 text-[10px] text-muted-foreground">
                      <code className="font-mono">{j.job_id.slice(0, 8)}</code>
                      <span>·</span>
                      <span>project: {j.project}</span>
                    </div>
                  </div>
                  {(j.status === "running" || j.status === "queued" || j.status === "recovering") && (
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-7 w-7 shrink-0 text-muted-foreground hover:text-rose-600"
                      onClick={() => cancel(j.job_id)}
                      aria-label="Cancel job"
                    >
                      <X className="h-3.5 w-3.5" />
                    </Button>
                  )}
                </div>
                {(j.status === "running" || j.status === "recovering") && (
                  <div className="mt-2">
                    <Progress value={Math.max(2, Math.min(100, j.progress || 0))} className="h-1.5" />
                  </div>
                )}
                {j.error && j.status === "failed" && (
                  <pre className="gem-scroll mt-2 max-h-32 overflow-auto rounded-md bg-rose-950 p-2 font-mono text-[11px] text-rose-100">
                    <code className="whitespace-pre-wrap break-all">{j.error}</code>
                  </pre>
                )}
                {j.result && (j.status === "completed" || j.status === "cancelled") && (
                  <pre className="gem-scroll mt-2 max-h-32 overflow-auto rounded-md bg-zinc-950 p-2 font-mono text-[11px] text-zinc-100">
                    <code className="whitespace-pre-wrap break-all">{j.result}</code>
                  </pre>
                )}
                {j.events && j.events.length > 0 && (
                  <div className="mt-1.5 text-[10px] text-muted-foreground">{j.events.length} events</div>
                )}
              </div>
            ))
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}
