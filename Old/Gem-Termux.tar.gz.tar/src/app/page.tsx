"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Briefcase, Gem, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Sidebar } from "@/components/gem/sidebar";
import { ChatView } from "@/components/gem/chat-view";
import { InputBar } from "@/components/gem/input-bar";
import { ArtifactsMenu } from "@/components/gem/artifacts-menu";
import { JobsSheet } from "@/components/gem/jobs-sheet";
import { ModelBadge } from "@/components/gem/status-badge";
import { useGemChat } from "@/hooks/use-gem-chat";
import {
  gemApi,
  type ChatSummary,
  type ProjectInfo,
  type StatusInfo,
  type JobState,
} from "@/lib/gem";
import { toast } from "sonner";

export default function Home() {
  // ---- top-level data ----
  const [status, setStatus] = useState<StatusInfo | null>(null);
  const [chats, setChats] = useState<ChatSummary[] | null>(null);
  const [projects, setProjects] = useState<ProjectInfo[] | null>(null);
  const [loadingChats, setLoadingChats] = useState(true);
  const [loadingProjects, setLoadingProjects] = useState(true);
  const [activeProject, setActiveProject] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0); // bump to refresh project trees
  const [jobsOpen, setJobsOpen] = useState(false);
  const [jobs, setJobs] = useState<JobState[] | null>(null);

  // mobile sidebar
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // uploaded file stashed for the next message
  const pendingUploadRef = useRef<string | null>(null);

  const refreshChats = useCallback(async () => {
    try {
      const list = await gemApi.listChats();
      setChats(list);
    } catch (e) {
      toast.error("Failed to load chats", { description: (e as Error).message });
    } finally {
      setLoadingChats(false);
    }
  }, []);

  const refreshProjects = useCallback(async () => {
    try {
      const list = await gemApi.listProjects();
      setProjects(list);
      // Auto-select the first real project if none selected.
      setActiveProject((cur) => {
        if (cur) return cur;
        const first = list.find((p) => p.name !== "_default") || list[0];
        return first ? first.name : null;
      });
    } catch (e) {
      toast.error("Failed to load projects", { description: (e as Error).message });
    } finally {
      setLoadingProjects(false);
    }
  }, []);

  const refreshStatus = useCallback(async () => {
    try {
      const s = await gemApi.status();
      setStatus(s);
    } catch (e) {
      // silent - status is non-critical
      console.error("status failed", e);
    }
  }, []);

  // Initial load.
  useEffect(() => {
    // Warm up the Python Gem API (spawned via the Node bridge) before any call.
    gemApi.ensureGemApi().finally(() => {
      void refreshChats();
      void refreshProjects();
      void refreshStatus();
    });
  }, [refreshChats, refreshProjects, refreshStatus]);

  // Periodic status refresh (cheap).
  useEffect(() => {
    const t = setInterval(refreshStatus, 15000);
    return () => clearInterval(t);
  }, [refreshStatus]);

  // Poll jobs lightly to surface a badge counter.
  useEffect(() => {
    let alive = true;
    const tick = async () => {
      try {
        const list = await gemApi.listJobs();
        if (alive) setJobs(list);
      } catch {
        /* ignore */
      }
    };
    tick();
    const t = setInterval(tick, 5000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  const activeJobs = jobs?.filter(
    (j) => j.status === "running" || j.status === "queued" || j.status === "recovering",
  ).length || 0;

  // ---- chat hook ----
  const chat = useGemChat({
    project: activeProject || "default",
    onChatsChanged: () => {
      void refreshChats();
      setRefreshKey((k) => k + 1);
    },
  });

  // When a chat turn finishes, refresh project trees so newly created files show up.
  useEffect(() => {
    if (!chat.isStreaming) {
      // turn just ended (or initial). bump refreshKey to refresh trees.
      setRefreshKey((k) => k + 1);
    }
     
  }, [chat.isStreaming]);

  const handleNewChat = useCallback(async () => {
    await chat.newChat();
    setSidebarOpen(false);
  }, [chat]);

  const handleSelectChat = useCallback(
    async (id: string) => {
      await chat.selectChat(id);
      setSidebarOpen(false);
    },
    [chat],
  );

  const handleCreateProject = useCallback(
    async (name: string) => {
      try {
        await gemApi.createProject(name);
        toast.success(`Project “${name}” created`);
        await refreshProjects();
        setActiveProject(name);
      } catch (e) {
        toast.error("Failed to create project", { description: (e as Error).message });
      }
    },
    [refreshProjects],
  );

  const onSend = useCallback(
    (message: string, opts: { swarm?: boolean }) => {
      void chat.send(message, opts);
    },
    [chat],
  );

  const onStop = useCallback(() => {
    chat.stop();
  }, [chat]);

  const sidebarContent = (
    <Sidebar
      chats={chats}
      activeChatId={chat.activeChatId}
      loadingChats={loadingChats}
      onSelectChat={handleSelectChat}
      onNewChat={handleNewChat}
      onRenameChat={chat.renameChat}
      onDeleteChat={chat.deleteChat}
      projects={projects}
      loadingProjects={loadingProjects}
      activeProject={activeProject}
      onSelectProject={(name) => setActiveProject(name)}
      onCreateProject={handleCreateProject}
      refreshKey={refreshKey}
      status={status}
    />
  );

  return (
    <div className="flex h-screen w-full flex-col overflow-hidden bg-background text-foreground">
      {/* Top bar */}
      <header className="flex h-14 shrink-0 items-center justify-between border-b border-border bg-background px-3 sm:px-4">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden h-9 w-9"
            onClick={() => setSidebarOpen(true)}
            aria-label="Open sidebar"
          >
            <Menu className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-zinc-900 to-zinc-700 text-white shadow-sm">
              <Gem className="h-4 w-4" />
            </div>
            <div className="leading-none">
              <div className="text-sm font-semibold tracking-tight">Gem</div>
              <div className="hidden sm:block text-[10px] text-muted-foreground">agentic AI ecosystem</div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <ModelBadge status={status} className="hidden sm:inline-flex" />
          <Button
            variant="ghost"
            size="sm"
            className="gap-1.5 text-muted-foreground hover:text-foreground"
            onClick={() => setJobsOpen(true)}
          >
            <Briefcase className="h-4 w-4" />
            <span className="hidden sm:inline">Jobs</span>
            {activeJobs > 0 && (
              <span className="inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-gem px-1 text-[10px] font-semibold text-white">
                {activeJobs}
              </span>
            )}
          </Button>
          <ArtifactsMenu />
        </div>
      </header>

      {/* Body: sidebar + main */}
      <div className="flex min-h-0 flex-1">
        {/* Desktop sidebar */}
        <aside className="hidden md:block w-[280px] shrink-0 border-r border-sidebar-border">
          {sidebarContent}
        </aside>

        {/* Mobile sidebar */}
        <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
          <SheetContent side="left" className="w-[280px] sm:max-w-[280px] p-0">
            <SheetHeader className="sr-only">
              <SheetTitle>Navigation</SheetTitle>
              <SheetDescription>Chats, projects and search</SheetDescription>
            </SheetHeader>
            {sidebarContent}
          </SheetContent>
        </Sheet>

        {/* Main column */}
        <main className="flex min-h-0 min-w-0 flex-1 flex-col">
          <ChatView
            turns={chat.turns}
            isStreaming={chat.isStreaming}
            isLoadingChat={chat.isLoadingChat}
            activeChatTitle={chat.activeChatTitle}
            hasActiveChat={!!chat.activeChatId}
          />
          <InputBar
            onSend={onSend}
            onStop={onStop}
            isStreaming={chat.isStreaming}
            activeProject={activeProject}
            pendingUploadRef={pendingUploadRef}
          />
        </main>
      </div>

      <JobsSheet open={jobsOpen} onOpenChange={setJobsOpen} hasActive={activeJobs > 0} />
    </div>
  );
}
