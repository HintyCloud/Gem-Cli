import { NextResponse } from "next/server";
import { spawn, type ChildProcess } from "child_process";
import { existsSync, readFileSync } from "fs";

// The sandbox kills processes spawned from bash tool calls once that call ends,
// but the Next.js dev server (a child of PID 1) is persistent. We therefore
// spawn the Python Gem API as a child of THIS Node process so it stays alive
// across tool calls. The handle is kept in a global so it is not GC'd/unref'd.

const GEM_GLOBAL = globalThis as unknown as { __gemApi?: ChildProcess; __gemStarting?: boolean };

function gemConfigured(): boolean {
  try {
    const p = "/home/z/my-project/config/secrets.toml";
    if (!existsSync(p)) return false;
    return readFileSync(p, "utf8").includes("api_key");
  } catch {
    return false;
  }
}

async function ensureGemApi(): Promise<{ ok: boolean; detail: string }> {
  if (GEM_GLOBAL.__gemApi && !GEM_GLOBAL.__gemApi.killed) {
    return { ok: true, detail: "already running" };
  }
  if (GEM_GLOBAL.__gemStarting) {
    // wait for the in-flight start
    for (let i = 0; i < 30; i++) {
      await new Promise((r) => setTimeout(r, 200));
      if (GEM_GLOBAL.__gemApi) return { ok: true, detail: "started after wait" };
    }
  }
  GEM_GLOBAL.__gemStarting = true;
  try {
    const child = spawn(
      "python3",
      ["-m", "uvicorn", "gem.api.app:app", "--host", "127.0.0.1", "--port", "8000", "--log-level", "warning"],
      { cwd: "/home/z/my-project", stdio: "ignore" }
    );
    child.on("exit", () => {
      GEM_GLOBAL.__gemApi = undefined;
    });
    GEM_GLOBAL.__gemApi = child;
    // give uvicorn a moment to bind
    await new Promise((r) => setTimeout(r, 3500));
    GEM_GLOBAL.__gemStarting = false;
    return { ok: true, detail: "started" };
  } catch (e) {
    GEM_GLOBAL.__gemStarting = false;
    return { ok: false, detail: String(e) };
  }
}

export async function GET() {
  const res = await ensureGemApi();
  return NextResponse.json({
    ...res,
    configured: gemConfigured(),
    pid: GEM_GLOBAL.__gemApi?.pid ?? null,
  });
}

export async function POST() {
  return GET();
}
