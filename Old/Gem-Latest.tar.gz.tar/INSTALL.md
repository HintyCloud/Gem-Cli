# Gem — Latest (primary distribution)

Includes: Gem Core, Gem API, Web UI, CLI, Agent, Swarm, Subagents, Tools,
Image generation, Jobs, Memory, History, OpenCode provider, default config for
`longcat-2.0-free`.

## Architecture
```
Client → Gem API → Gem Core → Provider → OpenCode → configured model
```

## Install & run
```bash
tar xzf Gem-Latest.tar.gz
cd Gem-Latest
pip install -e .
# Configure: edit config/secrets.toml with [opencode] api_key = "sk-..."
./run.sh          # Gem API on 127.0.0.1:8000
```

Web UI (separate terminal):
```bash
cd src && bun install && bun run dev   # http://127.0.0.1:3000
```

CLI:
```bash
gem status
gem chat
```
