// Gem AI - Interactive features
document.addEventListener('DOMContentLoaded', () => {
    console.log('✨ Gem AI initialized');
    
    // Add animation to heading
    const h1 = document.querySelector('h1');
    if (h1) {
        h1.style.animation = 'pulse 2s infinite';
    }
    
    // Log feature count
    const features = document.querySelectorAll('.feature');
    console.log('Features loaded: ' + features.length);
});