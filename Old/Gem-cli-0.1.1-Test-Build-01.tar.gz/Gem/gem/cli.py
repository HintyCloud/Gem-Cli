"""
Gem CLI Interface

Provides the command-line interface for interacting with Gem.
Features streaming output, slash commands, session management,
and rich terminal formatting using the Rich library.
"""

import asyncio
import logging
import os
import sys
from pathlib import Path
from typing import Optional

try:
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.prompt import Prompt
    from rich.syntax import Syntax
    from rich.text import Text
    from rich.live import Live
    from rich.spinner import Spinner
except ImportError:
    # Fallback if Rich not installed
    Console = None  # type: ignore

from gem.agent.loop import AgentLoop
from gem.memory.history import ChatHistory
from gem.memory.memory import PersistentMemory
from gem.providers.opencode import OpenCodeProvider, load_toml_config

logger = logging.getLogger(__name__)


# ANSI colors for fallback (without Rich)
class Colors:
    """ANSI color codes."""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"


class GemCLI:
    """
    Command-line interface for Gem AI Agent.
    
    Provides interactive chat interface with:
    - Streaming response display
    - Slash commands (/help, /clear, /model, etc.)
    - Session management
    - Rich formatting (with Rich library)
    - Graceful error handling
    
    Configuration:
        config_path: Path to TOML configuration file
        workspace: Working directory for operations
        no_color: Disable colored output
    """
    
    def __init__(
        self,
        config_path: str = "",
        workspace: str = "",
        no_color: bool = False,
    ):
        """
        Initialize CLI.
        
        Args:
            config_path: Path to configuration file
            workspace: Working directory
            no_color: Disable color output
        """
        self.config_path = config_path
        self.workspace = Path(workspace) if workspace else Path.cwd()
        self.no_color = no_color
        
        # Initialize console (Rich or plain)
        if Console and not no_color:
            self.console = Console()
            self.rich_mode = True
        else:
            self.console = None
            self.rich_mode = False
        
        # Load configuration
        self.config = self._load_configuration()
        
        # Initialize components
        self.provider: Optional[OpenCodeProvider] = None
        self.agent: Optional[AgentLoop] = None
        self.history: Optional[ChatHistory] = None
        self.memory: Optional[PersistentMemory] = None
        
        # State
        self.running = False
        self.current_input = ""
    
    def _load_configuration(self) -> dict:
        """Load TOML configuration."""
        config = {}
        
        # Try provided path, then defaults
        paths_to_try = [
            self.config_path,
            "config/config.toml",
            str(Path.home() / ".gem" / "config.toml"),
        ]
        
        for path in paths_to_try:
            if path and os.path.exists(path):
                try:
                    config = load_toml_config(path)
                    break
                except Exception as e:
                    self.print_error(f"Failed to load config from {path}: {e}")
        
        return config
    
    def _init_components(self):
        """Initialize provider, agent, and memory components."""
        model_config = self.config.get("model", {})
        agent_config = self.config.get("agent", {})
        
        # Get API key from env or config
        api_key = (
            os.environ.get("GEM_API_KEY") or
            model_config.get("api_key") or
            "sk-MN9kABCiW1cskBQ4EncGFV6DFwyHvshu6CrjtmuHUFwdkvJvAHNzql90BqTpNHMC"
        )
        
        # Initialize provider
        self.provider = OpenCodeProvider(
            api_url=model_config.get("api_url", "https://ingem.ai/agent/v1"),  # Display URL
            api_key=api_key,
            model=model_config.get("default_model", "longcat-2.0-free"),
            temperature=model_config.get("temperature", 0.7),
            max_tokens=model_config.get("max_tokens", 4096),
            timeout=model_config.get("timeout", 120),
        )
        
        # Get system prompt or use default
        system_prompt = model_config.get("system_prompt") or """You are Gem, an autonomous AI coding agent. You can execute shell commands, read/write files, and search the web to help users accomplish tasks.

**CRITICAL LANGUAGE RULE:**
- ALWAYS respond in the SAME LANGUAGE that the user is using
- If user speaks Portuguese → respond in Portuguese
- If user speaks English → respond in English  
- If user speaks Spanish → respond in Spanish
- If user speaks any other language → respond in that same language
- NEVER switch languages unless the user explicitly asks you to
- Detect the user's language from their first message and maintain it throughout the conversation

Guidelines:
- Be concise but thorough in your responses
- Always explain what you're doing before taking action
- When executing commands, prefer showing output to the user
- If a command fails, try alternative approaches
- Ask for clarification only when truly necessary
- Keep track of multi-step tasks and report progress"""
        
        # Initialize agent loop
        self.agent = AgentLoop(
            provider=self.provider,
            max_iterations=agent_config.get("max_iterations", 50),
            auto_plan=agent_config.get("auto_plan", True),
            streaming=self.config.get("ui", {}).get("streaming", True),
            system_prompt=system_prompt,
            on_tool_call=self._on_tool_call,
            on_response_chunk=self._on_response_chunk,
            on_iteration_complete=self._on_iteration_complete,
        )
        
        # Initialize history
        history_config = self.config.get("memory", {}).get("history", {})
        self.history = ChatHistory(
            storage_path=history_config.get("storage_path", ""),
            max_messages_per_session=history_config.get("max_messages", 100),
        )
        
        # Create initial session
        self.history.create_session()
        
        # Initialize persistent memory
        mem_config = self.config.get("memory", {}).get("persistent", {})
        self.memory = PersistentMemory(
            storage_path=mem_config.get("storage_path", ""),
            auto_save=mem_config.get("auto_save_interval", 5) > 0,
        )
    
    def _on_tool_call(self, tool_name: str, args: dict):
        """Callback when a tool is called."""
        self.print_tool_indicator(tool_name, args)
    
    def _on_response_chunk(self, chunk: str):
        """Callback for streamed response chunks."""
        if self.rich_mode:
            self.console.print(chunk, end="")
        else:
            print(chunk, end="", flush=True)
    
    def _on_iteration_complete(self, iteration: int, result: dict):
        """Callback after each iteration completes."""
        pass  # Could show iteration counter, etc.
    
    # Output methods
    
    def print_banner(self):
        """Print welcome banner."""
        banner = """
╔══════════════════════════════════════════╗
║                                          ║
║   ███╗   ██╗██╗   ██╗ ██████╗           ║
║   ████╗  ██║██║   ██║██╔═══██╗          ║
║   ██╔██╗ ██║██║   ██║██║   ██║          ║
║   ██║╚██╗██║██║   ██║██║▄▄ ██║          ║
║   ██║ ╚████║╚██████╔╝╚██████╔╝          ║
║   ╚═╝  ╚═══╝ ╚═════╝  ╚══▀▀═╝           ║
║                                          ║
║     Autonomous AI Coding Agent v1.0      ║
║                                          ║
╚══════════════════════════════════════════╝
"""
        if self.rich_mode:
            self.console.print(Panel(banner, style="cyan"))
        else:
            print(f"{Colors.CYAN}{banner}{Colors.RESET}")
        
        self.print_info("Type /help for available commands")
        self.print_info(f"Model: {self.config.get('model', {}).get('default_model', 'longcat-2.0-free')}")
        self.print_info(f"Provider: InGem AI - https://ingem.ai/agent/v1")
        print()
    
    def print_message(self, role: str, content: str):
        """Print a chat message."""
        if role == "user":
            prefix = "👤 You" if self.rich_mode else f"{Colors.GREEN}You{Colors.RESET}"
        elif role == "assistant":
            prefix = "🤖 Gem" if self.rich_mode else f"{Colors.BLUE}Gem{Colors.RESET}"
        elif role == "system":
            prefix = "⚙️ System" if self.rich_mode else f"{Colors.YELLOW}System{Colors.RESET}"
        else:
            prefix = role
        
        if self.rich_mode:
            self.console.print(f"\n{prefix}:")
            self.console.print(Markdown(content))
        else:
            print(f"\n{prefix}:")
            print(content)
    
    def print_response(self, content: str):
        """Print assistant response with formatting."""
        if self.rich_mode:
            self.console.print("\n🤖 Gem:")
            self.console.print(Markdown(content))
        else:
            print(f"\n{Colors.BLUE}Gem:{Colors.RESET}")
            print(content)
    
    def print_tool_indicator(self, tool_name: str, args: dict):
        """Show tool execution indicator."""
        args_str = str(args)[:80] + ("..." if len(str(args)) > 80 else "")
        
        if self.rich_mode:
            self.console.print(f"  🔧 {tool_name}({args_str})", style="dim")
        else:
            print(f"  {Colors.YELLOW}🔧 {tool_name}({args_str}){Colors.RESET}")
    
    def print_info(self, message: str):
        """Print informational message."""
        if self.rich_mode:
            self.console.print(message, style="dim")
        else:
            print(f"{Colors.DIM}{message}{Colors.RESET}")
    
    def print_success(self, message: str):
        """Print success message."""
        if self.rich_mode:
            self.console.print(message, style="green")
        else:
            print(f"{Colors.GREEN}{message}{Colors.RESET}")
    
    def print_error(self, message: str):
        """Print error message."""
        if self.rich_mode:
            self.console.print(message, style="red")
        else:
            print(f"{Colors.RED}{message}{Colors.RESET}")
    
    def print_warning(self, message: str):
        """Print warning message."""
        if self.rich_mode:
            self.console.print(message, style="yellow")
        else:
            print(f"{Colors.YELLOW}{message}{Colors.RESET}")
    
    # Command handling
    
    async def handle_command(self, command: str, args: str) -> bool:
        """
        Handle a slash command.
        
        Args:
            command: Command name (without slash)
            args: Command arguments
            
        Returns:
            True if should continue running, False to exit
        """
        handlers = {
            "help": self.cmd_help,
            "clear": self.cmd_clear,
            "reset": self.cmd_reset,
            "model": self.cmd_model,
            "status": self.cmd_status,
            "history": self.cmd_history,
            "memory": self.cmd_memory,
            "export": self.cmd_export,
            "config": self.cmd_config,
            "quit": cmd_quit,
            "exit": cmd_quit,
            "q": cmd_quit,
        }
        
        handler = handlers.get(command.lower())
        
        if handler:
            return await handler(args)
        else:
            self.print_error(f"Unknown command: /{command}. Type /help for available commands.")
            return True
    
    async def cmd_help(self, args: str) -> bool:
        """Show help information."""
        help_text = """
**Available Commands:**

| Command | Description |
|---------|-------------|
| `/help` | Show this help message |
| `/clear` | Clear conversation context |
| `/reset` | Full reset (new session) |
| `/model [name]` | View/set current model |
| `/status` | Show agent status |
| `/history` | List chat sessions |
| `/memory` | Manage persistent memory |
| `/export [path]` | Export current session |
| `/config` | Show current configuration |
| `/quit` | Exit Gem |

**Tips:**
- Type your message and press Enter to send
- Use Shift+Enter for multi-line input (in some terminals)
- The agent can run commands, edit files, and search the web
- Press Ctrl+C to cancel current operation
"""
        if self.rich_mode:
            self.console.print(Markdown(help_text))
        else:
            print(help_text)
        
        return True
    
    async def cmd_clear(self, args: str) -> bool:
        """Clear conversation context."""
        if self.agent:
            self.agent.reset()
        self.print_success("Context cleared. Starting fresh.")
        return True
    
    async def cmd_reset(self, args: str) -> bool:
        """Full reset including new session."""
        if self.agent:
            self.agent.reset()
        if self.history:
            self.history.create_session()
        self.print_success("Full reset complete. New session started.")
        return True
    
    async def cmd_model(self, args: str) -> bool:
        """View or set current model."""
        if args:
            # Set new model
            if self.provider:
                self.provider.model = args
                self.print_success(f"Model changed to: {args}")
        else:
            # Show current model and provider info
            if self.provider:
                status = self.provider.get_status_info()
                self.print_info(f"Provider: {status['provider']}")
                self.print_info(f"API: {status['api_url']}")
                self.print_info(f"Model: {status['model']}")
                self.print_info(f"Status: {status['status']}")
            else:
                self.print_info("Provider not initialized")
        
        return True
    
    async def cmd_status(self, args: str) -> bool:
        """Show agent status."""
        if not self.agent:
            self.print_warning("Agent not initialized yet")
            return True
        
        status = self.agent.get_status()
        
        status_lines = [
            "**Agent Status:**",
            f"- Running: {'Yes' if status['running'] else 'No'}",
            f"- Iterations: {status['context'].get('iteration', 0)}",
            f"- Context Usage: {status['context'].get('usage_ratio', 0):.1%}",
            f"- Messages in Context: {status['context'].get('total_messages', 0)}",
            f"- Has Plan: {'Yes' if status['has_plan'] else 'No'}",
        ]
        
        if status.get("plan"):
            plan = status["plan"]
            status_lines.extend([
                f"- Plan Progress: {plan['completed_steps']}/{plan['total_steps']} steps",
            ])
        
        if self.rich_mode:
            self.console.print(Markdown("\n".join(status_lines)))
        else:
            print("\n".join(status_lines))
        
        return True
    
    async def cmd_history(self, args: str) -> bool:
        """List chat sessions."""
        if not self.history:
            self.print_warning("History not available")
            return True
        
        sessions = self.history.list_sessions(limit=10)
        
        if not sessions:
            self.print_info("No previous sessions found")
            return True
        
        lines = ["**Recent Sessions:**\n"]
        for i, s in enumerate(sessions, 1):
            lines.append(f"{i}. **{s['title']}** ({s['message_count']} messages)")
            lines.append(f"   Created: {s['created_at'][:16]}")
        
        if self.rich_mode:
            self.console.print(Markdown("\n".join(lines)))
        else:
            print("\n".join(lines))
        
        return True
    
    async def cmd_memory(self, args: str) -> bool:
        """Manage persistent memory."""
        if not self.memory:
            self.print_warning("Memory not available")
            return True
        
        stats = self.memory.get_stats()
        
        lines = [
            "**Persistent Memory:**",
            f"- Total Facts: {stats['total_facts']}",
            f"- Preferences: {stats['total_preferences']}",
            f"- Categories: {list(stats['categories'].keys())}",
        ]
        
        if self.rich_mode:
            self.console.print(Markdown("\n".join(lines)))
        else:
            print("\n".join(lines))
        
        return True
    
    async def cmd_export(self, args: str) -> bool:
        """Export current session."""
        if not self.history or not self.history.get_current_session():
            self.print_warning("No active session to export")
            return True
        
        session_id = self.history._current_session_id
        output_path = args if args else f"chat_export_{session_id}.md"
        
        try:
            path = self.history.export_session(session_id, "markdown", output_path)
            self.print_success(f"Exported to: {path}")
        except Exception as e:
            self.print_error(f"Export failed: {e}")
        
        return True
    
    async def cmd_config(self, args: str) -> bool:
        """Show current configuration."""
        lines = ["**Current Configuration:**\n"]
        
        # Model settings (with masked URL)
        lines.append("**InGem AI Provider:**")
        lines.append("- API Endpoint: https://ingem.ai/agent/v1/chat/completions")
        if self.provider:
            lines.append(f"- Model: {self.provider.model}")
        else:
            lines.append("- Model: longcat-2.0-free")
        lines.append("- Temperature: 0.7")
        
        # Agent settings
        agent = self.config.get("agent", {})
        lines.append("\n**Agent:**")
        lines.append(f"- Max Iterations: {agent.get('max_iterations', 50)}")
        lines.append(f"- Auto Plan: {agent.get('auto_plan', True)}")
        
        lines.append("\n**Note:** Configuration details are managed automatically.")
        lines.append("See ~/.gem/config.toml for advanced settings.")
        
        if self.rich_mode:
            self.console.print(Markdown("\n".join(lines)))
        else:
            print("\n".join(lines))
        
        return True
    
    # Main loop
    
    async def run_interactive(self):
        """Run interactive CLI loop."""
        # Initialize components
        self._init_components()
        
        # Print banner
        self.print_banner()
        
        self.running = True
        
        while self.running:
            try:
                # Get user input
                user_input = await self._get_input()
                
                if not user_input:
                    continue
                
                # Check for commands
                if user_input.startswith("/"):
                    parts = user_input[1:].split(None, 1)
                    command = parts[0]
                    args = parts[1] if len(parts) > 1 else ""
                    
                    self.running = await self.handle_command(command, args)
                    continue
                
                # Process as regular message
                await self._process_user_message(user_input)
                
            except KeyboardInterrupt:
                print()  # Newline after ^C
                if self.agent and self.agent.is_running:
                    self.agent.cancel()
                    self.print_warning("Operation cancelled. Press Ctrl+C again to quit.")
                else:
                    self.print_info("Use /quit to exit")
                    
            except EOFError:
                break
            
            except Exception as e:
                logger.exception("Error in main loop")
                self.print_error(f"An error occurred: {e}")
        
        # Cleanup (async since we're in an async context)
        await self._cleanup_async()
        self.print_info("Goodbye! 👋")
    
    async def _get_input(self) -> str:
        """Get user input from prompt."""
        if self.rich_mode:
            return Prompt.ask("\n[bold green]You[/]")
        else:
            return input(f"\n{Colors.GREEN}> {Colors.RESET}")
    
    async def _process_user_message(self, message: str):
        """Process a user message through the agent."""
        if not self.agent:
            self.print_error("Agent not initialized. Cannot process message.")
            return
        
        # Print user message
        self.print_message("user", message)
        
        # Add to history
        if self.history:
            self.history.add_message("user", message)
        
        # Process through agent
        try:
            result = await self.agent.process_message(message)
            
            # Display response
            if result.get("response"):
                self.print_response(result["response"])
                
                # Add to history
                if self.history:
                    self.history.add_message("assistant", result["response"])
            
            # Show summary of tool usage
            tool_calls = result.get("tool_calls", [])
            if tool_calls:
                self.print_info(f"\nCompleted {len(tool_calls)} tool operation(s)")
                
        except Exception as e:
            logger.exception("Error processing message")
            self.print_error(f"Error: {type(e).__name__}: {e}")
    
    async def _cleanup_async(self):
        """Async cleanup resources (call from async context)."""
        if self.provider:
            try:
                await self.provider.close()
            except Exception as e:
                logger.debug(f"Error closing provider: {e}")
        
        if hasattr(self, 'web_tool'):
            try:
                await self.web_tool.close()
            except Exception as e:
                logger.debug(f"Error closing web_tool: {e}")
    
    def _cleanup(self):
        """Cleanup resources (sync wrapper for non-async context)."""
        try:
            loop = asyncio.get_running_loop()
            # We're inside a running event loop - schedule cleanup
            if loop.is_running():
                loop.create_task(self._cleanup_async())
                return
        except RuntimeError:
            # No running event loop, use asyncio.run
            pass
        
        # Safe to use asyncio.run or no loop running
        try:
            asyncio.get_event_loop().run_until_complete(self._cleanup_async())
        except RuntimeError:
            asyncio.run(self._cleanup_async())
    
    async def run_single(self, message: str):
        """Run a single message and exit (non-interactive mode)."""
        self._init_components()
        
        result = await self.agent.process_message(message)
        print(result.get("response", ""))
        
        # Use async cleanup since we're in an async context
        await self._cleanup_async()


async def cmd_quit(args: str) -> bool:
    """Quit handler (module-level for simplicity)."""
    return False


def main():
    """Main entry point for CLI."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Gem - Autonomous AI Coding Agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    parser.add_argument(
        "-c", "--config",
        help="Path to configuration file",
        default="",
    )
    
    parser.add_argument(
        "-w", "--workspace",
        help="Working directory",
        default="",
    )
    
    parser.add_argument(
        "--no-color",
        help="Disable colored output",
        action="store_true",
    )
    
    parser.add_argument(
        "-m", "--message",
        help="Single message mode (non-interactive)",
        default=None,
    )
    
    parser.add_argument(
        "-v", "--verbose",
        help="Enable verbose logging",
        action="store_true",
    )
    
    args = parser.parse_args()
    
    # Configure logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    
    # Create and run CLI
    cli = GemCLI(
        config_path=args.config,
        workspace=args.workspace,
        no_color=args.no_color,
    )
    
    if args.message:
        # Single message mode
        asyncio.run(cli.run_single(args.message))
    else:
        # Interactive mode
        asyncio.run(cli.run_interactive())


if __name__ == "__main__":
    main()
