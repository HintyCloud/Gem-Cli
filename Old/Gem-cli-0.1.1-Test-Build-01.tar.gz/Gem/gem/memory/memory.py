"""
Persistent Memory System

Manages long-term memory that persists across chat sessions.
Stores user preferences, learned information, and contextual
knowledge that should be remembered between conversations.
"""

import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class PersistentMemory:
    """
    Long-term persistent memory for the agent.
    
    Unlike chat history which is per-conversation, this memory
    persists across all sessions and stores:
    - User preferences and settings
    - Facts learned about the user/project
    - Important context that should be remembered
    - Tool usage patterns and shortcuts
    
    Configuration:
        storage_path: Directory for memory files
        auto_save: Automatically save after updates
        max_facts: Maximum number of facts to store
    """
    
    def __init__(
        self,
        storage_path: str = "",
        auto_save: bool = True,
        max_facts: int = 500,
    ):
        """
        Initialize persistent memory.
        
        Args:
            storage_path: Directory for memory storage
            auto_save: Save changes automatically
            max_facts: Maximum facts to store
        """
        # Set up storage path
        if storage_path:
            self.storage_path = Path(storage_path)
        else:
            self.storage_path = Path("data/memory")
        
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self.auto_save = auto_save
        self.max_facts = max_facts
        
        # Memory file path
        self.memory_file = self.storage_path / "memory.json"
        
        # In-memory data
        self._facts: Dict[str, Dict[str, Any]] = {}
        self._preferences: Dict[str, Any] = {}
        self._tags: Dict[str, Set[str]] = {}  # fact_id -> set of tags
        self._last_accessed: Dict[str, float] = {}  # fact_id -> timestamp
        
        # Load existing memory
        self._load()
        
        logger.debug(f"PersistentMemory initialized at {self.storage_path}")
    
    def _load(self):
        """Load memory from disk."""
        if not self.memory_file.exists():
            logger.debug("No existing memory file, starting fresh")
            return
        
        try:
            with open(self.memory_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            self._facts = data.get("facts", {})
            self._preferences = data.get("preferences", {})
            
            # Reconstruct tag sets
            raw_tags = data.get("tags", {})
            self._tags = {k: set(v) for k, v in raw_tags.items()}
            
            self._last_accessed = data.get("last_accessed", {})
            
            logger.info(f"Loaded {len(self._facts)} facts from memory")
            
        except Exception as e:
            logger.error(f"Failed to load memory: {e}")
            self._facts = {}
            self._preferences = {}
            self._tags = {}
            self._last_accessed = {}
    
    def _save(self):
        """Save memory to disk."""
        try:
            # Enforce max facts limit before saving
            if len(self._facts) > self.max_facts:
                self._prune_old_facts()
            
            data = {
                "facts": self._facts,
                "preferences": self._preferences,
                "tags": {k: list(v) for k, v in self._tags.items()},
                "last_accessed": self._last_accessed,
                "updated": datetime.now().isoformat(),
                "version": "1.0",
            }
            
            # Atomic write: write to temp then rename
            temp_file = self.memory_file.with_suffix('.tmp')
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            temp_file.rename(self.memory_file)
            
            logger.debug(f"Saved {len(self._facts)} facts to memory")
            
        except Exception as e:
            logger.error(f"Failed to save memory: {e}")
    
    def add_fact(
        self,
        content: str,
        category: str = "general",
        tags: Optional[List[str]] = None,
        source: str = "",
        confidence: float = 1.0,
        expires: Optional[float] = None,
    ) -> str:
        """
        Add a new fact to memory.
        
        Args:
            content: The fact content/text
            category: Category for organization (user, project, preference, etc.)
            tags: Tags for searchability
            source: Where this fact was learned
            confidence: Confidence level (0-1)
            expires: Optional expiration timestamp
            
        Returns:
            ID of the created fact
        """
        import hashlib
        
        # Generate deterministic ID from content
        fact_id = hashlib.sha256(content.encode()).hexdigest()[:12]
        
        # Check if already exists (update instead)
        if fact_id in self._facts:
            self.update_fact(fact_id, content=content, confidence=confidence)
            return fact_id
        
        # Create fact record
        now = datetime.now().timestamp()
        
        self._facts[fact_id] = {
            "content": content,
            "category": category,
            "source": source,
            "confidence": confidence,
            "created_at": now,
            "updated_at": now,
            "expires": expires,
            "access_count": 0,
        }
        
        # Store tags
        if tags:
            self._tags[fact_id] = set(tags)
        else:
            self._tags[fact_id] = set()
        
        self._last_accessed[fact_id] = now
        
        if self.auto_save:
            self._save()
        
        logger.debug(f"Added fact [{category}]: {content[:50]}...")
        return fact_id
    
    def get_fact(self, fact_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a specific fact by ID.
        
        Args:
            fact_id: Fact identifier
            
        Returns:
            Fact dictionary or None
        """
        fact = self._facts.get(fact_id)
        
        if not fact:
            return None
        
        # Check expiration
        if fact.get("expires") and fact["expires"] < datetime.now().timestamp():
            self.delete_fact(fact_id)
            return None
        
        # Update access stats
        self._last_accessed[fact_id] = datetime.now().timestamp()
        fact["access_count"] = fact.get("access_count", 0) + 1
        
        return dict(fact)
    
    def update_fact(self, fact_id: str, **updates) -> bool:
        """
        Update an existing fact.
        
        Args:
            fact_id: Fact identifier
            **updates: Fields to update
            
        Returns:
            True if updated successfully
        """
        if fact_id not in self._facts:
            return False
        
        fact = self._facts[fact_id]
        
        allowed_fields = {"content", "category", "source", "confidence", "expires"}
        
        for key, value in updates.items():
            if key in allowed_fields:
                fact[key] = value
        
        fact["updated_at"] = datetime.now().timestamp()
        
        if self.auto_save:
            self._save()
        
        return True
    
    def delete_fact(self, fact_id: str) -> bool:
        """
        Delete a fact from memory.
        
        Args:
            fact_id: Fact identifier
            
        Returns:
            True if deleted
        """
        if fact_id not in self._facts:
            return False
        
        del self._facts[fact_id]
        self._tags.pop(fact_id, None)
        self._last_accessed.pop(fact_id, None)
        
        if self.auto_save:
            self._save()
        
        return True
    
    def search_facts(
        self,
        query: str,
        category: Optional[str] = None,
        tags: Optional[List[str]] = None,
        limit: int = 20,
    ) -> List[Dict[str, Any]]:
        """
        Search for facts matching criteria.
        
        Args:
            query: Text search query
            category: Filter by category
            tags: Filter by tags (match any)
            limit: Maximum results
            
        Returns:
            List of matching fact dicts with IDs
        """
        results = []
        query_lower = query.lower() if query else ""
        
        for fact_id, fact in self._facts.items():
            # Check expiration
            if fact.get("expires") and fact["expires"] < datetime.now().timestamp():
                continue
            
            # Category filter
            if category and fact.get("category") != category:
                continue
            
            # Tag filter (match any)
            if tags:
                fact_tags = self._tags.get(fact_id, set())
                if not any(t in fact_tags for t in tags):
                    continue
            
            # Text search
            if query_lower and query_lower not in fact.get("content", "").lower():
                continue
            
            # Include with ID
            result = dict(fact)
            result["id"] = fact_id
            result["tags"] = list(self._tags.get(fact_id, set()))
            results.append(result)
            
            if len(results) >= limit:
                break
        
        # Sort by access count (most accessed first)
        results.sort(key=lambda x: x.get("access_count", 0), reverse=True)
        
        return results
    
    def get_by_category(self, category: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Get all facts in a category."""
        return self.search_facts(query="", category=category, limit=limit)
    
    def get_by_tag(self, tag: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Get all facts with a specific tag."""
        return self.search_facts(query="", tags=[tag], limit=limit)
    
    def add_tags(self, fact_id: str, tags: List[str]) -> bool:
        """Add tags to a fact."""
        if fact_id not in self._facts:
            return False
        
        if fact_id not in self._tags:
            self._tags[fact_id] = set()
        
        self._tags[fact_id].update(tags)
        
        if self.auto_save:
            self._save()
        
        return True
    
    def remove_tags(self, fact_id: str, tags: List[str]) -> bool:
        """Remove tags from a fact."""
        if fact_id not in self._tags:
            return False
        
        self._tags[fact_id].difference_update(tags)
        
        if self.auto_save:
            self._save()
        
        return True
    
    # Preference helpers
    
    def set_preference(self, key: str, value: Any):
        """Set a user preference."""
        self._preferences[key] = value
        
        if self.auto_save:
            self._save()
    
    def get_preference(self, key: str, default: Any = None) -> Any:
        """Get a user preference."""
        return self._preferences.get(key, default)
    
    def get_all_preferences(self) -> Dict[str, Any]:
        """Get all preferences."""
        return dict(self._preferences)
    
    def delete_preference(self, key: str) -> bool:
        """Delete a preference."""
        if key in self._preferences:
            del self._preferences[key]
            
            if self.auto_save:
                self._save()
            return True
        return False
    
    # Context management
    
    def get_context_for_prompt(self, max_chars: int = 1000) -> str:
        """
        Get relevant context formatted for inclusion in system prompt.
        
        Returns important facts and preferences as a summary string.
        
        Args:
            max_chars: Maximum characters to include
            
        Returns:
            Formatted context string
        """
        sections = []
        
        # User preferences
        if self._preferences:
            pref_lines = [f"- {k}: {v}" for k, v in list(self._preferences.items())[:10]]
            sections.append("**User Preferences:**\n" + "\n".join(pref_lines))
        
        # Recent/high-access facts (sorted by importance)
        sorted_facts = sorted(
            self._facts.items(),
            key=lambda x: x[1].get("access_count", 0),
            reverse=True,
        )[:15]
        
        if sorted_facts:
            fact_lines = []
            for fid, fact in sorted_facts:
                cat = fact.get("category", "")
                content = fact.get("content", "")[:100]
                fact_lines.append(f"- [{cat}] {content}")
            
            sections.append("**Remembered Information:**\n" + "\n".join(fact_lines))
        
        if not sections:
            return ""
        
        result = "\n\n".join(sections)
        
        # Truncate if needed
        if len(result) > max_chars:
            result = result[:max_chars] + "\n... [truncated]"
        
        return result
    
    def _prune_old_facts(self):
        """Remove least accessed facts when over limit."""
        if len(self._facts) <= self.max_facts:
            return
        
        # Sort by last accessed, keep most recent
        sorted_ids = sorted(
            self._last_accessed.keys(),
            key=lambda x: self._last_accessed.get(x, 0),
        )
        
        # Remove oldest
        to_remove = sorted_ids[:len(self._facts) - self.max_facts]
        
        for fact_id in to_remove:
            self.delete_fact(fact_id)
        
        logger.info(f"Pruned {len(to_remove)} old facts")
    
    def cleanup_expired(self) -> int:
        """Remove all expired facts. Returns count removed."""
        now = datetime.now().timestamp()
        expired = [
            fid for fid, fact in self._facts.items()
            if fact.get("expires") and fact["expires"] < now
        ]
        
        for fid in expired:
            self.delete_fact(fid)
        
        if expired:
            self._save()
        
        return len(expired)
    
    def merge_memory(self, other: 'PersistentMemory', overwrite: bool = False):
        """Merge another memory store into this one."""
        for fact_id, fact in other._facts.items():
            if fact_id not in self._facts or overwrite:
                self._facts[fact_id] = dict(fact)
                self._tags[fact_id] = set(other._tags.get(fact_id, []))
        
        for key, value in other._preferences.items():
            if key not in self._preferences or overwrite:
                self._preferences[key] = value
        
        if self.auto_save:
            self._save()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get memory statistics."""
        categories = {}
        for fact in self._facts.values():
            cat = fact.get("category", "unknown")
            categories[cat] = categories.get(cat, 0) + 1
        
        return {
            "total_facts": len(self._facts),
            "total_preferences": len(self._preferences),
            "categories": categories,
            "storage_file": str(self.memory_file),
            "file_size": self.memory_file.stat().st_size if self.memory_file.exists() else 0,
        }
    
    def export_json(self, output_path: str) -> str:
        """Export all memory to JSON file."""
        data = {
            "facts": self._facts,
            "preferences": self._preferences,
            "tags": {k: list(v) for k, v in self._tags.items()},
            "exported_at": datetime.now().isoformat(),
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        return output_path
    
    def import_json(self, input_path: str, merge: bool = True):
        """Import memory from JSON file."""
        with open(input_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if merge:
            for fact_id, fact in data.get("facts", {}).items():
                if fact_id not in self._facts:
                    self._facts[fact_id] = fact
            
            self._preferences.update(data.get("preferences", {}))
            
            for fact_id, tags in data.get("tags", {}).items():
                if fact_id not in self._tags:
                    self._tags[fact_id] = set(tags)
                else:
                    self._tags[fact_id].update(tags)
        else:
            self._facts = data.get("facts", {})
            self._preferences = data.get("preferences", {})
            self._tags = {k: set(v) for k, v in data.get("tags", {})}
        
        if self.auto_save:
            self._save()
    
    def clear(self):
        """Clear all memory."""
        self._facts.clear()
        self._preferences.clear()
        self._tags.clear()
        self._last_accessed.clear()
        
        if self.auto_save:
            self._save()
