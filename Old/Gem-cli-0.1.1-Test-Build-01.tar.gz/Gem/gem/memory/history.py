"""
Chat History Management

Handles persistence, retrieval, and management of chat conversation
history. Supports multiple storage backends and export formats.
"""

import json
import logging
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

logger = logging.getLogger(__name__)


@dataclass
class ChatMessage:
    """
    A single chat message with metadata.
    
    Attributes:
        id: Unique message identifier
        role: Message role (user, assistant, system, tool)
        content: Message content
        timestamp: When the message was created
        metadata: Additional message data (tool calls, etc.)
    """
    id: str
    role: str
    content: str
    timestamp: float
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "id": self.id,
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ChatMessage':
        """Deserialize from dictionary."""
        return cls(
            id=data["id"],
            role=data["role"],
            content=data["content"],
            timestamp=data.get("timestamp", datetime.now().timestamp()),
            metadata=data.get("metadata", {}),
        )
    
    @classmethod
    def create(cls, role: str, content: str, **metadata) -> 'ChatMessage':
        """Create a new message with auto-generated ID and timestamp."""
        return cls(
            id=str(uuid.uuid4())[:8],
            role=role,
            content=content,
            timestamp=datetime.now().timestamp(),
            metadata=metadata,
        )


from dataclasses import dataclass


@dataclass
class ChatSession:
    """
    A chat session containing messages and metadata.
    
    Attributes:
        id: Unique session identifier
        title: Session title (auto-generated or user-set)
        created_at: Session creation time
        updated_at: Last update time
        messages: List of messages in the session
        metadata: Session-level metadata
    """
    id: str
    title: str
    created_at: float
    updated_at: float
    messages: List[ChatMessage] = None
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.messages is None:
            self.messages = []
        if self.metadata is None:
            self.metadata = {}
    
    @property
    def message_count(self) -> int:
        return len(self.messages)
    
    @property
    def last_message(self) -> Optional[ChatMessage]:
        return self.messages[-1] if self.messages else None
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "id": self.id,
            "title": self.title,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "messages": [m.to_dict() for m in self.messages],
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ChatSession':
        """Deserialize from dictionary."""
        return cls(
            id=data["id"],
            title=data.get("title", "Untitled"),
            created_at=data.get("created_at", datetime.now().timestamp()),
            updated_at=data.get("updated_at", datetime.now().timestamp()),
            messages=[ChatMessage.from_dict(m) for m in data.get("messages", [])],
            metadata=data.get("metadata", {}),
        )


class ChatHistory:
    """
    Manages chat history persistence and retrieval.
    
    Provides functionality for:
    - Creating and managing chat sessions
    - Storing/retrieving messages
    - Exporting conversations
    - Searching history
    
    Configuration:
        storage_path: Directory for storing history files
        max_sessions: Maximum number of sessions to keep
        max_messages_per_session: Max messages per session
        auto_save: Automatically save after each message
    """
    
    def __init__(
        self,
        storage_path: str = "",
        max_sessions: int = 100,
        max_messages_per_session: int = 500,
        auto_save: bool = True,
    ):
        """
        Initialize chat history manager.
        
        Args:
            storage_path: Directory for history files
            max_sessions: Maximum sessions to retain
            max_messages_per_session: Message limit per session
            auto_save: Save after every add operation
        """
        # Set up storage path
        if storage_path:
            self.storage_path = Path(storage_path)
        else:
            self.storage_path = Path("data/chats")
        
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self.max_sessions = max_sessions
        self.max_messages_per_session = max_messages_per_session
        self.auto_save = auto_save
        
        # Active sessions (loaded in memory)
        self._sessions: Dict[str, ChatSession] = {}
        self._current_session_id: Optional[str] = None
        
        # Load existing sessions
        self._load_sessions()
        
        logger.debug(f"ChatHistory initialized at {self.storage_path}")
    
    def _load_sessions(self):
        """Load session list from storage."""
        try:
            index_file = self.storage_path / "index.json"
            
            if index_file.exists():
                with open(index_file, 'r', encoding='utf-8') as f:
                    index_data = json.load(f)
                
                # Load session IDs only (full load on demand)
                for session_id in index_data.get("sessions", []):
                    if session_id not in self._sessions:
                        # Create placeholder - load full on access
                        pass
                        
        except Exception as e:
            logger.warning(f"Failed to load session index: {e}")
    
    def _save_index(self):
        """Save session index to disk."""
        try:
            index_data = {
                "sessions": list(self._sessions.keys()),
                "updated": datetime.now().isoformat(),
            }
            
            index_file = self.storage_path / "index.json"
            with open(index_file, 'w', encoding='utf-8') as f:
                json.dump(index_data, f, indent=2)
                
        except Exception as e:
            logger.error(f"Failed to save session index: {e}")
    
    def create_session(self, title: str = "") -> ChatSession:
        """
        Create a new chat session.
        
        Args:
            title: Optional session title
            
        Returns:
            New ChatSession object
        """
        session_id = datetime.now().strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:6]
        
        if not title:
            title = f"Chat {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        
        session = ChatSession(
            id=session_id,
            title=title,
            created_at=datetime.now().timestamp(),
            updated_at=datetime.now().timestamp(),
        )
        
        self._sessions[session_id] = session
        self._current_session_id = session_id
        
        if self.auto_save:
            self.save_session(session_id)
            self._save_index()
        
        logger.info(f"Created chat session: {session_id}")
        return session
    
    def get_session(self, session_id: str) -> Optional[ChatSession]:
        """
        Get a session by ID.
        
        Args:
            session_id: Session identifier
            
        Returns:
            ChatSession or None if not found
        """
        # Check memory first
        if session_id in self._sessions:
            return self._sessions[session_id]
        
        # Try loading from disk
        return self._load_session_from_disk(session_id)
    
    def _load_session_from_disk(self, session_id: str) -> Optional[ChatSession]:
        """Load a session from disk storage."""
        try:
            session_file = self.storage_path / f"{session_id}.json"
            
            if not session_file.exists():
                return None
            
            with open(session_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            session = ChatSession.from_dict(data)
            self._sessions[session_id] = session
            
            return session
            
        except Exception as e:
            logger.error(f"Failed to load session {session_id}: {e}")
            return None
    
    def get_current_session(self) -> Optional[ChatSession]:
        """Get the current active session."""
        if self._current_session_id:
            return self.get_session(self._current_session_id)
        return None
    
    def set_current_session(self, session_id: str):
        """Set the active session."""
        if session_id in self._sessions or self._session_exists_on_disk(session_id):
            self._current_session_id = session_id
        else:
            raise ValueError(f"Session not found: {session_id}")
    
    def add_message(
        self,
        role: str,
        content: str,
        session_id: Optional[str] = None,
        **metadata,
    ) -> ChatMessage:
        """
        Add a message to a session.
        
        Args:
            role: Message role
            content: Message content
            session_id: Target session (default: current)
            **metadata: Additional message metadata
            
        Returns:
            Created ChatMessage
        """
        sid = session_id or self._current_session_id
        
        if not sid:
            # Create new session if none exists
            session = self.create_session()
            sid = session.id
        
        session = self.get_session(sid)
        if not session:
            raise ValueError(f"Session not found: {sid}")
        
        # Check message limit
        if len(session.messages) >= self.max_messages_per_session:
            # Remove oldest messages
            session.messages = session.messages[-(self.max_messages_per_session - 1):]
        
        # Create and add message
        message = ChatMessage.create(role, content, **metadata)
        session.messages.append(message)
        session.updated_at = datetime.now().timestamp()
        
        # Auto-generate title from first user message
        if len([m for m in session.messages if m.role == "user"]) == 1 and role == "user":
            session.title = content[:50] + ("..." if len(content) > 50 else "")
        
        if self.auto_save:
            self.save_session(sid)
        
        return message
    
    def get_messages(
        self,
        session_id: Optional[str] = None,
        since: Optional[float] = None,
        limit: Optional[int] = None,
    ) -> List[ChatMessage]:
        """
        Get messages from a session.
        
        Args:
            session_id: Target session
            since: Only messages after this timestamp
            limit: Maximum messages to return
            
        Returns:
            List of ChatMessage objects
        """
        sid = session_id or self._current_session_id
        session = self.get_session(sid) if sid else None
        
        if not session:
            return []
        
        messages = session.messages
        
        if since:
            messages = [m for m in messages if m.timestamp >= since]
        
        if limit:
            messages = messages[-limit:]
        
        return messages
    
    def save_session(self, session_id: str):
        """Save a session to disk."""
        session = self._sessions.get(session_id)
        if not session:
            return
        
        try:
            session_file = self.storage_path / f"{session_id}.json"
            with open(session_file, 'w', encoding='utf-8') as f:
                json.dump(session.to_dict(), f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Failed to save session {session_id}: {e}")
    
    def delete_session(self, session_id: str) -> bool:
        """
        Delete a session.
        
        Args:
            session_id: ID of session to delete
            
        Returns:
            True if deleted successfully
        """
        # Remove from memory
        if session_id in self._sessions:
            del self._sessions[session_id]
        
        # Remove from disk
        try:
            session_file = self.storage_path / f"{session_id}.json"
            if session_file.exists():
                session_file.unlink()
            
            if self._current_session_id == session_id:
                self._current_session_id = None
            
            self._save_index()
            return True
            
        except Exception as e:
            logger.error(f"Failed to delete session {session_id}: {e}")
            return False
    
    def list_sessions(
        self,
        limit: int = 20,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        List available sessions.
        
        Args:
            limit: Maximum sessions to return
            offset: Number of sessions to skip
            
        Returns:
            List of session summary dicts
        """
        # Ensure all sessions are loaded
        self._scan_sessions()
        
        sessions = sorted(
            self._sessions.values(),
            key=lambda s: s.updated_at,
            reverse=True,
        )
        
        result = []
        for session in sessions[offset:offset + limit]:
            result.append({
                "id": session.id,
                "title": session.title,
                "message_count": session.message_count,
                "created_at": datetime.fromtimestamp(session.created_at).isoformat(),
                "updated_at": datetime.fromtimestamp(session.updated_at).isoformat(),
            })
        
        return result
    
    def _scan_sessions(self):
        """Scan storage directory for all session files."""
        try:
            for file_path in self.storage_path.glob("*.json"):
                if file_path.name == "index.json":
                    continue
                
                session_id = file_path.stem
                if session_id not in self._sessions:
                    self._load_session_from_disk(session_id)
                    
        except Exception as e:
            logger.warning(f"Error scanning sessions: {e}")
    
    def search_messages(
        self,
        query: str,
        session_id: Optional[str] = None,
        limit: int = 20,
    ) -> List[Dict[str, Any]]:
        """
        Search messages by content.
        
        Args:
            query: Search query string
            session_id: Limit to specific session
            limit: Maximum results
            
        Returns:
            List of matching message summaries
        """
        results = []
        query_lower = query.lower()
        
        sessions_to_search = (
            [self._sessions[session_id]] if session_id and session_id in self._sessions
            else self._sessions.values()
        )
        
        for session in sessions_to_search:
            for message in session.messages:
                if query_lower in message.content.lower():
                    results.append({
                        "session_id": session.id,
                        "session_title": session.title,
                        "message_id": message.id,
                        "role": message.role,
                        "content_preview": message.content[:150],
                        "timestamp": message.timestamp,
                    })
                    
                    if len(results) >= limit:
                        break
            
            if len(results) >= limit:
                break
        
        return results
    
    def export_session(
        self,
        session_id: str,
        format: str = "json",
        output_path: Optional[str] = None,
    ) -> str:
        """
        Export a session to file.
        
        Args:
            session_id: Session to export
            format: Export format ('json' or 'markdown')
            output_path: Output file path
            
        Returns:
            Path to exported file
        """
        session = self.get_session(session_id)
        if not session:
            raise ValueError(f"Session not found: {session_id}")
        
        if not output_path:
            ext = "md" if format == "markdown" else "json"
            output_path = f"export_{session_id}.{ext}"
        
        if format == "markdown":
            content = self._export_as_markdown(session)
        else:
            content = json.dumps(session.to_dict(), indent=2, ensure_ascii=False)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return output_path
    
    def _export_as_markdown(self, session: ChatSession) -> str:
        """Export session as markdown text."""
        lines = [
            f"# {session.title}",
            f"",
            f"*Exported: {datetime.now().isoformat()}*",
            f"",
            "---",
            "",
        ]
        
        for msg in session.messages:
            time_str = datetime.fromtimestamp(msg.timestamp).strftime("%H:%M:%S")
            
            role_emoji = {
                "user": "👤",
                "assistant": "🤖",
                "system": "⚙️",
                "tool": "🔧",
            }.get(msg.role, "💬")
            
            lines.append(f"### {role_emoji} {msg.role} ({time_str})")
            lines.append("")
            lines.append(msg.content)
            lines.append("")
            lines.append("---")
            lines.append("")
        
        return "\n".join(lines)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get history statistics."""
        self._scan_sessions()
        
        total_messages = sum(s.message_count for s in self._sessions.values())
        
        return {
            "total_sessions": len(self._sessions),
            "total_messages": total_messages,
            "storage_path": str(self.storage_path),
            "current_session": self._current_session_id,
        }
    
    def cleanup_old_sessions(self, keep_recent: int = 50):
        """Remove old sessions beyond the keep limit."""
        sessions = sorted(
            self._sessions.values(),
            key=lambda s: s.updated_at,
        )
        
        for session in sessions[:-keep_recent]:
            self.delete_session(session.id)
        
        logger.info(f"Cleaned up old sessions, kept {min(keep_recent, len(sessions))}")
    
    def _session_exists_on_disk(self, session_id: str) -> bool:
        """Check if session file exists on disk."""
        session_file = self.storage_path / f"{session_id}.json"
        return session_file.exists()
