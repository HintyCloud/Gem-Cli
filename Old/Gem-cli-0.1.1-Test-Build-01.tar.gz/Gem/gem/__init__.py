"""
Gem - Autonomous AI Coding Agent

A terminal-based AI agent with tool-calling capabilities for autonomous
task execution including shell commands, file operations, and web search.
"""

__version__ = "1.0.0"
__author__ = "Gem Team"

from gem.agent.loop import AgentLoop
from gem.cli import main

__all__ = ["AgentLoop", "main", "__version__"]
