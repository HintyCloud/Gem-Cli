"""
Agent Loop - Core Agentic Behavior

Implements the main ReAct (Reason + Act) loop that drives Gem's
autonomous behavior. The loop processes user messages, calls the LLM,
executes tools, and iterates until task completion.
"""

import asyncio
import json
import logging
import time
from typing import Any, Callable, Dict, List, Optional, Union

from gem.agent.context import ContextManager
from gem.agent.planner import ExecutionPlan, TaskPlanner
from gem.providers.opencode import OpenCodeProvider, ToolCall, ToolDefinition
from gem.tools.base import ToolRegistry, ToolResult

logger = logging.getLogger(__name__)


class AgentLoop:
    """
    Main agent execution loop implementing ReAct pattern.
    
    The loop follows this cycle:
    1. Receive user message
    2. Get LLM response (with tool call options)
    3. If tool calls: execute them and return results
    4. If no tool calls: return final response to user
    5. Repeat from step 2 if needed
    
    Features:
    - Streaming output support
    - Automatic planning for complex tasks
    - Context management with compression
    - Checkpoint save/restore
    - Iteration limits for safety
    - Callback hooks for UI integration
    
    Configuration:
        provider: LLM provider instance
        max_iterations: Maximum loop iterations per message
        auto_plan: Enable automatic task planning
        streaming: Enable streaming responses
    """
    
    def __init__(
        self,
        provider: OpenCodeProvider,
        max_iterations: int = 50,
        auto_plan: bool = True,
        streaming: bool = True,
        system_prompt: Optional[str] = None,
        on_tool_call: Optional[Callable] = None,
        on_response_chunk: Optional[Callable] = None,
        on_iteration_complete: Optional[Callable] = None,
    ):
        """
        Initialize agent loop.
        
        Args:
            provider: Configured LLM provider
            max_iterations: Safety limit on iterations
            auto_plan: Enable automatic planning for complex tasks
            streaming: Use streaming responses
            system_prompt: Custom system prompt
            on_tool_call: Callback when tool is called (tool_name, args) -> None
            on_response_chunk: Callback for streamed chunks (chunk: str) -> None
            on_iteration_complete: Callback after each iteration (iteration, result) -> None
        """
        self.provider = provider
        self.max_iterations = max_iterations
        self.auto_plan = auto_plan
        self.streaming = streaming
        self.system_prompt = system_prompt
        
        # Callbacks
        self.on_tool_call = on_tool_call or (lambda *a, **k: None)
        self.on_response_chunk = on_response_chunk or (lambda *a, **k: None)
        self.on_iteration_complete = on_iteration_complete or (lambda *a, **k: None)
        
        # Context manager
        self.context = ContextManager()
        
        # Task planner
        self.planner = TaskPlanner(provider=provider)
        
        # Current execution plan (if any)
        self.current_plan: Optional[ExecutionPlan] = None
        
        # Available tools (from registry)
        self._tools_loaded = False
        
        # State tracking
        self._running = False
        self._cancelled = False
        
        logger.info(f"AgentLoop initialized (max_iterations={max_iterations}, streaming={streaming})")
    
    def _ensure_tools_loaded(self):
        """Load tools from registry if not already done."""
        if not self._tools_loaded:
            # Tools are registered at import time via __init_subclass__
            self._tools_loaded = True
            logger.debug(f"Tools available: {ToolRegistry.get_names()}")
    
    def get_tool_schemas(self) -> List[Dict[str, Any]]:
        """Get all tool schemas for function calling."""
        self._ensure_tools_loaded()
        return ToolRegistry.get_schemas()
    
    async def process_message(
        self,
        message: str,
        plan: Optional[ExecutionPlan] = None,
    ) -> Dict[str, Any]:
        """
        Process a user message through the agent loop.
        
        This is the main entry point for handling user input.
        
        Args:
            message: User's message/request
            plan: Optional pre-created execution plan
            
        Returns:
            Result dictionary with:
            - response: Final text response
            - tool_calls: List of tool executions performed
            - iterations: Number of loop iterations
            - plan_used: Whether a plan was used
        """
        self._running = True
        self._cancelled = False
        
        result = {
            "response": "",
            "tool_calls": [],
            "iterations": 0,
            "plan_used": False,
            "tokens_used": {},
        }
        
        try:
            # Add user message to context
            self.context.add_message("user", message)
            
            # Check if we should create a plan
            if plan:
                self.current_plan = plan
                result["plan_used"] = True
            elif self.auto_plan:
                should_plan, complexity = await self.planner.should_plan(message)
                if should_plan:
                    logger.info(f"Request complexity ({complexity:.2f}) exceeds threshold, creating plan")
                    plan = await self.planner.create_plan(message)
                    if plan:
                        self.current_plan = plan
                        result["plan_used"] = True
            
            # Display plan if created
            if self.current_plan:
                logger.info(f"Plan: {self.current_plan.to_display_string()}")
            
            # Run the main loop
            final_response = await self._run_loop(result)
            
            result["response"] = final_response
            
            # Save checkpoint after completion
            if self.context.should_checkpoint():
                await self.context.save_checkpoint(reason="message-complete")
            
        except Exception as e:
            logger.exception(f"Error processing message: {e}")
            result["response"] = f"I encountered an error: {type(e).__name__}: {e}"
            result["error"] = str(e)
        
        finally:
            self._running = False
        
        return result
    
    async def _run_loop(self, result: Dict[str, Any]) -> str:
        """
        Execute the main ReAct loop.
        
        Args:
            result: Result dictionary to update with progress
            
        Returns:
            Final text response
        """
        iteration = 0
        full_response = ""
        
        while iteration < self.max_iterations and not self._cancelled:
            iteration += 1
            self.context.increment_iteration()
            result["iterations"] = iteration
            
            logger.debug(f"Agent loop iteration {iteration}/{self.max_iterations}")
            
            try:
                if self.streaming:
                    response = await self._streaming_iteration(iteration, result, full_response)
                else:
                    response = await self._non_streaming_iteration(iteration, result)
                
                # Handle response
                if isinstance(response, str):
                    # Final text response
                    full_response = response
                    
                    # Add assistant message to context
                    self.context.add_message("assistant", full_response)
                    
                    # Mark complete
                    if self.current_plan:
                        step = self.current_plan.current_step
                        if step:
                            self.current_plan.mark_step_status(step.id, "completed")
                    
                    break
                
                elif response.get("tool_calls"):
                    # Has tool calls - execute them
                    tool_results = await self._execute_tool_calls(
                        response["tool_calls"],
                        result["tool_calls"],
                    )
                    
                    # Add results to context and continue loop
                    for tool_result in tool_results:
                        self.provider.add_tool_result(
                            tool_result["call_id"],
                            tool_result["result"].to_string(),
                            tool_result["name"],
                        )
                
                else:
                    # Response without tool calls but not final?
                    content = response.get("content", "")
                    if content:
                        full_response = content
                        self.context.add_message("assistant", content)
                        break
                
                # Check if we should compress context
                if self.context.should_compress():
                    summary = await self._generate_context_summary()
                    await self.context.compress_context(summary)
                
                # Auto-checkpoint
                if self.context.should_checkpoint():
                    await self.context.save_checkpoint()
                
                # Call iteration callback
                self.on_iteration_complete(iteration, result)
                
            except Exception as e:
                logger.exception(f"Error in iteration {iteration}: {e}")
                full_response = f"Error during execution: {type(e).__name__}: {e}"
                break
        
        else:
            # Hit max iterations
            if iteration >= self.max_iterations:
                logger.warning(f"Reached maximum iterations ({self.max_iterations})")
                full_response += "\n\n[Note: Reached maximum iterations. You can continue by sending another message.]"
        
        return full_response or "I've completed the requested operations."
    
    async def _non_streaming_iteration(
        self,
        iteration: int,
        result: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Execute a non-streaming iteration.
        
        Args:
            iteration: Current iteration number
            result: Result dictionary
            
        Returns:
            Response dict with content and/or tool_calls
        """
        # Get messages for API
        messages = self.context.get_messages_for_api()
        
        # Add system prompt
        if self.system_prompt:
            messages.insert(0, {"role": "system", "content": self.system_prompt})
        
        # Get tool schemas
        tool_definitions = self._get_tool_definitions_for_api()
        
        # Call LLM
        response = await self.provider.chat(
            message="",  # Messages already include history
            system_prompt=self.system_prompt if self.system_prompt else None,
            tools=tool_definitions if tool_definitions else None,
        )
        
        # Build result dict
        result_dict: Dict[str, Any] = {
            "content": response.content,
        }
        
        if response.has_tool_calls:
            result_dict["tool_calls"] = [
                {
                    "id": tc.id,
                    "name": tc.name,
                    "arguments": json.loads(tc.arguments),
                }
                for tc in response.tool_calls
            ]
        
        # Update token usage
        if response.usage:
            result["tokens_used"] = response.usage
        
        return result_dict
    
    async def _streaming_iteration(
        self,
        iteration: int,
        result: Dict[str, Any],
        current_response: str,
    ) -> Union[str, Dict[str, Any]]:
        """
        Execute a streaming iteration.
        
        Args:
            iteration: Current iteration number
            result: Result dictionary
            current_response: Accumulated response so far
            
        Returns:
            Either final string or dict with tool_calls
        """
        # Get messages for API
        messages = self.context.get_messages_for_api()
        
        # Get tool schemas
        tool_definitions = self._get_tool_definitions_for_api()
        
        # Collect streamed content and tool calls
        collected_content = ""
        collected_tool_calls: Dict[int, Dict] = {}
        
        try:
            stream = self.provider.chat_stream(
                message="",
                system_prompt=self.system_prompt,
                tools=tool_definitions if tool_definitions else None,
            )
            
            async for chunk in stream:
                if self._cancelled:
                    break
                
                if isinstance(chunk, str):
                    # Content chunk
                    collected_content += chunk
                    self.on_response_chunk(chunk)
                elif isinstance(chunk, ToolCall):
                    # Tool call complete
                    idx = len(collected_tool_calls)
                    collected_tool_calls[idx] = {
                        "id": chunk.id,
                        "name": chunk.name,
                        "arguments": json.loads(chunk.arguments),
                    }
            
        except Exception as e:
            logger.error(f"Streaming error: {e}")
            # Fall back to non-streaming
            return await self._non_streaming_iteration(iteration, result)
        
        # Determine return type
        if collected_tool_calls:
            return {
                "content": collected_content,
                "tool_calls": list(collected_tool_calls.values()),
            }
        elif collected_content:
            return collected_content
        else:
            return {"content": ""}
    
    async def _execute_tool_calls(
        self,
        tool_calls: List[Dict[str, Any]],
        execution_log: List[Dict],
    ) -> List[Dict[str, Any]]:
        """
        Execute a list of tool calls.
        
        Args:
            tool_calls: List of tool call dicts with id, name, arguments
            execution_log: Log to append execution records to
            
        Returns:
            List of result dicts with call_id, name, result
        """
        results = []
        
        for tool_call in tool_calls:
            call_id = tool_call["id"]
            tool_name = tool_call["name"]
            tool_args = tool_call.get("arguments", {})
            
            logger.info(f"Executing tool: {tool_name}({json.dumps(tool_args)[:100]})")
            
            # Notify callback
            self.on_tool_call(tool_name, tool_args)
            
            # Get tool from registry
            tool_instance = ToolRegistry.get(tool_name)
            
            if not tool_instance:
                logger.warning(f"Unknown tool: {tool_name}")
                result = ToolResult.from_error(f"Unknown tool: {tool_name}")
            else:
                # Execute tool
                try:
                    result = await tool_instance.safe_execute(**tool_args)
                except Exception as e:
                    logger.exception(f"Tool execution error: {e}")
                    result = ToolResult.from_error(f"Tool error: {type(e).__name__}: {e}")
            
            # Record execution
            execution_log.append({
                "tool": tool_name,
                "args": tool_args,
                "success": result.success,
                "output_preview": result.output[:200] if result.output else "",
            })
            
            results.append({
                "call_id": call_id,
                "name": tool_name,
                "result": result,
            })
        
        return results
    
    def _get_tool_definitions_for_api(self) -> List[Any]:
        """Get tool definitions in API format."""
        self._ensure_tools_loaded()
        
        schemas = ToolRegistry.get_schemas()
        
        # Convert to ToolDefinition objects
        definitions = []
        for schema in schemas:
            td = ToolDefinition(
                type=schema.get("type", "function"),
                function=schema.get("function", {}),
            )
            definitions.append(td)
        
        return definitions
    
    async def _generate_context_summary(self) -> str:
        """
        Generate a summary of the current conversation for compression.
        
        Uses the LLM to summarize the conversation so far.
        
        Returns:
            Summary string
        """
        try:
            messages = self.context.messages[-20:]  # Last 20 messages
            
            summary_prompt = (
                "Summarize the following conversation concisely, "
                "focusing on key actions taken, decisions made, "
                "and current state:\n\n"
            )
            
            for msg in messages:
                role = msg.get("role", "unknown")
                content = msg.get("content", "")[:200]
                summary_prompt += f"{role}: {content}\n"
            
            summary_prompt += "\nProvide a brief summary:"
            
            # Call LLM for summary
            response = await self.provider.chat(
                message=summary_prompt,
                temperature=0.3,
                max_tokens=500,
            )
            
            return response.content
            
        except Exception as e:
            logger.warning(f"Failed to generate summary: {e}")
            return f"Conversation of {len(self.context.messages)} messages"
    
    def cancel(self):
        """Cancel the current running operation."""
        self._cancelled = True
        logger.info("Agent loop cancellation requested")
    
    @property
    def is_running(self) -> bool:
        """Check if agent is currently running."""
        return self._running
    
    def get_status(self) -> Dict[str, Any]:
        """
        Get current agent status.
        
        Returns:
            Status dictionary
        """
        context_stats = self.context.get_stats()
        
        status = {
            "running": self._running,
            "cancelled": self._cancelled,
            "context": context_stats,
            "has_plan": self.current_plan is not None,
        }
        
        if self.current_plan:
            status["plan"] = {
                "goal": self.current_plan.goal,
                "total_steps": self.current_plan.total_steps,
                "completed_steps": self.current_plan.completed_steps,
                "is_complete": self.current_plan.is_complete,
            }
        
        return status
    
    def reset(self):
        """Reset agent state for new conversation."""
        self.context.reset()
        self.current_plan = None
        self._cancelled = False
        self.provider.clear_history()
        logger.info("Agent loop reset")
    
    async def restore_from_checkpoint(self, checkpoint_id: str) -> bool:
        """
        Restore agent state from a checkpoint.
        
        Args:
            checkpoint_id: ID of checkpoint to restore
            
        Returns:
            True if successful
        """
        success = await self.context.restore_checkpoint(checkpoint_id)
        if success:
            # Restore message history to provider
            self.provider.clear_history()
            for msg in self.context.messages:
                self.provider.add_message(**msg)
        
        return success
