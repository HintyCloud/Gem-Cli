"""
Context and Checkpoint Management

Manages conversation context, including message history compression,
checkpoint save/restore for long conversations, and token estimation.
Enables the agent to handle extended tasks without losing context.
"""

import json
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class Checkpoint:
    """
    A saved state of the agent's context.
    
    Attributes:
        id: Unique checkpoint identifier
        timestamp: When the checkpoint was created
        iteration: Agent loop iteration number
        messages: Saved message history
        summary: Optional summary of conversation up to this point
        metadata: Additional metadata (task info, etc.)
    """
    id: str
    timestamp: float
    iteration: int
    messages: List[Dict[str, Any]]
    summary: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "iteration": self.iteration,
            "messages": self.messages,
            "summary": self.summary,
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Checkpoint':
        """Deserialize from dictionary."""
        return cls(
            id=data["id"],
            timestamp=data["timestamp"],
            iteration=data["iteration"],
            messages=data.get("messages", []),
            summary=data.get("summary", ""),
            metadata=data.get("metadata", {}),
        )


# Rough token estimates (approximate)
TOKEN_ESTIMATES = {
    "char_per_token": 4,  # Average characters per token
    "tokens_per_message_overhead": 4,  # Role, formatting etc.
}


class ContextManager:
    """
    Manages agent context including history and checkpoints.
    
    Provides functionality for:
    - Tracking conversation messages with token estimates
    - Saving/restoring checkpoints for long conversations
    - Compressing old context when approaching limits
    - Managing context window size
    
    Configuration:
        max_context_tokens: Maximum tokens in context (default: 8000)
        checkpoint_dir: Directory for storing checkpoints
        auto_checkpoint_interval: Save every N iterations
        compression_threshold: Compress when above this % of max
    """
    
    def __init__(
        self,
        max_context_tokens: int = 8000,
        checkpoint_dir: str = "",
        auto_checkpoint_interval: int = 5,
        compression_threshold: float = 0.8,
    ):
        """
        Initialize context manager.
        
        Args:
            max_context_tokens: Maximum context window size
            checkpoint_dir: Directory for checkpoints
            auto_checkpoint_interval: Save every N iterations
            compression_threshold: Trigger compression at this usage ratio
        """
        self.max_context_tokens = max_context_tokens
        
        # Set up checkpoint directory
        if checkpoint_dir:
            self.checkpoint_dir = Path(checkpoint_dir)
        else:
            self.checkpoint_dir = Path("data/checkpoints")
        
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        self.auto_checkpoint_interval = auto_checkpoint_interval
        self.compression_threshold = compression_threshold
        
        # Current state
        self.messages: List[Dict[str, Any]] = []
        self.iteration_count = 0
        self.last_checkpoint_iteration = 0
        self.checkpoints: Dict[str, Checkpoint] = {}
        
        # Summary of compressed context
        self.compressed_summary = ""
        
        logger.debug(f"ContextManager initialized (max_tokens={max_context_tokens})")
    
    def add_message(
        self,
        role: str,
        content: str,
        tool_calls: Optional[List[Dict]] = None,
        tool_call_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Add a message to context.
        
        Args:
            role: Message role (user, assistant, system, tool)
            content: Message content
            tool_calls: Tool calls from assistant
            tool_call_id: For tool result messages
            
        Returns:
            The added message dict
        """
        message: Dict[str, Any] = {
            "role": role,
            "content": content,
            "timestamp": time.time(),
        }
        
        if tool_calls:
            message["tool_calls"] = tool_calls
        if tool_call_id:
            message["tool_call_id"] = tool_call_id
        
        self.messages.append(message)
        return message
    
    def get_messages_for_api(self) -> List[Dict[str, Any]]:
        """
        Get messages formatted for API submission.
        
        Removes internal metadata fields that shouldn't be sent to LLM.
        
        Returns:
            List of API-compatible message dicts
        """
        api_messages = []
        
        # Add compressed summary as system message if exists
        if self.compressed_summary:
            api_messages.append({
                "role": "system",
                "content": f"[Previous conversation summary]\n{self.compressed_summary}",
            })
        
        for msg in self.messages:
            api_msg = {
                "role": msg["role"],
                "content": msg["content"],
            }
            
            if "tool_calls" in msg:
                api_msg["tool_calls"] = msg["tool_calls"]
            if "tool_call_id" in msg:
                api_msg["tool_call_id"] = msg["tool_call_id"]
            
            api_messages.append(api_msg)
        
        return api_messages
    
    def estimate_tokens(self) -> int:
        """
        Estimate total tokens in current context.
        
        Uses rough character-based estimation. Not perfectly accurate
        but sufficient for threshold management.
        
        Returns:
            Estimated token count
        """
        total_chars = 0
        
        if self.compressed_summary:
            total_chars += len(self.compressed_summary) + 50  # Overhead for wrapper
        
        for msg in self.messages:
            content_len = len(msg.get("content", ""))
            total_chars += content_len + TOKEN_ESTIMATES["tokens_per_message_overhead"]
            
            # Account for tool calls
            if "tool_calls" in msg:
                for tc in msg["tool_calls"]:
                    total_chars += len(json.dumps(tc))
        
        return total_chars // TOKEN_ESTIMATES["char_per_token"]
    
    def get_context_usage(self) -> float:
        """
        Get context window usage as a ratio.
        
        Returns:
            Usage ratio (0.0 to 1.0+ where >1.0 means over limit)
        """
        return self.estimate_tokens() / self.max_context_tokens
    
    def should_compress(self) -> bool:
        """Check if context should be compressed."""
        return self.get_context_usage() > self.compression_threshold
    
    def should_checkpoint(self) -> bool:
        """Check if a checkpoint should be saved."""
        iterations_since_last = self.iteration_count - self.last_checkpoint_iteration
        return iterations_since_last >= self.auto_checkpoint_interval
    
    async def compress_context(self, summary: str):
        """
        Compress current context into a summary.
        
        Replaces message list with just the summary, freeing up
        context space for new interactions.
        
        Args:
            summary: Generated summary of conversation so far
        """
        # Save checkpoint before compressing
        await self.save_checkpoint(reason="pre-compression")
        
        # Update compressed summary
        if self.compressed_summary:
            self.compressed_summary += f"\n\n[Later]\n{summary}"
        else:
            self.compressed_summary = summary
        
        # Clear messages (keep only very recent ones if needed)
        self.messages.clear()
        
        logger.info(f"Context compressed (new estimate: {self.estimate_tokens()} tokens)")
    
    async def save_checkpoint(
        self,
        reason: str = "auto",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Checkpoint:
        """
        Save current state as a checkpoint.
        
        Args:
            reason: Reason for saving
            metadata: Additional metadata
            
        Returns:
            Created checkpoint object
        """
        checkpoint_id = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{self.iteration_count}"
        
        checkpoint = Checkpoint(
            id=checkpoint_id,
            timestamp=time.time(),
            iteration=self.iteration_count,
            messages=[dict(m) for m in self.messages],  # Deep copy
            summary=self.compressed_summary,
            metadata={
                **(metadata or {}),
                "reason": reason,
                "message_count": len(self.messages),
                "estimated_tokens": self.estimate_tokens(),
            },
        )
        
        # Store in memory
        self.checkpoints[checkpoint_id] = checkpoint
        self.last_checkpoint_iteration = self.iteration_count
        
        # Save to disk
        try:
            checkpoint_file = self.checkpoint_dir / f"{checkpoint_id}.json"
            with open(checkpoint_file, 'w', encoding='utf-8') as f:
                json.dump(checkpoint.to_dict(), f, indent=2, ensure_ascii=False)
            
            logger.debug(f"Saved checkpoint {checkpoint_id} ({reason})")
        except Exception as e:
            logger.error(f"Failed to save checkpoint: {e}")
        
        return checkpoint
    
    async def restore_checkpoint(self, checkpoint_id: str) -> bool:
        """
        Restore context from a checkpoint.
        
        Args:
            checkpoint_id: ID of checkpoint to restore
            
        Returns:
            True if restoration successful
        """
        # Try memory first
        if checkpoint_id in self.checkpoints:
            checkpoint = self.checkpoints[checkpoint_id]
        else:
            # Try loading from disk
            try:
                checkpoint_file = self.checkpoint_dir / f"{checkpoint_id}.json"
                with open(checkpoint_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                checkpoint = Checkpoint.from_dict(data)
            except Exception as e:
                logger.error(f"Failed to load checkpoint {checkpoint_id}: {e}")
                return False
        
        # Restore state
        self.messages = [dict(m) for m in checkpoint.messages]
        self.compressed_summary = checkpoint.summary
        self.iteration_count = checkpoint.iteration
        
        logger.info(f"Restored checkpoint {checkpoint_id}")
        return True
    
    def list_checkpoints(self) -> List[Dict[str, Any]]:
        """
        List all available checkpoints.
        
        Returns:
            List of checkpoint summaries
        """
        # Load from disk if needed
        self._load_checkpoints_from_disk()
        
        return [
            {
                "id": cp.id,
                "iteration": cp.iteration,
                "timestamp": datetime.fromtimestamp(cp.timestamp).isoformat(),
                "message_count": len(cp.messages),
                "reason": cp.metadata.get("reason", "unknown"),
            }
            for cp in sorted(self.checkpoints.values(), key=lambda c: c.timestamp, reverse=True)
        ]
    
    def _load_checkpoints_from_disk(self):
        """Load checkpoint files from disk."""
        try:
            for file_path in self.checkpoint_dir.glob("*.json"):
                checkpoint_id = file_path.stem
                
                if checkpoint_id not in self.checkpoints:
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            data = json.load(f)
                        self.checkpoints[checkpoint_id] = Checkpoint.from_dict(data)
                    except Exception as e:
                        logger.warning(f"Failed to load checkpoint file {file_path}: {e}")
        except Exception as e:
            logger.warning(f"Error scanning checkpoint directory: {e}")
    
    def delete_checkpoint(self, checkpoint_id: str) -> bool:
        """
        Delete a checkpoint.
        
        Args:
            checkpoint_id: ID to delete
            
        Returns:
            True if deleted successfully
        """
        # Remove from memory
        if checkpoint_id in self.checkpoints:
            del self.checkpoints[checkpoint_id]
        
        # Remove from disk
        try:
            checkpoint_file = self.checkpoint_dir / f"{checkpoint_id}.json"
            if checkpoint_file.exists():
                checkpoint_file.unlink()
                return True
        except Exception as e:
            logger.error(f"Failed to delete checkpoint file: {e}")
        
        return False
    
    def clear_old_checkpoints(self, keep_recent: int = 5):
        """
        Remove old checkpoints, keeping only recent ones.
        
        Args:
            keep_recent: Number of recent checkpoints to keep
        """
        self._load_checkpoints_from_disk()
        
        sorted_checkpoints = sorted(
            self.checkpoints.values(),
            key=lambda c: c.timestamp,
            reverse=True,
        )
        
        # Delete older checkpoints
        for checkpoint in sorted_checkpoints[keep_recent:]:
            self.delete_checkpoint(checkpoint.id)
        
        logger.debug(f"Cleared old checkpoints, kept {min(keep_recent, len(sorted_checkpoints))}")
    
    def increment_iteration(self):
        """Increment the iteration counter."""
        self.iteration_count += 1
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get context statistics.
        
        Returns:
            Dictionary with context stats
        """
        return {
            "total_messages": len(self.messages),
            "estimated_tokens": self.estimate_tokens(),
            "max_tokens": self.max_context_tokens,
            "usage_ratio": round(self.get_context_usage(), 3),
            "iteration": self.iteration_count,
            "has_compressed_context": bool(self.compressed_summary),
            "compressed_length": len(self.compressed_summary),
            "checkpoint_count": len(self.checkpoints),
            "last_checkpoint": self.last_checkpoint_iteration,
        }
    
    def reset(self):
        """Reset context manager to initial state."""
        self.messages.clear()
        self.iteration_count = 0
        self.last_checkpoint_iteration = 0
        self.compressed_summary = ""
        # Keep checkpoints but could optionally clear them too
