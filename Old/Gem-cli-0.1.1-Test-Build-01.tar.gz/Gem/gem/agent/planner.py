"""
Task Planner

Decomposes complex user requests into structured step-by-step plans.
Uses the LLM to analyze requests and generate execution plans that
the agent loop can follow.
"""

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class PlanStep:
    """
    A single step in an execution plan.
    
    Attributes:
        id: Step identifier (1-indexed)
        description: What this step should accomplish
        tools: Tools likely needed for this step
        dependencies: IDs of steps that must complete first
        expected_output: What we expect from this step
        status: Current status of the step
    """
    id: int
    description: str
    tools: List[str] = field(default_factory=list)
    dependencies: List[int] = field(default_factory=list)
    expected_output: str = ""
    status: str = "pending"  # pending, in_progress, completed, failed, skipped
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "id": self.id,
            "description": self.description,
            "tools": self.tools,
            "dependencies": self.dependencies,
            "expected_output": self.expected_output,
            "status": self.status,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'PlanStep':
        """Create from dictionary."""
        return cls(
            id=data["id"],
            description=data["description"],
            tools=data.get("tools", []),
            dependencies=data.get("dependencies", []),
            expected_output=data.get("expected_output", ""),
            status=data.get("status", "pending"),
        )


@dataclass
class ExecutionPlan:
    """
    A complete execution plan for a task.
    
    Attributes:
        goal: Overall goal of the plan
        steps: Ordered list of steps
        estimated_complexity: How complex the plan is (0-1)
        requires_confirmation: Whether user should confirm before execution
        metadata: Additional plan information
    """
    goal: str
    steps: List[PlanStep] = field(default_factory=list)
    estimated_complexity: float = 0.5
    requires_confirmation: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def total_steps(self) -> int:
        return len(self.steps)
    
    @property
    def completed_steps(self) -> int:
        return sum(1 for s in self.steps if s.status == "completed")
    
    @property
    def is_complete(self) -> bool:
        return all(s.status in ("completed", "skipped") for s in self.steps)
    
    @property
    def current_step(self) -> Optional[PlanStep]:
        """Get the next pending or in-progress step."""
        for step in self.steps:
            if step.status == "pending":
                return step
            if step.status == "in_progress":
                return step
        return None
    
    def get_next_step(self) -> Optional[PlanStep]:
        """
        Get the next executable step (dependencies satisfied).
        
        Returns:
            Next step or None if no more steps available
        """
        completed_ids = {s.id for s in self.steps if s.status in ("completed", "skipped")}
        
        for step in self.steps:
            if step.status != "pending":
                continue
            
            # Check dependencies
            if all(dep in completed_ids for dep in step.dependencies):
                return step
        
        return None
    
    def mark_step_status(self, step_id: int, status: str):
        """
        Update the status of a step.
        
        Args:
            step_id: Step ID to update
            status: New status value
        """
        for step in self.steps:
            if step.id == step_id:
                step.status = status
                break
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize plan to dictionary."""
        return {
            "goal": self.goal,
            "steps": [s.to_dict() for s in self.steps],
            "estimated_complexity": self.estimated_complexity,
            "requires_confirmation": self.requires_confirmation,
            "metadata": self.metadata,
        }
    
    def to_display_string(self) -> str:
        """Format plan for display to user."""
        lines = [
            f"📋 Execution Plan: {self.goal}",
            f"   Complexity: {self.estimated_complexity:.0%} | Steps: {self.total_steps}",
            "",
        ]
        
        for step in self.steps:
            status_icon = {
                "pending": "⏳",
                "in_progress": "🔄",
                "completed": "✅",
                "failed": "❌",
                "skipped": "⏭️",
            }.get(step.status, "❓")
            
            lines.append(f"  {status_icon} Step {step.id}: {step.description}")
            
            if step.tools:
                lines.append(f"     Tools: {', '.join(step.tools)}")
        
        return "\n".join(lines)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ExecutionPlan':
        """Deserialize plan from dictionary."""
        return cls(
            goal=data["goal"],
            steps=[PlanStep.from_dict(s) for s in data.get("steps", [])],
            estimated_complexity=data.get("estimated_complexity", 0.5),
            requires_confirmation=data.get("requires_confirmation", False),
            metadata=data.get("metadata", {}),
        )


class TaskPlanner:
    """
    Plans complex tasks by decomposing them into steps.
    
    Uses LLM analysis to understand user intent and generate
    structured execution plans. Handles dependency ordering
    and complexity estimation.
    
    Configuration:
        complexity_threshold: Minimum score to trigger planning
        max_steps: Maximum number of plan steps
        auto_confirm: Auto-confirm plans below threshold
    """
    
    def __init__(
        self,
        provider=None,  # Will be set by agent loop
        complexity_threshold: float = 0.3,
        max_steps: int = 20,
        auto_confirm_below: float = 0.3,
    ):
        """
        Initialize task planner.
        
        Args:
            provider: LLM provider instance (set later if needed)
            complexity_threshold: Score above which planning triggers
            max_steps: Maximum steps in generated plan
            auto_confirm_below: Auto-confirm plans with lower complexity
        """
        self.provider = provider
        self.complexity_threshold = complexity_threshold
        self.max_steps = max_steps
        self.auto_confirm_below = auto_confirm_below
        
        # Planning prompt template
        self.planning_prompt = """You are a task planner. Analyze the user's request and create a step-by-step execution plan.

Respond ONLY with a JSON object in this exact format:
{
  "goal": "Brief summary of what needs to be accomplished",
  "complexity": 0.0-1.0,
  "requiresConfirmation": true/false,
  "steps": [
    {
      "id": 1,
      "description": "What this step accomplishes",
      "tools": ["tool1", "tool2"],
      "dependencies": [],
      "expectedOutput": "Expected result"
    }
  ]
}

Guidelines:
- Break down complex tasks into clear, actionable steps
- Order steps logically (setup before action)
- Identify which tools are needed for each step
- Note dependencies between steps
- Keep descriptions concise but complete
- Set requiresConfirmation true for destructive operations
- Estimate complexity based on number of steps and risk"""
    
    async def analyze_complexity(self, request: str) -> float:
        """
        Estimate the complexity of a request.
        
        Simple heuristic-based estimation that doesn't require LLM call.
        For more accurate estimation, use create_plan() instead.
        
        Args:
            request: User's request string
            
        Returns:
            Complexity score between 0.0 and 1.0
        """
        # Heuristic indicators of complexity
        complexity_indicators = {
            # Multi-step indicators
            "and then": 0.2,
            "after that": 0.2,
            "also": 0.1,
            "finally": 0.15,
            "first": 0.15,
            "then": 0.1,
            
            # Complex operations
            "create": 0.2,
            "build": 0.25,
            "implement": 0.3,
            "refactor": 0.3,
            "migrate": 0.35,
            "deploy": 0.25,
            
            # Multi-file/project
            "project": 0.2,
            "application": 0.2,
            "system": 0.25,
            "api": 0.2,
            "database": 0.25,
            
            # Testing/quality
            "test": 0.15,
            "fix bug": 0.2,
            "debug": 0.2,
        }
        
        request_lower = request.lower()
        base_score = 0.1  # Minimum complexity
        
        for indicator, score in complexity_indicators.items():
            if indicator in request_lower:
                base_score += score
        
        # Check for multiple sentences/questions
        sentence_count = request.count('.') + request.count('?') + request.count('!')
        base_score += min(sentence_count * 0.05, 0.2)
        
        # Cap at 1.0
        return min(base_score, 1.0)
    
    async def create_plan(self, request: str) -> Optional[ExecutionPlan]:
        """
        Create an execution plan for a request.
        
        Uses the LLM to analyze and decompose the request into steps.
        
        Args:
            request: User's request
            
        Returns:
            ExecutionPlan or None if planning fails
        """
        if not self.provider:
            logger.warning("No provider available for planning")
            return None
        
        logger.info(f"Creating plan for request: {request[:50]}...")
        
        try:
            # Build planning prompt
            messages = [
                {"role": "system", "content": self.planning_prompt},
                {"role": "user", "content": f"Create an execution plan for:\n\n{request}"},
            ]
            
            # Call LLM
            response = await self.provider.client.post(
                f"{self.provider.api_url}/chat/completions",
                json={
                    "model": self.provider.model,
                    "messages": messages,
                    "temperature": 0.3,  # Lower temperature for structured output
                    "max_tokens": 2000,
                },
            )
            response.raise_for_status()
            
            content = response.json()["choices"][0]["message"]["content"]
            
            # Parse JSON response
            plan_data = self._parse_plan_response(content)
            
            if not plan_data:
                logger.error("Failed to parse plan from LLM response")
                return None
            
            # Build ExecutionPlan object
            plan = ExecutionPlan(
                goal=plan_data.get("goal", request),
                estimated_complexity=plan_data.get("complexity", 0.5),
                requires_confirmation=plan_data.get("requiresConfirmation", False),
                metadata={"original_request": request},
            )
            
            # Add steps
            for step_data in plan_data.get("steps", [])[:self.max_steps]:
                step = PlanStep(
                    id=step_data.get("id", len(plan.steps) + 1),
                    description=step_data.get("description", ""),
                    tools=step_data.get("tools", []),
                    dependencies=step_data.get("dependencies", []),
                    expected_output=step_data.get("expectedOutput", ""),
                )
                plan.steps.append(step)
            
            logger.info(f"Created plan with {len(plan.steps)} steps")
            return plan
            
        except Exception as e:
            logger.exception(f"Failed to create plan: {e}")
            return None
    
    def _parse_plan_response(self, content: str) -> Optional[Dict[str, Any]]:
        """
        Parse plan JSON from LLM response.
        
        Handles various formatting issues that might occur.
        
        Args:
            content: Raw LLM response content
            
        Returns:
            Parsed dictionary or None
        """
        # Try direct JSON parse first
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            pass
        
        # Try to extract JSON from markdown code blocks
        import re
        
        # Look for ```json ... ``` blocks
        json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', content, re.DOTALL)
        if json_match:
            try:
                return json.loads(json_match.group(1))
            except json.JSONDecodeError:
                pass
        
        # Try to find any JSON-like structure
        brace_start = content.find('{')
        brace_end = content.rfind('}')
        
        if brace_start >= 0 and brace_end > brace_start:
            json_str = content[brace_start:brace_end + 1]
            try:
                return json.loads(json_str)
            except json.JSONDecodeError:
                pass
        
        logger.warning(f"Could not parse plan JSON from: {content[:200]}...")
        return None
    
    async def should_plan(self, request: str) -> tuple[bool, float]:
        """
        Determine if a request needs planning.
        
        Args:
            request: User's request
            
        Returns:
            Tuple of (should_plan, complexity_score)
        """
        complexity = await self.analyze_complexity(request)
        return complexity > self.complexity_threshold, complexity
    
    def create_simple_plan(self, request: str) -> ExecutionPlan:
        """
        Create a simple single-step plan for straightforward requests.
        
        Args:
            request: User request
            
        Returns:
            Simple execution plan
        """
        return ExecutionPlan(
            goal=request,
            estimated_complexity=0.2,
            requires_confirmation=False,
            steps=[
                PlanStep(
                    id=1,
                    description=f"Complete the following request: {request}",
                    tools=["shell", "file", "web_search"],
                    dependencies=[],
                    expected_output="Request fulfilled",
                )
            ],
        )


def sentence_count(text: str) -> int:
    """Count sentences in text (simple heuristic)."""
    import re
    # Split on sentence endings followed by space or end
    sentences = re.split(r'[.!?]+(?:\s|$)', text)
    return len([s for s in sentences if s.strip()])
