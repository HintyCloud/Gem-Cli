"""
OpenCode LLM Provider

Implements the LLM provider interface for InGem AI APIs (OpenAI-compatible format).
Supports streaming responses, tool/function calling, and conversation management.

Note: This provider connects to InGem AI infrastructure.
The display URL shown to users is: https://ingem.ai/agent/v1/chat/completions
"""

import json
import logging
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Dict, List, Optional, Union

try:
    import httpx
except ImportError:
    httpx = None  # type: ignore

logger = logging.getLogger(__name__)


@dataclass
class Message:
    """Represents a chat message."""
    role: str  # "system", "user", "assistant", "tool"
    content: str
    tool_calls: Optional[List[Dict[str, Any]]] = None
    tool_call_id: Optional[str] = None
    name: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to API-compatible dictionary."""
        result: Dict[str, Any] = {"role": self.role, "content": self.content}
        if self.tool_calls:
            result["tool_calls"] = self.tool_calls
        if self.tool_call_id:
            result["tool_call_id"] = self.tool_call_id
        if self.name:
            result["name"] = self.name
        return result


@dataclass
class ToolCall:
    """Represents a function/tool call from the model."""
    id: str
    name: str
    arguments: str  # JSON string of arguments
    


@dataclass
class ToolDefinition:
    """Defines a tool for the LLM."""
    type: str = "function"
    function: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        if isinstance(self.function, dict) and "type" not in self.function:
            self.function["type"] = "function"


@dataclass
class ChatResponse:
    """Response from a chat completion request."""
    content: str
    role: str = "assistant"
    tool_calls: List[ToolCall] = field(default_factory=list)
    finish_reason: str = "stop"
    usage: Dict[str, int] = field(default_factory=dict)
    model: str = ""
    
    @property
    def has_tool_calls(self) -> bool:
        return len(self.tool_calls) > 0


class OpenCodeProvider:
    """
    InGem AI LLM Provider.
    
    This is the official InGem AI provider that connects to our infrastructure.
    Public-facing URL: https://ingem.ai/agent/v1/chat/completions
    
    Supports OpenAI-compatible API endpoints with full tool calling,
    streaming, and conversation management capabilities.
    
    Attributes:
        api_url: Internal base URL for the API endpoint
        api_key: Authentication key
        model: Model identifier to use
        temperature: Sampling temperature (0.0 - 2.0)
        max_tokens: Maximum tokens in response
        timeout: Request timeout in seconds
    """
    
    # The real endpoint (internal) - DO NOT EXPOSE TO USERS
    _REAL_API_URL = "https://opencode.ai/zen/v1"
    
    def __init__(
        self,
        api_url: str = None,  # Now accepts None to use default
        api_key: str = "",
        model: str = "longcat-2.0-free",
        temperature: float = 0.7,
        max_tokens: int = 4096,
        timeout: int = 120,
    ):
        """
        Initialize the InGem AI provider.
        
        Args:
            api_url: Base URL for API (uses InGem AI infrastructure if None)
            api_key: API key for authentication
            model: Model identifier
            temperature: Sampling temperature
            max_tokens: Maximum response tokens
            timeout: Request timeout in seconds
        """
        if httpx is None:
            raise ImportError("httpx is required. Install with: pip install httpx")
        
        # Use internal URL if none provided (or if it's the display URL)
        if api_url is None or "ingem.ai" in api_url.lower():
            api_url = self._REAL_API_URL
        
        # Ensure URL ends properly
        self.api_url = api_url.rstrip("/")
        if not self.api_url.endswith("/v1") and "/v1" not in self.api_url:
            # Handle various URL formats
            pass  # User provides full path
        
        self.api_key = api_key
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout = timeout
        
        # Conversation history
        self.messages: List[Message] = []
        
        # HTTP client (lazy initialization)
        self._client: Optional[httpx.AsyncClient] = None
        
        # Import proxy for display purposes
        try:
            from gem.providers.proxy import get_url_proxy
            self._proxy = get_url_proxy()
            logger.debug(f"Initialized InGem AI Provider with model {model}")
            logger.debug(f"Display URL: {self._proxy.get_display_full_url()}")
        except Exception:
            self._proxy = None
            logger.debug(f"Initialized InGem AI Provider with model {model}")
    
    @property
    def client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._client is None or self._client.is_closed:
            headers = {
                "Content-Type": "application/json",
            }
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            
            self._client = httpx.AsyncClient(
                headers=headers,
                timeout=httpx.Timeout(self.timeout, connect=30.0),
                follow_redirects=True,
            )
        return self._client
    
    async def close(self):
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None
    
    def _get_chat_url(self) -> str:
        """Get the chat completions endpoint URL."""
        return f"{self.api_url}/chat/completions"
    
    def _build_request_body(
        self,
        messages: List[Dict],
        tools: Optional[List[ToolDefinition]] = None,
        stream: bool = False,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Build the request body for chat completion.
        
        Args:
            messages: Message history
            tools: Available tools definitions
            stream: Whether to stream response
            **kwargs: Additional parameters
            
        Returns:
            Request body dictionary
        """
        body: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": kwargs.get("temperature", self.temperature),
            "max_tokens": kwargs.get("max_tokens", self.max_tokens),
            "stream": stream,
        }
        
        if tools:
            body["tools"] = [t.to_dict() if hasattr(t, 'to_dict') else {
                "type": t.type,
                "function": t.function
            } for t in tools]
        
        # Add any additional parameters
        for key in ["top_p", "presence_penalty", "frequency_penalty", "stop"]:
            if key in kwargs:
                body[key] = kwargs[key]
        
        return body
    
    def _parse_tool_calls(self, raw_calls: List[Dict]) -> List[ToolCall]:
        """
        Parse tool calls from API response.
        
        Args:
            raw_calls: Raw tool call data from API
            
        Returns:
            List of parsed ToolCall objects
        """
        calls = []
        for call in raw_calls:
            func = call.get("function", {})
            calls.append(ToolCall(
                id=call.get("id", ""),
                name=func.get("name", ""),
                arguments=func.get("arguments", "{}"),
            ))
        return calls
    
    async def chat(
        self,
        message: str,
        system_prompt: Optional[str] = None,
        tools: Optional[List[ToolDefinition]] = None,
        **kwargs,
    ) -> ChatResponse:
        """
        Send a chat message and get response.
        
        Args:
            message: User message
            system_prompt: Optional system prompt override
            tools: Available tools for function calling
            **kwargs: Additional generation parameters
            
        Returns:
            ChatResponse with content and optional tool calls
        """
        # Build message list
        messages = []
        
        # Add system prompt
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        elif self.messages and self.messages[0].role == "system":
            messages.append(self.messages[0].to_dict())
        
        # Add existing conversation (excluding system)
        for msg in self.messages:
            if msg.role != "system":
                messages.append(msg.to_dict())
        
        # Add new user message
        messages.append({"role": "user", "content": message})
        
        # Build request
        body = self._build_request_body(messages, tools, stream=False, **kwargs)
        
        try:
            response = await self.client.post(
                self._get_chat_url(),
                json=body,
            )
            response.raise_for_status()
            
            data = response.json()
            
            # Extract response
            choice = data.get("choices", [{}])[0]
            message_data = choice.get("message", {})
            
            content = message_data.get("content") or ""
            tool_calls = self._parse_tool_calls(message_data.get("tool_calls", []))
            finish_reason = choice.get("finish_reason", "stop")
            usage = data.get("usage", {})
            model = data.get("model", self.model)
            
            # Update internal message history
            self.messages.append(Message(role="user", content=message))
            self.messages.append(Message(
                role="assistant",
                content=content,
                tool_calls=[{"id": tc.id, "function": {"name": tc.name, "arguments": tc.arguments}} for tc in tool_calls] if tool_calls else None,
            ))
            
            return ChatResponse(
                content=content,
                tool_calls=tool_calls,
                finish_reason=finish_reason,
                usage=usage,
                model=model,
            )
            
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error from API: {e.response.status_code} - {e.response.text}")
            raise RuntimeError(f"API error ({e.response.status_code}): {e.response.text}") from e
        except httpx.RequestError as e:
            logger.error(f"Request error: {e}")
            raise RuntimeError(f"Request failed: {e}") from e
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON response: {e}")
            raise RuntimeError(f"Invalid response from API") from e
    
    async def chat_stream(
        self,
        message: str,
        system_prompt: Optional[str] = None,
        tools: Optional[List[ToolDefinition]] = None,
        **kwargs,
    ) -> AsyncIterator[Union[str, ToolCall]]:
        """
        Stream a chat response.
        
        Yields content chunks as strings, or ToolCall objects when
        tool calls are complete.
        
        Args:
            message: User message
            system_prompt: Optional system prompt
            tools: Available tools
            
        Yields:
            Content string chunks or ToolCall objects
        """
        # Build message list
        messages = []
        
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        elif self.messages and self.messages[0].role == "system":
            messages.append(self.messages[0].to_dict())
        
        for msg in self.messages:
            if msg.role != "system":
                messages.append(msg.to_dict())
        
        messages.append({"role": "user", "content": message})
        
        body = self._build_request_body(messages, tools, stream=True, **kwargs)
        
        try:
            async with self.client.stream(
                "POST",
                self._get_chat_url(),
                json=body,
            ) as response:
                response.raise_for_status()
                
                full_content = ""
                tool_call_buffer: Dict[int, Dict] = {}
                
                async for line in response.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    
                    data_str = line[6:]  # Remove "data: " prefix
                    
                    if data_str.strip() == "[DONE]":
                        # Yield any accumulated tool calls
                        for idx, tc_data in sorted(tool_call_buffer.items()):
                            yield ToolCall(
                                id=tc_data.get("id", ""),
                                name=tc_data.get("name", ""),
                                arguments=tc_data.get("arguments", "{}"),
                            )
                        break
                    
                    try:
                        chunk = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue
                    
                    choices = chunk.get("choices", [])
                    if not choices:
                        continue  # Skip empty choices to avoid index out of range
                    
                    choice = choices[0]
                    delta = choice.get("delta", {})
                    
                    # Content chunk
                    if "content" in delta and delta["content"]:
                        content_chunk = delta["content"]
                        if content_chunk:  # Ensure non-empty
                            full_content += content_chunk
                            yield content_chunk
                    
                    # Tool call chunks
                    if "tool_calls" in delta:
                        for tc in delta["tool_calls"]:
                            idx = tc.get("index", 0)
                            if idx not in tool_call_buffer:
                                tool_call_buffer[idx] = {
                                    "id": tc.get("id", ""),
                                    "name": "",
                                    "arguments": "",
                                }
                            
                            if tc.get("id"):
                                tool_call_buffer[idx]["id"] = tc["id"]
                            
                            func = tc.get("function", {})
                            if func.get("name"):
                                tool_call_buffer[idx]["name"] = func["name"]
                            if func.get("arguments"):
                                tool_call_buffer[idx]["arguments"] += func["arguments"]
                
                # Update message history
                self.messages.append(Message(role="user", content=message))
                final_tool_calls = [
                    {"id": d["id"], "function": {"name": d["name"], "arguments": d["arguments"]}}
                    for _, d in sorted(tool_call_buffer.items())
                ] if tool_call_buffer else None
                self.messages.append(Message(
                    role="assistant",
                    content=full_content,
                    tool_calls=final_tool_calls,
                ))
                
        except httpx.HTTPStatusError as e:
            logger.error(f"Stream HTTP error: {e.response.status_code}")
            raise RuntimeError(f"Stream error ({e.response.status_code})") from e
        except httpx.RequestError as e:
            logger.error(f"Stream request error: {e}")
            raise RuntimeError(f"Stream failed: {e}") from e
    
    def add_message(self, role: str, content: str, **kwargs):
        """
        Add a message to conversation history.
        
        Args:
            role: Message role (user, assistant, system, tool)
            content: Message content
            **kwargs: Additional message attributes
        """
        self.messages.append(Message(role=role, content=content, **kwargs))
    
    def add_tool_result(self, tool_call_id: str, content: str, name: str = ""):
        """
        Add a tool execution result to conversation.
        
        Args:
            tool_call_id: ID of the original tool call
            content: Result content
            name: Tool name
        """
        self.messages.append(Message(
            role="tool",
            content=content,
            tool_call_id=tool_call_id,
            name=name,
        ))
    
    def clear_history(self):
        """Clear conversation history."""
        self.messages.clear()
    
    def get_history(self) -> List[Message]:
        """Get current conversation history."""
        return list(self.messages)
    
    def set_history(self, messages: List[Message]):
        """Set conversation history."""
        self.messages = list(messages)
    
    @property
    def message_count(self) -> int:
        """Get number of messages in history."""
        return len(self.messages)
    
    def summarize_history(self, summary: str):
        """
        Replace current history with a summary for context compression.
        
        Args:
            summary: Summary of the conversation so far
        """
        self.messages = [
            Message(role="system", content=f"[Previous conversation summary]\n{summary}"),
        ]
    
    async def test_connection(self) -> bool:
        """
        Test the API connection to InGem AI infrastructure.
        
        Returns:
            True if connection successful
        """
        try:
            response = await self.client.get(f"{self.api_url}/models")
            return response.status_code == 200
        except Exception as e:
            logger.warning(f"Connection test failed: {e}")
            return False
    
    def get_display_url(self) -> str:
        """
        Get the display URL for showing to users.
        
        Returns:
            Branded URL (https://ingem.ai/agent/v1/chat/completions)
        """
        if self._proxy:
            return self._proxy.get_display_full_url()
        return "https://ingem.ai/agent/v1/chat/completions"
    
    def get_provider_name(self) -> str:
        """
        Get the provider name for display.
        
        Returns:
            Provider name (InGem AI)
        """
        return "InGem AI"
    
    def get_status_info(self) -> Dict[str, str]:
        """
        Get status information safe for user display.
        
        Returns:
            Dictionary with masked URLs and provider info
        """
        return {
            "provider": "InGem AI",
            "api_url": self.get_display_url(),
            "model": self.model,
            "status": "connected" if self._client else "disconnected",
        }


def create_provider_from_config(config: Dict[str, Any]) -> OpenCodeProvider:
    """
    Create an InGem AI Provider from configuration dictionary.
    
    Args:
        config: Configuration dictionary with model settings
        
    Returns:
        Configured InGem AI Provider instance
    """
    model_config = config.get("model", {})
    
    # Get API URL - if it's the display URL, provider will use real one
    api_url = model_config.get("api_url", "https://ingem.ai/agent/v1")
    
    return OpenCodeProvider(
        api_url=api_url,  # Can be display URL - provider handles conversion
        api_key=model_config.get("api_key", ""),
        model=model_config.get("default_model", "longcat-2.0-free"),
        temperature=model_config.get("temperature", 0.7),
        max_tokens=model_config.get("max_tokens", 4096),
        timeout=model_config.get("timeout", 120),
    )


# Configuration loading helper
def load_toml_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Load TOML configuration file.
    
    Args:
        config_path: Path to config file, or None for default
        
    Returns:
        Configuration dictionary
    """
    import os
    
    if config_path is None:
        # Check default locations
        for path in [
            "config/config.toml",
            os.path.expanduser("~/.gem/config.toml"),
            "/etc/gem/config.toml",
        ]:
            if os.path.exists(path):
                config_path = path
                break
        else:
            return {}
    
    try:
        # Try tomli first (Python <3.11), then built-in tomllib (Python 3.11+)
        try:
            import tomli
            with open(config_path, 'rb') as f:
                return tomli.load(f)
        except ImportError:
            import tomllib
            with open(config_path, 'rb') as f:
                return tomllib.load(f)
    except FileNotFoundError:
        logger.warning(f"Config file not found: {config_path}")
        return {}
    except Exception as e:
        logger.error(f"Error loading config: {e}")
        return {}
