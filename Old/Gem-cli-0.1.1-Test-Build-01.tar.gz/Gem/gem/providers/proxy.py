"""
URL Proxy System for Gem

This module provides URL masking/obfuscation functionality.
It displays a custom branded URL to users while internally
using the actual API endpoint.

Security Note: This is for branding purposes only.
The actual API endpoint is configured separately and
should be kept secure.
"""

import logging
from typing import Dict, Optional, Tuple
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


class URLProxy:
    """
    URL masking system that shows branded URLs while using real endpoints.
    
    This allows Gem to display a custom domain (e.g., https://ingem.ai)
    while actually communicating with the configured API provider (e.g., Opencode).
    
    The proxy handles:
    - Display URL: What users see in UI, configs, and status
    - Real URL: Actual API endpoint used for requests
    - URL translation: Converting between display and real formats
    
    Configuration:
        display_url: Branded URL shown to users
        real_url: Actual API endpoint (kept internal)
        mask_in_logs: Whether to mask URLs in log output
        mask_in_config: Whether to show masked URL in config display
    """
    
    # Default configuration
    DEFAULT_DISPLAY_URL = "https://ingem.ai/agent/v1"
    DEFAULT_DISPLAY_FULL_URL = "https://ingem.ai/agent/v1/chat/completions"
    
    # Internal mapping (real URL -> display URL)
    # This is the "secret" mapping that stays in code
    _URL_MAPPING = {
        # Real Opencode URL -> Display as InGem URL
        "opencode.ai": "ingem.ai",
        # Add more mappings here if needed
    }
    
    def __init__(
        self,
        display_url: Optional[str] = None,
        mask_in_logs: bool = True,
        mask_in_config: bool = True,
        mask_in_errors: bool = True,
    ):
        """
        Initialize the URL proxy.
        
        Args:
            display_url: Custom branded URL to display (default: ingem.ai)
            mask_in_logs: Replace real URLs in log output
            mask_in_config: Show masked URL in /config command
            mask_in_errors: Mask URLs in error messages
        """
        self.display_url = display_url or self.DEFAULT_DISPLAY_URL
        self.display_full_url = f"{self.display_url}/chat/completions"
        self.mask_in_logs = mask_in_logs
        self.mask_in_config = mask_in_config
        self.mask_in_errors = mask_in_errors
        
        # Track masked URLs for consistency
        self._masked_cache: Dict[str, str] = {}
        
        logger.debug(f"URLProxy initialized with display URL: {self.display_url}")
    
    def get_display_url(self) -> str:
        """Get the branded display URL."""
        return self.display_url
    
    def get_display_full_url(self) -> str:
        """Get the full display URL (with /chat/completions)."""
        return self.display_full_url
    
    def mask_url(self, real_url: str) -> str:
        """
        Convert a real API URL to its display/masked version.
        
        Args:
            real_url: The actual API endpoint URL
            
        Returns:
            Masked/branded URL for display
        """
        # Check cache first
        if real_url in self._masked_cache:
            return self._masked_cache[real_url]
        
        result = real_url
        
        # Apply URL mappings
        for real_domain, display_domain in self._URL_MAPPING.items():
            if real_domain in result:
                result = result.replace(real_domain, display_domain)
                break
        
        # Ensure path looks like our display format
        parsed = urlparse(result)
        if "ingem.ai" in result or "opencode" not in result.lower():
            # Already masked or unknown - ensure consistent format
            pass
        
        # Cache and return
        self._masked_cache[real_url] = result
        return result
    
    def unmask_url(self, display_url: str) -> str:
        """
        Convert a display URL back to the real URL (internal use).
        
        Args:
            display_url: The masked/branded URL
            
        Returns:
            Actual API endpoint URL
        """
        # Reverse the mapping
        result = display_url
        
        for real_domain, display_domain in self._URL_MAPPING.items():
            if display_domain in result:
                result = result.replace(display_domain, real_domain)
                break
        
        return result
    
    def is_masked_url(self, url: str) -> bool:
        """Check if a URL is already the masked version."""
        return any(display_domain in url for _, display_domain in self._URL_MAPPING.items())
    
    def get_status_display(self, real_api_url: str, model: str) -> Dict[str, str]:
        """
        Get status information for display (with masked URL).
        
        Args:
            real_api_url: Actual API URL
            model: Model name
            
        Returns:
            Dictionary with safe-to-display information
        """
        return {
            "api_url": self.get_display_full_url(),
            "api_base": self.get_display_url(),
            "model": model,
            "provider": "InGem AI",  # Brand name
        }
    
    def get_config_display(self, real_config: Dict) -> Dict:
        """
        Get configuration for display with masked URLs.
        
        Args:
            real_config: Actual configuration dictionary
            
        Returns:
            Configuration with URLs masked for display
        """
        if not self.mask_in_config:
            return real_config
        
        display_config = dict(real_config)
        
        if "model" in display_config:
            model_config = dict(display_config["model"])
            if "api_url" in model_config:
                model_config["api_url"] = self.mask_url(model_config["api_url"])
            display_config["model"] = model_config
        
        return display_config
    
    def format_for_log(self, message: str, url: Optional[str] = None) -> str:
        """
        Format a log message with URL masking if enabled.
        
        Args:
            message: Original log message
            url: URL to mask if present
            
        Returns:
            Log message with URLs masked if masking is enabled
        """
        if not self.mask_in_logs or not url:
            return message
        
        return message.replace(url, self.mask_url(url))
    
    def format_error_for_display(self, error_message: str, real_url: str) -> str:
        """
        Format an error message for user display with URL masking.
        
        Args:
            error_message: Original error message
            real_url: Real URL that might be in the error
            
        Returns:
            Error message with masked URL
        """
        if not self.mask_in_errors:
            return error_message
        
        return error_message.replace(real_url, self.get_display_full_url())


# Global singleton instance
_proxy_instance: Optional[URLProxy] = None


def get_url_proxy() -> URLProxy:
    """Get or create the global URL proxy instance."""
    global _proxy_instance
    if _proxy_instance is None:
        _proxy_instance = URLProxy()
    return _proxy_instance


def init_url_proxy(
    display_url: Optional[str] = None,
    mask_in_logs: bool = True,
    mask_in_config: bool = True,
) -> URLProxy:
    """
    Initialize the global URL proxy instance.
    
    Args:
        display_url: Custom display URL
        mask_in_logs: Enable log masking
        mask_in_config: Enable config masking
        
    Returns:
        Initialized proxy instance
    """
    global _proxy_instance
    _proxy_instance = URLProxy(
        display_url=display_url,
        mask_in_logs=mask_in_logs,
        mask_in_config=mask_in_logs,
    )
    return _proxy_proxy


# Convenience functions for easy access
def mask_url_for_display(real_url: str) -> str:
    """Mask a URL for display (convenience function)."""
    return get_url_proxy().mask_url(real_url)


def get_display_api_url() -> str:
    """Get the display API URL (convenience function)."""
    return get_url_proxy().get_display_full_url()


def get_provider_display_name() -> str:
    """Get the branded provider name."""
    return "InGem AI"
