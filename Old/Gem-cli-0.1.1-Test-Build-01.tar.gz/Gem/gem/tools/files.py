"""
File Operations Tool

Provides secure file read, write, list, and edit operations with
workspace isolation, path validation, and size limits. Prevents
path traversal attacks and access to sensitive system files.
"""

import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from gem.tools.base import ParameterDefinition, Tool, ToolResult

logger = logging.getLogger(__name__)


# Default blocked paths for security
DEFAULT_BLOCKED_PATHS = [
    "/etc/passwd",
    "/etc/shadow",
    ".ssh/id_rsa",
    ".ssh/id_ed25519",
    ".env",
    ".env.local",
    ".pem",
    ".key",
]


class FileTool(Tool):
    """
    File operations tool.
    
    Provides read, write, list, search, and edit operations with
    security sandboxing to prevent unauthorized file access.
    
    Configuration:
        base_dir: Base directory for operations (empty = allow relative paths)
        max_read_size: Maximum bytes to read (default: 1MB)
        allowed_extensions: Extensions allowed for writing (empty = all)
        blocked_paths: Glob patterns to block
        allow_path_escape: Allow absolute paths outside base_dir
    """
    
    name = "file"
    description = "Read, write, list, search, and edit files. Use for viewing code, creating new files, modifying existing ones, searching content, and managing project structure. All operations respect workspace boundaries."
    
    def __init__(
        self,
        base_dir: str = "",
        max_read_size: int = 1048576,  # 1MB
        allowed_extensions: Optional[List[str]] = None,
        blocked_paths: Optional[List[str]] = None,
        allow_path_escape: bool = False,
    ):
        """
        Initialize file tool.
        
        Args:
            base_dir: Base directory (sandbox root)
            max_read_size: Max bytes to read from a file
            allowed_extensions: Allowed extensions for writing
            blocked_paths: Paths/patterns to block
            allow_path_escape: Allow paths outside base_dir
        """
        self.base_dir = Path(base_dir).resolve() if base_dir else Path.cwd()
        self.max_read_size = max_read_size
        self.allowed_extensions = allowed_extensions or []
        self.blocked_paths = blocked_paths or DEFAULT_BLOCKED_PATHS
        self.allow_path_escape = allow_path_escape
    
    @property
    def parameters(self) -> List[ParameterDefinition]:
        """File tool parameters."""
        return [
            ParameterDefinition(
                name="action",
                type="string",
                description="Action to perform: read, write, list, search, edit, exists, info, mkdir, delete",
                required=True,
                enum=["read", "write", "list", "search", "edit", "exists", "info", "mkdir", "delete"],
            ),
            ParameterDefinition(
                name="path",
                type="string",
                description="File or directory path (relative to workspace or absolute)",
                required=True,
            ),
            ParameterDefinition(
                name="content",
                type="string",
                description="Content to write (for write action)",
                required=False,
                default="",
            ),
            ParameterDefinition(
                name="pattern",
                type="string",
                description="Search pattern (for search action)",
                required=False,
                default="",
            ),
            ParameterDefinition(
                name="old_text",
                type="string",
                description="Text to replace (for edit action)",
                required=False,
                default="",
            ),
            ParameterDefinition(
                name="new_text",
                type="string",
                description="Replacement text (for edit action)",
                required=False,
                default="",
            ),
        ]
    
    def _resolve_path(self, path_str: str) -> Path:
        """
        Resolve and validate a file path.
        
        Args:
            path_str: Path string (relative or absolute)
            
        Returns:
            Resolved Path object
            
        Raises:
            ValueError: If path is invalid or blocked
        """
        path = Path(path_str)
        
        # Handle relative paths
        if not path.is_absolute():
            path = self.base_dir / path
        
        # Resolve to absolute
        path = path.resolve()
        
        # Security check: prevent path traversal outside base_dir
        if not self.allow_path_escape:
            try:
                path.relative_to(self.base_dir)
            except ValueError:
                raise ValueError(
                    f"Path escapes workspace boundary: {path}\n"
                    f"Base directory: {self.base_dir}"
                )
        
        # Check against blocked patterns
        path_str_check = str(path)
        for blocked in self.blocked_paths:
            if blocked in path_str_check or path.name == blocked:
                raise ValueError(f"Path is blocked by security policy: {path}")
        
        return path
    
    def _check_extension(self, path: Path) -> tuple[bool, str]:
        """
        Check if file extension is allowed for writing.
        
        Args:
            path: File path
            
        Returns:
            Tuple of (allowed, error_message)
        """
        if not self.allowed_extensions:
            return True, ""
        
        ext = path.suffix.lower()
        if ext not in self.allowed_extensions and ext:
            return False, f"File extension '{ext}' not in allowed list"
        
        return True, ""
    
    async def execute(self, **kwargs) -> ToolResult:
        """
        Execute a file operation.
        
        Args:
            action: Operation type (read, write, list, etc.)
            path: Target path
            content: Content for write operations
            pattern: Pattern for search
            old_text/new_text: For edit operations
            
        Returns:
            ToolResult with operation outcome
        """
        action = kwargs.get("action", "").lower()
        path_str = kwargs.get("path", "")
        
        if not action:
            return ToolResult.from_error("No action specified")
        
        if not path_str:
            return ToolResult.from_error("No path specified")
        
        # Route to appropriate handler
        handlers = {
            "read": self._read_file,
            "write": self._write_file,
            "list": self._list_directory,
            "search": self._search_files,
            "edit": self._edit_file,
            "exists": self._check_exists,
            "info": self._get_info,
            "mkdir": self._make_directory,
            "delete": self._delete_file,
        }
        
        handler = handlers.get(action)
        if not handler:
            return ToolResult.from_error(f"Unknown action: {action}. Valid actions: {', '.join(handlers.keys())}")
        
        try:
            return await handler(**kwargs)
        except ValueError as e:
            return ToolResult.from_error(str(e))
        except Exception as e:
            logger.exception(f"Error in {action} operation: {e}")
            return ToolResult.from_error(f"{action} failed: {type(e).__name__}: {e}")
    
    async def _read_file(self, **kwargs) -> ToolResult:
        """Read file contents."""
        path = self._resolve_path(kwargs["path"])
        
        if not path.exists():
            return ToolResult.from_error(f"File not found: {path}")
        
        if not path.is_file():
            return ToolResult.from_error(f"Not a file: {path}")
        
        # Check size
        size = path.stat().st_size
        if size > self.max_read_size:
            return ToolResult.from_error(
                f"File too large ({size} bytes > {self.max_read_size} limit). "
                f"Use 'search' to find specific content."
            )
        
        try:
            # Try to detect encoding
            content = await self._read_with_encoding(path)
            
            return ToolResult(
                success=True,
                output=content,
                data={
                    "path": str(path),
                    "size": size,
                    "lines": content.count('\n') + 1,
                },
            )
        except Exception as e:
            return ToolResult.from_error(f"Failed to read file: {e}")
    
    async def _read_with_encoding(self, path: Path) -> str:
        """Read file with automatic encoding detection."""
        encodings = ['utf-8', 'latin-1', 'cp1252']
        
        for encoding in encodings:
            try:
                return path.read_text(encoding=encoding)
            except UnicodeDecodeError:
                continue
        
        # Last resort: read as binary and decode with errors
        return path.read_bytes().decode('utf-8', errors='replace')
    
    async def _write_file(self, **kwargs) -> ToolResult:
        """Write content to file."""
        path = self._resolve_path(kwargs["path"])
        content = kwargs.get("content", "")
        
        # Check extension
        allowed, error = self._check_extension(path)
        if not allowed:
            return ToolResult.from_error(error)
        
        # Create parent directories
        path.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            path.write_text(content, encoding='utf-8')
            
            return ToolResult(
                success=True,
                output=f"Written {len(content)} characters to {path}",
                data={
                    "path": str(path),
                    "size": len(content),
                },
            )
        except Exception as e:
            return ToolResult.from_error(f"Write failed: {e}")
    
    async def _list_directory(self, **kwargs) -> ToolResult:
        """List directory contents."""
        path = self._resolve_path(kwargs["path"])
        
        if not path.exists():
            return ToolResult.from_error(f"Directory not found: {path}")
        
        if not path.is_dir():
            return ToolResult.from_error(f"Not a directory: {path}")
        
        try:
            entries = []
            for item in sorted(path.iterdir()):
                try:
                    stat = item.stat()
                    entries.append({
                        "name": item.name,
                        "type": "directory" if item.is_dir() else "file",
                        "size": stat.st_size if item.is_file() else None,
                        "modified": stat.st_mtime,
                    })
                except PermissionError:
                    entries.append({
                        "name": item.name,
                        "type": "unknown",
                        "size": None,
                        "modified": None,
                    })
            
            output = "\n".join(
                f"{'📁' if e['type'] == 'directory' else '📄'} {e['name']}"
                for e in entries
            ) if entries else "(empty directory)"
            
            return ToolResult(
                success=True,
                output=output,
                data={
                    "path": str(path),
                    "entries": entries,
                    "count": len(entries),
                },
            )
        except PermissionError:
            return ToolResult.from_error(f"Permission denied: {path}")
    
    async def _search_files(self, **kwargs) -> ToolResult:
        """Search for pattern in files."""
        import fnmatch
        
        path = self._resolve_path(kwargs["path"])
        pattern = kwargs.get("pattern", "")
        
        if not pattern:
            return ToolResult.from_error("No search pattern provided")
        
        if not path.exists():
            return ToolResult.from_error(f"Path not found: {path}")
        
        try:
            results = []
            target = path if path.is_dir() else path.parent
            
            # Search in files
            for file_path in target.rglob("*"):
                if not file_path.is_file():
                    continue
                
                # Skip binary files
                if self._is_binary(file_path):
                    continue
                
                try:
                    content = file_path.read_text(encoding='utf-8', errors='ignore')
                    
                    for line_num, line in enumerate(content.splitlines(), 1):
                        if pattern.lower() in line.lower():
                            rel_path = file_path.relative_to(self.base_dir)
                            results.append({
                                "file": str(rel_path),
                                "line": line_num,
                                "content": line.strip()[:200],  # Truncate long lines
                            })
                            
                            # Limit results
                            if len(results) >= 50:
                                break
                except (PermissionError, UnicodeDecodeError):
                    continue
                
                if len(results) >= 50:
                    break
            
            if not results:
                return ToolResult.from_output(f"No matches found for '{pattern}'")
            
            output = "\n".join(
                f"{r['file']}:{r['line']}: {r['content']}"
                for r in results[:20]  # Show first 20 in output
            )
            
            if len(results) > 20:
                output += f"\n... and {len(results) - 20} more matches"
            
            return ToolResult(
                success=True,
                output=output,
                data={"matches": results, "total": len(results)},
            )
            
        except Exception as e:
            return ToolResult.from_error(f"Search failed: {e}")
    
    def _is_binary(self, path: Path) -> bool:
        """Check if file appears to be binary."""
        try:
            with open(path, 'rb') as f:
                chunk = f.read(8192)
            return b'\x00' in chunk
        except (IOError, OSError):
            return True
    
    async def _edit_file(self, **kwargs) -> ToolResult:
        """Edit file by replacing text."""
        path = self._resolve_path(kwargs["path"])
        old_text = kwargs.get("old_text", "")
        new_text = kwargs.get("new_text", "")
        
        if not old_text:
            return ToolResult.from_error("No old_text provided for replacement")
        
        if not path.exists():
            return ToolResult.from_error(f"File not found: {path}")
        
        try:
            content = path.read_text(encoding='utf-8')
            
            if old_text not in content:
                return ToolResult.from_error(f"Text not found in file: {old_text[:50]}...")
            
            new_content = content.replace(old_text, new_text, 1)  # Replace first occurrence
            path.write_text(new_content, encoding='utf-8')
            
            return ToolResult.from_output(
                f"Replaced text in {path} (1 occurrence)"
            )
        except Exception as e:
            return ToolResult.from_error(f"Edit failed: {e}")
    
    async def _check_exists(self, **kwargs) -> ToolResult:
        """Check if path exists."""
        path = self._resolve_path(kwargs["path"])
        
        exists = path.exists()
        file_type = "directory" if path.is_dir() else ("file" if path.is_file() else "unknown")
        
        return ToolResult(
            success=True,
            output=f"{'Exists' if exists else 'Not found'} ({file_type})",
            data={
                "exists": exists,
                "type": file_type if exists else None,
                "path": str(path),
            },
        )
    
    async def _get_info(self, **kwargs) -> ToolResult:
        """Get file/directory information."""
        path = self._resolve_path(kwargs["path"])
        
        if not path.exists():
            return ToolResult.from_error(f"Not found: {path}")
        
        try:
            stat = path.stat()
            
            import datetime
            
            info = {
                "path": str(path),
                "name": path.name,
                "type": "directory" if path.is_dir() else "file",
                "size": stat.st_size,
                "created": datetime.datetime.fromtimestamp(stat.st_ctime).isoformat(),
                "modified": datetime.datetime.fromtimestamp(stat.st_mtime).isoformat(),
                "permissions": oct(stat.st_mode)[-3:],
                "readable": os.access(path, os.R_OK),
                "writable": os.access(path, os.W_OK),
            }
            
            output = (
                f"Name: {info['name']}\n"
                f"Type: {info['type']}\n"
                f"Size: {info['size']} bytes\n"
                f"Modified: {info['modified']}\n"
                f"Permissions: {info['permissions']}"
            )
            
            return ToolResult(success=True, output=output, data=info)
        except Exception as e:
            return ToolResult.from_error(f"Get info failed: {e}")
    
    async def _make_directory(self, **kwargs) -> ToolResult:
        """Create directory."""
        path = self._resolve_path(kwargs["path"])
        
        if path.exists():
            if path.is_dir():
                return ToolResult.from_output(f"Directory already exists: {path}")
            return ToolResult.from_error(f"Path exists but is not a directory: {path}")
        
        try:
            path.mkdir(parents=True, exist_ok=True)
            return ToolResult.from_output(f"Created directory: {path}")
        except PermissionError:
            return ToolResult.from_error(f"Permission denied creating: {path}")
        except Exception as e:
            return ToolResult.from_error(f"Create directory failed: {e}")
    
    async def _delete_file(self, **kwargs) -> ToolResult:
        """Delete file or empty directory."""
        path = self._resolve_path(kwargs["path"])
        
        if not path.exists():
            return ToolResult.from_error(f"Not found: {path}")
        
        try:
            if path.is_dir():
                # Only delete empty directories for safety
                if any(path.iterdir()):
                    return ToolResult.from_error(
                        f"Directory not empty. Delete contents first or use shell command."
                    )
                path.rmdir()
            else:
                path.unlink()
            
            return ToolResult.from_output(f"Deleted: {path}")
        except PermissionError:
            return ToolResult.from_error(f"Permission denied deleting: {path}")
        except OSError as e:
            return ToolResult.from_error(f"Delete failed: {e}")
