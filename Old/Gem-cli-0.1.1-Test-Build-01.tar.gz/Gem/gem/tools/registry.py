"""
Tool Registry - Central registry for agent tools.

Provides a clean way to register, discover, and use tools.
The architecture allows adding new tools without rewriting the agent loop.
"""

import logging
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)


class ToolError(Exception):
    """Base exception for tool errors."""
    pass


class ToolExecutionError(ToolError):
    """Raised when a tool fails during execution."""
    pass


class ToolNotFoundError(ToolError):
    """Raised when a requested tool is not found."""
    pass


@dataclass
class ToolParameter:
    """Describes a parameter for a tool."""
    name: str
    type: str  # "string", "integer", "boolean", "object", "array"
    description: str
    required: bool = True
    default: Any = None
    enum: Optional[List[Any]] = None
    
    def to_dict(self) -> Dict:
        """Convert to JSON Schema format."""
        param = {
            "type": self.type,
            "description": self.description
        }
        if self.enum:
            param["enum"] = self.enum
        if not self.required:
            param["default"] = self.default
        return param


@dataclass
class ToolResult:
    """Result of a tool execution."""
    success: bool
    output: str
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    
    def to_string(self) -> str:
        """Convert to string for the model."""
        if self.success:
            return self.output or "Operation completed successfully."
        else:
            return f"Error: {self.error}"


@dataclass
class ToolDefinition:
    """Definition of a tool for the LLM."""
    name: str
    description: str
    parameters: List[ToolParameter] = field(default_factory=list)
    
    @property
    def required_params(self) -> List[str]:
        return [p.name for p in self.parameters if p.required]
    
    def to_dict(self) -> Dict:
        """Convert to OpenAI function calling format."""
        properties = {}
        required = []
        
        for param in self.parameters:
            properties[param.name] = param.to_dict()
            if param.required:
                required.append(param.name)
        
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required
                }
            }
        }


class BaseTool(ABC):
    """Abstract base class that all tools must implement."""
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Name of the tool (used for invocation)."""
        pass
    
    @property
    @abstractmethod
    def description(self) -> str:
        """Description of what the tool does."""
        pass
    
    @property
    @abstractmethod
    def parameters(self) -> List[ToolParameter]:
        """Parameters this tool accepts."""
        pass
    
    @abstractmethod
    def execute(self, **kwargs) -> ToolResult:
        """Execute the tool with given arguments."""
        pass
    
    def get_definition(self) -> ToolDefinition:
        """Get the tool definition for LLM consumption."""
        return ToolDefinition(
            name=self.name,
            description=self.description,
            parameters=self.parameters
        )
    
    def validate_args(self, args: Dict[str, Any]) -> tuple[bool, Optional[str]]:
        """Validate arguments before execution."""
        param_names = {p.name for p in self.parameters}
        required = {p.name for p in self.parameters if p.required}
        
        # Check for missing required params
        missing = required - set(args.keys())
        if missing:
            return False, f"Missing required parameters: {', '.join(missing)}"
        
        # Check for unknown params
        unknown = set(args.keys()) - param_names
        if unknown:
            logger.warning(f"Unknown parameters ignored: {unknown}")
        
        return True, None


class ToolRegistry:
    """
    Central registry for all tools.
    
    Allows tools to be registered and discovered by name.
    The agent loop uses this registry to find and execute tools.
    """
    
    def __init__(self):
        self._tools: Dict[str, BaseTool] = {}
        self._aliases: Dict[str, str] = {}  # alias -> actual name
    
    def register(self, tool: BaseTool, aliases: Optional[List[str]] = None) -> None:
        """Register a tool with optional aliases."""
        if not isinstance(tool, BaseTool):
            raise TypeError(f"Tool must be a BaseTool instance, got {type(tool)}")
        
        self._tools[tool.name] = tool
        logger.debug(f"Registered tool: {tool.name}")
        
        # Register aliases
        if aliases:
            for alias in aliases:
                self._aliases[alias] = tool.name
                logger.debug(f"Registered alias '{alias}' for tool: {tool.name}")
    
    def unregister(self, name: str) -> bool:
        """Remove a tool from the registry."""
        if name in self._tools:
            del self._tools[name]
            # Remove any aliases pointing to this tool
            self._aliases = {k: v for k, v in self._aliases.items() if v != name}
            return True
        return False
    
    def get(self, name: str) -> Optional[BaseTool]:
        """Get a tool by name or alias."""
        # Check direct name first
        if name in self._tools:
            return self._tools[name]
        
        # Check aliases
        resolved = self._aliases.get(name)
        if resolved and resolved in self._tools:
            return self._tools[resolved]
        
        return None
    
    def has_tool(self, name: str) -> bool:
        """Check if a tool exists."""
        return name in self._tools or name in self._aliases
    
    def list_tools(self) -> List[str]:
        """List all registered tool names."""
        return list(self._tools.keys())
    
    def get_definitions(self) -> List[Dict]:
        """Get all tool definitions in OpenAI format."""
        return [tool.get_definition().to_dict() for tool in self._tools.values()]
    
    def execute_tool(self, name: str, **kwargs) -> ToolResult:
        """Execute a tool by name with the given arguments."""
        tool = self.get(name)
        if not tool:
            raise ToolNotFoundError(f"Tool '{name}' not found. Available: {self.list_tools()}")
        
        # Validate arguments
        valid, error_msg = tool.validate_args(kwargs)
        if not valid:
            raise ToolExecutionError(f"Invalid arguments for '{name}': {error_msg}")
        
        try:
            logger.info(f"Executing tool: {name} with args: {list(kwargs.keys())}")
            result = tool.execute(**kwargs)
            
            if not isinstance(result, ToolResult):
                result = ToolResult(
                    success=True,
                    output=str(result)
                )
            
            return result
            
        except ToolError:
            raise
        except Exception as e:
            logger.error(f"Tool '{name}' execution failed: {e}", exc_info=True)
            raise ToolExecutionError(f"Tool '{name}' failed: {str(e)}")
    
    def create_default_registry(self) -> "ToolRegistry":
        """Create a registry with default tools."""
        from .shell import ShellTool
        from .files import FileTool
        from .web import WebTool
        
        self.register(ShellTool(), aliases=["sh", "bash", "command"])
        self.register(FileTool(), aliases=["file", "fs"])
        self.register(WebTool(), aliases=["search", "web"])
        
        return self


# Convenience function to create a pre-populated registry
def create_tool_registry(**tool_config) -> ToolRegistry:
    """Create and populate a tool registry with default tools."""
    registry = ToolRegistry()
    return registry.create_default_registry()
