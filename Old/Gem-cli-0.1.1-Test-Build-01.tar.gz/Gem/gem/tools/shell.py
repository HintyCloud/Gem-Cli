"""
Shell Execution Tool

Provides secure command execution with timeout, workspace isolation,
and output capture. Supports multiple shell environments including
bash, sh, and ash for Termux/Android compatibility.
"""

import asyncio
import logging
import os
import re
import shlex
from pathlib import Path
from typing import Any, Dict, List, Optional

from gem.tools.base import ParameterDefinition, Tool, ToolResult

logger = logging.getLogger(__name__)


# Default blocked patterns for security
DEFAULT_BLOCKED_PATTERNS = [
    r"rm -rf\s+/$",
    r"mkfs\.",
    r">\s*/dev/sda",
    r"format\s+[a-z]:",
    r":\(\)\s*\{\s*:\s*\|:\s*&\s*\}\s*;:",  # Fork bomb
    r"chmod\s+-R\s+777\s+/",
    r"dd\s+if=.*of=/dev/",
    r">\s*/etc/",
    r"shutdown",
    r"reboot",
    r"init\s+0",
    r"halt",
]


class ShellTool(Tool):
    """
    Shell command execution tool.
    
    Executes commands in a subprocess with configurable timeout,
    workspace isolation, and security filtering. Designed to work
    across Linux, macOS, and Android/Termux environments.
    
    Configuration:
        workdir: Working directory for commands (default: current)
        timeout: Command timeout in seconds (default: 300)
        shells: List of shell executables to try (default: bash, sh, ash)
        blocked_patterns: Regex patterns to block (security)
    """
    
    name = "shell"
    description = "Execute a shell command and return the output. Use for running build commands, git operations, package management, file system operations, and any terminal task. Commands run with configurable timeout and workspace isolation."
    
    def __init__(
        self,
        workdir: str = "",
        timeout: int = 300,
        shells: Optional[List[str]] = None,
        blocked_patterns: Optional[List[str]] = None,
    ):
        """
        Initialize shell tool.
        
        Args:
            workdir: Default working directory
            timeout: Default command timeout in seconds
            shells: List of shells to try (in order)
            blocked_patterns: Regex patterns to block
        """
        self.workdir = Path(workdir) if workdir else Path.cwd()
        self.timeout = timeout
        self.shells = shells or ["bash", "sh", "ash"]
        self.blocked_patterns = blocked_patterns or DEFAULT_BLOCKED_PATTERNS
        
        # Compile regex patterns for performance
        self._compiled_patterns = [re.compile(p) for p in self.blocked_patterns]
        
        # Track running processes for cancellation
        self._running_process: Optional[asyncio.subprocess.Process] = None
    
    @property
    def parameters(self) -> List[ParameterDefinition]:
        """Shell tool parameters."""
        return [
            ParameterDefinition(
                name="command",
                type="string",
                description="The shell command to execute",
                required=True,
            ),
            ParameterDefinition(
                name="workdir",
                type="string",
                description="Working directory for command execution (optional)",
                required=False,
                default="",
            ),
            ParameterDefinition(
                name="timeout",
                type="integer",
                description="Timeout in seconds (optional)",
                required=False,
                default=300,
            ),
            ParameterDefinition(
                name="shell",
                type="string",
                description="Shell to use (bash, sh, ash) or empty for auto-detect",
                required=False,
                default="",
            ),
        ]
    
    def _find_shell(self, preferred: str = "") -> str:
        """
        Find an available shell executable.
        
        Args:
            preferred: Preferred shell name
            
        Returns:
            Path to available shell
        """
        if preferred:
            # Check if preferred shell exists
            shell_path = shutil.which(preferred)
            if shell_path:
                return shell_path
        
        # Try each shell in order
        for shell_name in self.shells:
            shell_path = shutil.which(shell_name)
            if shell_path:
                logger.debug(f"Using shell: {shell_path}")
                return shell_path
        
        # Fallback: try /bin/sh (always exists on Unix)
        if os.path.exists("/bin/sh"):
            return "/bin/sh"
        
        raise RuntimeError("No suitable shell found")
    
    def _validate_command(self, command: str) -> tuple[bool, str]:
        """
        Validate command against security patterns.
        
        Args:
            command: Command string to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        command_stripped = command.strip()
        
        for pattern in self._compiled_patterns:
            if pattern.search(command_stripped):
                return False, f"Command blocked by security policy (matched: {pattern.pattern})"
        
        # Additional checks
        dangerous_commands = [
            ("rm -rf /", "Destructive command detected"),
            ("> /dev/sda", "Disk write attempt detected"),
            (":(){ :|:& };:", "Fork bomb detected"),
        ]
        
        for cmd_pattern, msg in dangerous_commands:
            if cmd_pattern in command_stripped.lower().replace(" ", ""):
                return False, msg
        
        return True, ""
    
    async def execute(self, **kwargs) -> ToolResult:
        """
        Execute a shell command.
        
        Args:
            command: Command to execute
            workdir: Working directory (optional)
            timeout: Timeout in seconds (optional)
            shell: Shell to use (optional)
            
        Returns:
            ToolResult with stdout/stderr content
        """
        import shutil
        
        command = kwargs.get("command", "")
        workdir = kwargs.get("workdir", "")
        timeout = kwargs.get("timeout", self.timeout)
        shell = kwargs.get("shell", "")
        
        if not command.strip():
            return ToolResult.from_error("No command provided")
        
        # Validate command
        is_valid, error_msg = self._validate_command(command)
        if not is_valid:
            return ToolResult.from_error(error_msg)
        
        # Determine working directory
        if workdir:
            cwd = Path(workdir)
            if not cwd.is_absolute():
                cwd = self.workdir / cwd
        else:
            cwd = self.workdir
        
        # Ensure directory exists
        if not cwd.exists():
            try:
                cwd.mkdir(parents=True, exist_ok=True)
            except PermissionError:
                return ToolResult.from_error(f"Cannot create working directory: {cwd}")
        
        # Find shell
        try:
            shell_path = self._find_shell(shell)
        except RuntimeError as e:
            return ToolResult.from_error(str(e))
        
        logger.info(f"Executing command in {cwd}: {command[:100]}...")
        
        try:
            # Execute command
            self._running_process = await asyncio.create_subprocess_exec(
                shell_path,
                "-c",
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(cwd),
                env={**os.environ, "TERM": "dumb"},  # Disable color codes
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    self._running_process.communicate(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                # Kill the process on timeout
                try:
                    self._running_process.kill()
                    await self._running_process.wait()
                except ProcessLookupError:
                    pass
                
                return ToolResult.from_error(
                    f"Command timed out after {timeout} seconds"
                )
            
            # Get exit code BEFORE clearing the process reference
            proc_exit_code = self._running_process.returncode if self._running_process else -1
            
            # Now clear the process reference
            self._running_process = None
            
            # Decode output
            stdout_text = stdout.decode('utf-8', errors='replace').strip()
            stderr_text = stderr.decode('utf-8', errors='replace').strip()
            
            # Build result
            output_parts = []
            if stdout_text:
                output_parts.append(stdout_text)
            if stderr_text and proc_exit_code != 0:
                output_parts.append(f"[stderr]\n{stderr_text}")
            
            result_output = "\n".join(output_parts) if output_parts else "(no output)"
            
            success = proc_exit_code == 0
            
            result = ToolResult(
                success=success,
                output=result_output,
                data={
                    "exit_code": proc_exit_code,
                    "command": command,
                    "working_directory": str(cwd),
                    "shell": shell_path,
                },
            )
            
            if not success and stderr_text:
                result.error = stderr_text
            
            logger.debug(f"Command completed with exit code {proc_exit_code}")
            return result
            
        except FileNotFoundError as e:
            return ToolResult.from_error(f"Shell not found: {e}")
        except PermissionError as e:
            return ToolResult.from_error(f"Permission denied: {e}")
        except Exception as e:
            logger.exception(f"Unexpected error executing command: {e}")
            return ToolResult.from_error(f"Execution failed: {type(e).__name__}: {e}")
    
    async def cancel(self):
        """Cancel any running command."""
        if self._running_process and self._running_process.returncode is None:
            try:
                self._running_process.kill()
                await self._running_process.wait()
            except ProcessLookupError:
                pass
    
    def get_available_shells(self) -> List[Dict[str, str]]:
        """
        Get list of available shells on this system.
        
        Returns:
            List of dicts with name and path
        """
        import shutil
        
        available = []
        for shell_name in self.shells:
            path = shutil.which(shell_name)
            if path:
                available.append({"name": shell_name, "path": path})
        return available


# Import shutil at module level after definition
import shutil
