"""
Web Search Tool

Provides web search capabilities using HTTP requests to search APIs.
Falls back to basic web scraping when dedicated APIs are unavailable.
"""

import json
import logging
import re
from typing import Any, Dict, List, Optional
from urllib.parse import quote, urlencode, urlparse

try:
    import httpx
except ImportError:
    httpx = None  # type: ignore

from gem.tools.base import ParameterDefinition, Tool, ToolResult

logger = logging.getLogger(__name__)


class WebTool(Tool):
    """
    Web search and information retrieval tool.
    
    Provides search functionality using configurable search backends.
    Supports multiple search providers and includes result parsing
    and relevance ranking.
    
    Configuration:
        enabled: Whether search is enabled
        max_results: Maximum results to return (default: 10)
        timeout: Request timeout in seconds (default: 30)
        search_engine: Search backend to use
    """
    
    name = "web_search"
    description = "Search the web for information. Use for finding documentation, looking up APIs, researching solutions, getting current data, and finding code examples. Returns relevant snippets with source URLs."
    
    def __init__(
        self,
        enabled: bool = True,
        max_results: int = 10,
        timeout: int = 30,
        search_engine: str = "auto",
        api_key: Optional[str] = None,
    ):
        """
        Initialize web tool.
        
        Args:
            enabled: Enable/disable search
            max_results: Maximum number of results
            timeout: Request timeout in seconds
            search_engine: 'auto', 'duckduckgo', or custom URL
            api_key: API key for premium search services
        """
        if httpx is None:
            raise ImportError("httpx is required for web search")
        
        self.enabled = enabled
        self.max_results = max_results
        self.timeout = timeout
        self.search_engine = search_engine
        self.api_key = api_key
        
        # HTTP client for requests
        self._client: Optional[httpx.AsyncClient] = None
    
    @property
    def client(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                headers={
                    "User-Agent": "Gem/1.0 (AI Assistant; Research Mode)",
                    "Accept": "text/html,application/json",
                },
                timeout=httpx.Timeout(self.timeout, connect=10.0),
                follow_redirects=True,
            )
        return self._client
    
    async def close(self):
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()
            self._client = None
    
    @property
    def parameters(self) -> List[ParameterDefinition]:
        """Web tool parameters."""
        return [
            ParameterDefinition(
                name="query",
                type="string",
                description="Search query string",
                required=True,
            ),
            ParameterDefinition(
                name="num_results",
                type="integer",
                description="Number of results to return (1-20)",
                required=False,
                default=10,
            ),
            ParameterDefinition(
                name="site",
                type="string",
                description="Limit search to specific site (e.g., 'github.com')",
                required=False,
                default="",
            ),
            ParameterDefinition(
                name="time_range",
                type="string",
                description="Time filter: day, week, month, year",
                required=False,
                default="",
                enum=["day", "week", "month", "year", ""],
            ),
        ]
    
    async def execute(self, **kwargs) -> ToolResult:
        """
        Execute a web search.
        
        Args:
            query: Search query
            num_results: Number of results
            site: Site restriction
            time_range: Time filter
            
        Returns:
            ToolResult with search results
        """
        if not self.enabled:
            return ToolResult.from_error("Web search is disabled")
        
        query = kwargs.get("query", "")
        num_results = min(kwargs.get("num_results", self.max_results), 20)
        site = kwargs.get("site", "")
        time_range = kwargs.get("time_range", "")
        
        if not query.strip():
            return ToolResult.from_error("No search query provided")
        
        # Build full query with modifiers
        full_query = query
        if site:
            full_query = f"site:{site} {full_query}"
        
        logger.info(f"Searching web for: {full_query[:50]}...")
        
        try:
            # Try different search methods
            results = await self._search_duckduckgo(full_query, num_results)
            
            if not results:
                # Fallback: try a simple HTML scrape approach
                results = await self._search_fallback(full_query, num_results)
            
            if not results:
                return ToolResult.from_output(f"No results found for '{query}'")
            
            # Format output
            output = self._format_results(results)
            
            return ToolResult(
                success=True,
                output=output,
                data={
                    "query": query,
                    "results": results,
                    "count": len(results),
                },
            )
            
        except Exception as e:
            logger.exception(f"Web search failed: {e}")
            return ToolResult.from_error(f"Search failed: {type(e).__name__}: {e}")
    
    async def _search_duckduckgo(self, query: str, num_results: int) -> List[Dict]:
        """
        Search using DuckDuckGo's instant answer API.
        
        This is a free, no-API-key-required method that provides
        decent results for most queries.
        
        Args:
            query: Search query
            num_results: Max results
            
        Returns:
            List of result dictionaries
        """
        results = []
        
        try:
            # DuckDuckGo Instant Answer API
            params = {
                "q": query,
                "format": "json",
                "no_html": "1",
                "skip_disambig": "1",
            }
            
            url = f"https://api.duckduckgo.com/?{urlencode(params)}"
            
            response = await self.client.get(url)
            response.raise_for_status()
            
            data = response.json()
            
            # Parse instant answer if available
            if data.get("Abstract"):
                results.append({
                    "title": data.get("Heading", ""),
                    "url": data.get("AbstractURL", ""),
                    "snippet": data["Abstract"],
                    "source": "DuckDuckGo",
                })
            
            # Try to get more results from HTML version
            html_results = await self._search_duckduckgo_html(query, num_results - len(results))
            results.extend(html_results)
            
        except Exception as e:
            logger.debug(f"DuckDuckGo API error: {e}")
        
        return results[:num_results]
    
    async def _search_duckduckgo_html(self, query: str, num_results: int) -> List[Dict]:
        """
        Search using DuckDuckGo HTML (lightweight scraping).
        
        Args:
            query: Search query
            num_results: Max results
            
        Returns:
            List of result dictionaries
        """
        results = []
        
        try:
            # Use DuckDuckGo lite version
            params = {
                "q": query,
                "kl": "wt-wt",  # No region restriction
            }
            
            url = f"https://lite.duckduckgo.com/lite/?{urlencode(params)}"
            
            response = await self.client.post(
                url,
                data={"q": query},
                headers={"Content-Type": "application/x-www-form-urlencoded"},
            )
            response.raise_for_status()
            
            # Parse HTML results
            html = response.text
            
            # Extract result blocks using regex
            # DDG lite uses <tr> tags for results
            result_pattern = re.compile(
                r'<a[^>]+rel="nofollow"[^>]*href="([^"]+)"[^>]*>([^<]+)</a>.*?'
                r'<td class="result-snippet"[^>]*>(.*?)</td>',
                re.DOTALL | re.IGNORECASE,
            )
            
            for match in result_pattern.finditer(html)[:num_results]:
                url_match = match.group(1)
                title_match = match.group(2).strip()
                snippet_match = re.sub(r'<[^>]+>', '', match.group(3)).strip()
                
                if title_match and url_match:
                    results.append({
                        "title": title_match,
                        "url": url_match,
                        "snippet": snippet_match[:300],
                        "source": "DuckDuckGo",
                    })
                    
        except Exception as e:
            logger.debug(f"DuckDuckGo HTML error: {e}")
        
        return results
    
    async def _search_fallback(self, query: str, num_results: int) -> List[Dict]:
        """
        Fallback search method using multiple sources.
        
        Tries alternative approaches when primary methods fail.
        
        Args:
            query: Search query
            num_results: Max results
            
        Returns:
            List of result dictionaries
        """
        results = []
        
        # Try Wikipedia for factual queries
        if any(word in query.lower() for word in ["what", "who", "when", "where", "define"]):
            wiki_results = await self._search_wikipedia(query, 2)
            results.extend(wiki_results)
        
        # Return what we have
        return results[:num_results]
    
    async def _search_wikipedia(self, query: str, num_results: int) -> List[Dict]:
        """
        Search Wikipedia for information.
        
        Good for factual queries, definitions, and encyclopedic content.
        
        Args:
            query: Search query
            num_results: Max results
            
        Returns:
            List of result dictionaries
        """
        results = []
        
        try:
            params = {
                "action": "query",
                "list": "search",
                "srsearch": query,
                "srlimit": num_results,
                "format": "json",
            }
            
            url = f"https://en.wikipedia.org/w/api.php?{urlencode(params)}"
            
            response = await self.client.get(url)
            response.raise_for_status()
            
            data = response.json()
            
            for item in data.get("query", {}).get("search", []):
                results.append({
                    "title": item.get("title", ""),
                    "url": f"https://en.wikipedia.org/wiki/{quote(item.get('title', '').replace(' ', '_'))}",
                    "snippet": item.get("snippet", "").replace('<span class="searchmatch">', '').replace('</span>', ''),
                    "source": "Wikipedia",
                })
                
        except Exception as e:
            logger.debug(f"Wikipedia search error: {e}")
        
        return results
    
    def _format_results(self, results: List[Dict]) -> str:
        """
        Format search results for display.
        
        Args:
            results: List of result dictionaries
            
        Returns:
            Formatted string
        """
        lines = []
        lines.append(f"Found {len(results)} results:\n")
        
        for i, result in enumerate(results, 1):
            title = result.get("title", "Untitled")
            url = result.get("url", "")
            snippet = result.get("snippet", "")
            source = result.get("source", "Unknown")
            
            lines.append(f"{i}. {title}")
            if url:
                lines.append(f"   URL: {url}")
            if snippet:
                # Clean up snippet
                clean_snippet = re.sub(r'<[^>]+>', '', snippet)
                clean_snippet = clean_snippet.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
                lines.append(f"   {clean_snippet[:250]}")
            lines.append(f"   Source: {source}")
            lines.append("")
        
        return "\n".join(lines)
    
    async def fetch_url(self, url: str, max_length: int = 5000) -> ToolResult:
        """
        Fetch content from a specific URL.
        
        Args:
            url: URL to fetch
            max_length: Maximum content length
            
        Returns:
            ToolResult with page content
        """
        if not self.enabled:
            return ToolResult.from_error("Web access is disabled")
        
        # Validate URL
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            return ToolResult.from_error("Only HTTP/HTTPS URLs are allowed")
        
        try:
            response = await self.client.get(url)
            response.raise_for_status()
            
            # Determine content type
            content_type = response.headers.get("content-type", "")
            
            if "text/html" in content_type or "text/plain" in content_type:
                # Text content - extract text
                content = response.text
                
                # Basic HTML tag removal
                if "text/html" in content_type:
                    content = re.sub(r'<script[^>]*>.*?</script>', '', content, flags=re.DOTALL | re.IGNORECASE)
                    content = re.sub(r'<style[^>]*>.*?</style>', '', content, flags=re.DOTALL | re.IGNORECASE)
                    content = re.sub(r'<[^>]+>', '\n', content)
                    content = re.sub(r'\n\s*\n+', '\n\n', content)
                    content = re.sub(r'[ \t]+', ' ', content)
                
                if len(content) > max_length:
                    content = content[:max_length] + "\n... [truncated]"
                
                return ToolResult.from_output(content.strip())
            
            else:
                # Binary or other content
                size = len(response.content)
                return ToolResult.from_output(
                    f"Fetched non-text content ({content_type}, {size} bytes)"
                )
                
        except httpx.HTTPStatusError as e:
            return ToolResult.from_error(f"HTTP {e.response.status_code}: {e.response.url}")
        except Exception as e:
            return ToolResult.from_error(f"Fetch failed: {type(e).__name__}: {e}")
