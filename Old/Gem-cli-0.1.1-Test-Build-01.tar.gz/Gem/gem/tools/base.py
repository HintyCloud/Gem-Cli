"""
Base Tool Classes

Defines the abstract tool interface and registry for managing available tools.
All tools inherit from the base Tool class and register with ToolRegistry.
"""

import json
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Type

logger = logging.getLogger(__name__)


@dataclass
class ToolResult:
    """
    Result of a tool execution.
    
    Attributes:
        success: Whether execution was successful
        output: Output content (stdout or result data)
        error: Error message if failed
        data: Additional structured data
    """
    success: bool
    output: str = ""
    error: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "success": self.success,
            "output": self.output,
            "error": self.error,
            "data": self.data,
        }
    
    def to_string(self) -> str:
        """Convert to string for LLM context."""
        if self.success:
            if self.output:
                return self.output
            return "Operation completed successfully"
        else:
            if self.error:
                return f"Error: {self.error}"
            return "Operation failed"
    
    @classmethod
    def from_output(cls, output: str) -> 'ToolResult':
        """Create successful result from output string."""
        return cls(success=True, output=output)
    
    @classmethod
    def from_error(cls, error: str) -> 'ToolResult':
        """Create failed result from error string."""
        return cls(success=False, error=error)


@dataclass
class ParameterDefinition:
    """Definition of a tool parameter."""
    name: str
    type: str  # "string", "integer", "number", "boolean", "object", "array"
    description: str
    required: bool = True
    default: Any = None
    enum: Optional[List[Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to JSON Schema format."""
        result: Dict[str, Any] = {
            "type": self.type,
            "description": self.description,
        }
        if self.enum:
            result["enum"] = self.enum
        if self.default is not None:
            result["default"] = self.default
        return result


class Tool(ABC):
    """
    Abstract base class for all tools.
    
    Tools must implement execute() and define their schema via properties.
    The registry system uses these to provide tool definitions to the LLM.
    """
    
    # Class-level attributes (override in subclasses)
    name: str = ""
    description: str = ""
    
    def __init_subclass__(cls, **kwargs):
        """Register tool classes automatically."""
        super().__init_subclass__(**kwargs)
        # Don't register abstract base classes
        if not getattr(cls, '__abstractmethods__', None) and cls.name:
            ToolRegistry._register_class(cls)
    
    @property
    @abstractmethod
    def parameters(self) -> List[ParameterDefinition]:
        """Return list of parameter definitions."""
        ...
    
    @abstractmethod
    async def execute(self, **kwargs) -> ToolResult:
        """
        Execute the tool with given parameters.
        
        Args:
            **kwargs: Parameter values
            
        Returns:
            ToolResult with execution outcome
        """
        ...
    
    def get_schema(self) -> Dict[str, Any]:
        """
        Get the function calling schema for this tool.
        
        Returns:
            OpenAI-compatible function definition
        """
        properties = {}
        required = []
        
        for param in self.parameters:
            properties[param.name] = param.to_dict()
            if param.required:
                required.append(param.name)
        
        schema: Dict[str, Any] = {
            "type": "object",
            "properties": properties,
        }
        
        if required:
            schema["required"] = required
        
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": schema,
            },
        }
    
    def validate_parameters(self, kwargs: Dict[str, Any]) -> tuple[bool, str]:
        """
        Validate parameters before execution.
        
        Args:
            kwargs: Parameters to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        param_names = {p.name for p in self.parameters}
        
        # Check required parameters
        for param in self.parameters:
            if param.required and param.name not in kwargs:
                return False, f"Missing required parameter: {param.name}"
        
        # Check for unknown parameters
        for key in kwargs:
            if key not in param_names:
                return False, f"Unknown parameter: {key}"
        
        return True, ""
    
    async def safe_execute(self, **kwargs) -> ToolResult:
        """
        Execute with validation and error handling.
        
        Args:
            **kwargs: Parameters
            
        Returns:
            ToolResult with proper error handling
        """
        try:
            is_valid, error_msg = self.validate_parameters(kwargs)
            if not is_valid:
                return ToolResult.from_error(f"Validation error: {error_msg}")
            
            return await self.execute(**kwargs)
            
        except PermissionError as e:
            logger.error(f"Permission denied in {self.name}: {e}")
            return ToolResult.from_error(f"Permission denied: {e}")
        except FileNotFoundError as e:
            logger.error(f"File not found in {self.name}: {e}")
            return ToolResult.from_error(f"Not found: {e}")
        except ValueError as e:
            logger.error(f"Invalid value in {self.name}: {e}")
            return ToolResult.from_error(f"Invalid value: {e}")
        except Exception as e:
            logger.exception(f"Unexpected error in {self.name}: {e}")
            return ToolResult.from_error(f"Execution error: {type(e).__name__}: {e}")


class ToolRegistry:
    """
    Registry for managing available tools.
    
    Provides lookup by name, schema generation for LLM context,
    and dynamic registration/unregistration of tools.
    """
    
    _tools: Dict[str, Type[Tool]] = {}
    _instances: Dict[str, Tool] = {}
    
    @classmethod
    def _register_class(cls, tool_class: Type[Tool]):
        """Register a tool class by its name."""
        if tool_class.name:
            cls._tools[tool_class.name] = tool_class
            logger.debug(f"Registered tool class: {tool_class.name}")
    
    @classmethod
    def register(cls, tool: Tool):
        """
        Register a tool instance.
        
        Args:
            tool: Tool instance to register
        """
        cls._instances[tool.name] = tool
        logger.debug(f"Registered tool instance: {tool.name}")
    
    @classmethod
    def unregister(cls, name: str):
        """
        Unregister a tool by name.
        
        Args:
            name: Tool name to remove
        """
        if name in cls._instances:
            del cls._instances[name]
            logger.debug(f"Unregistered tool: {name}")
    
    @classmethod
    def get(cls, name: str) -> Optional[Tool]:
        """
        Get a tool instance by name.
        
        Args:
            name: Tool name
            
        Returns:
            Tool instance or None if not found
        """
        # Return existing instance
        if name in cls._instances:
            return cls._instances[name]
        
        # Create instance from registered class
        if name in cls._tools:
            instance = cls._tools[name]()
            cls._instances[name] = instance
            return instance
        
        return None
    
    @classmethod
    def get_all(cls) -> List[Tool]:
        """Get all registered tool instances."""
        tools = []
        for name in cls._tools:
            if name not in cls._instances:
                cls._instances[name] = cls._tools[name]()
            tools.append(cls._instances[name])
        return tools
    
    @classmethod
    def get_names(cls) -> List[str]:
        """Get all registered tool names."""
        return list(cls._tools.keys())
    
    @classmethod
    def get_schemas(cls) -> List[Dict[str, Any]]:
        """
        Get all tool schemas for LLM function calling.
        
        Returns:
            List of OpenAI-compatible function definitions
        """
        schemas = []
        for tool in cls.get_all():
            try:
                schemas.append(tool.get_schema())
            except Exception as e:
                logger.warning(f"Failed to get schema for {tool.name}: {e}")
        return schemas
    
    @classmethod
    def has_tool(cls, name: str) -> bool:
        """Check if a tool is registered."""
        return name in cls._tools or name in cls._instances
    
    @classmethod
    def clear(cls):
        """Clear all registrations (useful for testing)."""
        cls._instances.clear()
        # Note: We don't clear _tools as class registration happens at import time
    
    @classmethod
    def create_instance(cls, name: str, **config) -> Optional[Tool]:
        """
        Create a new tool instance with custom configuration.
        
        Args:
            name: Tool name
            **config: Configuration parameters for the tool
            
        Returns:
            Configured tool instance or None
        """
        if name not in cls._tools:
            return None
        
        try:
            instance = cls._tools[name](**config)
            cls._instances[name] = instance
            return instance
        except Exception as e:
            logger.error(f"Failed to create tool {name}: {e}")
            return None


def create_function_tool(
    name: str,
    description: str,
    func: Callable,
    parameters: List[Dict[str, Any]],
) -> Tool:
    """
    Create a tool from a simple function.
    
    This is a convenience factory for creating tools without
    defining a full class.
    
    Args:
        name: Tool name
        description: Tool description
        func: Async function to execute
        parameters: Parameter definitions in JSON Schema format
        
    Returns:
        Tool instance wrapping the function
    """
    
    class FunctionTool(Tool):
        name = name
        description = description
        
        @property
        def parameters(self) -> List[ParameterDefinition]:
            params = []
            for p in parameters:
                params.append(ParameterDefinition(
                    name=p["name"],
                    type=p.get("type", "string"),
                    description=p.get("description", ""),
                    required=p.get("required", True),
                    default=p.get("default"),
                    enum=p.get("enum"),
                ))
            return params
        
        async def execute(self, **kwargs) -> ToolResult:
            try:
                result = func(**kwargs)
                if hasattr(result, '__await__'):
                    result = await result
                
                if isinstance(result, ToolResult):
                    return result
                elif isinstance(result, dict):
                    return ToolResult(success=True, output=json.dumps(result), data=result)
                else:
                    return ToolResult.from_output(str(result))
                    
            except Exception as e:
                return ToolResult.from_error(str(e))
    
    return FunctionTool()
