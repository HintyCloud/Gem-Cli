#!/usr/bin/env python3
"""
Test script to validate Gem AI Agent functionality.

This script tests the real agent loop by asking Gem to create a simple website.
It uses the actual OpenCode API with your credentials.
"""

import asyncio
import sys
import os

# Add project root to path
sys.path.insert(0, '/home/z/my-project/Gem')

from gem.providers.opencode import OpenCodeProvider
from gem.agent.loop import AgentLoop
from gem.tools.base import ToolRegistry


async def test_gem_creates_website():
    """Test that Gem can create a website using the real API."""
    
    print("=" * 60)
    print("GEM AI AGENT - REAL API TEST")
    print("=" * 60)
    print()
    
    # Initialize provider with your credentials
    print("[1/4] Initializing LLM provider...")
    provider = OpenCodeProvider(
        api_url="https://opencode.ai/zen/v1",
        api_key="sk-MN9kABCiW1cskBQ4EncGFV6DFwyHvshu6CrjtmuHUFwdkvJvAHNzql90BqTpNHMC",
        model="longcat-2.0-free",
        temperature=0.7,
        max_tokens=4096,
        timeout=120,
    )
    print("       ✓ Provider initialized")
    print(f"       Model: {provider.model}")
    print(f"       Endpoint: {provider.api_url}")
    print()
    
    # Create agent loop
    print("[2/4] Creating agent loop...")
    agent = AgentLoop(
        provider=provider,
        max_iterations=20,
        auto_plan=True,
        streaming=True,
        system_prompt="""You are Gem, an autonomous AI coding agent. You can execute shell commands, read/write files, and search the web.

For this task: Create a simple but beautiful website in /home/z/my-project/Gem/projects/test-website/

The website should:
- Be a single index.html file with embedded CSS
- Have a modern, clean design
- Include a header, main content area, and footer
- Be responsive (work on mobile)
- Use pleasant colors

After creating it, use shell tool to show the file size and location.""",
        on_tool_call=lambda name, args: print(f"       🔧 Tool: {name}({list(args.keys())})"),
        on_response_chunk=lambda chunk: print(chunk, end="", flush=True),
    )
    print("       ✓ Agent ready")
    print()
    
    # Available tools
    print("[3/4] Loading tools...")
    tools = ToolRegistry.get_names()
    print(f"       ✓ Tools loaded: {', '.join(tools)}")
    print()
    
    # Process request
    print("[4/4] Sending request to create a website...")
    print("-" * 60)
    print()
    
    try:
        result = await agent.process_message(
            "Create a beautiful personal portfolio website in the projects/test-website directory. "
            "Make it modern and responsive with nice colors."
        )
        
        print()
        print("-" * 60)
        print()
        
        if result.get("response"):
            print("✅ GEM RESPONSE:")
            print(result["response"])
        
        print()
        print(f"📊 Statistics:")
        print(f"   - Iterations: {result.get('iterations', 0)}")
        print(f"   - Tool calls: {len(result.get('tool_calls', []))}")
        
        if result.get("tool_calls"):
            print(f"   - Tools used:")
            for tc in result["tool_calls"]:
                print(f"      • {tc.get('tool', 'unknown')}")
        
        print()
        print("=" * 60)
        print("✅ TEST COMPLETED SUCCESSFULLY!")
        print("=" * 60)
        
        return True
        
    except Exception as e:
        print()
        print("-" * 60)
        print()
        print(f"❌ ERROR: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    finally:
        await provider.close()


if __name__ == "__main__":
    success = asyncio.run(test_gem_creates_website())
    sys.exit(0 if success else 1)
