#!/usr/bin/env python3
"""
Gem AI Agent - Create Website Test

Tests the full agent loop with tool calling to create a website.
"""

import asyncio
import sys
import os

sys.path.insert(0, '/home/z/my-project/Gem')

from gem.providers.opencode import OpenCodeProvider
from gem.agent.loop import AgentLoop


async def test_create_website():
    """Test creating a website with the agent."""
    
    print("=" * 60)
    print("GEM - CREATE WEBSITE TEST")
    print("=" * 60)
    print()
    
    # Initialize provider
    print("[1/3] Initializing...")
    provider = OpenCodeProvider(
        api_url="https://opencode.ai/zen/v1",
        api_key="sk-MN9kABCiW1cskBQ4EncGFV6DFwyHvshu6CrjtmuHUFwdkvJvAHNzql90BqTpNHMC",
        model="longcat-2.0-free",
        temperature=0.7,
        max_tokens=2000,
        timeout=90,
    )
    print(f"       Model: {provider.model}")
    print()
    
    # Create agent with simpler setup (no auto-plan to avoid issues)
    print("[2/3] Creating agent...")
    agent = AgentLoop(
        provider=provider,
        max_iterations=15,
        auto_plan=False,  # Disable planning for this test
        streaming=False,  # Use non-streaming for reliability
        system_prompt="""You are Gem, a coding assistant. You have access to tools:
- shell: Run commands (command, workdir, timeout)
- file: File operations (action: read/write/list/mkdir, path, content)
- web_search: Search the web (query)

TASK: Create a beautiful portfolio website.

Steps:
1. Use 'file' tool with action='mkdir' to create directory /home/z/my-project/Gem/projects/portfolio/
2. Use 'file' tool with action='write' to create index.html with complete HTML/CSS code
3. Use 'shell' tool to verify the file was created (ls -la command)

Create a modern, responsive single-page portfolio with:
- Header with name "John Doe" and nav
- Hero section with title and CTA
- About section
- Skills section  
- Contact section
- Footer
- Modern CSS with gradients, cards, shadows
- Mobile responsive design""",
    )
    print("       ✓ Agent ready")
    print()
    
    # Execute task
    print("[3/3] Creating website...")
    print("-" * 60)
    
    try:
        result = await agent.process_message(
            "Please create the portfolio website now. "
            "Make it professional and visually impressive."
        )
        
        print("-" * 60)
        print()
        
        if result.get("response"):
            print("📝 Final Response:")
            print(result["response"][:500])
            if len(result["response"]) > 500:
                print("... [truncated]")
        
        print()
        print("📊 Execution Stats:")
        print(f"   Iterations: {result.get('iterations', 0)}")
        print(f"   Tool calls: {len(result.get('tool_calls', []))}")
        
        if result.get("tool_calls"):
            print("\n🔧 Tools Used:")
            for i, tc in enumerate(result["tool_calls"], 1):
                print(f"   {i}. {tc.get('tool', '?')}")
        
        # Check if file was created
        website_path = "/home/z/my-project/Gem/projects/portfolio/index.html"
        if os.path.exists(website_path):
            size = os.path.getsize(website_path)
            print(f"\n✅ Website created successfully!")
            print(f"   Path: {website_path}")
            print(f"   Size: {size} bytes")
        else:
            print(f"\n⚠️  Website file not found at expected location")
        
        print()
        print("=" * 60)
        print("TEST COMPLETE")
        print("=" * 60)
        
        return True
        
    except Exception as e:
        print(f"\n❌ Error: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    finally:
        await provider.close()


if __name__ == "__main__":
    success = asyncio.run(test_create_website())
    sys.exit(0 if success else 1)
