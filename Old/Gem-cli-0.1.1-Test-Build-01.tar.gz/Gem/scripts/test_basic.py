#!/usr/bin/env python3
"""
Simplified test script for Gem AI Agent.

Tests basic API connectivity and simple response.
"""

import asyncio
import sys
import os

# Add project root to path
sys.path.insert(0, '/home/z/my-project/Gem')

from gem.providers.opencode import OpenCodeProvider


async def test_basic_api():
    """Test basic API functionality."""
    
    print("=" * 60)
    print("GEM AI AGENT - BASIC API TEST")
    print("=" * 60)
    print()
    
    # Initialize provider
    print("[1/3] Initializing provider...")
    provider = OpenCodeProvider(
        api_url="https://opencode.ai/zen/v1",
        api_key="sk-MN9kABCiW1cskBQ4EncGFV6DFwyHvshu6CrjtmuHUFwdkvJvAHNzql90BqTpNHMC",
        model="longcat-2.0-free",
        temperature=0.7,
        max_tokens=500,
        timeout=30,
    )
    print("       ✓ Provider initialized")
    print(f"       Model: {provider.model}")
    print()
    
    # Test basic chat (no tools)
    print("[2/3] Testing basic chat...")
    try:
        response = await provider.chat(
            message="Hello! Please respond with a brief greeting and confirm you are working.",
            system_prompt="You are a helpful assistant. Be concise.",
            temperature=0.5,
        )
        
        print("       ✓ Got response!")
        print(f"       Content: {response.content[:200]}...")
        print(f"       Model: {response.model}")
        print(f"       Finish reason: {response.finish_reason}")
        if response.usage:
            print(f"       Tokens: {response.usage}")
        print()
        
    except Exception as e:
        print(f"       ✗ Error: {e}")
        await provider.close()
        return False
    
    # Test streaming
    print("[3/3] Testing streaming...")
    try:
        print("       Response: ", end="", flush=True)
        
        async for chunk in provider.chat_stream(
            message="Say 'Streaming works!' and nothing else.",
            temperature=0.3,
        ):
            if isinstance(chunk, str):
                print(chunk, end="", flush=True)
        
        print()
        print("       ✓ Streaming complete!")
        print()
        
    except Exception as e:
        print(f"       ✗ Error: {e}")
    
    # Cleanup
    await provider.close()
    
    print("=" * 60)
    print("✅ BASIC TEST COMPLETED!")
    print("=" * 60)
    
    return True


if __name__ == "__main__":
    success = asyncio.run(test_basic_api())
    sys.exit(0 if success else 1)
