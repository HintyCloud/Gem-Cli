"""
Tests for CLI Interface (cli.py)

Covers CLI initialization, command handling, output formatting,
and integration with other components.
"""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from pathlib import Path

try:
    from gem.cli import GemCLI, Colors, main
    HAS_CLI = True
except ImportError:
    HAS_CLI = False


@pytest.mark.skipif(not HAS_CLI, reason="CLI dependencies not available")
class TestGemCLIInit:
    """Test CLI initialization."""
    
    def test_init_defaults(self):
        """Test default initialization."""
        cli = GemCLI()
        
        assert cli.workspace == Path.cwd()
        assert cli.no_color is False
    
    def test_init_custom(self):
        """Test custom configuration."""
        cli = GemCLI(
            workspace="/tmp/test",
            no_color=True,
            config_path="custom.toml",
        )
        
        assert str(cli.workspace) == "/tmp/test"
        assert cli.no_color is True
    
    def test_load_configuration(self, tmp_path):
        """Load configuration from file."""
        config_file = tmp_path / "config.toml"
        config_file.write_text('[model]\ndefault_model = "test-model"\n')
        
        cli = GemCLI(config_path=str(config_file))
        
        assert cli.config.get("model", {}).get("default_model") == "test-model"


@pytest.mark.skipif(not HAS_CLI, reason="CLI dependencies not available")
class TestCLIOutputMethods:
    """Test output and display methods."""
    
    @pytest.fixture
    def cli(self):
        """Create a CLI instance (without Rich if unavailable)."""
        return GemCLI(no_color=True)
    
    def test_print_banner_no_rich(self, cli, capsys):
        """Print banner without Rich library."""
        # Force non-rich mode
        cli.rich_mode = False
        
        cli.print_banner()
        
        captured = capsys.readouterr()
        assert "GEM" in captured.out or "Gem" in captured.out or "█" in captured.out
    
    def test_print_message_user(self, cli, capsys):
        """Print user message."""
        cli.rich_mode = False
        cli.print_message("user", "Hello!")
        
        captured = capsys.readouterr()
        assert "You" in captured.out or "hello" in captured.out.lower()
    
    def test_print_message_assistant(self, cli, capsys):
        """Print assistant message."""
        cli.rich_mode = False
        cli.print_message("assistant", "Response here")
        
        captured = capsys.readouterr()
        assert "Gem" in captured.out or "response" in captured.out.lower()
    
    def test_print_info(self, cli, capsys):
        """Print info message."""
        cli.rich_mode = False
        cli.print_info("Information")
        
        captured = capsys.readouterr()
        assert "Information" in captured.out
    
    def test_print_success(self, cli, capsys):
        """Print success message."""
        cli.rich_mode = False
        cli.print_success("Operation successful!")
        
        captured = capsys.readouterr()
        assert "successful" in captured.out.lower() or "Operation" in captured.out
    
    def test_print_error(self, cli, capsys):
        """Print error message."""
        cli.rich_mode = False
        cli.print_error("Something went wrong")
        
        captured = capsys.readouterr()
        assert "wrong" in captured.out.lower() or "Something" in captured.out
    
    def test_print_tool_indicator(self, cli, capsys):
        """Print tool execution indicator."""
        cli.rich_mode = False
        cli.print_tool_indicator("shell", {"command": "ls"})
        
        captured = capsys.readouterr()
        assert "shell" in captured.out


@pytest.mark.skipif(not HAS_CLI, reason="CLI dependencies not available")
class TestCLICommands:
    """Test slash command handling."""
    
    @pytest.fixture
    def cli(self):
        """Create a CLI instance for testing commands."""
        return GemCLI(no_color=True)
    
    @pytest.mark.asyncio
    async def test_cmd_help(self, cli, capsys):
        """Help command shows available commands."""
        cli.rich_mode = False
        
        result = await cli.cmd_help("")
        
        assert result is True  # Should continue running
        
        captured = capsys.readouterr()
        assert "help" in captured.out.lower() or "/" in captured.out
    
    @pytest.mark.asyncio
    async def test_cmd_clear(self, cli):
        """Clear command resets context."""
        # Need to initialize components first
        with patch.object(cli, '_init_components'):
            cli.agent = MagicMock()
            cli.agent.reset = MagicMock()
            
            result = await cli.cmd_clear("")
            
            assert result is True
            cli.agent.reset.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_cmd_reset(self, cli):
        """Reset command creates new session."""
        with patch.object(cli, '_init_components'):
            cli.agent = MagicMock()
            cli.history = MagicMock()
            cli.history.create_session = MagicMock(return_value=MagicMock())
            
            result = await cli.cmd_reset("")
            
            assert result is True
            cli.agent.reset.assert_called_once()
            cli.history.create_session.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_cmd_model_get(self, cli, capsys):
        """Model command without args shows current model."""
        cli.provider = MagicMock()
        cli.provider.model = "test-model-123"
        cli.rich_mode = False
        
        result = await cli.cmd_model("")
        
        assert result is True
        
        captured = capsys.readouterr()
        assert "test-model-123" in captured.out
    
    @pytest.mark.asyncio
    async def test_cmd_model_set(self, cli):
        """Model command with arg changes model."""
        cli.provider = MagicMock()
        
        result = await cli.cmd_model("new-model")
        
        assert result is True
        assert cli.provider.model == "new-model"
    
    @pytest.mark.asyncio
    async def test_cmd_status(self, cli, capsys):
        """Status command shows agent status."""
        cli.agent = MagicMock()
        cli.agent.get_status.return_value = {
            "running": False,
            "cancelled": False,
            "context": {"iteration": 5, "usage_ratio": 0.3},
            "has_plan": False,
        }
        cli.rich_mode = False
        
        result = await cli.cmd_status("")
        
        assert result is True
        
        captured = capsys.readouterr()
        assert "Status" in captured.out or "status" in captured.out.lower()
    
    @pytest.mark.asyncio
    async def test_cmd_quit(self):
        """Quit command returns False to exit."""
        from gem.cli import cmd_quit
        
        result = await cmd_quit("")
        
        assert result is False
    
    @pytest.mark.asyncio
    async def test_unknown_command(self, cli, capsys):
        """Unknown command shows error."""
        cli.rich_mode = False
        
        result = await cli.handle_command("nonexistentcommand", "")
        
        assert result is True  # Continue running
        
        captured = capsys.readouterr()
        assert "Unknown" in captured.out or "unknown" in captured.out.lower()


@pytest.mark.skipif(not HAS_CLI, reason="CLI dependencies not available")
class TestCLIMainLoop:
    """Test main interactive loop functionality."""
    
    @pytest.fixture
    def initialized_cli(self):
        """Create fully initialized CLI for testing."""
        cli = GemCLI(no_color=True)
        
        # Mock all components
        with patch.object(cli, '_init_components'):
            cli.provider = MagicMock()
            cli.agent = MagicMock()
            cli.history = MagicMock()
            cli.memory = MagicMock()
            
            # Setup agent.process_message to return simple response
            async def mock_process(msg, **kwargs):
                return {
                    "response": f"Processed: {msg}",
                    "tool_calls": [],
                    "iterations": 1,
                }
            cli.agent.process_message = mock_process
            
            # Setup history
            session = MagicMock()
            session.id = "test_session"
            cli.history.create_session.return_value = session
            cli.history._current_session_id = "test_session"
            cli.history.add_message = MagicMock(return_value=MagicMock())
        
        return cli
    
    @pytest.mark.asyncio
    async def test_process_regular_message(self, initialized_cli, capsys):
        """Process regular user message (not command)."""
        initialized_cli.rich_mode = False
        
        await initialized_cli._process_user_message("Hello Gem!")
        
        # Should have called process_message on agent
        initialized_cli.agent.process_message.assert_called_once()
        
        # Check output contains response
        captured = capsys.readouterr()
        assert "Processed" in captured.out or "Hello" in captured.out
    
    @pytest.mark.asyncio
    async def test_process_command_not_forwarded(self, initialized_cli):
        """Commands are not forwarded to agent."""
        initialized_cli.running = True
        
        # This would normally be caught before _process_user_message
        # but we can verify the flow
        result = await initialized_cli.handle_command("help", "")
        
        assert result is True  # Help doesn't exit


@pytest.mark.skipif(not HAS_CLI, reason="CLI dependencies not available")
class TestCLIIntegration:
    """Integration tests for CLI components."""
    
    def test_init_components_creates_provider(self, tmp_path):
        """Initialization creates provider with correct config."""
        cli = GemCLI(workspace=str(tmp_path))
        
        with patch.dict('os.environ', {'GEM_API_KEY': 'test-key-for-init'}):
            cli._init_components()
        
        assert cli.provider is not None
        assert cli.agent is not None
        assert cli.history is not None
        assert cli.memory is not None
    
    def test_cleanup_closes_provider(self):
        """Cleanup closes HTTP client."""
        cli = GemCLI()
        cli.provider = MagicMock()
        
        cli._cleanup()
        
        # Note: This runs the close coroutine
        assert True  # If we get here without error, cleanup worked


class TestColorsFallback:
    """Test ANSI color codes fallback class."""
    
    def test_colors_exist(self):
        """Color constants are defined."""
        assert hasattr(Colors, 'RESET')
        assert hasattr(Colors, 'GREEN')
        assert hasattr(Colors, 'BLUE')
        assert hasattr(Colors, 'RED')
    
    def test_colors_are_strings(self):
        """Color values are strings starting with escape."""
        assert Colors.RESET.startswith('\033')
        assert Colors.GREEN.startswith('\033')


@pytest.mark.skipif(not HAS_CLI, reason="CLI dependencies not available")  
class TestMainEntryPoint:
    """Test main entry point."""
    
    def test_main_exists(self):
        """Main function exists and is callable."""
        assert callable(main)
