"""
Tests for Task Planner (planner.py)

Covers task planning, complexity analysis, plan creation,
and execution tracking.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from gem.agent.planner import (
    TaskPlanner,
    PlanStep,
    ExecutionPlan,
    sentence_count,
)


class TestPlanStep:
    """Test PlanStep dataclass."""
    
    def test_create_step(self):
        """Create a basic plan step."""
        step = PlanStep(
            id=1,
            description="Create project structure",
            tools=["shell", "file"],
        )
        
        assert step.id == 1
        assert step.description == "Create project structure"
        assert "shell" in step.tools
        assert step.status == "pending"
    
    def test_step_to_dict(self):
        """Convert step to dictionary."""
        step = PlanStep(
            id=2,
            description="Write code",
            dependencies=[1],
        )
        
        d = step.to_dict()
        
        assert d["id"] == 2
        assert d["description"] == "Write code"
        assert 1 in d["dependencies"]
    
    def test_step_from_dict(self):
        """Create step from dictionary."""
        data = {
            "id": 3,
            "description": "Test the code",
            "tools": ["shell"],
            "dependencies": [1, 2],
            "status": "pending",
        }
        
        step = PlanStep.from_dict(data)
        
        assert step.id == 3
        assert len(step.dependencies) == 2
        assert step.status == "pending"


class TestExecutionPlan:
    """Test ExecutionPlan dataclass and methods."""
    
    @pytest.fixture
    def sample_plan(self):
        """Create a sample execution plan for testing."""
        return ExecutionPlan(
            goal="Build a simple web server",
            steps=[
                PlanStep(id=1, description="Create directory structure", tools=["shell"]),
                PlanStep(id=2, description="Write main file", tools=["file"], dependencies=[1]),
                PlanStep(id=3, description="Test the server", tools=["shell"], dependencies=[1, 2]),
            ],
            estimated_complexity=0.5,
        )
    
    def test_plan_properties(self, sample_plan):
        """Test plan property calculations."""
        assert sample_plan.total_steps == 3
        assert sample_plan.completed_steps == 0
        assert not sample_plan.is_complete
    
    def test_current_step_pending(self, sample_plan):
        """Get current (next pending) step."""
        current = sample_plan.current_step
        
        assert current is not None
        assert current.id == 1
        assert current.status == "pending"
    
    def test_get_next_step_no_dependencies(self, sample_plan):
        """Get next executable step (no deps)."""
        next_step = sample_plan.get_next_step()
        
        assert next_step is not None
        assert next_step.id == 1
    
    def test_get_next_step_with_completed_deps(self, sample_plan):
        """Get next step after completing dependencies."""
        # Complete step 1
        sample_plan.mark_step_status(1, "completed")
        
        next_step = sample_plan.get_next_step()
        
        # Should be step 2 now (step 3 still needs step 2)
        assert next_step.id == 2
    
    def test_mark_step_status(self, sample_plan):
        """Update step status."""
        sample_plan.mark_step_status(1, "in_progress")
        
        assert sample_plan.steps[0].status == "in_progress"
    
    def test_complete_all_steps(self, sample_plan):
        """Mark all steps complete."""
        for step in sample_plan.steps:
            sample_plan.mark_step_status(step.id, "completed")
        
        assert sample_plan.is_complete
        assert sample_plan.completed_steps == 3
        assert sample_plan.current_step is None
    
    def test_to_dict(self, sample_plan):
        """Serialize plan to dict."""
        d = sample_plan.to_dict()
        
        assert d["goal"] == "Build a simple web server"
        assert len(d["steps"]) == 3
        assert d["estimated_complexity"] == 0.5
    
    def test_from_dict(self):
        """Deserialize plan from dict."""
        data = {
            "goal": "Deploy application",
            "steps": [
                {"id": 1, "description": "Build", "tools": ["shell"], "dependencies": [], "expectedOutput": "", "status": "pending"},
                {"id": 2, "description": "Deploy", "tools": ["shell"], "dependencies": [1], "expectedOutput": "", "status": "pending"},
            ],
            "estimated_complexity": 0.4,
            "requiresConfirmation": True,
            "metadata": {},
        }
        
        plan = ExecutionPlan.from_dict(data)
        
        assert plan.goal == "Deploy application"
        assert plan.total_steps == 2
        assert plan.requires_confirmation is True
    
    def test_display_string(self, sample_plan):
        """Generate display string for user."""
        display = sample_plan.to_display_string()
        
        assert "Execution Plan" in display
        assert "Build a simple web server" in display
        assert "Step 1" in display
        assert "Step 2" in display


class TestTaskPlanner:
    """Test TaskPlanner class."""
    
    @pytest.fixture
    def mock_provider(self):
        """Create a mock provider for planner testing."""
        provider = MagicMock()
        provider.model = "test-model"
        provider.api_url = "https://test.api/v1"
        return provider
    
    @pytest.fixture
    def planner(self, mock_provider):
        """Create a TaskPlanner instance."""
        return TaskPlanner(
            provider=mock_provider,
            complexity_threshold=0.3,
        )
    
    @pytest.mark.asyncio
    async def test_analyze_complexity_simple(self, planner):
        """Analyze complexity of a simple request."""
        score = await planner.analyze_complexity("hello")
        
        # Simple request should have low complexity
        assert score < 0.5
    
    @pytest.mark.asyncio
    async def test_analyze_complexity_multi_step(self, planner):
        """Analyze complexity of multi-step request."""
        score = await planner.analyze_complexity(
            "create a new project, then build it, and finally deploy to production"
        )
        
        # Multi-step request should have higher complexity
        assert score > 0.3
    
    @pytest.mark.asyncio
    async def test_analyze_complexity_build_request(self, planner):
        """Analyze complexity of build/create requests."""
        score = await planner.analyze_complexity("build me a REST API with database")
        
        # Build requests should be moderately complex
        assert score >= 0.3
    
    @pytest.mark.asyncio
    async def test_should_plan_simple(self, planner):
        """Should not plan simple requests."""
        should_plan, score = await planner.should_plan("what is 2+2")
        
        assert should_plan is False or score < 0.3
    
    @pytest.mark.asyncio
    async def test_should_plan_complex(self, planner):
        """Should plan complex requests."""
        should_plan, score = await planner.should_plan(
            "create a full-stack web application with authentication"
        )
        
        assert should_plan is True or score > 0.3
    
    @pytest.mark.asyncio
    async def test_create_plan_success(self, planner, mock_provider):
        """Test successful plan creation."""
        # Mock LLM response
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "choices": [{
                "message": {
                    "content": json.dumps({
                        "goal": "Create a Python script",
                        "complexity": 0.4,
                        "requiresConfirmation": False,
                        "steps": [
                            {
                                "id": 1,
                                "description": "Create main.py file",
                                "tools": ["file"],
                                "dependencies": [],
                                "expectedOutput": "File created",
                            },
                            {
                                "id": 2,
                                "description": "Run the script",
                                "tools": ["shell"],
                                "dependencies": [1],
                                "expectedOutput": "Script output",
                            }
                        ]
                    })
                }
            }]
        }
        mock_response.raise_for_status = MagicMock()
        
        mock_provider.client.post.return_value = asyncio.Future() if False else mock_response
        
        # Actually we need to make this work properly
        async def mock_post(*args, **kwargs):
            r = MagicMock()
            r.json.return_value = {
                "choices": [{
                    "message": {
                        "content": json.dumps({
                            "goal": "Create a Python script",
                            "complexity": 0.4,
                            "requiresConfirmation": False,
                            "steps": [
                                {
                                    "id": 1,
                                    "description": "Create main.py file",
                                    "tools": ["file"],
                                    "dependencies": [],
                                    "expectedOutput": "File created",
                                }
                            ]
                        })
                    }
                }]
            }
            r.raise_for_status = MagicMock()
            return r
        
        mock_provider.client.post = mock_post
        
        plan = await planner.create_plan("make a python script")
        
        assert plan is not None
        assert plan.goal is not None
        assert len(plan.steps) >= 1
    
    @pytest.mark.asyncio
    async def test_create_plan_no_provider(self):
        """Test plan creation fails gracefully without provider."""
        planner = TaskPlanner(provider=None)
        
        plan = await planner.create_plan("test")
        
        assert plan is None
    
    @pytest.mark.asyncio
    async def test_create_plan_parse_error(self, planner, mock_provider):
        """Test handling of invalid LLM response."""
        async def mock_post(*args, **kwargs):
            r = MagicMock()
            r.json.return_value = {
                "choices": [{
                    "message": {
                        "content": "This is not valid JSON at all!"
                    }
                }]
            }
            r.raise_for_status = MagicMock()
            return r
        
        mock_provider.client.post = mock_post
        
        plan = await planner.create_plan("test")
        
        # Should handle parse error gracefully
        # Either returns None or a fallback plan
        assert plan is None or isinstance(plan, ExecutionPlan)
    
    def test_create_simple_plan(self, planner):
        """Test creating a simple single-step plan."""
        plan = planner.create_simple_plan("run ls -la")
        
        assert plan.goal == "run ls -la"
        assert plan.total_steps == 1
        assert not plan.requires_confirmation
        assert plan.estimated_complexity < 0.5
    
    def test_parse_plan_response_valid_json(self, planner):
        """Parse valid JSON plan response."""
        valid_json = json.dumps({
            "goal": "Test goal",
            "complexity": 0.5,
            "steps": [{"id": 1, "description": "Do something"}]
        })
        
        result = planner._parse_plan_response(valid_json)
        
        assert result is not None
        assert result["goal"] == "Test goal"
    
    def test_parse_plan_response_markdown_code_block(self, planner):
        """Parse JSON from markdown code block."""
        markdown = """
Some text here

```json
{
    "goal": "From markdown",
    "complexity": 0.6,
    "steps": []
}
```

More text
"""
        result = planner._parse_plan_response(markdown)
        
        assert result is not None
        assert result["goal"] == "From markdown"
    
    def test_parse_plan_response_invalid(self, planner):
        """Handle invalid JSON gracefully."""
        invalid_responses = [
            "This is just plain text",
            "{invalid: json}",
            "",
            "```python\nprint('hello')\n```",
        ]
        
        for invalid in invalid_responses:
            result = planner._parse_plan_response(invalid)
            assert result is None


class TestSentenceCount:
    """Test sentence counting utility function."""
    
    def test_single_sentence(self):
        assert sentence_count("Hello world.") == 1
    
    def test_multiple_sentences(self):
        text = "First sentence. Second! Third?"
        count = sentence_count(text)
        assert count == 3
    
    def test_empty_string(self):
        assert sentence_count("") == 0
    
    def test_no_sentence_endings(self):
        assert sentence_count("Just some words") <= 1
