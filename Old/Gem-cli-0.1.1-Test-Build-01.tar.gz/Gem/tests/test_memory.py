"""
Tests for Persistent Memory (memory.py)

Covers fact storage, retrieval, preferences, search,
export/import, and cleanup operations.
"""

import asyncio
import json
import pytest
from pathlib import Path

from gem.memory.memory import PersistentMemory


class TestPersistentMemoryInit:
    """Test PersistentMemory initialization."""
    
    def test_init_defaults(self):
        """Test default values."""
        mem = PersistentMemory()
        
        assert mem.auto_save is True
        assert mem.max_facts == 500
        assert len(mem._facts) == 0
    
    def test_init_custom(self):
        """Test custom configuration."""
        mem = PersistentMemory(
            max_facts=100,
            auto_save=False,
        )
        
        assert mem.max_facts == 100
        assert mem.auto_save is False
    
    def test_creates_storage_directory(self, tmp_path):
        """Storage directory is created."""
        mem = PersistentMemory(storage_path=str(tmp_path / "memory"))
        
        assert mem.storage_path.exists()


class TestPersistentMemoryFacts:
    """Test fact storage and retrieval."""
    
    @pytest.fixture
    def memory(self, tmp_path):
        """Create a PersistentMemory instance with temp storage."""
        return PersistentMemory(storage_path=str(tmp_path / "memory"), auto_save=False)
    
    def test_add_fact(self, memory):
        """Add a new fact."""
        fact_id = memory.add_fact(
            content="Python is a programming language",
            category="knowledge",
            tags=["programming", "python"],
        )
        
        assert len(fact_id) > 0  # Should have an ID
        assert fact_id in memory._facts
        
        # Check content
        fact = memory._facts[fact_id]
        assert "Python" in fact["content"]
        assert fact["category"] == "knowledge"
    
    def test_add_duplicate_fact(self, memory):
        """Adding same content returns same ID."""
        id1 = memory.add_fact("Same content", category="test")
        id2 = memory.add_fact("Same content", category="test")
        
        assert id1 == id2  # Same content = same ID (deterministic)
    
    def test_get_fact(self, memory):
        """Retrieve a specific fact."""
        fact_id = memory.add_fact("Test fact", category="general")
        
        result = memory.get_fact(fact_id)
        
        assert result is not None
        assert result["content"] == "Test fact"
        assert result["access_count"] >= 1  # Access increments count
    
    def test_get_nonexistent_fact(self, memory):
        """Getting nonexistent fact returns None."""
        result = memory.get_fact("nonexistent_id")
        
        assert result is None
    
    def test_update_fact(self, memory):
        """Update an existing fact."""
        fact_id = memory.add_fact("Original content")
        
        success = memory.update_fact(fact_id, content="Updated content")
        
        assert success is True
        assert memory._facts[fact_id]["content"] == "Updated content"
    
    def test_update_nonexistent_fact(self, memory):
        """Updating nonexistent fact fails."""
        success = memory.update_fact("nonexistent", content="new")
        
        assert success is False
    
    def test_delete_fact(self, memory):
        """Delete a fact."""
        fact_id = memory.add_fact("To be deleted")
        
        success = memory.delete_fact(fact_id)
        
        assert success is True
        assert fact_id not in memory._facts
    
    def test_delete_nonexistent_fact(self, memory):
        """Deleting nonexistent fact returns False."""
        success = memory.delete_fact("nonexistent")
        
        assert success is False


class TestPersistentMemorySearch:
    """Test fact search functionality."""
    
    @pytest.fixture
    def populated_memory(self, tmp_path):
        """Create memory with sample facts."""
        mem = PersistentMemory(storage_path=str(tmp_path / "memory"), auto_save=False)
        
        mem.add_fact("Python is great for data science", category="tech", tags=["python", "data"])
        mem.add_fact("JavaScript powers the web", category="tech", tags=["javascript", "web"])
        mem.add_fact("The user prefers dark mode", category="preference", tags=["ui"])
        mem.add_fact("Project uses React framework", category="project", tags=["react", "frontend"])
        
        return mem
    
    def test_search_by_text(self, populated_memory):
        """Search by text content."""
        results = populated_memory.search_facts("python")
        
        assert len(results) >= 1
        assert all("python" in r["content"].lower() for r in results)
    
    def test_search_by_category(self, populated_memory):
        """Search filtered by category."""
        results = populated_memory.search_facts("", category="preference")
        
        assert len(results) >= 1
        assert all(r.get("category") == "preference" for r in results)
    
    def test_search_by_tag(self, populated_memory):
        """Search filtered by tag."""
        results = populated_memory.search_facts("", tags=["web"])
        
        assert len(results) >= 1
        # Results should have web tag
        for r in results:
            assert "web" in r.get("tags", [])
    
    def test_search_combined_filters(self, populated_memory):
        """Search with multiple filters."""
        results = populated_memory.search_facts(
            query="",
            category="tech",
            tags=["data"],
        )
        
        # Should match facts that are both tech AND have data tag
        for r in results:
            assert r.get("category") == "tech"
            assert "data" in r.get("tags", [])
    
    def test_search_limit(self, populated_memory):
        """Search respects limit parameter."""
        results = populated_memory.search_facts("", limit=2)
        
        assert len(results) <= 2
    
    def test_search_no_results(self, populated_memory):
        """Search returns empty when no matches."""
        results = populated_memory.search_facts("xyznonexistent123")
        
        assert len(results) == 0
    
    def test_get_by_category(self, populated_memory):
        """Get all facts in a category."""
        tech_facts = populated_memory.get_by_category("tech")
        
        assert len(tech_facts) >= 2  # We added at least 2 tech facts
        assert all(f.get("category") == "tech" for f in tech_facts)
    
    def test_get_by_tag(self, populated_memory):
        """Get all facts with a tag."""
        python_facts = populated_memory.get_by_tag("python")
        
        assert len(python_facts) >= 1
        for f in python_facts:
            assert "python" in f.get("tags", [])


class TestPersistentMemoryTags:
    """Test tag management on facts."""
    
    @pytest.fixture
    def memory(self, tmp_path):
        return PersistentMemory(storage_path=str(tmp_path / "memory"), auto_save=False)
    
    def test_add_tags(self, memory):
        """Add tags to a fact."""
        fact_id = memory.add_fact("Tagged fact")
        
        success = memory.add_tags(fact_id, ["tag1", "tag2", "tag3"])
        
        assert success is True
        assert "tag1" in memory._tags[fact_id]
        assert "tag2" in memory._tags[fact_id]
    
    def test_add_tags_nonexistent(self, memory):
        """Adding tags to nonexistent fact fails."""
        success = memory.add_tags("nonexistent", ["tag1"])
        
        assert success is False
    
    def test_remove_tags(self, memory):
        """Remove tags from a fact."""
        fact_id = memory.add_fact("Fact with removable tags", tags=["keep", "remove"])
        
        success = memory.remove_tags(fact_id, ["remove"])
        
        assert success is True
        assert "remove" not in memory._tags[fact_id]
        assert "keep" in memory._tags[fact_id]


class TestPersistentMemoryPreferences:
    """Test preference management."""
    
    @pytest.fixture
    def memory(self, tmp_path):
        return PersistentMemory(storage_path=str(tmp_path / "memory"), auto_save=False)
    
    def test_set_preference(self, memory):
        """Set a preference value."""
        memory.set_preference("theme", "dark")
        
        assert memory._preferences["theme"] == "dark"
    
    def test_get_preference(self, memory):
        """Get a preference value."""
        memory._preferences["language"] = "en"
        
        value = memory.get_preference("language")
        
        assert value == "en"
    
    def test_get_preference_default(self, memory):
        """Get preference returns default when missing."""
        value = memory.get_preference("nonexistent", "default_value")
        
        assert value == "default_value"
    
    def test_get_all_preferences(self, memory):
        """Get all preferences."""
        memory.set_preference("pref1", "val1")
        memory.set_preference("pref2", "val2")
        
        all_prefs = memory.get_all_preferences()
        
        assert all_prefs["pref1"] == "val1"
        assert all_prefs["pref2"] == "val2"
    
    def test_delete_preference(self, memory):
        """Delete a preference."""
        memory.set_preference("to_delete", "value")
        
        success = memory.delete_preference("to_delete")
        
        assert success is True
        assert "to_delete" not in memory._preferences
    
    def test_delete_nonexistent_preference(self, memory):
        """Deleting nonexistent preference returns False."""
        success = memory.delete_preference("nonexistent")
        
        assert success is False


class TestPersistentMemoryContext:
    """Test context generation for prompts."""
    
    @pytest.fixture
    def memory_with_context(self, tmp_path):
        """Create memory with context-worthy data."""
        mem = PersistentMemory(storage_path=str(tmp_path / "memory"), auto_save=False)
        
        # Add preferences
        mem.set_preference("editor", "vscode")
        mem.set_preference("language", "python")
        
        # Add some remembered facts
        mem.add_fact("User is working on a ML project", category="project")
        mem.add_fact("User prefers concise responses", category="preference")
        
        return mem
    
    def test_context_includes_preferences(self, memory_with_context):
        """Context includes user preferences."""
        context = memory_with_context.get_context_for_prompt(max_chars=500)
        
        assert "Preferences" in context or "preferences" in context.lower()
        assert "vscode" in context or "editor" in context.lower()
    
    def test_context_includes_facts(self, memory_with_context):
        """Context includes important facts."""
        context = memory_with_context.get_context_for_prompt(max_chars=500)
        
        assert "Remembered" in context or "ML project" in context or "concise" in context.lower()
    
    def test_context_truncation(self, tmp_path):
        """Context is truncated when too long."""
        mem = PersistentMemory(storage_path=str(tmp_path / "memory"), auto_save=False)
        
        # Add many preferences and facts
        for i in range(50):
            mem.set_preference(f"pref_{i}", f"value_{i}" * 10)
            mem.add_fact(f"Fact content {i} " * 20, category="general")
        
        context = mem.get_context_for_prompt(max_chars=200)
        
        assert len(context) <= 250  # Allow some margin for truncation message


class TestPersistentMemoryPersistence:
    """Test save/load functionality."""
    
    def test_save_creates_file(self, tmp_path):
        """Saving creates a file on disk."""
        mem = PersistentMemory(storage_path=str(tmp_path / "memory"))
        mem.add_fact("Persist this fact")
        
        assert mem.memory_file.exists()
    
    def test_load_existing_data(self, tmp_path):
        """Loading restores saved data."""
        # Create and populate
        mem1 = PersistentMemory(storage_path=str(tmp_path / "memory"))
        mem1.add_fact("Saved fact", category="loaded")
        mem1.set_preference("saved_pref", "saved_val")
        
        # Create new instance pointing to same location
        mem2 = PersistentMemory(storage_path=str(tmp_path / "memory"))
        
        # Should have loaded the data
        assert len(mem2._facts) > 0 or "saved_pref" in mem2._preferences
    
    def test_export_json(self, tmp_path, memory):
        """Export memory to JSON file."""
        memory.add_fact("Export me")
        memory.set_preference("export_pref", "export_val")
        
        export_path = str(tmp_path / "export.json")
        path = memory.export_json(export_path)
        
        assert Path(path).exists()
        
        # Verify JSON structure
        with open(path) as f:
            data = json.load(f)
        
        assert "facts" in data
        assert "preferences" in data
        assert "exported_at" in data
    
    def test_import_json(self, tmp_path, memory):
        """Import memory from JSON file."""
        import_data = {
            "facts": {
                "fact123": {"content": "Imported fact", "category": "imported", "created_at": 1000.0}
            },
            "preferences": {"imported_pref": "imported_val"},
            "tags": {},
        }
        
        import_file = tmp_path / "import.json"
        import_file.write_text(json.dumps(import_data))
        
        memory.import_json(str(import_file), merge=True)
        
        # Should have imported data
        assert "fact123" in memory._facts or "imported_pref" in memory._preferences


class TestPersistentMemoryCleanup:
    """Test cleanup operations."""
    
    @pytest.fixture
    def memory(self, tmp_path):
        return PersistentMemory(
            storage_path=str(tmp_path / "memory"),
            max_facts=5,
            auto_save=False,
        )
    
    def test_prune_old_facts(self, memory):
        """Old facts are pruned when over limit."""
        # Add more than max_facts
        for i in range(10):
            memory.add_fact(f"Fact number {i}")
        
        # Trigger prune via save
        memory._save()
        
        assert len(memory._facts) <= memory.max_facts
    
    def test_cleanup_expired(self, tmp_path):
        """Expired facts are removed."""
        import time
        
        mem = PersistentMemory(
            storage_path=str(tmp_path / "memory"),
            auto_save=False,
        )
        
        # Add expired fact
        past_time = time.time() - 3600  # 1 hour ago
        mem._facts["expired_1"] = {
            "content": "Expired fact",
            "expires": past_time,
        }
        
        removed = mem.cleanup_expired()
        
        assert removed >= 1
        assert "expired_1" not in mem._facts


class TestPersistentMemoryMerge:
    """Test merging memory stores."""
    
    def test_merge(self, tmp_path):
        """Merge two memory stores."""
        mem1 = PersistentMemory(storage_path=str(tmp_path / "mem1"), auto_save=False)
        mem2 = PersistentMemory(storage_path=str(tmp_path / "mem2"), auto_save=False)
        
        mem1.add_fact("From mem1", category="source1")
        mem1.set_preference("mem1_pref", "val1")
        
        mem2.add_fact("From mem2", category="source2")
        mem2.set_preference("mem2_pref", "val2")
        
        mem1.merge_memory(mem2)
        
        # Should have both
        assert any("From mem1" in f.get("content", "") for f in mem1._facts.values())
        assert any("From mem2" in f.get("content", "") for f in mem1._facts.values())
        assert "mem1_pref" in mem1._preferences
        assert "mem2_pref" in mem1._preferences
    
    def test_clear(self, tmp_path):
        """Clear all memory."""
        mem = PersistentMemory(storage_path=str(tmp_path / "memory"), auto_save=False)
        
        mem.add_fact("To clear")
        mem.set_preference("to_clear", "value")
        
        mem.clear()
        
        assert len(mem._facts) == 0
        assert len(mem._preferences) == 0


class TestPersistentMemoryStats:
    """Test statistics reporting."""
    
    def test_stats_empty(self, tmp_path):
        """Stats for empty memory."""
        mem = PersistentMemory(storage_path=str(tmp_path / "memory"), auto_save=False)
        
        stats = mem.get_stats()
        
        assert stats["total_facts"] == 0
        assert stats["total_preferences"] == 0
    
    def test_stats_populated(self, tmp_path):
        """Stats with data."""
        mem = PersistentMemory(storage_path=str(tmp_path / "memory"), auto_save=False)
        
        mem.add_fact("Fact 1", category="cat1")
        mem.add_fact("Fact 2", category="cat2")
        mem.set_preference("pref", "val")
        
        stats = mem.get_stats()
        
        assert stats["total_facts"] == 2
        assert stats["total_preferences"] == 1
        assert "cat1" in stats["categories"]
        assert "cat2" in stats["categories"]
