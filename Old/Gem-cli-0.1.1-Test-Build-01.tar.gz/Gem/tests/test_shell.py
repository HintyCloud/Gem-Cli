"""
Tests for Shell Tool (shell.py)

Covers shell command execution, security validation,
timeout handling, and cross-platform compatibility.
"""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from pathlib import Path

from gem.tools.shell import ShellTool
from gem.tools.base import ToolResult


class TestShellToolInit:
    """Test ShellTool initialization."""
    
    def test_init_defaults(self):
        """Test default initialization values."""
        tool = ShellTool()
        
        assert tool.timeout == 300
        assert "bash" in tool.shells or "sh" in tool.shells
    
    def test_init_custom(self):
        """Test custom configuration."""
        tool = ShellTool(
            workdir="/tmp/test",
            timeout=60,
            shells=["bash", "sh"],
            blocked_patterns=[r"dangerous"],
        )
        
        assert str(tool.workdir) == "/tmp/test"
        assert tool.timeout == 60
        assert len(tool.blocked_patterns) > 0
    
    def test_parameters_defined(self):
        """Test that parameters are properly defined."""
        tool = ShellTool()
        
        params = tool.parameters
        
        assert len(params) >= 2  # At least command and optional params
        
        # Check required parameters
        param_names = [p.name for p in params]
        assert "command" in param_names


class TestShellToolValidation:
    """Test command validation and security."""
    
    @pytest.fixture
    def tool(self):
        """Create a shell tool instance."""
        return ShellTool(timeout=10)
    
    def test_validate_safe_command(self, tool):
        """Validate a safe command passes."""
        valid, error = tool._validate_command("ls -la")
        
        assert valid is True
        assert error == ""
    
    def test_validate_empty_command(self, tool):
        """Empty command should fail validation."""
        # This is handled in execute, not _validate_command
        result = asyncio.run(tool.execute(command=""))
        
        assert not result.success
        assert "No command" in result.error
    
    def test_validate_blocked_pattern_rm_rf(self, tool):
        """Block rm -rf / command."""
        valid, error = tool._validate_command("rm -rf /")
        
        assert valid is False
        assert "blocked" in error.lower() or "destructive" in error.lower()
    
    def test_validate_blocked_fork_bomb(self, tool):
        """Block fork bomb pattern."""
        valid, error = tool._validate_command(":(){ :|:& };:")
        
        assert valid is False
    
    def test_find_shell(self, tool):
        """Test finding available shell."""
        with patch('gem.tools.shutil.which') as mock_which:
            mock_which.return_value = "/bin/bash"
            
            shell = tool._find_shell()
            
            assert shell == "/bin/bash"
            mock_which.assert_called()


class TestShellToolExecution:
    """Test actual command execution."""
    
    @pytest.fixture
    def tool(self):
        """Create shell tool with short timeout for testing."""
        return ShellTool(
            timeout=5,
            workdir="/tmp",
        )
    
    @pytest.mark.asyncio
    async def test_execute_simple_echo(self, tool):
        """Execute simple echo command."""
        result = await tool.execute(command="echo hello world")
        
        assert result.success is True
        assert "hello world" in result.output.lower()
    
    @pytest.mark.asyncio
    async def test_execute_ls(self, tool):
        """Execute ls command."""
        result = await tool.execute(command="ls /tmp")
        
        assert result.success is True
        assert len(result.output) > 0  # Should have some output
    
    @pytest.mark.asyncio
    async def test_execute_with_workdir(self, tool):
        """Execute command in specific working directory."""
        import tempfile
        
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a test file in temp dir
            test_file = Path(tmpdir) / "testfile.txt"
            test_file.write_text("test content")
            
            result = await tool.execute(
                command="ls",
                workdir=tmpdir,
            )
            
            assert result.success is True
            assert "testfile.txt" in result.output
    
    @pytest.mark.asyncio
    async def test_execute_command_failure(self, tool):
        """Execute command that fails (non-zero exit)."""
        result = await tool.execute(command="ls /nonexistent_directory_12345")
        
        assert result.success is False  # ls returns non-zero for missing dir
        assert result.error or "cannot access" in result.output.lower() or "no such" in result.output.lower()
    
    @pytest.mark.asyncio
    async def test_execute_timeout(self):
        """Test command timeout handling."""
        tool = ShellTool(timeout=1)  # Very short timeout
        
        result = await tool.execute(command="sleep 10")  # Takes longer than timeout
        
        assert not result.success
        assert "timeout" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_execute_with_output_capture(self, tool):
        """Verify stdout and stderr are captured."""
        # Command that outputs to both stdout and stderr
        result = await tool.execute(command="echo stdout && echo stderr >&2")
        
        assert result.success is True
        assert "stdout" in result.output or len(result.output) > 0
    
    @pytest.mark.asyncio
    async def test_data_in_result(self, tool):
        """Check that result contains execution metadata."""
        result = await tool.execute(command="pwd")
        
        assert "data" in result.data
        assert "exit_code" in result.data
        assert "command" in result.data
        assert "working_directory" in result.data


class TestShellToolSafeExecute:
    """Test safe execution wrapper with validation."""
    
    @pytest.mark.asyncio
    async def test_safe_execute_valid(self):
        """Safe execute with valid input."""
        tool = ShellTool(timeout=5)
        
        result = await tool.safe_execute(command="echo test")
        
        assert result.success is True
    
    @pytest.mark.asyncio
    async def test_safe_execute_invalid_command(self):
        """Safe execute with blocked command."""
        tool = ShellTool(timeout=5)
        
        result = await tool.safe_execute(command="rm -rf /")
        
        assert not result.success
        assert "validation" in result.error.lower() or "blocked" in result.error.lower() or "destructive" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_safe_execute_missing_param(self):
        """Safe execute missing required parameter."""
        tool = ShellTool(timeout=5)
        
        result = await tool.safe_execute()  # No command
        
        assert not result.success
        assert "missing" in result.error.lower() or "required" in result.error.lower()


class TestShellToolUtilities:
    """Test utility methods."""
    
    def test_get_available_shells(self):
        """Get list of available shells on system."""
        tool = ShellTool()
        
        shells = tool.get_available_shells()
        
        assert isinstance(shells, list)
        # Should find at least one shell on any Unix system
        if len(shells) > 0:
            assert "name" in shells[0]
            assert "path" in shells[0]
    
    @pytest.mark.asyncio
    async def test_cancel_running_command(self):
        """Cancel a running command."""
        tool = ShellTool(timeout=30)
        
        # Start a long-running command in background
        task = asyncio.create_task(tool.execute(command="sleep 30"))
        
        # Give it a moment to start
        await asyncio.sleep(0.1)
        
        # Cancel it
        await tool.cancel()
        
        try:
            result = await asyncio.wait_for(task, timeout=2.0)
            # If completed, may have been cancelled or still running
        except asyncio.TimeoutError:
            pass  # Expected if cancellation worked


class TestShellToolCrossPlatform:
    """Test cross-platform compatibility (especially Termux/Android)."""
    
    @pytest.mark.asyncio
    async def test_sh_shell_fallback(self):
        """Test that sh works when bash unavailable."""
        tool = ShellTool(shells=["sh"])  # Only sh
        
        result = await tool.execute(command="echo sh_works")
        
        assert result.success is True
        assert "sh_works" in result.output
    
    @pytest.mark.asyncio
    async def test_ash_shell_termux(self):
        """Test ash shell (common on Termux)."""
        tool = ShellTool(shells=["ash", "sh"])
        
        # Try ash, fall back to sh if needed
        result = await tool.execute(command="echo termux_test")
        
        assert result.success is True
    
    @pytest.mark.asyncio
    async def test_path_handling_relative(self, tool):
        """Handle relative paths correctly."""
        import tempfile
        
        with tempfile.TemporaryDirectory() as tmpdir:
            original_cwd = Path.cwd()
            try:
                import os
                os.chdir(tmpdir)
                
                # Create subdirectory
                subdir = Path(tmpdir) / "subdir"
                subdir.mkdir()
                
                # Use relative path
                result = await tool.execute(
                    command="ls",
                    workdir="subdir",
                )
                
                assert result.success is True
                
            finally:
                os.chdir(original_cwd)
