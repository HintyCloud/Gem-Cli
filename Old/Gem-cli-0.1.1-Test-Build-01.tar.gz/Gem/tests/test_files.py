"""
Tests for File Tool (files.py)

Covers file operations including read, write, list, search,
edit, and security features like path validation.
"""

import asyncio
import os
import pytest
from pathlib import Path
from unittest.mock import patch

from gem.tools.files import FileTool
from gem.tools.base import ToolResult


@pytest.fixture
def temp_workspace(tmp_path):
    """Create a temporary workspace with test files."""
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    
    # Create test files
    (workspace / "hello.txt").write_text("Hello, World!")
    (workspace / "code.py").write_text("print('Hello')\n# A comment\nx = 42")
    
    # Create subdirectory
    subdir = workspace / "subdir"
    subdir.mkdir()
    (subdir / "nested.txt").write_text("Nested file content")
    
    return workspace


@pytest.fixture
def file_tool(temp_workspace):
    """Create FileTool instance pointing to temp workspace."""
    return FileTool(
        base_dir=str(temp_workspace),
        max_read_size=1048576,
    )


class TestFileToolInit:
    """Test FileTool initialization."""
    
    def test_init_defaults(self):
        """Test default values."""
        tool = FileTool()
        
        assert tool.max_read_size == 1048576  # 1MB
        assert len(tool.blocked_paths) > 0
    
    def test_init_custom(self):
        """Test custom configuration."""
        tool = FileTool(
            base_dir="/tmp/test",
            max_read_size=5000,
            allowed_extensions=[".txt", ".py"],
            allow_path_escape=False,
        )
        
        assert str(tool.base_dir) == "/tmp/test"
        assert tool.max_read_size == 5000
        assert ".txt" in tool.allowed_extensions
    
    def test_parameters_defined(self):
        """Check parameters are defined."""
        tool = FileTool()
        
        params = tool.parameters
        param_names = [p.name for p in params]
        
        assert "action" in param_names
        assert "path" in param_names
        assert "content" in param_names


class TestFileToolPathValidation:
    """Test path validation and security."""
    
    def test_resolve_relative_path(self, file_tool):
        """Resolve relative paths correctly."""
        resolved = file_tool._resolve_path("hello.txt")
        
        assert resolved.name == "hello.txt"
        # Should be within workspace
        try:
            resolved.relative_to(file_tool.base_dir)
        except ValueError:
            pytest.fail("Path escapes workspace")
    
    def test_resolve_absolute_path_within_base(self, file_tool, temp_workspace):
        """Resolve absolute path within base directory."""
        abs_path = temp_workspace / "hello.txt"
        resolved = file_tool._resolve_path(str(abs_path))
        
        assert resolved.name == "hello.txt"
    
    def test_block_path_traversal(self, file_tool):
        """Block paths that escape workspace via .."""
        file_tool.allow_path_escape = False
        
        with pytest.raises(ValueError, match="escape"):
            file_tool._resolve_path("../../etc/passwd")
    
    def test_block_sensitive_files(self, file_tool):
        """Block access to sensitive files."""
        with pytest.raises(ValueError, match="blocked"):
            file_tool._resolve_path(".ssh/id_rsa")
    
    def test_allow_path_escape_enabled(self, file_tool):
        """Allow escape when configured."""
        tool = FileTool(base_dir="/tmp", allow_path_escape=True)
        
        # Should not raise even for paths outside base
        resolved = tool._resolve_path("/etc/hostname")
        
        assert resolved.name == "hostname"


class TestFileToolRead:
    """Test file reading operations."""
    
    @pytest.mark.asyncio
    async def test_read_file(self, file_tool):
        """Read a basic text file."""
        result = await file_tool.execute(
            action="read",
            path="hello.txt",
        )
        
        assert result.success is True
        assert "Hello, World!" in result.output
    
    @pytest.mark.asyncio
    async def test_read_nested_file(self, file_tool):
        """Read a nested file."""
        result = await file_tool.execute(
            action="read",
            path="subdir/nested.txt",
        )
        
        assert result.success is True
        assert "Nested file content" in result.output
    
    @pytest.mark.asyncio
    async def test_read_nonexistent_file(self, file_tool):
        """Read nonexistent file returns error."""
        result = await file_tool.execute(
            action="read",
            path="nonexistent.txt",
        )
        
        assert not result.success
        assert "not found" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_read_directory_as_file(self, file_tool):
        """Try to read a directory as file."""
        result = await file_tool.execute(
            action="read",
            path="subdir",
        )
        
        assert not result.success
        assert "not a file" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_read_includes_metadata(self, file_tool):
        """Result includes file metadata."""
        result = await file_tool.execute(
            action="read",
            path="hello.txt",
        )
        
        assert "data" in result.data
        assert "size" in result.data
        assert "path" in result.data


class TestFileToolWrite:
    """Test file writing operations."""
    
    @pytest.mark.asyncio
    async def test_write_new_file(self, file_tool, temp_workspace):
        """Write a new file."""
        result = await file_tool.execute(
            action="write",
            path="new_file.txt",
            content="This is new content!",
        )
        
        assert result.success is True
        
        # Verify file was created
        new_file = temp_workspace / "new_file.txt"
        assert new_file.exists()
        assert new_file.read_text() == "This is new content!"
    
    @pytest.mark.asyncio
    async def test_write_overwrites_existing(self, file_tool, temp_workspace):
        """Writing overwrites existing file."""
        original_content = (temp_workspace / "hello.txt").read_text()
        
        result = await file_tool.execute(
            action="write",
            path="hello.txt",
            content="Updated content",
        )
        
        assert result.success is True
        assert (temp_workspace / "hello.txt").read_text() == "Updated content"
    
    @pytest.mark.asyncio
    async def test_write_creates_directories(self, file_tool, temp_workspace):
        """Write creates parent directories if needed."""
        result = await file_tool.execute(
            action="write",
            path="deep/nested/dir/file.txt",
            content="Deep file",
        )
        
        assert result.success is True
        assert (temp_workspace / "deep" / "nested" / "dir" / "file.txt").exists()
    
    @pytest.mark.asyncio
    async def test_write_with_extension_filter(self, temp_workspace):
        """Respect allowed extensions filter."""
        tool = FileTool(
            base_dir=str(temp_workspace),
            allowed_extensions=[".txt"],
        )
        
        # Allowed extension
        result = await tool.execute(
            action="write",
            path="allowed.txt",
            content="OK",
        )
        assert result.success is True
        
        # Blocked extension
        result = await tool.execute(
            action="write",
            path="blocked.exe",
            content="Not OK",
        )
        assert not result.success
        assert "extension" in result.error.lower()


class TestFileToolList:
    """Test directory listing operations."""
    
    @pytest.mark.asyncio
    async def test_list_directory(self, file_tool):
        """List contents of a directory."""
        result = await file_tool.execute(
            action="list",
            path=".",
        )
        
        assert result.success is True
        assert "hello.txt" in result.output or "code.py" in result.output or "subdir" in result.output
    
    @pytest.mark.asyncio
    async def test_list_subdirectory(self, file_tool):
        """List a subdirectory."""
        result = await file_tool.execute(
            action="list",
            path="subdir",
        )
        
        assert result.success is True
        assert "nested.txt" in result.output
    
    @pytest.mark.asyncio
    async def test_list_nonexistent_directory(self, file_tool):
        """List nonexistent directory."""
        result = await file_tool.execute(
            action="list",
            path="nonexistent",
        )
        
        assert not result.success
        assert "not found" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_list_includes_entry_count(self, file_tool):
        """Result includes entry count."""
        result = await file_tool.execute(
            action="list",
            path=".",
        )
        
        assert "count" in result.data


class TestFileToolSearch:
    """Test file search operations."""
    
    @pytest.mark.asyncio
    async def test_search_content(self, file_tool):
        """Search for text in files."""
        result = await file_tool.execute(
            action="search",
            path=".",
            pattern="Hello",
        )
        
        assert result.success is True
        assert "match" in result.output.lower() or "hello" in result.output.lower()
    
    @pytest.mark.asyncio
    async def test_search_no_matches(self, file_tool):
        """Search with no matches."""
        result = await file_tool.execute(
            action="search",
            path=".",
            pattern="xyznonexistent123",
        )
        
        assert result.success is True  # Search itself succeeds
        assert "no matches" in result.output.lower() or "not found" in result.output.lower()
    
    @pytest.mark.asyncio
    async def test_search_code_comment(self, file_tool):
        """Search for code patterns."""
        result = await file_tool.execute(
            action="search",
            path=".",
            pattern="comment",
        )
        
        assert result.success is True


class TestFileToolEdit:
    """Test file editing operations."""
    
    @pytest.mark.asyncio
    async def test_edit_replace_text(self, file_tool, temp_workspace):
        """Replace text in a file."""
        result = await file_tool.execute(
            action="edit",
            path="hello.txt",
            old_text="World",
            new_text="Universe",
        )
        
        assert result.success is True
        
        # Verify change
        content = (temp_workspace / "hello.txt").read_text()
        assert "Universe" in content
        assert "World" not in content
    
    @pytest.mark.asyncio
    async def test_edit_text_not_found(self, file_tool):
        """Edit fails when old_text not found."""
        result = await file_tool.execute(
            action="edit",
            path="hello.txt",
            old_text="NonexistentText",
            new_text="Replacement",
        )
        
        assert not result.success
        assert "not found" in result.error.lower()


class TestFileToolInfo:
    """Test file info operations."""
    
    @pytest.mark.asyncio
    async def test_get_file_info(self, file_tool):
        """Get information about a file."""
        result = await file_tool.execute(
            action="info",
            path="hello.txt",
        )
        
        assert result.success is True
        assert "Name:" in result.output
        assert "Size:" in result.output
        assert "hello.txt" in result.output
    
    @pytest.mark.asyncio
    async def test_get_info_nonexistent(self, file_tool):
        """Get info for nonexistent file."""
        result = await file_tool.execute(
            action="info",
            path="nonexistent.xyz",
        )
        
        assert not result.success
        assert "not found" in result.error.lower()


class TestFileToolExists:
    """Test exists check operation."""
    
    @pytest.mark.asyncio
    async def test_exists_true(self, file_tool):
        """Check existing file."""
        result = await file_tool.execute(
            action="exists",
            path="hello.txt",
        )
        
        assert result.success is True
        assert "exists" in result.output.lower() or "found" in result.output.lower()
    
    @pytest.mark.asyncio
    async def test_exists_false(self, file_tool):
        """Check nonexistent file."""
        result = await file_tool.execute(
            action="exists",
            path="nonexistent.xyz",
        )
        
        assert result.success is True  # Operation succeeds
        assert "not found" in result.output.lower()


class TestFileToolMkdirDelete:
    """Test mkdir and delete operations."""
    
    @pytest.mark.asyncio
    async def test_mkdir(self, file_tool, temp_workspace):
        """Create new directory."""
        result = await file_tool.execute(
            action="mkdir",
            path="new_directory",
        )
        
        assert result.success is True
        assert (temp_workspace / "new_directory").is_dir()
    
    @pytest.mark.asyncio
    async def test_mkdir_nested(self, file_tool, temp_workspace):
        """Create nested directories."""
        result = await file_tool.execute(
            action="mkdir",
            path="a/b/c",
        )
        
        assert result.success is True
        assert (temp_workspace / "a" / "b" / "c").is_dir()
    
    @pytest.mark.asyncio
    async def test_delete_file(self, file_tool, temp_workspace):
        """Delete a file."""
        # Create a file to delete
        (temp_workspace / "to_delete.txt").write_text("delete me")
        
        result = await file_tool.execute(
            action="delete",
            path="to_delete.txt",
        )
        
        assert result.success is True
        assert not (temp_workspace / "to_delete.txt").exists()
    
    @pytest.mark.asyncio
    async def test_delete_empty_directory(self, file_tool, temp_workspace):
        """Delete an empty directory."""
        (temp_workspace / "empty_dir").mkdir()
        
        result = await file_tool.execute(
            action="delete",
            path="empty_dir",
        )
        
        assert result.success is True
    
    @pytest.mark.asyncio
    async def test_delete_nonempty_directory_fails(self, file_tool, temp_workspace):
        """Deleting non-empty directory should fail."""
        nonempty = temp_workspace / "nonempty_dir"
        nonempty.mkdir()
        (nonempty / "file.txt").write_text("content")
        
        result = await file_tool.execute(
            action="delete",
            path="nonempty_dir",
        )
        
        assert not result.success
        assert "empty" in result.error.lower()


class TestFileToolBinaryDetection:
    """Test binary file detection."""
    
    def test_is_binary_false_for_text(self, file_tool):
        """Text files are not binary."""
        assert not file_tool._is_binary(file_tool.base_dir / "hello.txt")
    
    def test_is_binary_true_for_binary(self, file_tool, tmp_path):
        """Files with null bytes are detected as binary."""
        binary_file = tmp_path / "binary.bin"
        binary_file.write_bytes(b'\x00\x01\x02\x03')
        
        # Need to create within workspace
        dest = file_tool.base_dir / "binary.bin"
        dest.write_bytes(b'\x00\x01\x02\x03')
        
        assert file_tool._is_binary(dest)


class TestFileToolSafeExecute:
    """Test safe execution wrapper."""
    
    @pytest.mark.asyncio
    async def test_safe_execute_validates_action(self, file_tool):
        """Invalid action caught by safe_execute."""
        result = await file_tool.safe_execute(
            action="invalid_action",
            path="test.txt",
        )
        
        assert not result.success
        assert "unknown" in result.error.lower() or "invalid" in result.error.lower()
