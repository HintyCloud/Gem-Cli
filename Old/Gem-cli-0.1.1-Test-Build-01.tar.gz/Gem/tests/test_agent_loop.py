"""
Tests for Agent Loop (loop.py)

Covers the main ReAct loop, message processing, tool execution,
streaming, and context management integration.
"""

import asyncio
import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from gem.agent.loop import AgentLoop
from gem.providers.opencode import OpenCodeProvider, ToolCall


@pytest.fixture
def mock_provider():
    """Create a mock provider for testing."""
    provider = MagicMock(spec=OpenCodeProvider)
    provider.model = "test-model"
    provider.api_url = "https://test.api/v1"
    provider.messages = []
    
    # Mock chat to return simple response
    async def mock_chat(message, **kwargs):
        return type('Response', (), {
            'content': 'Test response',
            'tool_calls': [],
            'finish_reason': 'stop',
            'usage': {},
            'model': 'test-model',
            'has_tool_calls': False,
        })()
    
    provider.chat = mock_chat
    
    return provider


@pytest.fixture
def agent(mock_provider):
    """Create an agent loop instance for testing."""
    return AgentLoop(
        provider=mock_provider,
        max_iterations=10,
        auto_plan=False,
        streaming=False,
    )


class TestAgentLoopInit:
    """Test agent initialization."""
    
    def test_init_defaults(self, mock_provider):
        """Test default initialization values."""
        agent = AgentLoop(provider=mock_provider)
        
        assert agent.max_iterations == 50
        assert agent.auto_plan is True
        assert agent.streaming is True
        assert not agent._running
    
    def test_init_custom(self, mock_provider):
        """Test custom initialization values."""
        callbacks = {
            'on_tool_call': lambda *a: None,
            'on_response_chunk': lambda *a: None,
            'on_iteration_complete': lambda *a: None,
        }
        
        agent = AgentLoop(
            provider=mock_provider,
            max_iterations=20,
            auto_plan=False,
            streaming=False,
            **callbacks,
        )
        
        assert agent.max_iterations == 20
        assert agent.auto_plan is False
        assert agent.streaming is False
    
    def test_context_initialized(self, agent):
        """Test that context manager is initialized."""
        assert agent.context is not None
        assert agent.context.max_context_tokens == 8000
    
    def test_planner_initialized(self, agent):
        """Test that task planner is initialized."""
        assert agent.planner is not None
        assert agent.planner.provider is mock_provider  # Check if same object or set


class TestAgentLoopProcessMessage:
    """Test the main message processing functionality."""
    
    @pytest.mark.asyncio
    async def test_process_simple_message(self, agent):
        """Test processing a simple text-only response."""
        result = await agent.process_message("Hello")
        
        assert "response" in result
        assert len(result["response"]) > 0
        assert result["iterations"] >= 1
    
    @pytest.mark.asyncio
    async def test_process_message_adds_to_context(self, agent):
        """Test that messages are added to context."""
        await agent.process_message("Test message")
        
        # Should have user message in context
        user_msgs = [m for m in agent.context.messages if m.get("role") == "user"]
        assert len(user_msgs) >= 1
        assert user_msgs[0]["content"] == "Test message"
    
    @pytest.mark.asyncio
    async def test_process_with_tool_calls(self, mock_provider):
        """Test processing that involves tool calls."""
        # Setup provider to return tool call first, then final response
        call_count = [0]
        
        async def mock_chat_with_tools(message, **kwargs):
            call_count[0] += 1
            
            if call_count[0] == 1:
                # First call: return tool call
                return type('Response', (), {
                    'content': '',
                    'tool_calls': [
                        {'id': 'call_1', 'name': 'shell', 'arguments': '{"command": "echo test"}'}
                    ],
                    'finish_reason': 'tool_calls',
                    'usage': {},
                    'model': 'test-model',
                    'has_tool_calls': True,
                })()
            else:
                # Second call: return final response
                return type('Response', (), {
                    'content': 'Command executed successfully!',
                    'tool_calls': [],
                    'finish_reason': 'stop',
                    'usage': {},
                    'model': 'test-model',
                    'has_tool_calls': False,
                })()
        
        mock_provider.chat = mock_chat_with_tools
        
        agent = AgentLoop(
            provider=mock_provider,
            max_iterations=10,
            streaming=False,
        )
        
        # Mock tool execution
        with patch('gem.agent.loop.ToolRegistry') as MockRegistry:
            mock_tool = AsyncMock()
            mock_tool.safe_execute.return_value = type('Result', (), {
                'success': True,
                'output': 'test output',
                'to_string': lambda: 'test output',
            })()
            
            MockRegistry.get.return_value = mock_tool
            
            result = await agent.process_message("run echo test")
            
            assert "response" in result
            assert len(result.get("tool_calls", [])) > 0
    
    @pytest.mark.asyncio
    async def test_max_iterations_limit(self, mock_provider):
        """Test that max iterations limit is respected."""
        iteration_count = [0]
        
        async def always_return_tools(**kwargs):
            iteration_count[0] += 1
            return type('Response', (), {
                'content': '',
                'tool_calls': [{'id': f'call_{iteration_count[0]}', 'name': 'shell', 'arguments': '{}'}],
                'finish_reason': 'tool_calls',
                'usage': {},
                'model': 'test',
                'has_tool_calls': True,
            })()
        
        mock_provider.chat = always_return_tools
        
        agent = AgentLoop(
            provider=mock_provider,
            max_iterations=3,  # Very low limit
            streaming=False,
        )
        
        with patch('gem.agent.loop.ToolRegistry') as MockRegistry:
            mock_tool = AsyncMock()
            mock_tool.safe_execute.return_value = type('Result', (), {
                'success': True,
                'output': '',
                'to_string': lambda: '',
            })()
            MockRegistry.get.return_value = mock_tool
        
        result = await agent.process_message("test")
        
        # Should have hit max iterations
        assert result["iterations"] <= 3
        assert "maximum" in result["response"].lower() or result["iterations"] == 3


class TestAgentLoopCallbacks:
    """Test callback functionality."""
    
    @pytest.mark.asyncio
    async def test_on_tool_call_callback(self, mock_provider):
        """Test that tool call callback is invoked."""
        tool_calls_made = []
        
        def capture_tool_call(name, args):
            tool_calls_made.append((name, args))
        
        async def mock_chat(**kwargs):
            return type('Response', (), {
                'content': '',
                'tool_calls': [{'id': 'call_1', 'name': 'shell', 'arguments': '{"cmd":"ls"}'}],
                'finish_reason': 'tool_calls',
                'usage': {},
                'model': 'test',
                'has_tool_calls': True,
            })()
        
        mock_provider.chat = mock_chat
        
        agent = AgentLoop(
            provider=mock_provider,
            on_tool_call=capture_tool_call,
            streaming=False,
        )
        
        with patch('gem.agent.loop.ToolRegistry') as MockRegistry:
            mock_tool = AsyncMock()
            mock_tool.safe_execute.return_value = type('Result', (), {
                'success': True,
                'output': '',
                'to_string': lambda: '',
            })()
            MockRegistry.get.return_value = mock_tool
        
        await agent.process_message("list files")
        
        assert len(tool_calls_made) > 0
        assert tool_calls_made[0][0] == "shell"
    
    @pytest.mark.asyncio
    async def test_on_response_chunk_callback_streaming(self, mock_provider):
        """Test that response chunk callback works during streaming."""
        chunks_received = []
        
        def capture_chunk(chunk):
            chunks_received.append(chunk)
        
        agent = AgentLoop(
            provider=mock_provider,
            streaming=True,
            on_response_chunk=capture_chunk,
        )
        
        # For now just verify callback is stored
        assert agent.on_response_chunk is not None


class TestAgentLoopStatus:
    """Test status and state management."""
    
    def test_initial_status(self, agent):
        """Test initial status values."""
        status = agent.get_status()
        
        assert status["running"] is False
        assert status["cancelled"] is False
        assert status["has_plan"] is False
    
    def test_cancel(self, agent):
        """Test cancelling a running operation."""
        agent._running = True
        agent.cancel()
        
        assert agent._cancelled is True
    
    def test_reset(self, agent, mock_provider):
        """Test resetting agent state."""
        # Add some state
        agent.context.add_message("user", "test")
        agent.current_plan = MagicMock()
        
        agent.reset()
        
        assert len(agent.context.messages) == 0
        assert agent.current_plan is None
        assert agent._cancelled is False


class TestAgentLoopContextIntegration:
    """Test integration with context manager."""
    
    @pytest.mark.asyncio
    async def test_checkpoint_saving(self, agent):
        """Test that checkpoints are saved during long conversations."""
        # Process multiple messages to trigger checkpoint
        for i in range(6):  # checkpoint_interval is 5
            await agent.process_message(f"message {i}")
        
        # Should have at least one checkpoint saved
        checkpoints = agent.context.list_checkpoints()
        assert len(checkpoints) >= 0  # May or may not have depending on timing


class TestToolExecution:
    """Test internal tool execution logic."""
    
    @pytest.mark.asyncio
    async def test_execute_single_tool_call(self, agent):
        """Test executing a single tool call."""
        tool_call = {
            "id": "call_1",
            "name": "shell",
            "arguments": {"command": "echo hello"},
        }
        
        execution_log = []
        
        with patch('gem.agent.loop.ToolRegistry') as MockRegistry:
            expected_result = type('Result', (), {
                'success': True,
                'output': 'hello\n',
                'error': '',
                'data': {},
                'to_string': lambda: 'hello\n',
            })()
            
            mock_tool = AsyncMock(return_value=expected_result)
            MockRegistry.get.return_value = mock_tool
            
            results = await agent._execute_tool_calls([tool_call], execution_log)
            
            assert len(results) == 1
            assert results[0]["call_id"] == "call_1"
            assert results[0]["result"].success
            assert len(execution_log) == 1
    
    @pytest.mark.asyncio
    async def test_execute_unknown_tool(self, agent):
        """Test handling of unknown tools."""
        tool_call = {
            "id": "call_1",
            "name": "nonexistent_tool",
            "arguments": {},
        }
        
        execution_log = []
        
        with patch('gem.agent.loop.ToolRegistry') as MockRegistry:
            MockRegistry.get.return_value = None
            
            results = await agent._execute_tool_calls([tool_call], execution_log)
            
            assert len(results) == 1
            assert not results[0]["result"].success
            assert "Unknown tool" in results[0]["result"].error
    
    @pytest.mark.asyncio
    async def test_execute_multiple_tool_calls(self, agent):
        """Test executing multiple tool calls in sequence."""
        tool_calls = [
            {"id": "call_1", "name": "shell", "arguments": {"command": "echo 1"}},
            {"id": "call_2", "name": "file", "arguments": {"action": "read", "path": "/tmp/test"}},
        ]
        
        execution_log = []
        
        with patch('gem.agent.loop.ToolRegistry') as MockRegistry:
            success_result = type('Result', (), {
                'success': True,
                'output': 'output',
                'error': '',
                'data': {},
                'to_string': lambda: 'output',
            })()
            
            mock_tool = AsyncMock(return_value=success_result)
            MockRegistry.get.return_value = mock_tool
            
            results = await agent._execute_tool_calls(tool_calls, execution_log)
            
            assert len(results) == 2
            assert len(execution_log) == 2
            assert mock_tool.call_count == 2
