"""
Tests for Context Manager (context.py)

Covers context management, message handling, token estimation,
checkpoint save/restore, and compression.
"""

import asyncio
import json
import pytest
from pathlib import Path

from gem.agent.context import ContextManager, Checkpoint


class TestCheckpoint:
    """Test Checkpoint dataclass."""
    
    def test_create_checkpoint(self):
        """Create a basic checkpoint."""
        cp = Checkpoint(
            id="cp_001",
            timestamp=1234567890.0,
            iteration=5,
            messages=[{"role": "user", "content": "test"}],
        )
        
        assert cp.id == "cp_001"
        assert cp.iteration == 5
        assert len(cp.messages) == 1
    
    def test_to_dict(self):
        """Serialize checkpoint to dict."""
        cp = Checkpoint(
            id="cp_002",
            timestamp=1000.0,
            iteration=1,
            messages=[],
            summary="Test summary",
        )
        
        d = cp.to_dict()
        
        assert d["id"] == "cp_002"
        assert d["summary"] == "Test summary"
        assert "messages" in d
    
    def test_from_dict(self):
        """Deserialize checkpoint from dict."""
        data = {
            "id": "cp_003",
            "timestamp": 2000.0,
            "iteration": 10,
            "messages": [{"role": "assistant", "content": "hello"}],
            "summary": "",
            "metadata": {},
        }
        
        cp = Checkpoint.from_dict(data)
        
        assert cp.id == "cp_003"
        assert cp.iteration == 10
        assert len(cp.messages) == 1


class TestContextManager:
    """Test ContextManager class."""
    
    @pytest.fixture
    def context(self, tmp_path):
        """Create a ContextManager with temp directory."""
        return ContextManager(
            max_context_tokens=1000,
            checkpoint_dir=str(tmp_path / "checkpoints"),
            auto_checkpoint_interval=3,
        )
    
    def test_init_defaults(self):
        """Test default initialization."""
        ctx = ContextManager()
        
        assert ctx.max_context_tokens == 8000
        assert ctx.auto_checkpoint_interval == 5
        assert len(ctx.messages) == 0
        assert ctx.iteration_count == 0
    
    def test_add_message_user(self, context):
        """Add a user message."""
        msg = context.add_message("user", "Hello!")
        
        assert msg["role"] == "user"
        assert msg["content"] == "Hello!"
        assert "timestamp" in msg
        assert len(context.messages) == 1
    
    def test_add_message_with_tool_calls(self, context):
        """Add assistant message with tool calls."""
        tool_calls = [{"id": "call_1", "function": {"name": "shell"}}]
        
        msg = context.add_message("assistant", "", tool_calls=tool_calls)
        
        assert msg["tool_calls"] == tool_calls
        assert len(context.messages) == 1
    
    def test_add_message_tool_result(self, context):
        """Add tool result message."""
        msg = context.add_message(
            role="tool",
            content="Command output",
            tool_call_id="call_123",
        )
        
        assert msg["role"] == "tool"
        assert msg["tool_call_id"] == "call_123"
    
    def test_get_messages_for_api(self, context):
        """Get messages formatted for API submission."""
        context.add_message("user", "test")
        context.add_message("assistant", "response")
        
        api_messages = context.get_messages_for_api()
        
        # Should have both messages
        assert len(api_messages) >= 2
        
        # Check format (no internal fields)
        for msg in api_messages:
            assert "timestamp" not in msg or isinstance(msg["timestamp"], (int, float))
    
    def test_get_messages_with_compressed_summary(self, context):
        """Messages include compressed summary when present."""
        context.compressed_summary = "Previous conversation about X"
        context.add_message("user", "new question")
        
        api_messages = context.get_messages_for_api()
        
        # First message should be the summary
        assert "Previous conversation" in api_messages[0]["content"]
    
    def test_estimate_tokens_empty(self, context):
        """Token estimate for empty context."""
        tokens = context.estimate_tokens()
        
        assert tokens == 0
    
    def test_estimate_tokens_with_messages(self, context):
        """Token estimate with messages."""
        # Add some messages
        for i in range(10):
            context.add_message("user" if i % 2 == 0 else "assistant", f"Message {i} " * 20)
        
        tokens = context.estimate_tokens()
        
        assert tokens > 0
        # Rough check: should be proportional to content length
    
    def test_get_context_usage(self, context):
        """Get context usage ratio."""
        usage = context.get_context_usage()
        
        # Empty context should be 0 or very low
        assert usage >= 0
    
    def test_should_compress_false_when_low_usage(self, context):
        """Should not compress when under threshold."""
        context.add_message("user", "short")
        
        should = context.should_compress()
        
        assert should is False
    
    def test_should_compress_true_when_high_usage(self, context):
        """Should compress when over threshold."""
        # Set low max tokens and add lots of content
        context.max_context_tokens = 100
        
        for i in range(50):
            context.add_message("user", f"This is a longer message number {i} with more content to increase token count")
        
        should = context.should_compress()
        
        # May or may not be true depending on exact calculation
        assert isinstance(should, bool)
    
    def test_should_checkpoint_false_initially(self, context):
        """Should not checkpoint initially."""
        should = context.should_checkpoint()
        
        assert should is False
    
    def test_should_checkpoint_true_after_iterations(self, context):
        """Should checkpoint after enough iterations."""
        context.iteration_count = 5
        context.last_checkpoint_iteration = 2
        
        should = context.should_checkpoint()
        
        assert should is True
    
    @pytest.mark.asyncio
    async def test_compress_context(self, context):
        """Test context compression."""
        # Add messages
        for i in range(5):
            context.add_message("user" if i % 2 == 0 else "assistant", f"msg {i}")
        
        await context.compress_context("Summary of conversation")
        
        # Messages should be cleared
        assert len(context.messages) == 0
        
        # Summary should be set
        assert "Summary of conversation" in context.compressed_summary
    
    @pytest.mark.asyncio
    async def test_save_checkpoint(self, context, tmp_path):
        """Test saving a checkpoint."""
        context.add_message("user", "test message")
        context.iteration_count = 3
        
        checkpoint = await context.save_checkpoint(reason="test")
        
        assert checkpoint.id is not None
        assert checkpoint.iteration == 3
        assert len(checkpoint.messages) == 1
        
        # File should exist on disk
        checkpoint_file = tmp_path / "checkpoints" / f"{checkpoint.id}.json"
        assert checkpoint_file.exists()
    
    @pytest.mark.asyncio
    async def test_restore_checkpoint(self, context, tmp_path):
        """Test restoring from a checkpoint."""
        # Save original state
        original_msgs = [
            context.add_message("user", "original message"),
            context.add_message("assistant", "original response"),
        ]
        context.iteration_count = 5
        
        checkpoint = await context.save_checkpoint(reason="before restore")
        
        # Modify state
        context.add_message("user", "new message after checkpoint")
        context.iteration_count = 10
        
        # Restore
        success = await context.restore_checkpoint(checkpoint.id)
        
        assert success is True
        assert context.iteration_count == 5
        assert len(context.messages) == 2
    
    @pytest.mark.asyncio
    async def test_restore_nonexistent_checkpoint(self, context):
        """Test restoring nonexistent checkpoint fails gracefully."""
        success = await context.restore_checkpoint("nonexistent_id")
        
        assert success is False
    
    def test_list_checkpoints(self, context):
        """List available checkpoints."""
        # Initially empty
        checkpoints = context.list_checkpoints()
        
        assert isinstance(checkpoints, list)
    
    def test_delete_checkpoint(self, context, tmp_path):
        """Delete a checkpoint."""
        import asyncio
        
        async def run_test():
            # Create a checkpoint first
            context.add_message("user", "to delete")
            cp = await context.save_checkpoint(reason="delete test")
            
            # Delete it
            success = context.delete_checkpoint(cp.id)
            
            assert success is True
            
            # Should no longer be in memory
            assert cp.id not in context.checkpoints
        
        asyncio.run(run_test())
    
    def test_increment_iteration(self, context):
        """Increment iteration counter."""
        initial = context.iteration_count
        
        context.increment_iteration()
        
        assert context.iteration_count == initial + 1
    
    def test_get_stats(self, context):
        """Get context statistics."""
        stats = context.get_stats()
        
        assert "total_messages" in stats
        assert "estimated_tokens" in stats
        assert "max_tokens" in stats
        assert "usage_ratio" in stats
        assert "iteration" in stats
    
    def test_reset(self, context):
        """Reset context manager."""
        # Add state
        context.add_message("user", "test")
        context.iteration_count = 10
        context.compressed_summary = "summary"
        
        context.reset()
        
        assert len(context.messages) == 0
        assert context.iteration_count == 0
        assert context.compressed_summary == ""


class TestCheckpointFileOperations:
    """Test checkpoint file I/O operations."""
    
    @pytest.mark.asyncio
    async def test_checkpoint_file_format(self, tmp_path):
        """Verify checkpoint file JSON format."""
        context = ContextManager(
            checkpoint_dir=str(tmp_path),
        )
        
        context.add_message("user", "file format test")
        checkpoint = await context.save_checkpoint(reason="format test")
        
        # Read file and verify structure
        checkpoint_file = tmp_path / f"{checkpoint.id}.json"
        with open(checkpoint_file, 'r') as f:
            data = json.load(f)
        
        assert data["id"] == checkpoint.id
        assert "messages" in data
        assert "timestamp" in data
        assert "iteration" in data
        assert "reason" in data["metadata"]
    
    @pytest.mark.asyncio
    async def test_load_checkpoints_from_disk(self, tmp_path):
        """Loading checkpoints from disk populates registry."""
        context = ContextManager(
            checkpoint_dir=str(tmp_path),
        )
        
        # Save multiple checkpoints
        for i in range(3):
            context.add_message("user", f"message {i}")
            await context.save_checkpoint(reason=f"test {i}")
        
        # Clear in-memory checkpoints
        saved_ids = list(context.checkpoints.keys())
        context.checkpoints.clear()
        
        # Load from disk
        context._load_checkpoints_from_disk()
        
        # Should have reloaded them
        for cp_id in saved_ids:
            assert cp_id in context.checkpoints
    
    def test_clear_old_checkpoints(self, tmp_path):
        """Clear old checkpoints keeping recent ones."""
        import asyncio
        
        async def run_test():
            context = ContextManager(
                checkpoint_dir=str(tmp_path),
                auto_checkpoint_interval=1,
            )
            
            # Create several checkpoints
            for i in range(8):
                context.increment_iteration()
                context.add_message("user", f"msg {i}")
                await context.save_checkpoint(reason=f"keep {i}")
            
            # Keep only 3 most recent
            context.clear_old_checkpoints(keep_recent=3)
            
            remaining = len(context.checkpoints)
            assert remaining <= 3
        
        asyncio.run(run_test())
