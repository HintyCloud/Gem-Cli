"""
Pytest Configuration and Shared Fixtures

Provides common test fixtures for all test modules including
mock providers, sample data, and test utilities.
"""

import asyncio
import json
import os
import sys
import pytest
from pathlib import Path
from typing import Any, Dict, List, Optional
from unittest.mock import AsyncMock, MagicMock, patch

# Add project root to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))


# Sample API responses for mocking
SAMPLE_CHAT_RESPONSE = {
    "id": "chatcmpl-test",
    "object": "chat.completion",
    "created": 1234567890,
    "model": "longcat-2.0-free",
    "choices": [
        {
            "index": 0,
            "message": {
                "role": "assistant",
                "content": "Hello! I'm Gem, your AI assistant. How can I help you today?",
            },
            "finish_reason": "stop",
        }
    ],
    "usage": {
        "prompt_tokens": 20,
        "completion_tokens": 15,
        "total_tokens": 35,
    }
}

SAMPLE_TOOL_CALL_RESPONSE = {
    "id": "chatcmpl-tool-test",
    "object": "chat.completion",
    "created": 1234567890,
    "model": "longcat-2.0-free",
    "choices": [
        {
            "index": 0,
            "message": {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "call_test_123",
                        "type": "function",
                        "function": {
                            "name": "shell",
                            "arguments": '{"command": "echo hello"}',
                        }
                    }
                ]
            },
            "finish_reason": "tool_calls",
        }
    ],
    "usage": {
        "prompt_tokens": 100,
        "completion_tokens": 30,
        "total_tokens": 130,
    }
}

SAMPLE_STREAM_CHUNKS = [
    'data: {"choices":[{"delta":{"content":"Hello"},"index":0}]}\n\n',
    'data: {"choices":[{"delta":{"content":" there!"},"index":0}]}\n\n',
    'data: [DONE]\n\n',
]


@pytest.fixture
def mock_http_client():
    """Create a mock HTTP client for testing."""
    client = AsyncMock()
    
    # Configure default responses
    response = MagicMock()
    response.status_code = 200
    response.json.return_value = SAMPLE_CHAT_RESPONSE
    response.text = "test content"
    client.post.return_value = asyncio.Future()
    client.post.return_value.set_result(response)
    client.get.return_value = asyncio.Future()
    client.get.return_value.set_result(response)
    
    return client


@pytest.fixture
def mock_provider(mock_http_client):
    """Create a mock LLM provider."""
    from gem.providers.opencode import OpenCodeProvider
    
    with patch.object(OpenCodeProvider, 'client', mock_http_client):
        provider = OpenCodeProvider(
            api_url="https://test.api/v1",
            api_key="test-key",
            model="test-model",
        )
        provider._client = mock_http_client
        yield provider


@pytest.fixture
def sample_config():
    """Sample configuration dictionary."""
    return {
        "model": {
            "api_url": "https://opencode.ai/zen/v1",
            "api_key": "test-api-key",
            "default_model": "longcat-2.0-free",
            "temperature": 0.7,
            "max_tokens": 4096,
            "timeout": 120,
        },
        "agent": {
            "max_iterations": 50,
            "auto_plan": True,
            "plan_threshold": 0.3,
        },
        "tools": {
            "shell": {
                "timeout": 300,
                "blocked_patterns": [],
            },
            "files": {
                "base_dir": "/tmp/test_workspace",
                "max_read_size": 1048576,
            },
        },
        "memory": {
            "history": {
                "max_messages": 100,
            },
            "persistent": {
                "enabled": True,
            },
        },
    }


@pytest.fixture
def temp_dir(tmp_path):
    """Create a temporary directory for file tests."""
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    
    # Create some test files
    (workspace / "test.txt").write_text("Hello, World!")
    (workspace / "subdir").mkdir()
    (workspace / "subdir" / "nested.txt").write_text("Nested file")
    
    return workspace


@pytest.fixture
def event_loop():
    """Create an event loop for async tests."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


class MockResponse:
    """Mock HTTP response for testing."""
    
    def __init__(self, status_code=200, json_data=None, text=""):
        self.status_code = status_code
        self._json_data = json_data or {}
        self._text = text
        self.headers = {}
        
    def raise_for_status(self):
        if self.status_code >= 400:
            raise Exception(f"HTTP {self.status_code}")
    
    def json(self):
        return self._json_data
    
    @property
    def text(self):
        return self._text
    
    def __aenter__(self):
        return self
    
    def __aexit__(self, *args):
        pass
    
    async def aiter_lines(self):
        if self._text:
            for line in self._text.split("\n"):
                yield line


@pytest.fixture
def mock_tool_registry():
    """Provide a fresh tool registry for each test."""
    from gem.tools.base import ToolRegistry
    ToolRegistry.clear()
    yield ToolRegistry
    ToolRegistry.clear()


# Helper functions for tests

async def run_async(coro):
    """Run an async coroutine synchronously for testing."""
    return await coro


def make_tool_call(name: str, args: Dict[str, Any], call_id: str = "test_call") -> Dict:
    """Create a tool call dictionary."""
    return {
        "id": call_id,
        "name": name,
        "arguments": json.dumps(args),
    }


def assert_tool_result(result, success=True, has_output=False):
    """Common assertions for tool results."""
    from gem.tools.base import ToolResult
    assert isinstance(result, ToolResult)
    assert result.success == success
    if has_output:
        assert len(result.output) > 0
