"""
Tests for Web Tool (web.py)

Covers web search functionality, URL fetching, result parsing,
and error handling.
"""

import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

try:
    from gem.tools.web import WebTool
    from gem.tools.base import ToolResult
    HAS_WEB_TOOL = True
except ImportError:
    HAS_WEB_TOOL = False


@pytest.mark.skipif(not HAS_WEB_TOOL, reason="WebTool dependencies not available")
class TestWebToolInit:
    """Test WebTool initialization."""
    
    def test_init_defaults(self):
        """Test default values."""
        tool = WebTool()
        
        assert tool.enabled is True
        assert tool.max_results == 10
        assert tool.timeout == 30
    
    def test_init_custom(self):
        """Test custom configuration."""
        tool = WebTool(
            enabled=False,
            max_results=5,
            timeout=15,
            search_engine="custom",
            api_key="test-key",
        )
        
        assert tool.enabled is False
        assert tool.max_results == 5
        assert tool.api_key == "test-key"
    
    def test_parameters_defined(self):
        """Check parameters are properly defined."""
        tool = WebTool()
        
        params = tool.parameters
        param_names = [p.name for p in params]
        
        assert "query" in param_names
        assert "num_results" in param_names
        assert "site" in param_names


@pytest.mark.skipif(not HAS_WEB_TOOL, reason="WebTool dependencies not available")
class TestWebToolSearch:
    """Test web search operations."""
    
    @pytest.fixture
    def web_tool(self):
        """Create a WebTool instance."""
        return WebTool(enabled=True, max_results=5)
    
    @pytest.mark.asyncio
    async def test_search_disabled(self):
        """Search when disabled returns error."""
        tool = WebTool(enabled=False)
        
        result = await tool.execute(query="test search")
        
        assert not result.success
        assert "disabled" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_search_no_query(self, web_tool):
        """Search without query returns error."""
        result = await web_tool.execute(query="")
        
        assert not result.success
        assert "no query" in result.error.lower() or "no search" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_search_with_site_filter(self, web_tool):
        """Search with site restriction."""
        # Mock the actual HTTP calls to avoid network dependency
        with patch.object(web_tool, '_search_duckduckgo', new_callable=AsyncMock) as mock_ddg:
            mock_ddg.return_value = [
                {
                    "title": "Test Result",
                    "url": "https://example.com/page",
                    "snippet": "A test snippet",
                    "source": "DuckDuckGo",
                }
            ]
            
            with patch.object(web_tool, '_search_fallback', new_callable=AsyncMock) as mock_fallback:
                mock_fallback.return_value = []
                
                result = await web_tool.execute(
                    query="python tutorial",
                    site="github.com",
                )
                
                # Should have called with site in query
                call_args = mock_ddg.call_args[0][0]
                assert "github.com" in call_args or "site:" in call_args or result.success


@pytest.mark.skipif(not HAS_WEB_TOOL, reason="WebTool dependencies not available")
class TestWebToolDuckDuckGo:
    """Test DuckDuckGo search integration."""
    
    @pytest.fixture
    def web_tool(self):
        """Create WebTool for testing."""
        return WebTool(max_results=3)
    
    @pytest.mark.asyncio
    async def test_duckduckgo_api_call(self, web_tool):
        """Test DuckDuckGo API is called correctly."""
        with patch.object(web_tool.client, 'get', new_callable=AsyncMock) as mock_get:
            # Mock API response
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "Abstract": "Python is a programming language",
                "AbstractURL": "https://python.org",
                "Heading": "Python",
            }
            mock_get.return_value = mock_response
            
            results = await web_tool._search_duckduckgo("python", 5)
            
            # Should have made a GET request
            mock_get.assert_called_once()
            
            # Should parse abstract if present
            if results:
                assert "Python" in results[0].get("title", "") or "programming" in results[0].get("snippet", "").lower()
    
    @pytest.mark.asyncio
    async def test_duckduckgo_html_fallback(self, web_tool):
        """Test HTML fallback when API fails."""
        with patch.object(web_tool.client, 'post', new_callable=AsyncMock) as mock_post:
            # Mock HTML response
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.text = """
            <html><body>
            <tr><td><a rel="nofollow" href="https://example.com">Example Page</a></td>
            <td class="result-snippet">This is an example page about testing</td></tr>
            </body></html>
            """
            mock_post.return_value = mock_response
            
            results = await web_tool._search_duckduckgo_html("example", 10)
            
            # Should attempt POST request
            mock_post.assert_called_once()


@pytest.mark.skipif(not HAS_WEB_TOOL, reason="WebTool dependencies not available")
class TestWebToolWikipedia:
    """Test Wikipedia search fallback."""
    
    @pytest.fixture
    def web_tool(self):
        """Create WebTool for testing."""
        return WebTool()
    
    @pytest.mark.asyncio
    async def test_wikipedia_search(self, web_tool):
        """Test Wikipedia API integration."""
        with patch.object(web_tool.client, 'get', new_callable=AsyncMock) as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "query": {
                    "search": [
                        {
                            "title": "Python (programming language)",
                            "snippet": "Python is a high-level <span class=\"searchmatch\">programming</span> language",
                        }
                    ]
                }
            }
            mock_get.return_value = mock_response
            
            results = await web_tool._search_wikipedia("python programming", 5)
            
            mock_get.assert_called_once()
            
            if results:
                assert "Python" in results[0]["title"]
                assert "Wikipedia" == results[0]["source"]


@pytest.mark.skipif(not HAS_WEB_TOOL, reason="WebTool dependencies not available")
class TestWebToolFetchURL:
    """Test URL fetching functionality."""
    
    @pytest.fixture
    def web_tool(self):
        """Create WebTool for testing."""
        return WebTool(timeout=10)
    
    @pytest.mark.asyncio
    async def test_fetch_text_url(self, web_tool):
        """Fetch a text/HTML URL."""
        with patch.object(web_tool.client, 'get', new_callable=AsyncMock) as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.headers = {"content-type": "text/html"}
            mock_response.text = "<html><body><h1>Test Page</h1><p>Content here</p></body></html>"
            mock_get.return_value = mock_response
            
            result = await web_tool.fetch_url("https://example.com")
            
            assert result.success is True
            assert "Test Page" in result.output or "Content" in result.output
    
    @pytest.mark.asyncio
    async def test_fetch_binary_content(self, web_tool):
        """Fetch binary content (non-text)."""
        with patch.object(web_tool.client, 'get', new_callable=AsyncMock) as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 200
            mock_response.headers = {"content-type": "application/pdf"}
            mock_response.content = b'%PDF-1.4 fake pdf content'
            mock_get.return_value = mock_response
            
            result = await web_tool.fetch_url("https://example.com/doc.pdf")
            
            assert result.success is True
            assert "non-text" in result.output.lower() or "pdf" in result.output.lower()
    
    @pytest.mark.asyncio
    async def test_fetch_invalid_scheme(self, web_tool):
        """Reject non-HTTP URLs."""
        result = await web_tool.fetch_url("ftp://files.example.com/file.txt")
        
        assert not result.success
        assert "http" in result.error.lower()
    
    @pytest.mark.asyncio
    async def test_fetch_http_error(self, web_tool):
        """Handle HTTP errors gracefully."""
        import httpx
        
        with patch.object(web_tool.client, 'get', new_callable=AsyncMock) as mock_get:
            mock_response = MagicMock()
            mock_response.status_code = 404
            mock_response.url = "https://example.com/notfound"
            
            error = httpx.HTTPStatusError("Not Found", request=MagicMock(), response=mock_response)
            mock_get.side_effect = error
            
            result = await web_tool.fetch_url("https://example.com/notfound")
            
            assert not result.success
            assert "404" in result.error or "not found" in result.error.lower()


@pytest.mark.skipif(not HAS_WEB_TOOL, reason="WebTool dependencies not available")
class TestWebToolResultFormatting:
    """Test result formatting and display."""
    
    @pytest.fixture
    def web_tool(self):
        """Create WebTool for testing."""
        return WebTool()
    
    def test_format_results_empty(self, web_tool):
        """Format empty results list."""
        output = web_tool._format_results([])
        
        assert "0 results" in output
    
    def test_format_results_single(self, web_tool):
        """Format single result."""
        results = [{
            "title": "Test Title",
            "url": "https://example.com",
            "snippet": "A brief description of the page",
            "source": "TestSource",
        }]
        
        output = web_tool._format_results(results)
        
        assert "Test Title" in output
        assert "example.com" in output
        assert "description" in output.lower() or "brief" in output.lower()
    
    def test_format_results_multiple(self, web_tool):
        """Format multiple results."""
        results = [
            {
                "title": f"Result {i}",
                "url": f"https://example.com/{i}",
                "snippet": f"Snippet number {i}",
                "source": "Source",
            }
            for i in range(3)
        ]
        
        output = web_tool._format_results(results)
        
        assert "3 results" in output or "Found" in output
        assert "Result 0" in output
        assert "Result 2" in output
    
    def test_format_truncates_long_snippets(self, web_tool):
        """Long snippets are truncated."""
        long_snippet = "x" * 500
        results = [{
            "title": "Long Content",
            "url": "https://example.com/long",
            "snippet": long_snippet,
            "source": "Test",
        }]
        
        output = web_tool._format_results(results)
        
        # Should be truncated
        assert len(output) < len(long_snippet) + 100


@pytest.mark.skipif(not HAS_WEB_TOOL, reason="WebTool dependencies not available")
class TestWebToolClientManagement:
    """Test HTTP client lifecycle."""
    
    def test_client_creation(self):
        """Client is created lazily."""
        tool = WebTool()
        
        # Client should exist after access
        client = tool.client
        
        assert client is not None
    
    @pytest.mark.asyncio
    async def test_close_client(self):
        """Close client properly."""
        tool = WebTool()
        
        # Get client then close
        _ = tool.client
        await tool.close()
        
        # After closing, should create new client on next access
        client2 = tool.client
        assert client2 is not None
