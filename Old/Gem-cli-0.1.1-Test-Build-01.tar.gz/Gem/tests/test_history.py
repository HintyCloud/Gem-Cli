"""
Tests for Chat History (history.py)

Covers session management, message persistence,
export functionality, and search capabilities.
"""

import asyncio
import json
import pytest
from datetime import datetime
from pathlib import Path

from gem.memory.history import ChatHistory, ChatSession, ChatMessage


class TestChatMessage:
    """Test ChatMessage dataclass."""
    
    def test_create_message(self):
        """Create a basic message."""
        msg = ChatMessage.create("user", "Hello!")
        
        assert msg.role == "user"
        assert msg.content == "Hello!"
        assert len(msg.id) > 0  # Should have auto-generated ID
        assert isinstance(msg.timestamp, float)
    
    def test_to_dict(self):
        """Serialize message to dict."""
        msg = ChatMessage(
            id="msg123",
            role="assistant",
            content="Response",
            timestamp=1000.0,
            metadata={"key": "value"},
        )
        
        d = msg.to_dict()
        
        assert d["id"] == "msg123"
        assert d["role"] == "assistant"
        assert d["metadata"]["key"] == "value"
    
    def test_from_dict(self):
        """Deserialize message from dict."""
        data = {
            "id": "msg456",
            "role": "user",
            "content": "Test",
            "timestamp": 2000.0,
            "metadata": {},
        }
        
        msg = ChatMessage.from_dict(data)
        
        assert msg.id == "msg456"
        assert msg.content == "Test"


class TestChatSession:
    """Test ChatSession dataclass."""
    
    @pytest.fixture
    def session(self):
        """Create a sample session."""
        return ChatSession(
            id="session_001",
            title="Test Session",
            created_at=datetime.now().timestamp(),
            updated_at=datetime.now().timestamp(),
        )
    
    def test_session_properties(self, session):
        """Test session property calculations."""
        # Initially empty
        assert session.message_count == 0
        assert session.last_message is None
    
    def test_add_messages(self, session):
        """Add messages to session."""
        session.messages.append(ChatMessage.create("user", "Hello"))
        session.messages.append(ChatMessage.create("assistant", "Hi!"))
        
        assert session.message_count == 2
        assert session.last_message.role == "assistant"
    
    def test_to_dict(self, session):
        """Serialize session to dict."""
        session.messages.append(ChatMessage.create("user", "test"))
        
        d = session.to_dict()
        
        assert d["id"] == "session_001"
        assert d["title"] == "Test Session"
        assert len(d["messages"]) == 1
    
    def test_from_dict(self):
        """Deserialize session from dict."""
        data = {
            "id": "session_002",
            "title": "Loaded Session",
            "created_at": 1000.0,
            "updated_at": 2000.0,
            "messages": [
                {"id": "m1", "role": "user", "content": "msg1", "timestamp": 1500.0, "metadata": {}}
            ],
            "metadata": {},
        }
        
        session = ChatSession.from_dict(data)
        
        assert session.id == "session_002"
        assert session.message_count == 1


class TestChatHistory:
    """Test ChatHistory class."""
    
    @pytest.fixture
    def history(self, tmp_path):
        """Create ChatHistory with temp storage."""
        return ChatHistory(
            storage_path=str(tmp_path / "chats"),
            auto_save=True,
        )
    
    def test_init_creates_storage_dir(self, history):
        """Storage directory is created on init."""
        assert history.storage_path.exists()
    
    def test_create_session(self, history):
        """Create a new chat session."""
        session = history.create_session()
        
        assert session is not None
        assert len(session.id) > 0
        assert history._current_session_id == session.id
        assert session.id in history._sessions
    
    def test_create_session_with_title(self, history):
        """Create session with custom title."""
        session = history.create_session(title="My Custom Chat")
        
        assert session.title == "My Custom Chat"
    
    def test_get_current_session(self, history):
        """Get the current active session."""
        history.create_session()
        
        current = history.get_current_session()
        
        assert current is not None
        assert current.id == history._current_session_id
    
    def test_get_session_by_id(self, history):
        """Retrieve a specific session by ID."""
        created = history.create_session()
        
        retrieved = history.get_session(created.id)
        
        assert retrieved is not None
        assert retrieved.id == created.id
    
    def test_get_nonexistent_session(self, history):
        """Getting nonexistent session returns None."""
        result = history.get_session("nonexistent")
        
        assert result is None
    
    def test_add_message(self, history):
        """Add a message to current session."""
        history.create_session()
        
        msg = history.add_message("user", "Hello from user!")
        
        assert msg.role == "user"
        assert msg.content == "Hello from user!"
        
        # Should be in current session
        current = history.get_current_session()
        assert current.message_count >= 1
    
    def test_auto_generate_title(self, history):
        """Title auto-generated from first user message."""
        history.create_session()
        history.add_message("user", "This is my first message about Python coding")
        
        current = history.get_current_session()
        
        assert "Python" in current.title or "first message" in current.title.lower()
    
    def test_get_messages(self, history):
        """Retrieve messages from session."""
        history.create_session()
        history.add_message("user", "First")
        history.add_message("assistant", "Second")
        history.add_message("user", "Third")
        
        messages = history.get_messages()
        
        assert len(messages) == 3
        assert messages[0].content == "First"
    
    def test_get_messages_with_limit(self, history):
        """Limit number of returned messages."""
        history.create_session()
        for i in range(10):
            history.add_message("user" if i % 2 == 0 else "assistant", f"Msg {i}")
        
        messages = history.get_messages(limit=3)
        
        assert len(messages) == 3
        # Should be last 3 messages
        assert messages[-1].content == "Msg 9"
    
    def test_save_and_load_session(self, history, tmp_path):
        """Session persists to disk and can be reloaded."""
        history.create_session()
        history.add_message("user", "Persistent message")
        
        session_id = history._current_session_id
        
        # Clear from memory
        history._sessions.clear()
        
        # Reload from disk
        loaded = history.get_session(session_id)
        
        assert loaded is not None
        assert loaded.message_count >= 1
        assert loaded.messages[0].content == "Persistent message"
    
    def test_delete_session(self, history):
        """Delete a session."""
        session = history.create_session()
        session_id = session.id
        
        result = history.delete_session(session_id)
        
        assert result is True
        assert session_id not in history._sessions
        assert history._current_session_id is None
    
    def test_list_sessions(self, history):
        """List available sessions."""
        history.create_session(title="First")
        history.create_session(title="Second")
        history.create_session(title="Third")
        
        sessions = history.list_sessions(limit=10)
        
        assert len(sessions) >= 3
        
        # Check format
        for s in sessions:
            assert "id" in s
            assert "title" in s
            assert "message_count" in s
    
    def test_search_messages(self, history):
        """Search messages by content."""
        history.create_session()
        history.add_message("user", "I love Python programming")
        history.add_message("assistant", "Python is great for data science")
        history.add_message("user", "JavaScript is also popular")
        
        results = history.search_messages("python")
        
        assert len(results) >= 2  # Both Python-related messages
        assert all("python" in r["content_preview"].lower() for r in results)
    
    def test_search_no_results(self, history):
        """Search returns empty when no matches."""
        history.create_session()
        history.add_message("user", "Hello world")
        
        results = history.search_messages("xyznonexistent123")
        
        assert len(results) == 0
    
    def test_export_markdown(self, history, tmp_path):
        """Export session as markdown."""
        history.create_session()
        history.add_message("user", "User message here")
        history.add_message("assistant", "Assistant response")
        
        export_path = str(tmp_path / "export.md")
        path = history.export_session(history._current_session_id, "markdown", export_path)
        
        assert Path(path).exists()
        
        content = Path(path).read_text()
        assert "# " in content  # Markdown heading
        assert "User message here" in content or "user" in content.lower()


class TestChatHistoryEdgeCases:
    """Test edge cases and error handling."""
    
    @pytest.fixture
    def history(self, tmp_path):
        return ChatHistory(storage_path=str(tmp_path / "chats"))
    
    def test_add_message_without_session(self, history):
        """Adding message without session creates one automatically."""
        msg = history.add_message("user", "Auto-create session")
        
        assert msg is not None
        assert history._current_session_id is not None
    
    def test_set_current_session_valid(self, history):
        """Set current session to valid ID."""
        session = history.create_session()
        
        history.set_current_session(session.id)
        
        assert history._current_session_id == session.id
    
    def test_set_current_session_invalid(self, history):
        """Setting invalid session ID raises error."""
        with pytest.raises(ValueError, match="not found"):
            history.set_current_session("invalid_id_12345")
    
    def test_message_limit_enforced(self, tmp_path):
        """Old messages removed when limit reached."""
        history = ChatHistory(
            storage_path=str(tmp_path / "chats"),
            max_messages_per_session=5,
        )
        history.create_session()
        
        # Add more than limit
        for i in range(10):
            history.add_message("user", f"Message {i}")
        
        current = history.get_current_session()
        
        # Should have at most max_messages
        assert current.message_count <= 5


class TestChatHistoryStats:
    """Test statistics and metadata."""
    
    @pytest.fixture
    def history(self, tmp_path):
        return ChatHistory(storage_path=str(tmp_path / "chats"))
    
    def test_get_stats_empty(self, history):
        """Stats for empty history."""
        stats = history.get_stats()
        
        assert stats["total_sessions"] == 0
        assert stats["total_messages"] == 0
    
    def test_get_stats_with_data(self, history):
        """Stats after adding data."""
        history.create_session()
        history.add_message("user", "test")
        history.add_message("assistant", "response")
        
        stats = history.get_stats()
        
        assert stats["total_sessions"] >= 1
        assert stats["total_messages"] >= 2
    
    def test_cleanup_old_sessions(self, history):
        """Cleanup removes old sessions."""
        # Create more sessions than keep_recent allows
        for i in range(10):
            history.create_session(f"Session {i}")
        
        history.cleanup_old_sessions(keep_recent=5)
        
        sessions = history.list_sessions(limit=20)
        
        assert len(sessions) <= 5
