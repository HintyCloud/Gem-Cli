"""
Tests for LLM Provider (opencode.py)

Covers provider initialization, message handling, streaming,
tool calling, and error scenarios.
"""

import asyncio
import json
import pytest
from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock

from gem.providers.opencode import (
    OpenCodeProvider,
    Message,
    ToolCall,
    ToolDefinition,
    ChatResponse,
    create_provider_from_config,
)


class TestMessage:
    """Test Message dataclass."""
    
    def test_create_user_message(self):
        """Create a basic user message."""
        msg = Message(role="user", content="Hello")
        assert msg.role == "user"
        assert msg.content == "Hello"
        assert msg.tool_calls is None
    
    def test_create_assistant_message_with_tools(self):
        """Create assistant message with tool calls."""
        tool_calls = [{"id": "call_1", "function": {"name": "shell", "arguments": "{}"}}]
        msg = Message(role="assistant", content="", tool_calls=tool_calls)
        
        assert len(msg.tool_calls) == 1
        assert msg.tool_calls[0]["id"] == "call_1"
    
    def test_create_tool_result_message(self):
        """Create tool result message."""
        msg = Message(
            role="tool",
            content="Command output",
            tool_call_id="call_1",
            name="shell"
        )
        
        assert msg.role == "tool"
        assert msg.tool_call_id == "call_1"
        assert msg.name == "shell"
    
    def test_to_dict_basic(self):
        """Convert basic message to dict."""
        msg = Message(role="user", content="test")
        d = msg.to_dict()
        
        assert d["role"] == "user"
        assert d["content"] == "test"
        assert "tool_calls" not in d
    
    def test_to_dict_with_tool_calls(self):
        """Convert message with tool calls to dict."""
        tc = [{"id": "call_1", "function": {"name": "test", "arguments": "{}}"}}]
        msg = Message(role="assistant", content="done", tool_calls=tc)
        d = msg.to_dict()
        
        assert "tool_calls" in d
        assert len(d["tool_calls"]) == 1


class TestToolCall:
    """Test ToolCall dataclass."""
    
    def test_create_tool_call(self):
        """Create a basic tool call."""
        tc = ToolCall(id="call_1", name="shell", arguments='{"command":"ls"}')
        
        assert tc.id == "call_1"
        assert tc.name == "shell"
        assert '"command"' in tc.arguments


class TestChatResponse:
    """Test ChatResponse dataclass."""
    
    def test_response_without_tools(self):
        """Response without tool calls."""
        resp = ChatResponse(content="Hello!")
        
        assert resp.content == "Hello!"
        assert not resp.has_tool_calls
        assert resp.finish_reason == "stop"
    
    def test_response_with_tools(self):
        """Response with tool calls."""
        tc = ToolCall(id="call_1", name="shell", arguments='{}')
        resp = ChatResponse(content=None, tool_calls=[tc], finish_reason="tool_calls")
        
        assert resp.has_tool_calls
        assert resp.finish_reason == "tool_calls"


class TestOpenCodeProvider:
    """Test OpenCodeProvider class."""
    
    @pytest.fixture
    def provider(self):
        """Create a provider instance for testing."""
        return OpenCodeProvider(
            api_url="https://test.api/v1",
            api_key="test-key-12345",
            model="test-model",
        )
    
    def test_init_defaults(self):
        """Test initialization with defaults."""
        provider = OpenCodeProvider()
        
        assert provider.model == "longcat-2.0-free"
        assert provider.temperature == 0.7
        assert provider.max_tokens == 4096
        assert len(provider.messages) == 0
    
    def test_init_custom(self):
        """Test initialization with custom values."""
        provider = OpenCodeProvider(
            api_url="https://custom.api/v1",
            api_key="custom-key",
            model="custom-model",
            temperature=0.5,
            max_tokens=1000,
            timeout=60,
        )
        
        assert "custom.api" in provider.api_url
        assert provider.api_key == "custom-key"
        assert provider.model == "custom-model"
        assert provider.temperature == 0.5
        assert provider.max_tokens == 1000
        assert provider.timeout == 60
    
    def test_init_no_httpx(self):
        """Test that missing httpx raises error."""
        with patch.dict('sys.modules', {'httpx': None}):
            with pytest.raises(ImportError, match="httpx"):
                OpenCodeProvider()
    
    @pytest.mark.asyncio
    async def test_add_message(self, provider):
        """Test adding messages to history."""
        provider.add_message("user", "Hello")
        provider.add_message("assistant", "Hi there!")
        
        assert provider.message_count == 2
        
        # Check last message
        last_msg = provider.messages[-1]
        assert last_msg.role == "assistant"
        assert last_msg.content == "Hi there!"
    
    @pytest.mark.asyncio
    async def test_add_tool_result(self, provider):
        """Test adding tool result to history."""
        provider.add_tool_result("call_123", "output text", "shell")
        
        assert provider.message_count == 1
        result_msg = provider.messages[0]
        
        assert result_msg.role == "tool"
        assert result_msg.tool_call_id == "call_123"
        assert result_msg.name == "shell"
        assert result_msg.content == "output text"
    
    @pytest.mark.asyncio
    async def test_clear_history(self, provider):
        """Test clearing message history."""
        provider.add_message("user", "test")
        provider.add_message("assistant", "response")
        
        assert provider.message_count == 2
        
        provider.clear_history()
        
        assert provider.message_count == 0
    
    @pytest.mark.asyncio
    async def test_get_history(self, provider):
        """Test getting message history."""
        msgs = [Message(role="user", content=f"msg{i}") for i in range(3)]
        for m in msgs:
            provider.messages.append(m)
        
        history = provider.get_history()
        
        assert len(history) == 3
        assert history[0].content == "msg0"
    
    @pytest.mark.asyncio
    async def test_set_history(self, provider):
        """Test setting message history."""
        new_msgs = [
            Message(role="system", content="You are helpful"),
            Message(role="user", content="Hello"),
        ]
        
        provider.set_history(new_msgs)
        
        assert provider.message_count == 2
        assert provider.messages[0].role == "system"
    
    @pytest.mark.asyncio
    async def test_summarize_history(self, provider):
        """Test summarizing/compressing history."""
        # Add some messages
        for i in range(10):
            provider.add_message("user" if i % 2 == 0 else "assistant", f"message {i}")
        
        # Summarize
        provider.summarize_history("This was a conversation about coding.")
        
        # Should have only the summary now
        assert provider.message_count == 1
        assert "conversation about coding" in provider.messages[0].content.lower()
    
    @pytest.mark.asyncio
    async def test_chat_success(self, provider, mock_http_client):
        """Test successful chat completion."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": "Hello! How can I help?",
                },
                "finish_reason": "stop",
            }],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5},
            "model": "test-model",
        }
        
        mock_http_client.post.return_value = asyncio.Future()
        mock_http_client.post.return_value.set_result(mock_response)
        provider._client = mock_http_client
        
        response = await provider.chat("Hello")
        
        assert response.success is True  # type: ignore
        assert "help" in response.content.lower()  # type: ignore
        assert response.model == "test-model"  # type: ignore
    
    @pytest.mark.asyncio
    async def test_chat_with_tool_calls(self, provider, mock_http_client):
        """Test chat that returns tool calls."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": None,
                    "tool_calls": [{
                        "id": "call_123",
                        "type": "function",
                        "function": {
                            "name": "shell",
                            "arguments": '{"command": "echo hello"}',
                        }
                    }]
                },
                "finish_reason": "tool_calls",
            }],
            "usage": {},
            "model": "test-model",
        }
        
        mock_http_client.post.return_value = asyncio.Future()
        mock_http_client.post.return_value.set_result(mock_response)
        provider._client = mock_http_client
        
        response = await provider.chat("run echo hello")
        
        assert response.has_tool_calls  # type: ignore
        assert len(response.tool_calls) == 1  # type: ignore
        assert response.tool_calls[0].name == "shell"  # type: ignore
    
    @pytest.mark.asyncio
    async def test_chat_http_error(self, provider, mock_http_client):
        """Test handling of HTTP errors."""
        import httpx
        
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.text = "Unauthorized"
        
        error = httpx.HTTPStatusError("Unauthorized", request=MagicMock(), response=mock_response)
        mock_http_client.post.side_effect = error
        provider._client = mock_http_client
        
        with pytest.raises(RuntimeError, match="API error"):
            await provider.chat("test")
    
    @pytest.mark.asyncio
    async def test_chat_stream_basic(self, provider, mock_http_client):
        """Test streaming chat response."""
        chunks = [
            'data: {"choices":[{"delta":{"content":"Hello"},"index":0}]}\n\n',
            'data: {"choices":[{"delta":{"content":" world!"},"index":0}]}\n\n',
            'data: [DONE]\n\n',
        ]
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.aiter_lines = AsyncMock(return_value=iter(chunks))
        mock_response.__aenter__ = AsyncMock(return_value=mock_response)
        mock_response.__aexit__ = AsyncMock(return_value=False)
        
        mock_http_client.stream.return_value.__aenter__ = AsyncMock(return_value=mock_response)
        mock_http_client.stream.return_value.__aexit__ = AsyncMock(return_value=False)
        provider._client = mock_http_client
        
        collected = []
        async for chunk in provider.chat_stream("say hello"):
            collected.append(chunk)
        
        # Should have collected content chunks
        assert any(c == "Hello" for c in collected)
        assert any(c == " world!" for c in collected)
    
    @pytest.mark.asyncio
    async def test_close(self, provider, mock_http_client):
        """Test closing the HTTP client."""
        provider._client = mock_http_client
        
        await provider.close()
        
        assert mock_http_client.aclose.called


class TestCreateProviderFromConfig:
    """Test factory function for creating providers from config."""
    
    def test_from_config_full(self, sample_config):
        """Create provider from full configuration."""
        provider = create_provider_from_config(sample_config)
        
        assert provider.api_url == "https://opencode.ai/zen/v1"
        assert provider.api_key == "test-api-key"
        assert provider.model == "longcat-2.0-free"
    
    def test_from_config_empty(self):
        """Create provider from empty config (uses defaults)."""
        provider = create_provider_from_config({})
        
        assert provider.model == "longcat-2.0-free"
        assert provider.temperature == 0.7
    
    def test_from_config_partial(self):
        """Create provider from partial config."""
        config = {
            "model": {
                "api_url": "https://custom.url/v1",
                # Missing other fields - should use defaults
            }
        }
        
        provider = create_provider_from_config(config)
        
        assert provider.api_url == "https://custom.url/v1"
        assert provider.model == "longcat-2.0-free"  # Default


class TestLoadTomlConfig:
    """Test TOML configuration loading."""
    
    def test_load_nonexistent_file(self):
        """Test loading nonexistent file returns empty dict."""
        from gem.providers.opencode import load_toml_config
        
        config = load_toml_config("/nonexistent/path/config.toml")
        
        assert config == {}
    
    def test_load_default_locations(self, tmp_path):
        """Test loading from default locations."""
        from gem.providers.opencode import load_toml_config
        
        # Create a temp config file
        config_file = tmp_path / "config.toml"
        config_file.write_text('[model]\ndefault_model = "test-model"\n')
        
        # Temporarily change to that directory and test
        import os
        original_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            config = load_toml_config()
            
            assert config.get("model", {}).get("default_model") == "test-model"
        finally:
            os.chdir(original_cwd)
