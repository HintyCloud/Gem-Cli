# Gem - Autonomous AI Coding Agent

**Gem** is a powerful terminal-based AI agent that can autonomously execute tasks using tool calling. It combines the power of Large Language Models with shell commands, file operations, and web search to help you accomplish complex coding and system administration tasks.

## ✨ Features

- **🤖 Autonomous Agent Loop**: ReAct pattern (Reason → Act → Observe) for intelligent task execution
- **🔧 Tool Calling**: Built-in tools for shell execution, file operations, and web search
- **💬 Streaming Responses**: Real-time output as the agent thinks and acts
- **📋 Task Planning**: Automatic decomposition of complex requests into step-by-step plans
- **💾 Persistent Memory**: Remembers preferences and facts across sessions
- **🔄 Checkpoint System**: Save/restore state for long-running tasks
- **🛡️ Security**: Workspace isolation, path validation, command filtering
- **📱 Cross-Platform**: Works on Linux, macOS, and Android/Termux (ARM64)

## 🚀 Quick Start

### Installation

```bash
# Clone or download the project
cd Gem

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -e ".[dev]"
```

### Configuration

Edit `config/config.toml` or set environment variables:

```bash
export GEM_API_KEY="your-api-key-here"
```

### Run Gem

```bash
# Interactive mode
gem

# Single message mode
gem -m "Create a Python web server"

# With custom workspace
gem -w /path/to/project
```

## 🎯 Usage Examples

### Basic Chat
```
> Hello Gem!
🤖 Gem: Hi! I'm your AI assistant. How can I help you today?
```

### Execute Commands
```
> List files in current directory
🔧 shell: ls -la
   total 24
   drwxr-xr-x  5 user user 4096 Aug  9 17:00 .
   ...
   
🤖 Gem: I found 5 items in the directory...
```

### Create Files
```
> Create a hello world Python script
🔧 file: write (path=hello.py)
🔧 shell: python3 hello.py
   
🤖 Gem: Created hello.py and ran it successfully!
```

### Web Search
```
> What's the latest Python version?
🔧 web_search: query="latest Python version release"
   
🤖 Gem: According to my search, Python 3.12 was released in October 2023...
```

## 🏗️ Architecture

```
Gem/
├── gem/
│   ├── agent/          # Core agentic loop
│   │   ├── loop.py    # Main ReAct loop
│   │   ├── planner.py # Task decomposition
│   │   └── context.py # Context & checkpoint management
│   ├── tools/         # Tool implementations
│   │   ├── base.py    # Tool registry & base class
│   │   ├── shell.py   # Command execution
│   │   ├── files.py   # File operations
│   │   └── web.py     # Web search
│   ├── memory/        # Persistence layer
│   │   ├── history.py # Chat history
│   │   └── memory.py  # Long-term memory
│   ├── providers/     # LLM providers
│   │   └── opencode.py# OpenCode/OpenAI API
│   └── cli.py         # Terminal interface
├── config/            # Configuration files
├── tests/             # Test suite (212 tests)
└── projects/          # Default workspace
```

## 🔧 Available Tools

| Tool | Description | Example |
|------|-------------|---------|
| `shell` | Execute terminal commands | `ls -la`, `python script.py` |
| `file` | Read/write/list/edit files | Create, modify, search files |
| `web_search` | Search the web for information | Find docs, look up APIs |

## ⌨️ Slash Commands

While running Gem, use these commands:

| Command | Description |
|---------|-------------|
| `/help` | Show available commands |
| `/clear` | Clear conversation context |
| `/reset` | Full reset (new session) |
| `/model [name]` | View/set LLM model |
| `/status` | Show agent status |
| `/history` | List chat sessions |
| `/export [path]` | Export session to file |
| `/quit` | Exit Gem |

## 🧪 Testing

```bash
# Run all tests
pytest tests/ -v

# Run specific test module
pytest tests/test_shell.py -v

# Run with coverage
pytest --cov=gem tests/
```

**Test Results**: 212+ tests covering all major components.

## 🔒 Security Features

- **Workspace Isolation**: File operations restricted to working directory
- **Path Validation**: Prevents path traversal attacks
- **Command Filtering**: Blocks dangerous patterns (`rm -rf /`, fork bombs)
- **Timeout Protection**: Commands auto-terminate after configurable timeout
- **API Key Safety**: Keys stored in config/env vars, never logged

## 📱 ARM/Termux Compatibility

Gem is designed to work on:
- ✅ Linux (x86_64, ARM64)
- ✅ macOS (Intel, Apple Silicon)
- ✅ Android via Termux
- ✅ WSL (Windows Subsystem for Linux)

Pure Python implementation where possible, no platform-specific binaries required.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details.

---

**Built with ❤️ using OpenCode API**
