# Gem — Windows

Gem does NOT assume Bash. It uses cmd/PowerShell via the platform adapter.

## Requirements
- Python 3.10+ (python.org)
- (optional) Node.js 18+ for the Web UI

## Install
```powershell
Expand-Archive Gem-Windows.tar.gz .
cd Gem-Windows
pip install -e .
```

## Run
```bat
run.bat
```
Starts the Gem API on 127.0.0.1:8000. For the Web UI, in another terminal:
```powershell
cd src; bun install; bun run dev
```

## CLI
```powershell
gem status
gem chat
```

Configure `config/secrets.toml` with your `[opencode] api_key`.
