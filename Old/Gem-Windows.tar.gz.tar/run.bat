@echo off
cd /d %~dp0
python -m pip install -e . --quiet
python -m gem.cli serve --host 127.0.0.1 --port 8000
