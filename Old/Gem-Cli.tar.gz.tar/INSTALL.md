# Gem — CLI (terminal-first)

A terminal-focused distribution: providers, API keys, model selection,
configuration, tools, agents, swarm, subagents, jobs, projects.

## Install
```bash
tar xzf Gem-Cli.tar.gz
cd Gem-Cli
pip install -e .
```

## Configure providers / models
```bash
gem providers          # list
gem models             # current model
# Add key in config/secrets.toml: [opencode] api_key = "sk-..."
```

## Use
```bash
gem chat               # interactive (slash commands: /help /model /chats ...)
gem project list
gem jobs
@swarm <task>          # run a task through the swarm inside chat
```

## Commands
`gem serve | chat | project | jobs | models | providers | tools | agents | status`
