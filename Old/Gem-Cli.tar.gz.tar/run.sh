#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m pip install -e . --quiet 2>/dev/null || true
python3 -m gem.cli chat
