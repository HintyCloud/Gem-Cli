/**
 * InGem AI - Chat Interface JavaScript
 * Handles chat functionality, streaming, and UI interactions
 */

// State
let isGenerating = false;
let currentMessageElement = null;
let messageHistory = [];

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // Focus input
    const input = document.getElementById('messageInput');
    if (input) {
        input.focus();
    }
    
    // Load chat history from localStorage
    loadChatHistory();
});

/**
 * Send a message to the AI
 */
async function sendMessage() {
    const input = document.getElementById('messageInput');
    const sendBtn = document.getElementById('sendBtn');
    const message = input.value.trim();
    
    if (!message || isGenerating) return;
    
    // Clear input
    input.value = '';
    autoResize(input);
    
    // Hide welcome screen
    hideWelcomeScreen();
    
    // Add user message to UI
    addMessageToUI('user', message);
    
    // Disable input while generating
    isGenerating = true;
    sendBtn.disabled = true;
    
    // Create assistant message container
    currentMessageElement = createAssistantMessageContainer();
    
    try {
        // Send to API with streaming
        await streamMessage(message);
    } catch (error) {
        console.error('Error sending message:', error);
        showError(`Erro: ${error.message}`);
        isGenerating = false;
        sendBtn.disabled = false;
    }
}

/**
 * Stream message from server using SSE
 */
async function streamMessage(message) {
    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message }),
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        
        while (true) {
            const { done, value } = await reader.read();
            
            if (done) break;
            
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';
            
            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    try {
                        const data = JSON.parse(line.slice(6));
                        handleStreamData(data);
                    } catch (e) {
                        console.warn('Failed to parse SSE data:', line);
                    }
                }
            }
        }
        
        // Finalize
        finishMessage();
        
    } catch (error) {
        throw error;
    }
}

/**
 * Handle incoming stream data
 */
function handleStreamData(data) {
    switch (data.type) {
        case 'chunk':
            appendToCurrentMessage(data.content);
            break;
        case 'done':
            finishMessage();
            break;
        case 'error':
            showError(data.content);
            finishMessage();
            break;
    }
}

/**
 * Append text to current assistant message
 */
function appendToCurrentMessage(text) {
    if (!currentMessageElement) return;
    
    let contentDiv = currentMessageElement.querySelector('.message-content');
    if (contentDiv) {
        contentDiv.innerHTML += escapeHtml(text);
        // Render markdown and highlight code
        contentDiv.innerHTML = marked.parse(contentDiv.textContent || '');
        contentDiv.querySelectorAll('pre code').forEach((block) => {
            hljs.highlightElement(block);
            addCopyButton(block);
        });
        scrollToBottom();
    }
}

/**
 * Finish the current message
 */
function finishMessage() {
    isGenerating = false;
    document.getElementById('sendBtn').disabled = false;
    
    // Save to history
    saveChatHistory();
}

/**
 * Show error in message area
 */
function showError(message) {
    if (currentMessageElement) {
        let contentDiv = currentMessageElement.querySelector('.message-content');
        if (contentDiv) {
            contentDiv.innerHTML += `<div class="error-message">${escapeHtml(message)}</div>`;
        }
    }
}

/**
 * Add message to UI
 */
function addMessageToUI(role, content) {
    const messagesList = document.getElementById('messagesList');
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;
    
    const avatarClass = role === 'user' ? 'user' : 'assistant';
    const avatarText = role === 'user' ? 'Você' : '💎';
    const roleText = role === 'user' ? 'Você' : 'InGem AI';
    
    messageDiv.innerHTML = `
        <div class="message-header">
            <div class="message-avatar ${avatarClass}">${avatarText}</div>
            <span class="message-role">${roleText}</span>
        </div>
        <div class="message-content">${role === 'assistant' ? marked.parse(content) : escapeHtml(content)}</div>
    `;
    
    messagesList.appendChild(messageDiv);
    
    // Highlight code blocks
    messageDiv.querySelectorAll('pre code').forEach((block) => {
        hljs.highlightElement(block);
        addCopyButton(block);
    });
    
    scrollToBottom();
    
    // Add to history
    messageHistory.push({ role, content, timestamp: Date.now() });
}

/**
 * Create empty assistant message container
 */
function createAssistantMessageContainer() {
    const messagesList = document.getElementById('messagesList');
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message assistant';
    
    messageDiv.innerHTML = `
        <div class="message-header">
            <div class="message-avatar assistant">💎</div>
            <span class="message-role">InGem AI</span>
        </div>
        <div class="message-content">
            <div class="typing-indicator">
                <span></span><span></span><span></span>
            </div>
        </div>
    `;
    
    messagesList.appendChild(messageDiv);
    scrollToBottom();
    
    return messageDiv;
}

/**
 * Handle keyboard events
 */
function handleKeyDown(event) {
    // Enter to send (without Shift)
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
    }
}

/**
 * Auto-resize textarea
 */
function autoResize(textarea) {
    textarea.style.height = 'auto';
    textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
}

/**
 * Scroll to bottom of messages
 */
function scrollToBottom() {
    const container = document.getElementById('messagesContainer');
    if (container) {
        container.scrollTop = container.scrollHeight;
    }
}

/**
 * Toggle sidebar visibility
 */
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('open');
}

/**
 * Start new chat
 */
function newChat() {
    // Clear messages
    const messagesList = document.getElementById('messagesList');
    messagesList.innerHTML = '';
    
    // Show welcome screen
    showWelcomeScreen();
    
    // Clear history
    messageHistory = [];
    saveChatHistory();
}

/**
 * Send suggestion from welcome screen
 */
function sendSuggestion(text) {
    document.getElementById('messageInput').value = text;
    sendMessage();
}

/**
 * Hide welcome screen
 */
function hideWelcomeScreen() {
    const welcome = document.getElementById('welcomeScreen');
    if (welcome) {
        welcome.style.display = 'none';
    }
}

/**
 * Show welcome screen
 */
function showWelcomeScreen() {
    const welcome = document.getElementById('welcomeScreen');
    if (welcome) {
        welcome.style.display = 'flex';
    }
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Add copy button to code blocks
 */
function addCopyButton(codeBlock) {
    const pre = codeBlock.parentElement;
    if (pre && !pre.querySelector('.copy-code-btn')) {
        const btn = document.createElement('button');
        btn.className = 'copy-code-btn';
        btn.textContent = 'Copiar';
        btn.onclick = () => {
            navigator.clipboard.writeText(codeBlock.textContent).then(() => {
                btn.textContent = 'Copiado!';
                setTimeout(() => btn.textContent = 'Copiar', 2000);
            });
        };
        pre.appendChild(btn);
    }
}

/**
 * Save chat history to localStorage
 */
function saveChatHistory() {
    try {
        localStorage.setItem('gem_chat_history', JSON.stringify(messageHistory));
    } catch (e) {
        console.warn('Failed to save chat history:', e);
    }
}

/**
 * Load chat history from localStorage
 */
function loadChatHistory() {
    try {
        const saved = localStorage.getItem('gem_chat_history');
        if (saved) {
            messageHistory = JSON.parse(saved);
            
            // Restore messages to UI
            hideWelcomeScreen();
            messageHistory.forEach(msg => {
                addMessageToUIWithoutScroll(msg.role, msg.content);
            });
        }
    } catch (e) {
        console.warn('Failed to load chat history:', e);
    }
}

/**
 * Add message without scrolling (for loading history)
 */
function addMessageToUIWithoutScroll(role, content) {
    const messagesList = document.getElementById('messagesList');
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;
    
    const avatarClass = role === 'user' ? 'user' : 'assistant';
    const avatarText = role === 'user' ? 'Você' : '💎';
    const roleText = role === 'user' ? 'Você' : 'InGem AI';
    
    messageDiv.innerHTML = `
        <div class="message-header">
            <div class="message-avatar ${avatarClass}">${avatarText}</div>
            <span class="message-role">${roleText}</span>
        </div>
        <div class="message-content">${role === 'assistant' ? marked.parse(content) : escapeHtml(content)}</div>
    `;
    
    messagesList.appendChild(messageDiv);
    
    // Highlight code blocks
    messageDiv.querySelectorAll('pre code').forEach((block) => {
        hljs.highlightElement(block);
        addCopyButton(block);
    });
}
