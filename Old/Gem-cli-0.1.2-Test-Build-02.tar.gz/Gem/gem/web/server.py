"""
Gem Web Server - ChatGPT-style Interface

Provides a modern web interface for Gem AI Agent using Flask.
Features:
- ChatGPT-like UI with dark/light theme
- Streaming responses
- Markdown rendering
- Code syntax highlighting
- Image display
- Multi-language support (auto-detect)
"""

import asyncio
import json
import logging
import os
from typing import Optional

from flask import (
    Flask, render_template, request, jsonify,
    Response, stream_with_context, send_from_directory
)

logger = logging.getLogger(__name__)

# Global reference to CLI for agent access
_gem_cli = None


def create_app(gem_cli=None):
    """
    Create and configure the Flask application.
    
    Args:
        gem_cli: Instance of GemCLI for agent access
        
    Returns:
        Configured Flask app
    """
    global _gem_cli
    _gem_cli = gem_cli
    
    app = Flask(
        __name__,
        template_folder='templates',
        static_folder='static',
        static_url_path='/static'
    )
    
    # Configuration
    app.config['SECRET_KEY'] = 'ingem-ai-secret-key-2024'
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max
    
    # Routes
    @app.route('/')
    def index():
        """Serve the main chat interface."""
        return render_template('chat.html')
    
    @app.route('/api/chat', methods=['POST'])
    async def chat():
        """Handle chat messages and return streaming response."""
        data = request.get_json()
        
        if not data or 'message' not in data:
            return jsonify({'error': 'No message provided'}), 400
        
        user_message = data['message']
        
        if not _gem_cli or not _gem_cli.agent:
            return jsonify({'error': 'Agent not initialized'}), 500
        
        # Detect language and update system prompt
        from gem.cli import detect_language, get_language_system_prompt
        detected_lang = detect_language(user_message)
        _gem_cli.user_language = detected_lang
        _gem_cli.agent.system_prompt = get_language_system_prompt(user_message)
        
        def generate():
            """Generator for streaming response."""
            try:
                # Create async loop for agent processing
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                try:
                    # Process message through agent
                    result = loop.run_until_complete(
                        _gem_cli.agent.process_message(user_message)
                    )
                    
                    # Stream the response in chunks
                    response_text = result.get('response', '')
                    
                    # Send as SSE (Server-Sent Events)
                    chunk_size = 2  # Small chunks for typewriter effect
                    for i in range(0, len(response_text), chunk_size):
                        chunk = response_text[i:i+chunk_size]
                        data = json.dumps({
                            'type': 'chunk',
                            'content': chunk
                        })
                        yield f"data: {data}\n\n"
                    
                    # Send completion signal
                    done_data = json.dumps({
                        'type': 'done',
                        'tool_calls': result.get('tool_calls', []),
                        'iterations': result.get('iterations', 0)
                    })
                    yield f"data: {done_data}\n\n"
                    
                finally:
                    loop.close()
                    
            except Exception as e:
                logger.error(f"Error in chat: {e}")
                error_data = json.dumps({
                    'type': 'error',
                    'content': str(e)
                })
                yield f"data: {error_data}\n\n"
        
        return Response(
            stream_with_context(generate()),
            mimetype='text/event-stream',
            headers={
                'Cache-Control': 'no-cache',
                'X-Accel-Buffering': 'no'
            }
        )
    
    @app.route('/api/status', methods=['GET'])
    def status():
        """Get current agent status."""
        if not _gem_cli or not _gem_cli.agent:
            return jsonify({'status': 'not_initialized'})
        
        agent_status = _gem_cli.agent.get_status()
        
        if _gem_cli.provider:
            provider_status = _gem_cli.provider.get_status_info()
        else:
            provider_status = {}
        
        return jsonify({
            'agent': agent_status,
            'provider': provider_status,
            'language': getattr(_gem_cli, 'user_language', 'en')
        })
    
    @app.route('/api/config', methods=['GET'])
    def config():
        """Get configuration (masked)."""
        return jsonify({
            'provider': 'InGem AI',
            'api_url': 'https://ingem.ai/agent/v1/chat/completions',
            'model': 'longcat-2.0-free',
            'features': [
                'chat',
                'code_execution',
                'file_operations',
                'web_search',
                'image_generation'
            ]
        })
    
    @app.route('/health', methods=['GET'])
    def health():
        """Health check endpoint."""
        return jsonify({'status': 'healthy'})
    
    return app


async def start_web_server(port: int = 7860, gem_cli=None):
    """
    Start the web server.
    
    Args:
        port: Port to listen on
        gem_cli: GemCLI instance for agent access
    """
    global _gem_cli
    _gem_cli = gem_cli
    
    app = create_app(gem_cli)
    
    # Use Flask's development server (for production, use gunicorn)
    import threading
    
    def run_flask():
        app.run(
            host='0.0.0.0',
            port=port,
            debug=False,
            use_reloader=False
        )
    
    # Run Flask in a separate thread
    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()
    
    logger.info(f"Web server started on http://localhost:{port}")
    
    # Keep the coroutine alive
    while True:
        await asyncio.sleep(3600)  # Check every hour


if __name__ == '__main__':
    print("Starting InGem AI Web Interface...")
    print("Access at http://localhost:7860")
    
    app = create_app()
    app.run(host='0.0.0.0', port=7860, debug=True)
