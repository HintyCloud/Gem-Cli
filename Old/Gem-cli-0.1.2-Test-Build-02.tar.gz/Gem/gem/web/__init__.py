"""
Gem Web Interface Module

Provides ChatGPT-style web interface for Gem AI Agent.
"""

from .server import create_app, start_web_server

__all__ = ['create_app', 'start_web_server']
