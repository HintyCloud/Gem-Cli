"""
Image Generation Tool for Gem

Generates images using Pollinations AI API.
Model: recraft-v4.1-vector (or customizable)
"""

import logging
import urllib.request
import urllib.parse
import json
import os
from pathlib import Path
from typing import Any, Dict, Optional
from dataclasses import dataclass

try:
    import httpx
except ImportError:
    httpx = None  # type: ignore

from .base import Tool, ToolResult, ToolRegistry

logger = logging.getLogger(__name__)


@dataclass
class ImageGenerationConfig:
    """Configuration for image generation."""
    model: str = "recraft-v4.1-vector"
    width: int = 1024
    height: int = 1024
    seed: Optional[int] = None
    enhance: bool = True
    nologo: bool = True
    output_dir: str = "projects/generated_images"


class ImageGenTool(Tool):
    """
    Tool for generating images using Pollinations AI.
    
    Supports various models including:
    - recraft-v4.1-vector (default, good for general images)
    - flux (realistic images)
    - turbo (fast generation)
    - And more from Pollinations
    
    Example usage:
        "Generate an image of a cat wearing sunglasses"
        "Crie uma imagem de um robô programando"
    """
    
    name = "image_generator"
    description = """Generate images using AI. Use this when the user asks to create, generate, or make an image, picture, drawing, or visual content.
Supports multiple languages for prompts. Can generate:
- Art and illustrations
- Photos and realistic images
- Logos and icons
- Concept art
- And much more

Examples of when to use:
- "generate an image of X"
- "create a picture of Y"
- "faça uma imagem de Z"
- "draw me a W"
- "crie um logo para..."
"""
    
    # Input schema for function calling
    parameters = {
        "type": "object",
        "properties": {
            "prompt": {
                "type": "string",
                "description": "Detailed description of the image to generate (supports any language)"
            },
            "model": {
                "type": "string",
                "description": "Model to use (default: recraft-v4.1-vector)",
                "enum": ["recraft-v4.1-vector", "flux", "flux-realism", "flux-cablyai", "flux-anime", "turbo", "midjourney"]
            },
            "width": {
                "type": "integer",
                "description": "Image width in pixels (default: 1024)",
                "minimum": 256,
                "maximum": 2048
            },
            "height": {
                "type": "integer",
                "description": "Image height in pixels (default: 1024)",
                "minimum": 256,
                "maximum": 2048
            },
            "seed": {
                "type": "integer",
                "description": "Seed for reproducible generation (optional)"
            }
        },
        "required": ["prompt"]
    }
    
    def __init__(self, config: Optional[ImageGenerationConfig] = None):
        """
        Initialize image generation tool.
        
        Args:
            config: Generation configuration options
        """
        self.config = config or ImageGenerationConfig()
        
        # Ensure output directory exists
        self.output_dir = Path(self.config.output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"ImageGenTool initialized with model {self.config.model}")
    
    def _build_url(self, prompt: str, **kwargs) -> str:
        """
        Build the Pollinations image URL.
        
        Args:
            prompt: Image description
            **kwargs: Additional parameters
            
        Returns:
            URL for the generated image
        """
        model = kwargs.get("model", self.config.model)
        width = kwargs.get("width", self.config.width)
        height = kwargs.get("height", self.config.height)
        seed = kwargs.get("seed", self.config.seed)
        
        # Build the base URL
        base_url = f"https://image.pollinations.ai/prompt/{urllib.parse.quote(prompt)}"
        
        # Add query parameters
        params = {
            "model": model,
            "width": width,
            "height": height,
            "nologo": "true" if self.config.nologo else "false",
            "enhance": "true" if self.config.enhance else "false",
        }
        
        if seed is not None:
            params["seed"] = str(seed)
        
        # Build query string
        query_string = "&".join(f"{k}={v}" for k, v in params.items())
        
        return f"{base_url}?{query_string}"
    
    async def execute(self, prompt: str, **kwargs) -> ToolResult:
        """
        Generate an image based on the prompt.
        
        Args:
            prompt: Description of the image to generate
            **kwargs: Additional options (model, width, height, seed)
            
        Returns:
            ToolResult with image path/URL
        """
        try:
            # Build the URL
            url = self._build_url(prompt, **kwargs)
            
            logger.info(f"Generating image with prompt: {prompt[:50]}...")
            
            # Generate unique filename
            import time
            timestamp = int(time.time())
            safe_prompt = "".join(c if c.isalnum() else "_" for c in prompt[:30])
            filename = f"img_{timestamp}_{safe_prompt}.png"
            filepath = self.output_dir / filename
            
            # Download the image
            if httpx:
                async with httpx.AsyncClient(timeout=120.0) as client:
                    response = await client.get(url)
                    response.raise_for_status()
                    
                    with open(filepath, 'wb') as f:
                        f.write(response.content)
            else:
                # Fallback to urllib
                urllib.request.urlretrieve(url, str(filepath))
            
            file_size = os.path.getsize(filepath) / 1024  # KB
            
            # Return success result
            return ToolResult(
                success=True,
                output=f"""✅ Image generated successfully!

**Prompt:** {prompt}
**Model:** {kwargs.get('model', self.config.model)}
**Size:** {kwargs.get('width', self.config.width)}x{kwargs.get('height', self.config.height)}
**File:** {filepath.absolute()}
**Size:** {file_size:.1f} KB

**URL:** {url}

The image has been saved to your project directory.""",
                data={
                    "url": url,
                    "path": str(filepath.absolute()),
                    "prompt": prompt,
                    "model": kwargs.get('model', self.config.model),
                    "size": f"{kwargs.get('width', self.config.width)}x{kwargs.get('height', self.config.height)}"
                }
            )
            
        except Exception as e:
            logger.error(f"Image generation failed: {e}")
            return ToolResult.from_error(f"Failed to generate image: {str(e)}")
    
    async def safe_execute(self, **kwargs) -> ToolResult:
        """
        Safe execution with validation.
        
        Args:
            **kwargs: Tool arguments
            
        Returns:
            ToolResult with error handling
        """
        # Validate required parameter
        prompt = kwargs.get("prompt")
        if not prompt:
            return ToolResult.from_error("Missing required parameter: prompt")
        
        # Validate dimensions
        width = kwargs.get("width", self.config.width)
        height = kwargs.get("height", self.config.height)
        
        if not (256 <= width <= 2048):
            return ToolResult.from_error("Width must be between 256 and 2048")
        if not (256 <= height <= 2048):
            return ToolResult.from_error("Height must be between 256 and 2048")
        
        # Execute
        return await self.execute(prompt=prompt, **kwargs)


# Register the tool
def register_image_tool():
    """Register the image generation tool with the registry."""
    tool = ImageGenTool()
    ToolRegistry.register(tool)
    logger.info("Registered image_generator tool")
    return tool


# Auto-register on import
try:
    register_image_tool()
except Exception as e:
    logger.warning(f"Failed to auto-register image tool: {e}")
