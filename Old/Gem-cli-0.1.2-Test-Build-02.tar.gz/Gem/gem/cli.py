"""
Gem AI Agent - CLI & Web Interface

Provides both command-line and web-based interfaces for interacting with Gem.
Features streaming output, slash commands, session management,
and optional ChatGPT-like web UI.
"""

import asyncio
import logging
import os
import sys
import re
from pathlib import Path
from typing import Optional

try:
    from rich.console import Console
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.prompt import Prompt
    from rich.syntax import Syntax
    from rich.text import Text
    from rich.live import Live
    from rich.spinner import Spinner
except ImportError:
    Console = None  # type: ignore

from gem.agent.loop import AgentLoop
from gem.memory.history import ChatHistory
from gem.memory.memory import PersistentMemory
from gem.providers.opencode import OpenCodeProvider, load_toml_config

# Configure logging to HIDE sensitive URLs
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)

# CRITICAL: Suppress httpx URL logging
httpx_logger = logging.getLogger("httpx")
httpx_logger.setLevel(logging.WARNING)

logger = logging.getLogger(__name__)


# ANSI colors for fallback (without Rich)
class Colors:
    """ANSI color codes."""
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"


# Language detection helper
def detect_language(text: str) -> str:
    """
    Detect the language of user input.
    
    Returns:
        'pt' for Portuguese, 'en' for English, 'es' for Spanish, etc.
    """
    text_lower = text.lower()
    
    # Portuguese indicators
    pt_indicators = [
        'olá', 'oi', 'eai', 'e ai', 'eae', 'tudo bem', 'como vai',
        'obrigado', 'valeu', 'por favor', 'porfavor', 'pfvr',
        'não', 'sim', 'é', 'você', 'voce', 'eu quero', 'quero',
        'preciso', 'pode', 'pode me', 'me ajuda', 'ajuda',
        'crie', 'fazer', 'faça', 'fiz', 'feito', 'código',
        'programa', 'funciona', 'funcionar', 'erro', 'bug',
        'português', 'portugues', 'brasil', 'brasileiro',
        'cara', 'man', 'galera', 'moçada', 'gente',
    ]
    
    # Spanish indicators
    es_indicators = [
        'hola', 'gracias', 'por favor', 'si', 'no', 'qué', 'que',
        'puedo', 'necesito', 'ayuda', 'crear', 'hacer',
        'español', 'mexico', 'argentina', 'amigos',
    ]
    
    # Count matches
    pt_count = sum(1 for word in pt_indicators if word in text_lower)
    es_count = sum(1 for word in es_indicators if word in text_lower)
    
    if pt_count > es_count:
        return 'pt'
    elif es_count > 0:
        return 'es'
    else:
        return 'en'


def get_language_system_prompt(user_message: str = "") -> str:
    """
    Generate a system prompt that enforces language based on user's input.
    
    This is MORE aggressive than just instructions - it sets the persona.
    """
    lang = detect_language(user_message) if user_message else 'en'
    
    prompts = {
        'pt': """Você é o Gem, um agente de IA autônomo de codificação. Você pode executar comandos shell, ler/escrever arquivos e pesquisar na web para ajudar usuários.

**REGRA OBRIGATÓRIA DE IDIOMA:**
- Você DEVE responder SEMPRE em PORTUGUÊS DO BRASIL
- NUNCA responda em inglês se o usuário falou em português
- Use gírias brasileiras naturais quando apropriado ("cara", "legal", "bacana", etc.)
- Seja natural, como um brasileiro conversando

**SUAS CAPACIDADES:**
- Executar comandos no terminal
- Criar, editar e ler arquivos
- Pesquisar na web
- Gerar imagens (quando pedido)
- Explicar código
- Debuggar problemas

**COMPORTAMENTO:**
- Seja direto e objetivo
- Quando o usuário pedir para ALGO FAZER, FAÇA! Não só explique
- Mostre o código completo
- Execute os comandos necessários
- Confirme quando terminar""",
        
        'en': """You are Gem, an autonomous AI coding agent. You can execute shell commands, read/write files, and search the web to help users.

**MANDATORY LANGUAGE RULE:**
- You MUST respond in ENGLISH if the user speaks English
- Be natural and conversational

**YOUR CAPABILITIES:**
- Execute terminal commands
- Create, edit, and read files
- Search the web
- Generate images (when requested)
- Explain code
- Debug problems

**BEHAVIOR:**
- Be direct and concise
- When asked to DO something, DO IT! Don't just explain
- Show complete code
- Execute necessary commands
- Confirm when done""",
        
        'es': """Eres Gem, un agente autónomo de IA de codificación. Puedes ejecutar comandos shell, leer/escribir archivos y buscar en la web.

**REGLA OBLIGATORIA DE IDIOMA:**
- Debes responder SIEMPRE en ESPAÑOL
- Sé natural y conversacional

**TUS CAPACIDADES:**
- Ejecutar comandos en terminal
- Crear, editar y leer archivos
- Buscar en la web
- Generar imágenes (cuando se solicite)
- Explicar código
- Depurar problemas

**COMPORTAMIENTO:**
- Sé directo y conciso
- Cuando te pidan hacer algo, ¡HAZLO! No solo expliques
- Muestra código completo
- Ejecuta los comandos necesarios
- Confirma cuando termines"""
    }
    
    return prompts.get(lang, prompts['en'])


class GemCLI:
    """
    Command-line interface for Gem AI Agent.
    
    Provides interactive chat interface with:
    - Streaming response display
    - Slash commands (/help, /clear, /model, etc.)
    - Session management
    - Rich formatting (with Rich library)
    - Graceful error handling
    - AUTOMATIC LANGUAGE DETECTION (responds in user's language)
    
    Configuration:
        config_path: Path to TOML configuration file
        workspace: Working directory for operations
        no_color: Disable colored output
    """
    
    def __init__(
        self,
        config_path: str = "",
        workspace: str = "",
        no_color: bool = False,
    ):
        self.config_path = config_path
        self.workspace = Path(workspace) if workspace else Path.cwd()
        self.no_color = no_color
        
        # Initialize console (Rich or plain)
        if Console and not no_color:
            self.console = Console()
            self.rich_mode = True
        else:
            self.console = None
            self.rich_mode = False
        
        # Load configuration
        self.config = self._load_configuration()
        
        # Initialize components
        self.provider: Optional[OpenCodeProvider] = None
        self.agent: Optional[AgentLoop] = None
        self.history: Optional[ChatHistory] = None
        self.memory: Optional[PersistentMemory] = None
        
        # State
        self.running = False
        self.current_input = ""
        self.user_language = 'pt'  # Default to Portuguese
    
    def _load_configuration(self) -> dict:
        """Load TOML configuration."""
        config = {}
        
        paths_to_try = [
            self.config_path,
            "config/config.toml",
            str(Path.home() / ".gem" / "config.toml"),
        ]
        
        for path in paths_to_try:
            if path and os.path.exists(path):
                try:
                    config = load_toml_config(path)
                    break
                except Exception as e:
                    self.print_error(f"Failed to load config from {path}: {e}")
        
        return config
    
    def _init_components(self):
        """Initialize provider, agent, and memory components."""
        model_config = self.config.get("model", {})
        agent_config = self.config.get("agent", {})
        
        # Get API key from env or config
        api_key = (
            os.environ.get("GEM_API_KEY") or
            model_config.get("api_key") or
            "sk-MN9kABCiW1cskBQ4EncGFV6DFwyHvshu6CrjtmuHUFwdkvJvAHNzql90BqTpNHMC"
        )
        
        # Initialize provider with DISPLAY URL (will be converted internally)
        self.provider = OpenCodeProvider(
            api_url=model_config.get("api_url", "https://ingem.ai/agent/v1"),
            api_key=api_key,
            model=model_config.get("default_model", "longcat-2.0-free"),
            temperature=model_config.get("temperature", 0.7),
            max_tokens=model_config.get("max_tokens", 4096),
            timeout=model_config.get("timeout", 120),
        )
        
        # System prompt - will be updated per message based on language detection
        self.base_system_prompt = get_language_system_prompt('pt')  # Default to Portuguese
        
        # Initialize agent loop
        self.agent = AgentLoop(
            provider=self.provider,
            max_iterations=agent_config.get("max_iterations", 50),
            auto_plan=agent_config.get("auto_plan", True),
            streaming=self.config.get("ui", {}).get("streaming", True),
            system_prompt=self.base_system_prompt,
            on_tool_call=self._on_tool_call,
            on_response_chunk=self._on_response_chunk,
            on_iteration_complete=self._on_iteration_complete,
        )
        
        # Initialize history
        history_config = self.config.get("memory", {}).get("history", {})
        self.history = ChatHistory(
            storage_path=history_config.get("storage_path", ""),
            max_messages_per_session=history_config.get("max_messages", 100),
        )
        
        # Create initial session
        self.history.create_session()
        
        # Initialize persistent memory
        mem_config = self.config.get("memory", {}).get("persistent", {})
        self.memory = PersistentMemory(
            storage_path=mem_config.get("storage_path", ""),
            auto_save=mem_config.get("auto_save_interval", 5) > 0,
        )
    
    def update_system_prompt_for_message(self, message: str):
        """
        Update the system prompt based on detected language of user message.
        This ensures Gem ALWAYS responds in the correct language.
        """
        detected_lang = detect_language(message)
        self.user_language = detected_lang
        
        new_prompt = get_language_system_prompt(message)
        
        # Update agent's system prompt
        if self.agent:
            self.agent.system_prompt = new_prompt
            logger.info(f"Language detected: {detected_lang}, updated system prompt")
    
    def _on_tool_call(self, tool_name: str, args: dict):
        """Callback when a tool is called."""
        self.print_tool_indicator(tool_name, args)
    
    def _on_response_chunk(self, chunk: str):
        """Callback for streamed response chunks."""
        if self.rich_mode:
            self.console.print(chunk, end="")
        else:
            print(chunk, end="", flush=True)
    
    def _on_iteration_complete(self, iteration: int, result: dict):
        """Callback after each iteration completes."""
        pass
    
    # Output methods
    
    def print_banner(self):
        """Print welcome banner."""
        banner = """
╔══════════════════════════════════════════╗
║                                          ║
║   ███╗   ██╗██╗   ██╗ ██████╗           ║
║   ████╗  ██║██║   ██║██╔═══██╗          ║
║   ██╔██╗ ██║██║   ██║██║   ██║          ║
║   ██║╚██╗██║██║   ██║██║▄▄ ██║          ║
║   ██║ ╚████║╚██████╔╝╚██████╔╝          ║
║   ╚═╝  ╚═══╝ ╚═════╝  ╚══▀▀═╝           ║
║                                          ║
║     InGem AI Agent v2.0                  ║
║     Powered by InGem AI                  ║
║                                          ║
╚══════════════════════════════════════════╝
"""
        if self.rich_mode:
            self.console.print(Panel(banner, style="cyan"))
        else:
            print(f"{Colors.CYAN}{banner}{Colors.RESET}")
        
        self.print_info("Type /help for available commands")
        self.print_info("Model: longcat-2.0-free | Provider: InGem AI")
        print()
    
    def print_message(self, role: str, content: str):
        """Print a chat message."""
        if role == "user":
            prefix = "👤 Você" if self.user_language == 'pt' else ("👤 You" if self.rich_mode else f"{Colors.GREEN}You{Colors.RESET}")
        elif role == "assistant":
            prefix = "🤖 Gem" if self.rich_mode else f"{Colors.BLUE}Gem{Colors.RESET}"
        elif role == "system":
            prefix = "⚙️ Sistema" if self.user_language == 'pt' else ("⚙️ System" if self.rich_mode else f"{Colors.YELLOW}System{Colors.RESET}")
        else:
            prefix = role
        
        if self.rich_mode:
            self.console.print(f"\n{prefix}:")
            self.console.print(Markdown(content))
        else:
            print(f"\n{prefix}:")
            print(content)
    
    def print_response(self, content: str):
        """Print assistant response with formatting."""
        if self.rich_mode:
            self.console.print("\n🤖 Gem:")
            self.console.print(Markdown(content))
        else:
            print(f"\n{Colors.BLUE}Gem:{Colors.RESET}")
            print(content)
    
    def print_tool_indicator(self, tool_name: str, args: dict):
        """Show tool execution indicator."""
        args_str = str(args)[:80] + ("..." if len(str(args)) > 80 else "")
        
        if self.rich_mode:
            self.console.print(f"  🔧 {tool_name}({args_str})", style="dim")
        else:
            print(f"  {Colors.YELLOW}🔧 {tool_name}({args_str}){Colors.RESET}")
    
    def print_info(self, message: str):
        """Print informational message."""
        if self.rich_mode:
            self.console.print(message, style="dim")
        else:
            print(f"{Colors.DIM}{message}{Colors.RESET}")
    
    def print_success(self, message: str):
        """Print success message."""
        if self.rich_mode:
            self.console.print(message, style="green")
        else:
            print(f"{Colors.GREEN}{message}{Colors.RESET}")
    
    def print_error(self, message: str):
        """Print error message."""
        if self.rich_mode:
            self.console.print(message, style="red")
        else:
            print(f"{Colors.RED}{message}{Colors.RESET}")
    
    def print_warning(self, message: str):
        """Print warning message."""
        if self.rich_mode:
            self.console.print(message, style="yellow")
        else:
            print(f"{Colors.YELLOW}{message}{Colors.RESET}")
    
    # Command handling
    
    async def handle_command(self, command: str, args: str) -> bool:
        """Handle a slash command."""
        handlers = {
            "help": self.cmd_help,
            "clear": self.cmd_clear,
            "reset": self.cmd_reset,
            "model": self.cmd_model,
            "status": self.cmd_status,
            "history": self.cmd_history,
            "memory": self.cmd_memory,
            "export": self.cmd_export,
            "config": self.cmd_config,
            "web": self.cmd_start_web,
            "quit": cmd_quit,
            "exit": cmd_quit,
            "q": cmd_quit,
        }
        
        handler = handlers.get(command.lower())
        
        if handler:
            return await handler(args)
        else:
            if self.user_language == 'pt':
                self.print_error(f"Comando desconhecido: /{command}. Digite /help para ver os comandos.")
            else:
                self.print_error(f"Unknown command: /{command}. Type /help for available commands.")
            return True
    
    async def cmd_help(self, args: str) -> bool:
        """Show help information."""
        if self.user_language == 'pt':
            help_text = """
**Comandos Disponíveis:**

| Comando | Descrição |
|---------|-----------|
| `/help` | Mostra esta ajuda |
| `/clear` | Limpa o contexto da conversa |
| `/reset` | Reinicia completa (nova sessão) |
| `/model [nome]` | Ver/mudar modelo atual |
| `/status` | Mostrar status do agente |
| `/history` | Listar sessões de chat |
| `/memory` | Gerenciar memória persistente |
| `/export [caminho]` | Exportar sessão atual |
| `/config` | Mostrar configuração atual |
| `/web` | Iniciar interface web (ChatGPT-style) |
| `/quit` | Sair do Gem |

**Dicas:**
- Digite sua mensagem e pressione Enter para enviar
- O Gem detecta automaticamente seu idioma!
- Pressione Ctrl+C para cancelar operação
"""
        else:
            help_text = """
**Available Commands:**

| Command | Description |
|---------|-------------|
| `/help` | Show this help message |
| `/clear` | Clear conversation context |
| `/reset` | Full reset (new session) |
| `/model [name]` | View/set current model |
| `/status` | Show agent status |
| `/history` | List chat sessions |
| `/memory` | Manage persistent memory |
| `/export [path]` | Export current session |
| `/config` | Show current configuration |
| `/web` | Start web interface (ChatGPT-style) |
| `/quit` | Exit Gem |

**Tips:**
- Type your message and press Enter to send
- Gem auto-detects your language!
- Press Ctrl+C to cancel current operation
"""
        
        if self.rich_mode:
            self.console.print(Markdown(help_text))
        else:
            print(help_text)
        
        return True
    
    async def cmd_clear(self, args: str) -> bool:
        """Clear conversation context."""
        if self.agent:
            self.agent.reset()
        msg = "Contexto limpo. Começando do zero." if self.user_language == 'pt' else "Context cleared. Starting fresh."
        self.print_success(msg)
        return True
    
    async def cmd_reset(self, args: str) -> bool:
        """Full reset including new session."""
        if self.agent:
            self.agent.reset()
        if self.history:
            self.history.create_session()
        msg = "Reset completo! Nova sessão iniciada." if self.user_language == 'pt' else "Full reset complete. New session started."
        self.print_success(msg)
        return True
    
    async def cmd_model(self, args: str) -> bool:
        """View or set current model."""
        if args:
            if self.provider:
                self.provider.model = args
                msg = f"Modelo mudado para: {args}" if self.user_language == 'pt' else f"Model changed to: {args}"
                self.print_success(msg)
        else:
            if self.provider:
                status = self.provider.get_status_info()
                if self.user_language == 'pt':
                    self.print_info(f"Fornecedor: {status['provider']}")
                    self.print_info(f"API: {status['api_url']}")
                    self.print_info(f"Modelo: {status['model']}")
                    self.print_info(f"Status: {status['status']}")
                else:
                    self.print_info(f"Provider: {status['provider']}")
                    self.print_info(f"API: {status['api_url']}")
                    self.print_info(f"Model: {status['model']}")
                    self.print_info(f"Status: {status['status']}")
            else:
                self.print_info("Provider not initialized")
        
        return True
    
    async def cmd_status(self, args: str) -> bool:
        """Show agent status."""
        if not self.agent:
            self.print_warning("Agent not initialized yet")
            return True
        
        status = self.agent.get_status()
        
        if self.user_language == 'pt':
            status_lines = [
                "**Status do Agente:**",
                f"- Rodando: {'Sim' if status['running'] else 'Não'}",
                f"- Iterações: {status['context'].get('iteration', 0)}",
                f"- Uso de Contexto: {status['context'].get('usage_ratio', 0):.1%}",
                f"- Mensagens no Contexto: {status['context'].get('total_messages', 0)}",
                f"- Tem Plano: {'Sim' if status['has_plan'] else 'Não'}",
            ]
        else:
            status_lines = [
                "**Agent Status:**",
                f"- Running: {'Yes' if status['running'] else 'No'}",
                f"- Iterations: {status['context'].get('iteration', 0)}",
                f"- Context Usage: {status['context'].get('usage_ratio', 0):.1%}",
                f"- Messages in Context: {status['context'].get('total_messages', 0)}",
                f"- Has Plan: {'Yes' if status['has_plan'] else 'No'}",
            ]
        
        if status.get("plan"):
            plan = status["plan"]
            progress_msg = f"- Progresso do Plano: {plan['completed_steps']}/{plan['total_steps']} passos" if self.user_language == 'pt' else f"- Plan Progress: {plan['completed_steps']}/{plan['total_steps']} steps"
            status_lines.append(progress_msg)
        
        if self.rich_mode:
            self.console.print(Markdown("\n".join(status_lines)))
        else:
            print("\n".join(status_lines))
        
        return True
    
    async def cmd_history(self, args: str) -> bool:
        """List chat sessions."""
        if not self.history:
            self.print_warning("History not available")
            return True
        
        sessions = self.history.list_sessions(limit=10)
        
        if not sessions:
            msg = "Nenhuma sessão anterior encontrada." if self.user_language == 'pt' else "No previous sessions found."
            self.print_info(msg)
            return True
        
        header = "**Sessões Recentes:**\n" if self.user_language == 'pt' else "**Recent Sessions:**\n"
        lines = [header]
        for i, s in enumerate(sessions, 1):
            lines.append(f"{i}. **{s['title']}** ({s['message_count']} mensagens)")
            lines.append(f"   Criado: {s['created_at'][:16]}")
        
        if self.rich_mode:
            self.console.print(Markdown("\n".join(lines)))
        else:
            print("\n".join(lines))
        
        return True
    
    async def cmd_memory(self, args: str) -> bool:
        """Manage persistent memory."""
        if not self.memory:
            self.print_warning("Memory not available")
            return True
        
        stats = self.memory.get_stats()
        
        if self.user_language == 'pt':
            lines = [
                "**Memória Persistente:**",
                f"- Total de Fatos: {stats['total_facts']}",
                f"- Preferências: {stats['total_preferences']}",
                f"- Categorias: {list(stats['categories'].keys())}",
            ]
        else:
            lines = [
                "**Persistent Memory:**",
                f"- Total Facts: {stats['total_facts']}",
                f"- Preferences: {stats['total_preferences']}",
                f"- Categories: {list(stats['categories'].keys())}",
            ]
        
        if self.rich_mode:
            self.console.print(Markdown("\n".join(lines)))
        else:
            print("\n".join(lines))
        
        return True
    
    async def cmd_export(self, args: str) -> bool:
        """Export current session."""
        if not self.history or not self.history.get_current_session():
            msg = "Nenhuma sessão ativa para exportar." if self.user_language == 'pt' else "No active session to export."
            self.print_warning(msg)
            return True
        
        session_id = self.history._current_session_id
        output_path = args if args else f"chat_export_{session_id}.md"
        
        try:
            path = self.history.export_session(session_id, "markdown", output_path)
            msg = f"Exportado para: {path}" if self.user_language == 'pt' else f"Exported to: {path}"
            self.print_success(msg)
        except Exception as e:
            err_msg = f"Erro na exportação: {e}" if self.user_language == 'pt' else f"Export failed: {e}"
            self.print_error(err_msg)
        
        return True
    
    async def cmd_config(self, args: str) -> bool:
        """Show current configuration (with masked URLs)."""
        if self.user_language == 'pt':
            lines = [
                "**Configuração Atual:**\n",
                "**Fornecedor InGem AI:**",
                "- API Endpoint: https://ingem.ai/agent/v1/chat/completions",
            ]
            if self.provider:
                lines.append(f"- Modelo: {self.provider.model}")
            else:
                lines.append("- Modelo: longcat-2.0-free")
            lines.append("- Temperatura: 0.7")
            lines.append("\n**Agente:**")
            lines.append("- Máximo de Iterações: 50")
            lines.append("- Planejamento Automático: Sim")
            lines.append("\n**Nota:** Detalhes gerenciados automaticamente.")
        else:
            lines = [
                "**Current Configuration:**\n",
                "**InGem AI Provider:**",
                "- API Endpoint: https://ingem.ai/agent/v1/chat/completions",
            ]
            if self.provider:
                lines.append(f"- Model: {self.provider.model}")
            else:
                lines.append("- Model: longcat-2.0-free")
            lines.append("- Temperature: 0.7")
            lines.append("\n**Agent:**")
            lines.append("- Max Iterations: 50")
            lines.append("- Auto Plan: Yes")
            lines.append("\n**Note:** Configuration managed automatically.")
        
        if self.rich_mode:
            self.console.print(Markdown("\n".join(lines)))
        else:
            print("\n".join(lines))
        
        return True
    
    async def cmd_start_web(self, args: str) -> bool:
        """Start web interface (ChatGPT-style)."""
        msg = "Iniciando interface web..." if self.user_language == 'pt' else "Starting web interface..."
        self.print_info(msg)
        
        try:
            # Import web server
            from gem.web.server import start_web_server
            
            # Start web server in background
            port = int(args) if args.isdigit() else 7860
            msg = f"Interface web disponível em http://localhost:{port}" if self.user_language == 'pt' else f"Web interface available at http://localhost:{port}"
            self.print_success(msg)
            
            # Run web server
            await start_web_server(port=port, gem_cli=self)
            
        except ImportError:
            err = "Módulo web não instalado. Instale com: pip install flask" if self.user_language == 'pt' else "Web module not installed. Install with: pip install flask"
            self.print_error(err)
        except Exception as e:
            err_msg = f"Erro ao iniciar web: {e}" if self.user_language == 'pt' else f"Error starting web: {e}"
            self.print_error(err_msg)
        
        return True
    
    # Main loop
    
    async def run_interactive(self):
        """Run interactive CLI loop."""
        # Initialize components
        self._init_components()
        
        # Print banner
        self.print_banner()
        
        self.running = True
        
        while self.running:
            try:
                # Get user input
                user_input = await self._get_input()
                
                if not user_input:
                    continue
                
                # Check for commands
                if user_input.startswith("/"):
                    parts = user_input[1:].split(None, 1)
                    command = parts[0]
                    args = parts[1] if len(parts) > 1 else ""
                    
                    self.running = await self.handle_command(command, args)
                    continue
                
                # Process as regular message
                await self._process_user_message(user_input)
                
            except KeyboardInterrupt:
                print()
                if self.agent and self.agent.is_running:
                    self.agent.cancel()
                    msg = "Operação cancelada. Pressione Ctrl+C novamente para sair." if self.user_language == 'pt' else "Operation cancelled. Press Ctrl+C again to quit."
                    self.print_warning(msg)
                else:
                    msg = "Use /quit para sair" if self.user_language == 'pt' else "Use /quit to exit"
                    self.print_info(msg)
                    
            except EOFError:
                break
            
            except Exception as e:
                logger.exception("Error in main loop")
                err = f"Ocorreu um erro: {e}" if self.user_language == 'pt' else f"An error occurred: {e}"
                self.print_error(err)
        
        # Cleanup
        await self._cleanup_async()
        msg = "Tchau! 👋" if self.user_language == 'pt' else "Goodbye! 👋"
        self.print_info(msg)
    
    async def _get_input(self) -> str:
        """Get user input from prompt."""
        if self.rich_mode:
            prompt_text = "[bold green]Você[/]" if self.user_language == 'pt' else "[bold green]You[/]"
            return Prompt.ask(prompt_text)
        else:
            prompt = f"\n{Colors.GREEN}> {Colors.RESET}"
            return input(prompt)
    
    async def _process_user_message(self, message: str):
        """Process a user message through the agent."""
        if not self.agent:
            msg = "Agente não inicializado. Não é possível processar mensagem." if self.user_language == 'pt' else "Agent not initialized. Cannot process message."
            self.print_error(msg)
            return
        
        # CRITICAL: Detect language and update system prompt BEFORE processing
        self.update_system_prompt_for_message(message)
        
        # Print user message
        self.print_message("user", message)
        
        # Add to history
        if self.history:
            self.history.add_message("user", message)
        
        # Process through agent
        try:
            result = await self.agent.process_message(message)
            
            # Display response
            if result.get("response"):
                self.print_response(result["response"])
                
                # Add to history
                if self.history:
                    self.history.add_message("assistant", result["response"])
            
            # Show summary of tool usage
            tool_calls = result.get("tool_calls", [])
            if tool_calls:
                msg = f"\n✅ {len(tool_calls)} operação(ões) de ferramenta concluída(s)" if self.user_language == 'pt' else f"\n✅ Completed {len(tool_calls)} tool operation(s)"
                self.print_info(msg)
                
        except Exception as e:
            logger.exception("Error processing message")
            err = f"Erro: {type(e).__name__}: {e}" if self.user_language == 'pt' else f"Error: {type(e).__name__}: {e}"
            self.print_error(err)
    
    async def _cleanup_async(self):
        """Async cleanup resources."""
        if self.provider:
            try:
                await self.provider.close()
            except Exception as e:
                logger.debug(f"Error closing provider: {e}")
        
        if hasattr(self, 'web_tool'):
            try:
                await self.web_tool.close()
            except Exception as e:
                logger.debug(f"Error closing web_tool: {e}")
    
    def _cleanup(self):
        """Cleanup resources (sync wrapper)."""
        try:
            loop = asyncio.get_running_loop()
            if loop.is_running():
                loop.create_task(self._cleanup_async())
                return
        except RuntimeError:
            pass
        
        try:
            asyncio.get_event_loop().run_until_complete(self._cleanup_async())
        except RuntimeError:
            asyncio.run(self._cleanup_async())
    
    async def run_single(self, message: str):
        """Run a single message and exit (non-interactive mode)."""
        self._init_components()
        
        # Detect language for single message mode
        self.update_system_prompt_for_message(message)
        
        result = await self.agent.process_message(message)
        print(result.get("response", ""))
        
        await self._cleanup_async()


async def cmd_quit(args: str) -> bool:
    """Quit handler (module-level for simplicity)."""
    return False


def main():
    """Main entry point for CLI."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="Gem - InGem AI Coding Agent",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    parser.add_argument(
        "-c", "--config",
        help="Path to configuration file",
        default="",
    )
    
    parser.add_argument(
        "-w", "--workspace",
        help="Working directory",
        default="",
    )
    
    parser.add_argument(
        "--no-color",
        help="Disable colored output",
        action="store_true",
    )
    
    parser.add_argument(
        "-m", "--message",
        help="Single message mode (non-interactive)",
        default=None,
    )
    
    parser.add_argument(
        "--web",
        help="Start in web mode (ChatGPT-style UI)",
        action="store_true",
    )
    
    parser.add_argument(
        "-p", "--port",
        help="Port for web mode (default: 7860)",
        default="7860",
    )
    
    parser.add_argument(
        "-v", "--verbose",
        help="Enable verbose logging",
        action="store_true",
    )
    
    args = parser.parse_args()
    
    # Configure logging - CRITICAL: suppress httpx URL logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    
    # CRITICAL: Make sure httpx doesn't log URLs
    httpx_logger = logging.getLogger("httpx")
    httpx_logger.setLevel(logging.WARNING)
    
    # Also suppress urllib3 if present
    try:
        urllib3_logger = logging.getLogger("urllib3")
        urllib3_logger.setLevel(logging.WARNING)
    except:
        pass
    
    # Create and run CLI
    cli = GemCLI(
        config_path=args.config,
        workspace=args.workspace,
        no_color=args.no_color,
    )
    
    if args.web:
        # Web mode
        import asyncio
        from gem.web.server import start_web_server
        
        cli._init_components()
        port = int(args.port)
        print(f"🌐 Starting InGem AI Web Interface on http://localhost:{port}")
        asyncio.run(start_web_server(port=port, gem_cli=cli))
        
    elif args.message:
        # Single message mode
        asyncio.run(cli.run_single(args.message))
    else:
        # Interactive mode
        asyncio.run(cli.run_interactive())


if __name__ == "__main__":
    main()
