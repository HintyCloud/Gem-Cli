# Gem — Development

Source + tests + tooling for developers who want to modify Gem.

## Install
```bash
tar xzf Gem-Development.tar.gz
cd Gem-Development
pip install -e .
```

## Tests
```bash
python3 -m pytest tests/ -q      # 59 tests (mocks for external services)
```

## Web UI dev
```bash
cd src && bun install && bun run dev
bun run lint
```

## Layout
- `gem/` — shared core (agent, swarm, tools, memory, providers, api, jobs, sandbox, platform)
- `src/` — Next.js Web UI
- `tests/` — pytest suite
- `scripts/build_all.py` — regenerate all distributions
- `packaging/` — per-distro scripts
