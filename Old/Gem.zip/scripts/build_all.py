#!/usr/bin/env python3
"""Build all Gem distributions.

Generates in dist/:
  Gem-Linux.tar.gz
  Gem-Windows.tar.gz
  Gem-Termux.tar.gz
  Gem-Latest.tar.gz
  Gem-Cli.tar.gz
  Gem-Development.tar.gz
  Gem.zip

All distributions share the same gem/ core. They differ only in config,
scripts and docs. Excludes: .git, __pycache__, caches, venvs, secrets, temp
files. A secret scan runs before packaging and aborts if anything is found.

Usage: python3 scripts/build_all.py
"""
from __future__ import annotations

import os
import re
import shutil
import sys
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
STAGE = ROOT / "dist" / "_stage"

# ---------------- file selection ----------------

CORE_DIRS = ["gem"]
ROOT_FILES = ["pyproject.toml", "README.md"]
CONFIG_FILES = ["config/config.toml"]  # secrets.toml NEVER included
WEB_DIRS = ["src", "public", "tests"]
DEV_EXTRAS = ["tests", "scripts", "packaging", "examples", "Caddyfile",
              "package.json", "bun.lock", "tsconfig.json", "tailwind.config.ts",
              "postcss.config.mjs", "next.config.ts", "eslint.config.mjs",
              "components.json", "next-env.d.ts"]

EXCLUDE_NAMES = {".git", "__pycache__", ".pytest_cache", ".mypy_cache", ".cache",
                 ".venv", "venv", "env", "node_modules", ".next", "build",
                 ".eggs", "dist", "_stage", ".DS_Store", "Thumbs.db"}
EXCLUDE_PATTERNS = [re.compile(r"\.py[cod]$"), re.compile(r"\.egg-info$"),
                    re.compile(r"\.log$")]
SECRET_PATTERNS = [
    re.compile(r"sk-[A-Za-z0-9]{20,}"),
    re.compile(r"gh[pousr]_[A-Za-z0-9]{30,}"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
]


def should_skip(name: str) -> bool:
    if name in EXCLUDE_NAMES:
        return True
    for p in EXCLUDE_PATTERNS:
        if p.search(name):
            return True
    return False


def copy_tree(src: Path, dst: Path) -> None:
    """Copy a directory tree, applying exclusion rules."""
    if not src.exists():
        return
    if src.is_file():
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        return
    dst.mkdir(parents=True, exist_ok=True)
    for name in os.listdir(src):
        if should_skip(name):
            continue
        copy_tree(src / name, dst / name)


def copy_file(src: Path, dst: Path) -> None:
    if not src.exists() or should_skip(src.name):
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def secret_scan(staging: Path) -> list[str]:
    """Scan staged files for likely secrets. Returns list of hits."""
    hits = []
    for p in staging.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix in {".png", ".jpg", ".jpeg", ".webp", ".gif", ".zip", ".gz"}:
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for pat in SECRET_PATTERNS:
            for m in pat.finditer(text):
                # ignore obvious placeholders/examples
                snippet = text[max(0, m.start()-10):m.end()+10]
                if "example" in snippet.lower() or "your_" in snippet.lower() or "xxx" in m.group(0):
                    continue
                hits.append(f"{p.relative_to(staging)}: {m.group(0)[:12]}...")
    return hits


# ---------------- per-distro builders ----------------

def stage_common(staging: Path, *, web: bool = False, dev: bool = False) -> None:
    """Copy the shared core into a staging dir."""
    for d in CORE_DIRS:
        copy_tree(ROOT / d, staging / d)
    for f in ROOT_FILES:
        copy_file(ROOT / f, staging / f)
    for f in CONFIG_FILES:
        copy_file(ROOT / f, staging / f)
    if web:
        for d in WEB_DIRS:
            copy_tree(ROOT / d, staging / d)
        for f in ["package.json", "tsconfig.json", "tailwind.config.ts",
                  "postcss.config.mjs", "next.config.ts", "components.json",
                  "next-env.d.ts"]:
            copy_file(ROOT / f, staging / f)
        copy_tree(ROOT / "public", staging / "public")
    if dev:
        for d in DEV_EXTRAS:
            if (ROOT / d).exists():
                copy_tree(ROOT / d, staging / d)


def write_run_script(staging: Path, cmd: str) -> None:
    (staging / "run.sh").write_text(
        "#!/usr/bin/env bash\nset -e\ncd \"$(dirname \"$0\")\"\n"
        f"python3 -m pip install -e . --quiet 2>/dev/null || true\n{cmd}\n",
        encoding="utf-8")
    os.chmod(staging / "run.sh", 0o755)


def write_install(staging: Path, content: str) -> None:
    (staging / "INSTALL.md").write_text(content, encoding="utf-8")


def build_linux(staging: Path) -> None:
    stage_common(staging, web=True)
    write_run_script(staging, "python3 -m gem.cli serve --host 127.0.0.1 --port 8000")
    write_install(staging, INSTALL_LINUX)
    (staging / "packaging").mkdir(exist_ok=True)
    copy_tree(ROOT / "packaging", staging / "packaging") if (ROOT / "packaging").exists() else None


def build_windows(staging: Path) -> None:
    stage_common(staging, web=True)
    (staging / "run.bat").write_text(
        "@echo off\r\ncd /d %~dp0\r\npython -m pip install -e . --quiet\r\n"
        "python -m gem.cli serve --host 127.0.0.1 --port 8000\r\n", encoding="utf-8")
    write_install(staging, INSTALL_WINDOWS)


def build_termux(staging: Path) -> None:
    stage_common(staging, web=True)
    write_run_script(staging, "python3 -m gem.cli serve --host 127.0.0.1 --port 8000")
    write_install(staging, INSTALL_TERMUX)
    (staging / "termux-setup.sh").write_text(TERMUX_SETUP, encoding="utf-8")
    os.chmod(staging / "termux-setup.sh", 0o755)


def build_latest(staging: Path) -> None:
    stage_common(staging, web=True)
    write_run_script(staging, "python3 -m gem.cli serve --host 127.0.0.1 --port 8000")
    write_install(staging, INSTALL_LATEST)


def build_cli(staging: Path) -> None:
    # Terminal-first: core + CLI + config, no Web UI.
    for d in CORE_DIRS:
        copy_tree(ROOT / d, staging / d)
    for f in ROOT_FILES:
        copy_file(ROOT / f, staging / f)
    for f in CONFIG_FILES:
        copy_file(ROOT / f, staging / f)
    write_run_script(staging, "python3 -m gem.cli chat")
    write_install(staging, INSTALL_CLI)


def build_dev(staging: Path) -> None:
    stage_common(staging, web=True, dev=True)
    write_install(staging, INSTALL_DEV)


BUILDERS = {
    "Gem-Linux": build_linux,
    "Gem-Windows": build_windows,
    "Gem-Termux": build_termux,
    "Gem-Latest": build_latest,
    "Gem-Cli": build_cli,
    "Gem-Development": build_dev,
}


def make_tarball(staging: Path, out: Path) -> None:
    with tarfile.open(out, "w:gz") as tf:
        for item in sorted(staging.iterdir()):
            tf.add(item, arcname=item.name)


def make_zip(staging: Path, out: Path) -> None:
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in staging.rglob("*"):
            if p.is_file():
                zf.write(p, arcname=str(p.relative_to(staging)))


def main() -> int:
    DIST.mkdir(parents=True, exist_ok=True)
    if STAGE.exists():
        shutil.rmtree(STAGE)
    STAGE.mkdir(parents=True)

    print("Building Gem distributions...")
    built = []
    for name, builder in BUILDERS.items():
        staging = STAGE / name
        staging.mkdir(parents=True)
        print(f"  - staging {name}...")
        builder(staging)
        # Secret scan
        hits = secret_scan(staging)
        if hits:
            print(f"  ! SECRET SCAN FAILED for {name}:")
            for h in hits[:10]:
                print(f"      {h}")
            return 1
        out = DIST / f"{name}.tar.gz"
        make_tarball(staging, out)
        size = out.stat().st_size
        print(f"    -> {out.name} ({size//1024} KB)")
        built.append(out)

    # Gem.zip = full project (core + web + tests + scripts + packaging), no secrets.
    print("  - staging Gem.zip (full project)...")
    zip_staging = STAGE / "Gem"
    zip_staging.mkdir(parents=True)
    stage_common(zip_staging, web=True, dev=True)
    hits = secret_scan(zip_staging)
    if hits:
        print(f"  ! SECRET SCAN FAILED for Gem.zip:")
        for h in hits[:10]:
            print(f"      {h}")
        return 1
    zip_out = DIST / "Gem.zip"
    make_zip(zip_staging, zip_out)
    print(f"    -> {zip_out.name} ({zip_out.stat().st_size//1024} KB)")
    built.append(zip_out)

    shutil.rmtree(STAGE)
    print("\n=== Built ===")
    for b in built:
        print(f"  {b}  ({b.stat().st_size//1024} KB)")
    return 0


# ---------------- install docs ----------------

INSTALL_LINUX = """# Gem — Linux

## Requirements
- Python 3.10+
- (optional) Node.js 18+ / bun for the Web UI

## Install
```bash
tar xzf Gem-Linux.tar.gz
cd Gem-Linux
pip install -e .
```

## Run the API + Web UI
```bash
./run.sh                     # starts Gem API on 127.0.0.1:8000
# In another terminal, for the Web UI:
cd src && bun install && bun run dev   # http://127.0.0.1:3000
```

## Or use the CLI
```bash
gem status
gem chat
```

## Configure
Put your OpenCode key in `config/secrets.toml`:
```toml
[opencode]
api_key = "sk-..."
```
"""

INSTALL_WINDOWS = """# Gem — Windows

Gem does NOT assume Bash. It uses cmd/PowerShell via the platform adapter.

## Requirements
- Python 3.10+ (python.org)
- (optional) Node.js 18+ for the Web UI

## Install
```powershell
Expand-Archive Gem-Windows.tar.gz .
cd Gem-Windows
pip install -e .
```

## Run
```bat
run.bat
```
Starts the Gem API on 127.0.0.1:8000. For the Web UI, in another terminal:
```powershell
cd src; bun install; bun run dev
```

## CLI
```powershell
gem status
gem chat
```

Configure `config/secrets.toml` with your `[opencode] api_key`.
"""

INSTALL_TERMUX = """# Gem — Termux (Android)

Optimized for Termux on Android (ARM32/armv8l compatible + ARM64).

## Install
```bash
pkg update && pkg install python git
# (optional) termux-setup-storage   # enables ~/storage/downloads
tar xzf Gem-Termux.tar.gz
cd Gem-Termux
pip install -e .
./termux-setup.sh
```

## Run
```bash
./run.sh                 # Gem API on 127.0.0.1:8000
# Open http://127.0.0.1:8000/status in the Android browser, or use:
gem chat
```

## Keeping it alive
Termux cannot guarantee infinite background execution. Use `termux-wake-lock`
when available. Gem RECOVERS interrupted tasks from checkpoints when restarted:
```bash
gem jobs      # shows recovering jobs, auto-resumed
```

If shared storage is available, distribution archives are copied to
`~/storage/downloads/`.

## Notes
- No systemd, sudo or Docker assumed.
- Degrades clearly when a native dependency is unavailable.
"""

INSTALL_LATEST = """# Gem — Latest (primary distribution)

Includes: Gem Core, Gem API, Web UI, CLI, Agent, Swarm, Subagents, Tools,
Image generation, Jobs, Memory, History, OpenCode provider, default config for
`longcat-2.0-free`.

## Architecture
```
Client → Gem API → Gem Core → Provider → OpenCode → configured model
```

## Install & run
```bash
tar xzf Gem-Latest.tar.gz
cd Gem-Latest
pip install -e .
# Configure: edit config/secrets.toml with [opencode] api_key = "sk-..."
./run.sh          # Gem API on 127.0.0.1:8000
```

Web UI (separate terminal):
```bash
cd src && bun install && bun run dev   # http://127.0.0.1:3000
```

CLI:
```bash
gem status
gem chat
```
"""

INSTALL_CLI = """# Gem — CLI (terminal-first)

A terminal-focused distribution: providers, API keys, model selection,
configuration, tools, agents, swarm, subagents, jobs, projects.

## Install
```bash
tar xzf Gem-Cli.tar.gz
cd Gem-Cli
pip install -e .
```

## Configure providers / models
```bash
gem providers          # list
gem models             # current model
# Add key in config/secrets.toml: [opencode] api_key = "sk-..."
```

## Use
```bash
gem chat               # interactive (slash commands: /help /model /chats ...)
gem project list
gem jobs
@swarm <task>          # run a task through the swarm inside chat
```

## Commands
`gem serve | chat | project | jobs | models | providers | tools | agents | status`
"""

INSTALL_DEV = """# Gem — Development

Source + tests + tooling for developers who want to modify Gem.

## Install
```bash
tar xzf Gem-Development.tar.gz
cd Gem-Development
pip install -e .
```

## Tests
```bash
python3 -m pytest tests/ -q      # 59 tests (mocks for external services)
```

## Web UI dev
```bash
cd src && bun install && bun run dev
bun run lint
```

## Layout
- `gem/` — shared core (agent, swarm, tools, memory, providers, api, jobs, sandbox, platform)
- `src/` — Next.js Web UI
- `tests/` — pytest suite
- `scripts/build_all.py` — regenerate all distributions
- `packaging/` — per-distro scripts
"""

TERMUX_SETUP = """#!/data/data/com.termux/files/usr/bin/bash
# Termux setup helper for Gem.
set -e
echo "Setting up Gem for Termux..."
pkg install -y python git 2>/dev/null || true
pip install -e . --quiet || pip install -e .
# Enable wake lock if available (keeps CPU alive while foregrounded).
command -v termux-wake-lock >/dev/null 2>&1 && termmux-wake-lock 2>/dev/null || true
echo "Done. Run: ./run.sh  (or: gem chat)"
"""


if __name__ == "__main__":
    sys.exit(main())
