# Gem — Linux

## Requirements
- Python 3.10+
- (optional) Node.js 18+ / bun for the Web UI

## Install
```bash
tar xzf Gem-Linux.tar.gz
cd Gem-Linux
pip install -e .
```

## Run the API + Web UI
```bash
./run.sh                     # starts Gem API on 127.0.0.1:8000
# In another terminal, for the Web UI:
cd src && bun install && bun run dev   # http://127.0.0.1:3000
```

## Or use the CLI
```bash
gem status
gem chat
```

## Configure
Put your OpenCode key in `config/secrets.toml`:
```toml
[opencode]
api_key = "sk-..."
```
